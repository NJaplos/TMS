/**
 * ==========================================
 * USMCI Navigation Configuration
 * ==========================================
 */

window.USMCI = window.USMCI || {};

USMCI.Navbar = {

    stickyOffset: 80,

    animationSpeed: 350,

    mobileBreakpoint: 991

};