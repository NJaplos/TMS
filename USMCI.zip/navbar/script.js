/**
 * ==========================================
 * Navigation Initializer
 * ==========================================
 */

document.addEventListener("DOMContentLoaded", () => {

    console.log("USMCI Navigation Loaded");

});