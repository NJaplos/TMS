/**
 * Mobile Navigation Toggle
 */

(function () {

    const toggle = document.getElementById("navbarToggle");

    const navigation = document.querySelector(".navbar__navigation");

    if (!toggle || !navigation) return;

    toggle.addEventListener("click", function () {

        navigation.classList.toggle("is-open");

        toggle.classList.toggle("is-active");

    });

})();