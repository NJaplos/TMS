/**
 * Active Navigation Link
 */

(function () {

    const links = document.querySelectorAll(".navbar__link");

    links.forEach(link => {

        link.addEventListener("click", function () {

            links.forEach(item => item.classList.remove("is-active"));

            this.classList.add("is-active");

        });

    });

})();