/**
 * Sticky Navigation
 */

(function () {

    const navbar = document.getElementById("navbar");

    if (!navbar) return;

    window.addEventListener("scroll", function () {

        if (window.scrollY > USMCI.Navbar.stickyOffset) {

            navbar.classList.add("is-sticky");

        } else {

            navbar.classList.remove("is-sticky");

        }

    });

})();