-- ============================================================
-- USMCI-TMS — Migration: Inquiry Status + Applicant Invitation
-- ------------------------------------------------------------
-- Adds the two pieces missing from the current schema to
-- complete the Inquiry → Account → Enrollment handoff:
--
-- 1. mnt_inquiry_status — a proper status lookup for `inquiry`.
--    inquiry.status_id already exists as a column, but nothing
--    populates it yet (no matching lookup table exists). This
--    also matches the NEW / REPLIED / TEMP ACCOUNT badges
--    already drawn in the inquiry-queue frontend mockup.
--
-- 2. applicant_invitation — the missing link between "staff
--    decides this inquiry should proceed" and "applicant can
--    create an account". Stores a HASH of the invitation
--    token, never the raw token (see inquiry_invite.php for
--    why this matters).
--
-- Safe to run once against the existing enrollsys database —
-- does not modify any existing table.
-- ============================================================

USE enrollsys;

-- ------------------------------------------------------------
-- 1. Inquiry status lookup
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS mnt_inquiry_status (
    id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    code        VARCHAR(30) NOT NULL UNIQUE,
    label       VARCHAR(100) NOT NULL,
    sort_order  INT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO mnt_inquiry_status (code, label, sort_order) VALUES
('NEW',       'New',                1),
('REPLIED',   'Replied',            2),
('INVITED',   'Invited to Enroll',  3),
('CONVERTED', 'Account Created',    4),
('CLOSED',    'Closed',             5);

-- Backfill: every existing inquiry that has no status yet
-- (all of them, currently) starts at NEW.
UPDATE inquiry
SET status_id = (SELECT id FROM mnt_inquiry_status WHERE code = 'NEW')
WHERE status_id IS NULL;

-- ------------------------------------------------------------
-- 2. Applicant invitation (the missing Phase 4 link)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS applicant_invitation (
    id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    inquiry_id      BIGINT UNSIGNED NOT NULL,
    applicant_id    BIGINT UNSIGNED NULL,
    token_hash      CHAR(64) NOT NULL UNIQUE,
    email           VARCHAR(150) NOT NULL,
    expires_at      DATETIME NOT NULL,
    used_at         DATETIME NULL,
    created_by      BIGINT UNSIGNED NOT NULL,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (inquiry_id) REFERENCES inquiry(id) ON DELETE CASCADE,
    FOREIGN KEY (applicant_id) REFERENCES applicant(id) ON DELETE SET NULL,
    FOREIGN KEY (created_by) REFERENCES sys_user(id),

    INDEX idx_invitation_lookup (token_hash, used_at, expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
