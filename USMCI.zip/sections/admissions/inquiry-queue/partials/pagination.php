<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Module      : Admissions
 * Partial     : Inquiry Queue Pagination
 * File        : pagination.php
 * Version     : 1.0
 *
 * Description :
 * Pagination footer for the Inquiry Queue.
 *
 * Backend integration will update:
 * - Record count
 * - Current page
 * - Total pages
 * - Page navigation
 * ---------------------------------------------------------
 */
?>

<section class="workspace-pagination">

    <div class="pagination-left">

        <span>

            Showing

            <strong>1 - 10</strong>

            of

            <strong>128</strong>

            inquiries

        </span>

    </div>

    <div class="pagination-center">

        <label for="pageSize">

            Rows per page

        </label>

        <select id="pageSize">

            <option>10</option>

            <option>25</option>

            <option>50</option>

            <option>100</option>

        </select>

    </div>

    <div class="pagination-right">

        <button
            type="button"
            class="btn-page">

            ⏮

        </button>

        <button
            type="button"
            class="btn-page">

            ◀

        </button>

        <span class="page-number">

            Page

            <strong>1</strong>

            of

            <strong>13</strong>

        </span>

        <button
            type="button"
            class="btn-page">

            ▶

        </button>

        <button
            type="button"
            class="btn-page">

            ⏭

        </button>

    </div>

</section>