<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Module      : Admissions
 * Partial     : Inquiry Queue Table
 * File        : table.php
 * Version     : 1.0
 *
 * Description :
 * Main operational table for the Admissions
 * Inquiry Queue.
 *
 * NOTE:
 * Static records are temporary placeholders.
 * Backend integration will populate the table
 * from the database.
 * ---------------------------------------------------------
 */
?>

<section class="workspace-table">

    <!-- ==========================================
         Toolbar Actions
    =========================================== -->

    <div class="table-toolbar">

        <div class="table-toolbar__left">

            <button
                type="button"
                class="btn-primary"
                id="btnReply">

                Reply

            </button>

            <button
                type="button"
                class="btn-secondary"
                id="btnAssign">

                Assign Staff

            </button>

            <button
                type="button"
                class="btn-secondary"
                id="btnConvert">

                Create Applicant

            </button>

        </div>

        <div class="table-toolbar__right">

            <button
                type="button"
                class="btn-secondary"
                id="btnExport">

                Export

            </button>

            <button
                type="button"
                class="btn-secondary"
                id="btnPrint">

                Print

            </button>

            <button
                type="button"
                class="btn-secondary"
                id="btnRefreshTable">

                Refresh

            </button>

        </div>

    </div>

    <!-- ==========================================
         Inquiry Table
    =========================================== -->

    <div class="table-responsive">

        <table class="inquiry-table">

            <thead>

                <tr>

                    <th width="40">
                        <input type="checkbox">
                    </th>

                    <th>Inquiry No.</th>

                    <th>Date</th>

                    <th>Applicant</th>

                    <th>Email</th>

                    <th>Mobile</th>

                    <th>Inquiry Type</th>

                    <th>Course</th>

                    <th>Assigned</th>

                    <th>Status</th>

                    <th width="170">Actions</th>

                </tr>

            </thead>

            <tbody id="inquiryTableBody">

                <!-- Rows are rendered by script.js from actions/list.php.
                     See partials/empty-state.php for the "no results" state. -->

            </tbody>

        </table>

    </div>

    <?php require INQUIRY_QUEUE_PARTIALS . '/empty-state.php'; ?>

</section>