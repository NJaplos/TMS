<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Module      : Admissions
 * Partial     : Inquiry Queue Header
 * File        : header.php
 * Version     : 1.0
 *
 * Description :
 * Workspace header displayed at the top of the
 * Admissions Inquiry Queue.
 * ---------------------------------------------------------
 */
?>

<section class="workspace-header">

    <div class="workspace-header__left">

        <h1>
            Inquiry Queue
        </h1>

        <p>

            Manage incoming admissions inquiries,
            review applicant concerns, respond to
            inquiries and prepare applicants for
            enrollment.

        </p>

    </div>

    <div class="workspace-header__right">

        <button
            type="button"
            class="btn-refresh">

            ⟳ Refresh

        </button>

    </div>

</section>