<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Module      : Admissions
 * Partial     : Inquiry Queue Summary
 * File        : summary.php
 * Version     : 1.0
 *
 * Description :
 * Displays operational summary cards for the
 * Admissions Inquiry Queue.
 *
 * Note:
 * Values are temporary placeholders and will
 * be replaced by live database counts during
 * backend integration.
 * ---------------------------------------------------------
 */
?>

<section class="summary-cards">

    <article class="summary-card">

        <div class="summary-card__icon">
            📨
        </div>

        <div class="summary-card__content">

            <span class="summary-card__value">
                128
            </span>

            <span class="summary-card__label">
                Total Inquiries
            </span>

        </div>

    </article>

    <article class="summary-card">

        <div class="summary-card__icon">
            📅
        </div>

        <div class="summary-card__content">

            <span class="summary-card__value">
                14
            </span>

            <span class="summary-card__label">
                Today's Inquiries
            </span>

        </div>

    </article>

    <article class="summary-card">

        <div class="summary-card__icon">
            ⏳
        </div>

        <div class="summary-card__content">

            <span class="summary-card__value">
                37
            </span>

            <span class="summary-card__label">
                Awaiting Reply
            </span>

        </div>

    </article>

    <article class="summary-card">

        <div class="summary-card__icon">
            ✅
        </div>

        <div class="summary-card__content">

            <span class="summary-card__value">
                91
            </span>

            <span class="summary-card__label">
                Replied
            </span>

        </div>

    </article>

</section>