<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Module      : Admissions
 * Partial     : Toast Notification
 * File        : toast.php
 * Version     : 1.0
 *
 * Description :
 * Global notification container for the
 * Inquiry Queue module.
 *
 * Initially hidden.
 * ---------------------------------------------------------
 */
?>

<div
    id="toastNotification"
    class="toast-notification toast-success"
    style="display:none;">

    <div class="toast-icon">

        ✔

    </div>

    <div class="toast-content">

        <strong id="toastTitle">

            Success

        </strong>

        <p id="toastMessage">

            Operation completed successfully.

        </p>

    </div>

    <button
        type="button"
        class="toast-close"
        id="toastClose">

        &times;

    </button>

</div>