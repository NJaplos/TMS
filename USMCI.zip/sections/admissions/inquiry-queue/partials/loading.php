<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Module      : Admissions
 * Partial     : Loading Overlay
 * File        : loading.php
 * Version     : 1.0
 *
 * Description :
 * Global loading indicator used by the
 * Inquiry Queue while processing data.
 *
 * Initially hidden.
 * ---------------------------------------------------------
 */
?>

<div
    id="loadingOverlay"
    class="loading-overlay"
    style="display:none;">

    <div class="loading-box">

        <div class="loading-spinner"></div>

        <h4>

            Processing Request...

        </h4>

        <p>

            Please wait while the system
            retrieves the requested information.

        </p>

    </div>

</div>