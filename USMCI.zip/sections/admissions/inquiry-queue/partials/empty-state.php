<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Module      : Admissions
 * Partial     : Inquiry Queue Empty State
 * File        : empty-state.php
 * Version     : 1.0
 *
 * Description :
 * Displayed whenever no inquiry records
 * are available after loading or filtering.
 * ---------------------------------------------------------
 */
?>

<section
    id="emptyState"
    class="workspace-empty"
    style="display:none;">

    <div class="workspace-empty__icon">

        📭

    </div>

    <h3>

        No Inquiry Records Found

    </h3>

    <p>

        There are currently no inquiry records
        matching the selected criteria.

    </p>

</section>