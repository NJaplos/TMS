<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Admissions Workspace
 * Administrative Sidebar
 * File : sidebar-admin.php
 * ---------------------------------------------------------
 */
?>

<aside class="workspace-sidebar">

    <div class="workspace-sidebar__header">

        <span class="admissions-badge">

            Admissions Workspace

        </span>

    </div>

    <nav class="workspace-navigation">

        <a href="#" class="active">

            🏠 Dashboard

        </a>

        <a href="#">

            📨 Inquiry Queue

        </a>

        <a href="#">

            👥 Applicants

        </a>

        <a href="#">

            📅 Course Availability

        </a>

        <a href="#">

            📝 Enrollment

        </a>

        <a href="#">

            📧 Email Center

        </a>

        <a href="#">

            📊 Reports

        </a>

        <a href="#">

            ⚙ Settings

        </a>

    </nav>

</aside>