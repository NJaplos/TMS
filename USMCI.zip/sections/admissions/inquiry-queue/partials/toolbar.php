<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Module      : Admissions
 * Partial     : Inquiry Queue Toolbar
 * File        : toolbar.php
 * Version     : 1.0
 *
 * Description :
 * Search and filtering toolbar for the
 * Admissions Inquiry Queue.
 *
 * Backend integration will populate the
 * dropdown values and execute filtering.
 * ---------------------------------------------------------
 */
?>

<section class="workspace-toolbar">

    <div class="toolbar-left">

        <!-- Search -->

        <div class="toolbar-search">

            <input
                type="text"
                id="searchKeyword"
                placeholder="Search applicant, inquiry no., email or contact number...">

        </div>

    </div>

    <div class="toolbar-right">

        <!-- Inquiry Type -->

        <select id="filterInquiryType">

            <option value="">
                All Inquiry Types
            </option>

            <!-- Dynamic Records -->

        </select>

        <!-- Date -->

        <input
            type="date"
            id="filterDate">

        <!-- Refresh -->

        <button
            type="button"
            class="btn-secondary"
            id="btnRefresh">

            Refresh

        </button>

    </div>

</section>