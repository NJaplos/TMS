<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Module      : Admissions
 * Page        : Inquiry Queue
 * File        : index.php
 * Version     : 3.0
 *
 * Description :
 * Admissions Inquiry Queue Workspace.
 *
 * Uses the global application bootstrap so the
 * project can be moved or renamed without changing
 * page code.
 * ---------------------------------------------------------
 */

/* ==========================================================
   Load Global Framework
========================================================== */

require_once dirname(__DIR__, 3) . '/config/bootstrap.php';

/* ==========================================================
   Page Configuration
========================================================== */

$page = [
    'title'       => 'Admissions Inquiry Queue | USMCI-TMS',
    'description' => 'Admissions Inquiry Queue Workspace',
    'bodyClass'   => 'admissions-page'
];

?>

<!DOCTYPE html>

<html lang="en">

<?php include INCLUDES_PATH . '/head.php'; ?>

<!-- ==========================================================
     Stylesheets
========================================================== -->

<link
    rel="stylesheet"
    href="<?= ADMISSIONS_URL; ?>/workspace.css">

<link
    rel="stylesheet"
    href="<?= INQUIRY_QUEUE_URL; ?>/style.css">

<body class="<?= e($page['bodyClass']); ?>">

    <!-- =====================================================
         Main Navigation
    ====================================================== -->

    <?php include NAVBAR_PATH . '/index.php'; ?>

    <!-- =====================================================
         Admissions Workspace
    ====================================================== -->

    <section
        id="admissions-portal"
        class="admissions-portal admissions-portal--workspace">

        <!-- ==========================================
             Shared Admissions Sidebar
        =========================================== -->

        <?php require ADMISSIONS_PARTIALS . '/sidebar.php'; ?>

        <!-- ==========================================
             Workspace Content
        =========================================== -->

        <main class="portal-content">

            <?php require INQUIRY_QUEUE_PARTIALS . '/header.php'; ?>

            <?php require INQUIRY_QUEUE_PARTIALS . '/summary.php'; ?>

            <?php require INQUIRY_QUEUE_PARTIALS . '/toolbar.php'; ?>

            <?php require INQUIRY_QUEUE_PARTIALS . '/table.php'; ?>

            <?php require INQUIRY_QUEUE_PARTIALS . '/pagination.php'; ?>

        </main>

        <!-- ==========================================
             Shared Admissions Right Panel
                    Right Panel Removed
               Inquiry Queue is an operational workspace.
               Full width is allocated to the data table.
          =========================================== -->

    </section>

    <!-- =====================================================
         Inquiry Queue Modal
    ====================================================== -->

    <?php require INQUIRY_QUEUE_PARTIALS . '/loading.php'; ?>

    <?php require INQUIRY_QUEUE_PARTIALS . '/modal.php'; ?>

    <!-- =====================================================
         Footer
    ====================================================== -->

    <?php include INCLUDES_PATH . '/footer.php'; ?>

    <?php include INCLUDES_PATH . '/scripts.php'; ?>

    <!-- =====================================================
         JavaScript
    ====================================================== -->

    <script src="<?= ADMISSIONS_URL; ?>/script.js"></script>

    <script src="<?= INQUIRY_QUEUE_URL; ?>/script.js"></script>

</body>

</html>