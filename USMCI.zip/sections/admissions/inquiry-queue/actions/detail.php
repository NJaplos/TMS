<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Inquiry Queue
 * GET /actions/detail.php?id=123
 * ---------------------------------------------------------
 * Returns one inquiry's full detail plus its reply thread,
 * for populating the modal when a staff member opens a row.
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once dirname(__DIR__, 4) . '/config/bootstrap.php';

header('Content-Type: application/json');

$inquiryId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$inquiryId) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Missing or invalid inquiry id.']);
    exit;
}

$pdo = db();

$stmt = $pdo->prepare(
    "SELECT
        i.id, i.inquiry_no, i.full_name, i.email, i.mobile_no,
        i.preferred_contact, i.course_interest, i.preferred_schedule,
        i.preferred_date, i.subject, i.message, i.created_at,
        s.code AS status_code, s.label AS status_label
     FROM inquiry i
     LEFT JOIN mnt_inquiry_status s ON s.id = i.status_id
     WHERE i.id = :id"
);
$stmt->execute(['id' => $inquiryId]);
$inquiry = $stmt->fetch();

if (!$inquiry) {
    http_response_code(404);
    echo json_encode(['success' => false, 'message' => 'Inquiry not found.']);
    exit;
}

$repliesStmt = $pdo->prepare(
    "SELECT sender_type, sender_id, message, created_at
     FROM inquiry_reply
     WHERE inquiry_id = :id
     ORDER BY created_at ASC"
);
$repliesStmt->execute(['id' => $inquiryId]);

echo json_encode([
    'success' => true,
    'inquiry' => $inquiry,
    'replies' => $repliesStmt->fetchAll(),
]);
