<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Inquiry Queue
 * POST /actions/reply.php
 * ---------------------------------------------------------
 * This is the actual "Send Reply" wiring: logs the staff
 * reply in inquiry_reply, queues a real email to the
 * applicant via email_queue (sent next time
 * mailer/send_queued_emails.php runs), and advances the
 * inquiry to REPLIED.
 *
 * Expected POST fields:
 *   inquiry_id   — required
 *   message      — required, the reply text
 *   staff_id     — required (from session once auth exists;
 *                  hardcoded to 1 for now — see note below)
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once dirname(__DIR__, 4) . '/config/bootstrap.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'POST required.']);
    exit;
}

$inquiryId = filter_input(INPUT_POST, 'inquiry_id', FILTER_VALIDATE_INT);
$message = trim((string) ($_POST['message'] ?? ''));

// TODO: replace with the real logged-in staff id once auth.php
// (currently commented out in bootstrap.php) is wired up.
$staffId = filter_input(INPUT_POST, 'staff_id', FILTER_VALIDATE_INT) ?: 1;

if (!$inquiryId) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Missing or invalid inquiry_id.']);
    exit;
}

if ($message === '') {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Reply message cannot be empty.']);
    exit;
}

$messageLength = function_exists('mb_strlen') ? mb_strlen($message) : strlen($message);

if ($messageLength > 2000) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Reply is too long (max 2000 characters).']);
    exit;
}

$pdo = db();
$pdo->beginTransaction();

try {
    $inquiryStmt = $pdo->prepare(
        "SELECT id, inquiry_no, full_name, email, subject FROM inquiry WHERE id = :id FOR UPDATE"
    );
    $inquiryStmt->execute(['id' => $inquiryId]);
    $inquiry = $inquiryStmt->fetch();

    if (!$inquiry) {
        throw new RuntimeException('Inquiry not found.');
    }

    if ($inquiry['email'] === null || trim($inquiry['email']) === '') {
        throw new RuntimeException('This inquiry has no email address on file — cannot send a reply.');
    }

    $pdo->prepare(
        "INSERT INTO inquiry_reply (inquiry_id, sender_type, sender_id, message, created_at)
         VALUES (:inquiry_id, 'staff', :sender_id, :message, NOW())"
    )->execute([
        'inquiry_id' => $inquiryId,
        'sender_id' => $staffId,
        'message' => $message,
    ]);

    $repliedStatusId = $pdo->query(
        "SELECT id FROM mnt_inquiry_status WHERE code = 'REPLIED'"
    )->fetchColumn();

    $pdo->prepare(
        "UPDATE inquiry SET status_id = :status_id, assigned_to = :staff_id WHERE id = :id"
    )->execute([
        'status_id' => $repliedStatusId,
        'staff_id' => $staffId,
        'id' => $inquiryId,
    ]);

    $safeName = htmlspecialchars($inquiry['full_name'], ENT_QUOTES, 'UTF-8');
    $safeMessage = nl2br(htmlspecialchars($message, ENT_QUOTES, 'UTF-8'));
    $safeSubject = htmlspecialchars((string) $inquiry['subject'], ENT_QUOTES, 'UTF-8');

    $bodyHtml = <<<HTML
        <h2>Re: {$safeSubject}</h2>
        <p>Hi {$safeName},</p>
        <p>{$safeMessage}</p>
        <p style="color:#6B7280;font-size:.85rem;">
            Reference: {$inquiry['inquiry_no']}<br>
            — USMCI Admissions Office
        </p>
    HTML;

    $pdo->prepare(
        "INSERT INTO email_queue (recipient_email, subject, body_html, status, scheduled_at, created_at)
         VALUES (:email, :subject, :body, 'pending', NOW(), NOW())"
    )->execute([
        'email' => $inquiry['email'],
        'subject' => 'Re: ' . ($inquiry['subject'] ?: 'Your Admissions Inquiry'),
        'body' => $bodyHtml,
    ]);

    $pdo->commit();

    echo json_encode([
        'success' => true,
        'message' => 'Reply sent and queued for delivery.',
    ]);
} catch (Throwable $exception) {
    $pdo->rollBack();
    error_log('reply.php failed: ' . $exception->getMessage());

    http_response_code(500);
    echo json_encode(['success' => false, 'message' => $exception->getMessage()]);
}
