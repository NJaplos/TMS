<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Inquiry Queue
 * GET /actions/list.php
 * ---------------------------------------------------------
 * Returns inquiries as JSON for the queue table, replacing
 * the previously hardcoded mock rows. Supports optional
 * ?status=NEW / REPLIED / INVITED / CONVERTED filtering.
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once dirname(__DIR__, 4) . '/config/bootstrap.php';

header('Content-Type: application/json');

$pdo = db();

$statusFilter = $_GET['status'] ?? null;

$sql = "SELECT
            i.id,
            i.inquiry_no,
            i.full_name,
            i.email,
            i.mobile_no,
            i.course_interest,
            i.subject,
            i.message,
            i.created_at,
            s.code AS status_code,
            s.label AS status_label
        FROM inquiry i
        LEFT JOIN mnt_inquiry_status s ON s.id = i.status_id";

$params = [];

if ($statusFilter !== null && $statusFilter !== '') {
    $sql .= " WHERE s.code = :status";
    $params['status'] = $statusFilter;
}

$sql .= " ORDER BY i.created_at DESC LIMIT 200";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);

echo json_encode([
    'success' => true,
    'inquiries' => $stmt->fetchAll(),
]);
