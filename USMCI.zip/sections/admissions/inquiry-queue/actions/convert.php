<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Inquiry Queue
 * POST /actions/convert.php
 * ---------------------------------------------------------
 * Wires the "Create Applicant Account" button to the existing
 * invite_applicant_to_enroll() function in
 * sections/admissions/inquiry_invite.php — creates the
 * applicant stub, generates the secure invitation token, and
 * queues the invitation email.
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once dirname(__DIR__, 4) . '/config/bootstrap.php';
require_once ADMISSIONS_PATH . '/inquiry_invite.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'POST required.']);
    exit;
}

$inquiryId = filter_input(INPUT_POST, 'inquiry_id', FILTER_VALIDATE_INT);

// TODO: replace with the real logged-in staff id once auth.php is wired up.
$staffId = filter_input(INPUT_POST, 'staff_id', FILTER_VALIDATE_INT) ?: 1;

if (!$inquiryId) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Missing or invalid inquiry_id.']);
    exit;
}

$result = invite_applicant_to_enroll($inquiryId, $staffId);

if (!$result['success']) {
    http_response_code(422);
}

echo json_encode($result);
