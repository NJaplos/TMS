/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Module      : Admissions Inquiry Queue
 * File        : script.js
 * Version     : 1.0
 *
 * Wires the previously frontend-only workspace to real data:
 *   - loads inquiries from actions/list.php
 *   - opens the modal with real detail from actions/detail.php
 *   - Send Reply posts to actions/reply.php (queues a real
 *     email — see mailer/send_queued_emails.php)
 *   - Create Applicant Account posts to actions/convert.php
 * ---------------------------------------------------------
 */

(() => {
    "use strict";

    const ACTIONS_BASE = window.location.pathname.replace(/\/[^/]*$/, "") + "/actions";

    const tableBody = document.getElementById("inquiryTableBody");
    const emptyState = document.getElementById("emptyState");
    const modal = document.getElementById("inquiryModal");
    const closeButtons = [
        document.getElementById("closeInquiryModal"),
        document.getElementById("closeInquiryModalBtn"),
    ];

    let currentInquiryId = null;

    // ------------------------------------------------------
    // Status badge styling helper
    // ------------------------------------------------------
    function statusBadgeClass(code) {
        const map = {
            NEW: "status-new",
            REPLIED: "status-replied",
            INVITED: "status-invited",
            CONVERTED: "status-converted",
            CLOSED: "status-closed",
        };
        return map[code] || "status-new";
    }

    function escapeHtml(value) {
        const div = document.createElement("div");
        div.textContent = value ?? "";
        return div.innerHTML;
    }

    function formatDate(value) {
        if (!value) return "—";
        const date = new Date(value.replace(" ", "T"));
        if (Number.isNaN(date.getTime())) return value;
        return date.toLocaleDateString("en-US", { year: "numeric", month: "short", day: "numeric" });
    }

    // ------------------------------------------------------
    // Load + render the table
    // ------------------------------------------------------
    async function loadInquiries() {
        try {
            const response = await fetch(`${ACTIONS_BASE}/list.php`);
            const data = await response.json();

            if (!data.success) {
                console.error("Failed to load inquiries:", data.message);
                return;
            }

            renderTable(data.inquiries);
        } catch (error) {
            console.error("loadInquiries error:", error);
        }
    }

    function renderTable(inquiries) {
        tableBody.innerHTML = "";

        if (inquiries.length === 0) {
            emptyState.style.display = "flex";
            return;
        }

        emptyState.style.display = "none";

        for (const inquiry of inquiries) {
            const row = document.createElement("tr");

            row.innerHTML = `
                <td><input type="checkbox"></td>
                <td>${escapeHtml(inquiry.inquiry_no)}</td>
                <td>${formatDate(inquiry.created_at)}</td>
                <td>${escapeHtml(inquiry.full_name)}</td>
                <td>${escapeHtml(inquiry.email)}</td>
                <td>${escapeHtml(inquiry.mobile_no)}</td>
                <td>${escapeHtml(inquiry.course_interest || "—")}</td>
                <td>${escapeHtml(inquiry.subject || "—")}</td>
                <td>
                    <span class="status-badge ${statusBadgeClass(inquiry.status_code)}">
                        ${escapeHtml(inquiry.status_label || "New")}
                    </span>
                </td>
                <td>
                    <button class="btn-table" data-open="${inquiry.id}">View</button>
                </td>
            `;

            tableBody.appendChild(row);
        }
    }

    // ------------------------------------------------------
    // Modal: open + populate with real detail
    // ------------------------------------------------------
    async function openInquiry(inquiryId) {
        try {
            const response = await fetch(`${ACTIONS_BASE}/detail.php?id=${encodeURIComponent(inquiryId)}`);
            const data = await response.json();

            if (!data.success) {
                alert(data.message || "Could not load this inquiry.");
                return;
            }

            populateModal(data.inquiry, data.replies);
            currentInquiryId = inquiryId;
            document.getElementById("modalInquiryId").value = inquiryId;
            modal.style.display = "flex";
            switchTab("inquiry");
        } catch (error) {
            console.error("openInquiry error:", error);
            alert("Something went wrong loading this inquiry. Please try again.");
        }
    }

    function populateModal(inquiry, replies) {
        document.getElementById("modalInquiryNo").textContent = inquiry.inquiry_no;
        document.getElementById("modalApplicant").textContent = inquiry.full_name;
        document.getElementById("modalEmail").textContent = inquiry.email;
        document.getElementById("modalMobile").textContent = inquiry.mobile_no || "—";
        document.getElementById("modalCourse").textContent = inquiry.course_interest || "—";
        document.getElementById("modalDate").textContent = formatDate(inquiry.created_at);
        document.getElementById("modalSchedule").textContent = inquiry.preferred_schedule || "—";
        document.getElementById("modalPreferredDate").textContent = inquiry.preferred_date || "—";
        document.getElementById("modalSubject").textContent = inquiry.subject || "—";
        document.getElementById("modalMessage").textContent = inquiry.message || "—";
        document.getElementById("modalStatus").textContent = inquiry.status_label || "New";

        const list = document.getElementById("modalConversationList");

        if (!replies || replies.length === 0) {
            list.innerHTML = '<p class="conversation-empty">No replies yet.</p>';
        } else {
            list.innerHTML = replies.map((reply) => `
                <div class="conversation-item conversation-item--${escapeHtml(reply.sender_type)}">
                    <div class="conversation-item__meta">
                        <strong>${reply.sender_type === "staff" ? "Admissions Office" : escapeHtml(inquiry.full_name)}</strong>
                        <span>${formatDate(reply.created_at)}</span>
                    </div>
                    <p>${escapeHtml(reply.message)}</p>
                </div>
            `).join("");
        }

        document.getElementById("replyMessage").value = "";
        const feedback = document.getElementById("replyFeedback");
        feedback.style.display = "none";
        feedback.textContent = "";
    }

    function closeModal() {
        modal.style.display = "none";
        currentInquiryId = null;
    }

    // ------------------------------------------------------
    // Tabs
    // ------------------------------------------------------
    function switchTab(tabName) {
        document.querySelectorAll(".tab-button").forEach((btn) => {
            btn.classList.toggle("active", btn.dataset.tab === tabName);
        });

        document.querySelectorAll("[data-tab-content]").forEach((panel) => {
            panel.style.display = panel.dataset.tabContent === tabName ? "block" : "none";
        });
    }

    // ------------------------------------------------------
    // Send Reply — the actual email-sending integration
    // ------------------------------------------------------
    async function sendReply() {
        const message = document.getElementById("replyMessage").value.trim();
        const feedback = document.getElementById("replyFeedback");

        if (!currentInquiryId) return;

        if (message === "") {
            showReplyFeedback("Please type a reply before sending.", true);
            return;
        }

        const sendButton = document.getElementById("btnSendReply");
        sendButton.disabled = true;
        sendButton.textContent = "Sending...";

        try {
            const response = await fetch(`${ACTIONS_BASE}/reply.php`, {
                method: "POST",
                headers: { "Content-Type": "application/x-www-form-urlencoded" },
                body: new URLSearchParams({
                    inquiry_id: currentInquiryId,
                    message: message,
                }),
            });

            const data = await response.json();
            showReplyFeedback(data.message, !data.success);

            if (data.success) {
                await openInquiry(currentInquiryId); // refresh conversation + status
                switchTab("conversation");
                await loadInquiries(); // refresh table's status badge
            }
        } catch (error) {
            console.error("sendReply error:", error);
            showReplyFeedback("Something went wrong sending this reply. Please try again.", true);
        } finally {
            sendButton.disabled = false;
            sendButton.textContent = "Send Reply";
        }
    }

    function showReplyFeedback(message, isError) {
        const feedback = document.getElementById("replyFeedback");
        feedback.textContent = message;
        feedback.style.display = "block";
        feedback.className = "reply-feedback " + (isError ? "reply-feedback--error" : "reply-feedback--success");
    }

    // ------------------------------------------------------
    // Create Applicant Account
    // ------------------------------------------------------
    async function convertToApplicant() {
        if (!currentInquiryId) return;

        if (!confirm("Send this applicant an invitation to create their Admissions Portal account?")) {
            return;
        }

        const convertButton = document.getElementById("btnConvert");
        convertButton.disabled = true;
        convertButton.textContent = "Sending Invitation...";

        try {
            const response = await fetch(`${ACTIONS_BASE}/convert.php`, {
                method: "POST",
                headers: { "Content-Type": "application/x-www-form-urlencoded" },
                body: new URLSearchParams({ inquiry_id: currentInquiryId }),
            });

            const data = await response.json();
            alert(data.message || (data.success ? "Invitation sent." : "Something went wrong."));

            if (data.success) {
                await openInquiry(currentInquiryId);
                await loadInquiries();
            }
        } catch (error) {
            console.error("convertToApplicant error:", error);
            alert("Something went wrong sending the invitation. Please try again.");
        } finally {
            convertButton.disabled = false;
            convertButton.textContent = "Create Applicant Account";
        }
    }

    // ------------------------------------------------------
    // Event wiring
    // ------------------------------------------------------
    document.addEventListener("DOMContentLoaded", () => {
        loadInquiries();

        tableBody.addEventListener("click", (event) => {
            const openBtn = event.target.closest("[data-open]");
            if (openBtn) {
                openInquiry(openBtn.dataset.open);
            }
        });

        closeButtons.forEach((btn) => btn && btn.addEventListener("click", closeModal));

        modal.addEventListener("click", (event) => {
            if (event.target === modal) closeModal();
        });

        document.querySelectorAll(".tab-button").forEach((btn) => {
            btn.addEventListener("click", () => switchTab(btn.dataset.tab));
        });

        document.getElementById("btnSendReply").addEventListener("click", sendReply);
        document.getElementById("btnConvert").addEventListener("click", convertToApplicant);

        const refreshBtn = document.getElementById("btnRefreshTable");
        if (refreshBtn) refreshBtn.addEventListener("click", loadInquiries);
    });
})();
