/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Admissions Portal
 * Campus Slideshow
 * ---------------------------------------------------------
 */

const slide = document.getElementById("campusSlide");

let currentIndex = 0;

if (
    typeof campusImages !== "undefined" &&
    campusImages.length > 1 &&
    slide
) {

    setInterval(() => {

        slide.style.opacity = 0;

        setTimeout(() => {

            currentIndex++;

            if (currentIndex >= campusImages.length) {

                currentIndex = 0;

            }

            slide.src = campusImages[currentIndex];

            slide.style.opacity = 1;

        }, 300);

    }, 4000);

}