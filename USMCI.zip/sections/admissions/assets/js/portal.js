document.addEventListener("DOMContentLoaded",()=>{

console.log("Admissions Portal Loaded");

});