<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Module      : Admissions
 * File        : programs.php
 * Description : Featured Training Programs
 * Author      : Niel Japlos
 * ---------------------------------------------------------
 */
?>

<section class="featured-programs">

    <div class="container">

        <div class="section-header">

            <span class="section-badge">

                Featured Programs

            </span>

            <h2>

                Maritime Training Programs

            </h2>

            <p>

                Explore some of our most popular maritime training
                programs. Additional courses are available through
                the complete course catalog.

            </p>

        </div>

        <div class="program-grid">

            <div class="program-card">

                <h3>Basic Safety Training (BST)</h3>

                <p>

                    Essential safety training for aspiring and
                    active seafarers.

                </p>

            </div>

            <div class="program-card">

                <h3>Security Awareness Training</h3>

                <p>

                    Develop awareness and security responsibilities
                    while working onboard.

                </p>

            </div>

            <div class="program-card">

                <h3>Advanced Fire Fighting</h3>

                <p>

                    Advanced techniques for emergency response
                    and onboard fire control.

                </p>

            </div>

            <div class="program-card">

                <h3>Medical First Aid</h3>

                <p>

                    Learn emergency medical procedures
                    applicable at sea.

                </p>

            </div>

        </div>

        <div class="section-action">

            <a href="../courses/" class="btn-secondary">

                View All Training Programs

            </a>

        </div>

    </div>

</section>