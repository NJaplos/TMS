<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Module      : Admissions
 * File        : status.php
 * Description : Admissions Status
 * ---------------------------------------------------------
 */
?>

<section class="admission-status">

    <div class="container">

        <div class="status-card">

            <div class="status-left">

                <span class="status-badge">

                    Admissions Status

                </span>

                <h2>

                    Online Applications are Open

                </h2>

                <p>

                    Applications are currently being accepted.
                    Applicants may begin their admission process
                    online and monitor their progress through
                    their applicant account.

                </p>

            </div>

            <div class="status-right">

                <ul>

                    <li>

                        ✔ Admissions Portal Available

                    </li>

                    <li>

                        ✔ Online Applications Accepted

                    </li>

                    <li>

                        ✔ Account Registration Available

                    </li>

                    <li>

                        ✔ Admissions Office Review Required

                    </li>

                </ul>

            </div>

        </div>

    </div>

</section>