<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Module      : Admissions
 * File        : requirements.php
 * Description : Basic Requirements
 * ---------------------------------------------------------
 */
?>

<section class="admission-requirements">

    <div class="container">

        <div class="section-header">

            <span class="section-badge">

                Basic Requirements

            </span>

            <h2>

                Prepare Before You Apply

            </h2>

            <p>

                Applicants are encouraged to prepare the following
                documents before beginning their application.

            </p>

        </div>

        <div class="requirement-grid">

            <div class="requirement-card">

                <h3>Identification</h3>

                <p>

                    Valid government-issued identification.

                </p>

            </div>

            <div class="requirement-card">

                <h3>Recent Photograph</h3>

                <p>

                    Passport-size or 2×2 ID photograph.

                </p>

            </div>

            <div class="requirement-card">

                <h3>Supporting Documents</h3>

                <p>

                    Academic records, certificates, or other
                    documents applicable to your chosen training.

                </p>

            </div>

            <div class="requirement-card">

                <h3>Additional Requirements</h3>

                <p>

                    Requirements may vary depending on the selected
                    training program and applicant category.

                </p>

            </div>

        </div>

        <div class="requirement-note">

            <strong>Note:</strong>

            The Admissions Office may request additional documents
            during the evaluation of your application.

        </div>

    </div>

</section>