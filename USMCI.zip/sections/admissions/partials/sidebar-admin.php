<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Module      : Admissions Workspace
 * Partial     : Sidebar (Admin)
 * File        : sidebar-admin.php
 * Version     : 3.0
 *
 * Description
 * ---------------------------------------------------------
 * Administrative sidebar for Admissions Workspace.
 *
 * IMPORTANT
 * ---------------------------------------------------------
 * This file intentionally reuses the SAME visual
 * structure as the Public Admissions Portal sidebar.
 *
 * Only the navigation content differs.
 * ---------------------------------------------------------
 */
?>

<aside class="portal-sidebar">

    <div class="portal-sidebar__inner">

        <span class="admissions-badge">
            Admissions Portal
        </span>

        <h2>
            Start Your Maritime Career
        </h2>

        <p>
            Complete your admission online through the secure
            USMCI Admissions Portal.
        </p>

        <nav class="portal-sidebar__menu">

            <a href="#" class="menu-item">
                Dashboard
            </a>

            <a href="#" class="menu-item active">
                Inquiry Queue
            </a>

            <a href="#" class="menu-item">
                Applicants
            </a>

            <a href="#" class="menu-item">
                Course Availability
            </a>

            <a href="#" class="menu-item">
                Enrollment
            </a>

            <a href="#" class="menu-item">
                Email Center
            </a>

            <a href="#" class="menu-item">
                Reports
            </a>

            <a href="#" class="menu-item">
                Settings
            </a>

        </nav>

        <div class="portal-sidebar__actions">

            <button class="btn btn-primary">
                Login
            </button>

            <button class="btn btn-outline">
                Create Account
            </button>

        </div>

        <div class="info-card">

            <div class="info-icon">
                🕒
            </div>

            <div class="info-text">

                <strong>Office Hours</strong>

                <p>
                    Monday – Friday, 8:00 AM – 5:00 PM
                </p>

            </div>

        </div>

    </div>

</aside>