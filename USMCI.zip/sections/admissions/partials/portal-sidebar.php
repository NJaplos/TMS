<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Admissions Portal
 * Portal Sidebar
 * ---------------------------------------------------------
 * Purpose:
 * Navigation sidebar for authenticated Admissions users.
 *
 * Version:
 * 1.0
 * ---------------------------------------------------------
 */

/*
|--------------------------------------------------------------------------
| Active Page
|--------------------------------------------------------------------------
|
| Used for highlighting the active menu.
|
*/

$currentPage = basename($_SERVER['PHP_SELF']);
?>

<aside class="portal-sidebar">

    <div class="portal-sidebar__header">

        <h2>USMCI-TMS</h2>

        <span class="portal-badge">
            Admissions Portal
        </span>

    </div>

    <nav class="portal-nav">

        <!-- ===================================================== -->
        <!-- OVERVIEW -->
        <!-- ===================================================== -->

        <div class="nav-group">

            <span class="nav-group-title">

                OVERVIEW

            </span>

            <a
                href="/USMCI-TMS/sections/admissions/dashboard/"
                class="nav-link <?= ($currentPage == 'dashboard.php') ? 'active' : ''; ?>">

                <i class="fas fa-chart-line"></i>

                Dashboard

            </a>

        </div>


        <!-- ===================================================== -->
        <!-- ADMISSIONS -->
        <!-- ===================================================== -->

        <div class="nav-group">

            <span class="nav-group-title">

                ADMISSIONS

            </span>

            <a
                href="/USMCI-TMS/sections/admissions/inquiry-queue/"
                class="nav-link <?= (strpos($_SERVER['REQUEST_URI'], 'inquiry-queue') !== false) ? 'active' : ''; ?>">

                <i class="fas fa-inbox"></i>

                Inquiry Queue

            </a>


            <a
                href="#"
                class="nav-link disabled">

                <i class="fas fa-user-graduate"></i>

                Applicants

            </a>


            <a
                href="#"
                class="nav-link disabled">

                <i class="fas fa-user-check"></i>

                Enrollment

            </a>

        </div>


        <!-- ===================================================== -->
        <!-- ACADEMICS -->
        <!-- ===================================================== -->

        <div class="nav-group">

            <span class="nav-group-title">

                ACADEMICS

            </span>

            <a
                href="#"
                class="nav-link disabled">

                <i class="fas fa-book"></i>

                Courses

            </a>

        </div>


        <!-- ===================================================== -->
        <!-- ADMINISTRATION -->
        <!-- ===================================================== -->

        <div class="nav-group">

            <span class="nav-group-title">

                ADMINISTRATION

            </span>

            <a
                href="#"
                class="nav-link disabled">

                <i class="fas fa-chart-bar"></i>

                Reports

            </a>

            <a
                href="#"
                class="nav-link disabled">

                <i class="fas fa-cogs"></i>

                Maintenance

            </a>

        </div>

    </nav>


    <div class="portal-sidebar-footer">

        <div class="logged-user">

            <strong>Administrator</strong>

            <small>

                Full Access

            </small>

        </div>

        <a
            href="#"
            class="logout-btn">

            <i class="fas fa-sign-out-alt"></i>

            Logout

        </a>

    </div>

</aside>