<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Module      : Admissions
 * File        : benefits.php
 * Description : Why Apply Online
 * ---------------------------------------------------------
 */
?>

<section class="admission-benefits">

    <div class="container">

        <div class="section-header">

            <span class="section-badge">

                Why Apply Online

            </span>

            <h2>

                Convenient, Secure, and Accessible

            </h2>

            <p>

                The USMCI Admissions Portal allows applicants to
                complete the admission process online while keeping
                track of their application anytime.

            </p>

        </div>

        <div class="benefit-grid">

            <div class="benefit-card">

                <div class="benefit-icon">💻</div>

                <h3>Online Application</h3>

                <p>

                    Submit your admission application from anywhere
                    using your computer or mobile device.

                </p>

            </div>

            <div class="benefit-card">

                <div class="benefit-icon">📈</div>

                <h3>Track Your Progress</h3>

                <p>

                    Monitor your application status and continue
                    your submission anytime.

                </p>

            </div>

            <div class="benefit-card">

                <div class="benefit-icon">🔒</div>

                <h3>Secure Information</h3>

                <p>

                    Your personal information is protected using
                    secure authentication and controlled access.

                </p>

            </div>

        </div>

    </div>

</section>