<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Module      : Admissions
 * Partial     : Hero
 * Description : Compact Admissions Portal Header
 * ---------------------------------------------------------
 */
?>

<section class="portal-header">

    <div class="portal-header__content">

        <span class="portal-badge">
            Admissions Portal
        </span>

        <h1>

            Start Your Maritime Career

        </h1>

        <p>

            Complete your application online through our
            secure admissions portal.

        </p>

        <div class="portal-buttons">

            <button
                class="btn-primary login-btn">

                Login

            </button>

            <button
                class="btn-outline register-btn">

                Create Account

            </button>

        </div>

        <div
            class="portal-message"
            id="portalMessage">

            Continue your admission application.

        </div>

    </div>

</section>