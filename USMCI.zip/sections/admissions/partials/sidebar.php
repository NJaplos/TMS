<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Module      : Admissions Portal
 * Partial     : Sidebar
 * Description : Branding/pitch panel — same structural role
 *               and visual language as the Inquiry page's
 *               sidebar (sections/admissions/inquiry/partials/hero.php),
 *               reusing the shared .admissions-badge component
 *               so both pages carry the same identifier.
 * ---------------------------------------------------------
 */
?>

<aside class="portal-sidebar">

    <div class="portal-sidebar__inner">

        <span class="admissions-badge">
            Admissions Portal
        </span>

        <h2>
            Start Your Maritime Career
        </h2>

        <p>
            Complete your admission online through the secure
            USMCI Admissions Portal.
        </p>

        <ul class="portal-sidebar__features">

            <li>
                <span>✓</span>
                Secure Online Application
            </li>

            <li>
                <span>✓</span>
                Save Progress Anytime
            </li>

            <li>
                <span>✓</span>
                Upload Documents Later
            </li>

            <li>
                <span>✓</span>
                Track Admission Status
            </li>

        </ul>

        <div class="portal-sidebar__actions">

            <button class="btn btn-primary">
                Login
            </button>

            <button class="btn btn-outline">
                Create Account
            </button>

        </div>

        <div class="info-card">

            <div class="info-icon">
                🕒
            </div>

            <div class="info-text">

                <strong>Office Hours</strong>

                <p>
                    Monday – Friday, 8:00 AM – 5:00 PM
                </p>

            </div>

        </div>

    </div>

</aside>