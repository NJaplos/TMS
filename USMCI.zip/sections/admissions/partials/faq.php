<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Module      : Admissions
 * File        : faq.php
 * Description : Frequently Asked Questions
 * Author      : Niel Japlos
 * ---------------------------------------------------------
 */
?>

<section class="admission-faq">

    <div class="container">

        <div class="section-header">

            <span class="section-badge">

                Frequently Asked Questions

            </span>

            <h2>

                Need More Information?

            </h2>

        </div>

        <div class="faq-list">

            <div class="faq-item">

                <h3>

                    Can I apply online?

                </h3>

                <p>

                    Yes. Applicants may complete their admission
                    process through the online Admissions Portal.

                </p>

            </div>

            <div class="faq-item">

                <h3>

                    Can I continue my application later?

                </h3>

                <p>

                    Yes. Your progress is saved after logging into
                    your applicant account.

                </p>

            </div>

            <div class="faq-item">

                <h3>

                    Can I submit missing documents later?

                </h3>

                <p>

                    Yes. The Admissions Office may allow applicants
                    to submit additional documents during the
                    admission process.

                </p>

            </div>

            <div class="faq-item">

                <h3>

                    Who approves my admission?

                </h3>

                <p>

                    The Admissions Office performs the final review
                    and approval of all applications.

                </p>

            </div>

            <div class="faq-item">

                <h3>

                    How can I contact Admissions?

                </h3>

                <p>

                    You may submit an inquiry through the Inquiry
                    page or contact the Admissions Office directly.

                </p>

            </div>

        </div>

    </div>

</section>