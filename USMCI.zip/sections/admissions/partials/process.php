<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Module      : Admissions
 * File        : process.php
 * Version     : 1.0
 * Description : Admissions Process
 * ---------------------------------------------------------
 */
?>

<section class="admission-process">

    <div class="container">

        <div class="section-header">

            <span class="section-badge">

                Admission Process

            </span>

            <h2>

                Your Journey Starts Here

            </h2>

            <p>

                Follow these six simple steps to complete your
                admission process. Your application may be saved,
                allowing you to continue at your convenience.

            </p>

        </div>

        <div class="process-timeline">

            <!-- STEP 1 -->

            <div class="process-card">

                <div class="step-number">

                    01

                </div>

                <h3>

                    Create Applicant Account

                </h3>

                <p>

                    Register your applicant account using a valid
                    email address. Existing applicants may simply
                    log in to continue.

                </p>

            </div>

            <!-- STEP 2 -->

            <div class="process-card">

                <div class="step-number">

                    02

                </div>

                <h3>

                    Complete Your Profile

                </h3>

                <p>

                    Provide your personal information,
                    emergency contact details, and other
                    required applicant information.

                </p>

            </div>

            <!-- STEP 3 -->

            <div class="process-card">

                <div class="step-number">

                    03

                </div>

                <h3>

                    Upload Documents

                </h3>

                <p>

                    Upload available supporting documents.
                    Additional requirements may still be
                    submitted during the admission process
                    if permitted by the Admissions Office.

                </p>

            </div>

            <!-- STEP 4 -->

            <div class="process-card">

                <div class="step-number">

                    04

                </div>

                <h3>

                    Choose Training

                </h3>

                <p>

                    Select your preferred maritime training
                    program based on your qualification
                    and professional objectives.

                </p>

            </div>

            <!-- STEP 5 -->

            <div class="process-card">

                <div class="step-number">

                    05

                </div>

                <h3>

                    Enrollment

                </h3>

                <p>

                    Submit your enrollment request.
                    Depending on your application,
                    additional documents may still be
                    requested by Admissions.

                </p>

            </div>

            <!-- STEP 6 -->

            <div class="process-card">

                <div class="step-number">

                    06

                </div>

                <h3>

                    Admissions Review

                </h3>

                <p>

                    The Admissions Office performs the
                    final evaluation of your application
                    and determines whether your enrollment
                    will be approved, deferred, or cancelled.

                </p>

            </div>

        </div>

    </div>

</section>