<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Module      : Admissions
 * File        : cta.php
 * Description : Call to Action
 * Author      : Niel Japlos
 * ---------------------------------------------------------
 */
?>

<section class="admission-cta">

    <div class="container">

        <div class="cta-card">

            <span class="section-badge">

                Ready to Begin?

            </span>

            <h2>

                Start Your USMCI Admission Today

            </h2>

            <p>

                Access your applicant account to continue your
                admission process or create a new applicant
                account if you are applying for the first time.

            </p>

            <div class="cta-actions">

                <a href="login/" class="btn-primary">

                    Login

                </a>

                <a href="register/" class="btn-secondary">

                    Create Applicant Account

                </a>

            </div>

        </div>

    </div>

</section>