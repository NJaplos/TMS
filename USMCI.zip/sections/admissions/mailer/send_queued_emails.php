<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Email Queue Worker
 * ---------------------------------------------------------
 * Drains pending rows from email_queue and actually sends
 * them. Run this on a schedule:
 *
 *   Linux/XAMPP cron (every 2 minutes) — crontab -e, add:
 *     every-2-minutes php /path/to/USMCI-TMS/sections/admissions/mailer/send_queued_emails.php
 *     (cron syntax: two asterisks, slash-2, then three more
 *     asterisks — written in prose since the literal symbols
 *     would prematurely close this comment block)
 *
 *   Windows Task Scheduler: run `php.exe` with this file as
 *   the argument, repeating every 2 minutes.
 *
 * Can also be run manually anytime from a terminal:
 *   php send_queued_emails.php
 *
 * Safe to run repeatedly/concurrently — each email is only
 * ever picked up while status = 'pending', and is updated to
 * 'sent' or 'failed' immediately after each attempt.
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/config/bootstrap.php';
require_once __DIR__ . '/SimpleSmtpMailer.php';

const MAX_ATTEMPTS = 5;
const BATCH_SIZE = 20;

function extract_reply_to(string $bodyHtml): ?string
{
    if (preg_match('/Reply-To:<\/strong>\s*([^<\n]+)/i', $bodyHtml, $matches)) {
        return trim($matches[1]);
    }

    return null;
}

function process_email_queue(): array
{
    $pdo = db();

    $stmt = $pdo->prepare(
        "SELECT id, recipient_email, subject, body_html, attempts
         FROM email_queue
         WHERE status = 'pending' AND attempts < :maxAttempts
         ORDER BY created_at ASC
         LIMIT :batchSize"
    );
    $stmt->bindValue(':maxAttempts', MAX_ATTEMPTS, PDO::PARAM_INT);
    $stmt->bindValue(':batchSize', BATCH_SIZE, PDO::PARAM_INT);
    $stmt->execute();

    $rows = $stmt->fetchAll();
    $results = ['sent' => 0, 'failed' => 0, 'total' => count($rows)];

    foreach ($rows as $row) {
        $replyTo = extract_reply_to($row['body_html']);

        $result = SimpleSmtpMailer::send(
            $row['recipient_email'],
            $row['subject'],
            $row['body_html'],
            $replyTo
        );

        if ($result['success']) {
            $update = $pdo->prepare(
                "UPDATE email_queue
                 SET status = 'sent', sent_at = NOW(), attempts = attempts + 1, error_message = NULL
                 WHERE id = :id"
            );
            $update->execute(['id' => $row['id']]);
            $results['sent']++;
        } else {
            $newAttempts = $row['attempts'] + 1;
            $newStatus = $newAttempts >= MAX_ATTEMPTS ? 'failed' : 'pending';

            $update = $pdo->prepare(
                "UPDATE email_queue
                 SET status = :status, attempts = :attempts, error_message = :error
                 WHERE id = :id"
            );
            $update->execute([
                'status' => $newStatus,
                'attempts' => $newAttempts,
                'error' => $result['error'],
                'id' => $row['id'],
            ]);
            $results['failed']++;
        }
    }

    return $results;
}

// Only auto-run when executed directly (php send_queued_emails.php),
// not when included/required by another script (e.g. the "Send Now"
// button endpoint, which calls process_email_queue() itself and
// handles the result as JSON instead of plain text).
if (realpath($_SERVER['SCRIPT_FILENAME'] ?? '') === __FILE__) {
    $summary = process_email_queue();

    echo sprintf(
        "[%s] Processed %d email(s): %d sent, %d failed.\n",
        date('Y-m-d H:i:s'),
        $summary['total'],
        $summary['sent'],
        $summary['failed']
    );
}
