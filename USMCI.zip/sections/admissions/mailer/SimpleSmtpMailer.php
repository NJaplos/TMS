<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Simple SMTP Mailer
 * ---------------------------------------------------------
 * A minimal, dependency-free SMTP client — no Composer/
 * PHPMailer required. Supports STARTTLS + AUTH LOGIN, which
 * is exactly what Gmail SMTP needs (smtp.gmail.com:587),
 * matching the setup already documented in config/mail.php.
 *
 * If SMTP isn't configured yet (SMTP_HOST is empty/undefined),
 * falls back to PHP's built-in mail() — works for basic local
 * testing, but real delivery (especially to Gmail/Outlook
 * inboxes rather than spam) needs real SMTP configured.
 * ---------------------------------------------------------
 */

declare(strict_types=1);

final class SimpleSmtpMailer
{
    /**
     * @return array{success: bool, error: ?string}
     */
    public static function send(string $toEmail, string $subject, string $bodyHtml, ?string $replyTo = null): array
    {
        $useSmtp = defined('SMTP_HOST') && SMTP_HOST !== '';

        if ($useSmtp) {
            return self::sendViaSmtp($toEmail, $subject, $bodyHtml, $replyTo);
        }

        return self::sendViaPhpMail($toEmail, $subject, $bodyHtml, $replyTo);
    }

    private static function sendViaPhpMail(string $toEmail, string $subject, string $bodyHtml, ?string $replyTo): array
    {
        $fromEmail = defined('WEBSITE_FROM_EMAIL') ? WEBSITE_FROM_EMAIL : 'no-reply@localhost';
        $fromName = defined('WEBSITE_FROM_NAME') ? WEBSITE_FROM_NAME : 'USMCI-TMS';

        $headers = "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
        $headers .= "From: {$fromName} <{$fromEmail}>\r\n";

        if ($replyTo !== null && $replyTo !== '') {
            $headers .= "Reply-To: {$replyTo}\r\n";
        }

        $sent = @mail($toEmail, $subject, $bodyHtml, $headers);

        return $sent
            ? ['success' => true, 'error' => null]
            : ['success' => false, 'error' => 'PHP mail() returned false — check your php.ini sendmail/SMTP settings.'];
    }

    private static function sendViaSmtp(string $toEmail, string $subject, string $bodyHtml, ?string $replyTo): array
    {
        $host = SMTP_HOST;
        $port = defined('SMTP_PORT') ? (int) SMTP_PORT : 587;
        $encryption = defined('SMTP_ENCRYPTION') ? SMTP_ENCRYPTION : 'tls';
        $username = defined('SMTP_USERNAME') ? SMTP_USERNAME : '';
        $password = defined('SMTP_PASSWORD') ? SMTP_PASSWORD : '';
        $fromEmail = defined('WEBSITE_FROM_EMAIL') ? WEBSITE_FROM_EMAIL : $username;
        $fromName = defined('WEBSITE_FROM_NAME') ? WEBSITE_FROM_NAME : 'USMCI-TMS';

        $socket = @stream_socket_client(
            "tcp://{$host}:{$port}",
            $errno,
            $errstr,
            15,
            STREAM_CLIENT_CONNECT
        );

        if ($socket === false) {
            return ['success' => false, 'error' => "Could not connect to {$host}:{$port} — {$errstr}"];
        }

        try {
            self::expect($socket, 220);
            self::command($socket, "EHLO " . gethostname(), 250);

            if ($encryption === 'tls') {
                self::command($socket, "STARTTLS", 220);

                if (!stream_socket_enable_crypto($socket, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) {
                    return ['success' => false, 'error' => 'STARTTLS negotiation failed.'];
                }

                self::command($socket, "EHLO " . gethostname(), 250);
            }

            if ($username !== '') {
                self::command($socket, "AUTH LOGIN", 334);
                self::command($socket, base64_encode($username), 334);
                self::command($socket, base64_encode($password), 235);
            }

            self::command($socket, "MAIL FROM:<{$fromEmail}>", 250);
            self::command($socket, "RCPT TO:<{$toEmail}>", 250);
            self::command($socket, "DATA", 354);

            $headers = "From: {$fromName} <{$fromEmail}>\r\n";
            $headers .= "To: <{$toEmail}>\r\n";
            $headers .= "Subject: {$subject}\r\n";
            $headers .= "MIME-Version: 1.0\r\n";
            $headers .= "Content-Type: text/html; charset=UTF-8\r\n";

            if ($replyTo !== null && $replyTo !== '') {
                $headers .= "Reply-To: {$replyTo}\r\n";
            }

            // Dot-stuff any line that starts with a lone "." per RFC 5321.
            $escapedBody = preg_replace('/^\./m', '..', $bodyHtml);

            self::command($socket, $headers . "\r\n" . $escapedBody . "\r\n.", 250);
            self::command($socket, "QUIT", 221);

            return ['success' => true, 'error' => null];
        } catch (RuntimeException $exception) {
            return ['success' => false, 'error' => $exception->getMessage()];
        } finally {
            fclose($socket);
        }
    }

    /** @param resource $socket */
    private static function command($socket, string $line, int $expectedCode): string
    {
        fwrite($socket, $line . "\r\n");

        return self::expect($socket, $expectedCode);
    }

    /** @param resource $socket */
    private static function expect($socket, int $expectedCode): string
    {
        $response = '';

        while ($line = fgets($socket, 515)) {
            $response .= $line;

            // Multi-line SMTP responses use "code-" until the final "code ".
            if (isset($line[3]) && $line[3] === ' ') {
                break;
            }
        }

        $actualCode = (int) substr($response, 0, 3);

        if ($actualCode !== $expectedCode) {
            throw new RuntimeException("Expected SMTP {$expectedCode}, got: " . trim($response));
        }

        return $response;
    }
}
