<?php
$status = $_GET['status'] ?? '';
$inquiryNo = $_GET['inquiry_no'] ?? '';
$message = $_GET['message'] ?? '';
?>

<?php if ($status === 'success'): ?>
    <div id="inquiry-success" class="inquiry-feedback inquiry-feedback--success">
        <strong>Inquiry sent successfully.</strong>
        <?php if ($inquiryNo !== ''): ?>
            <span>Your reference number is <?= htmlspecialchars($inquiryNo, ENT_QUOTES, 'UTF-8'); ?>.</span>
        <?php endif; ?>
    </div>
<?php elseif ($status === 'error'): ?>
    <div id="inquiry-success" class="inquiry-feedback inquiry-feedback--error">
        <strong>Inquiry was not sent.</strong>
        <span><?= htmlspecialchars($message !== '' ? $message : 'Please check the form and try again.', ENT_QUOTES, 'UTF-8'); ?></span>
    </div>
<?php endif; ?>
