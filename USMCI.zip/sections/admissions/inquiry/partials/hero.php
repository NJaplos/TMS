<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Module      : Admissions Inquiry
 * File        : hero.php
 * Version     : 2.0
 * Description : Inquiry Sidebar (redesigned — no longer a
 *               stacked hero; sits beside the form as a
 *               fixed-width panel so nothing overlaps)
 * ---------------------------------------------------------
 */
?>

<section class="inquiry-hero">

    <div class="inquiry-hero__inner">

        <span class="admissions-badge">
            Admissions Office
        </span>

        <h1>
            Admissions Inquiry
        </h1>

        <p>
            Have questions about our maritime training programs?
            Our team can help with courses, schedules, requirements,
            and fees.
        </p>

        <ul class="hero-features">

            <li>
                <span><i class="fas fa-check"></i>✓</span>
                Course Information
            </li>

            <li>
                <span>✓</span>
                Training Schedule
            </li>

            <li>
                <span>✓</span>
                Enrollment Requirements
            </li>

            <li>
                <span>✓</span>
                Training Fees
            </li>

        </ul>

        <div class="info-card">

            <div class="info-icon">
                ⏱
            </div>

            <div class="info-text">

                <strong>Estimated Response Time</strong>

                <p>
                    We usually respond within one (1) business day.
                </p>

            </div>

        </div>

    </div>

</section>