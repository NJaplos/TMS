<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Module      : Admissions
 * Page        : Inquiry
 * File        : index.php
 * Version     : 2.0
 * Description : Admissions Inquiry Page — now uses the same
 *               full page shell as the homepage (head, navbar,
 *               footer, scripts), rather than being a bare
 *               content fragment with no navbar/head at all.
 * ---------------------------------------------------------
 */

$page = [
    'title'       => 'Admissions Inquiry — USMCI Training Management System',
    'description' => 'Send an admissions inquiry to United Seafarers Maritime Center, Inc.',
    'bodyClass'   => 'admissions-inquiry-page'
];
?>

<?php
// Path to the project root (USMCI-TMS/), three levels up from
// sections/admissions/inquiry/. Relative, so it works regardless
// of how the docroot is configured.
$root = __DIR__ . '/../../../';
?>

<!DOCTYPE html>
<html lang="en">

<?php include $root . 'includes/head.php'; ?>

<link rel="stylesheet" href="/USMCI-TMS/sections/admissions/inquiry/style.css">

<body class="<?= $page['bodyClass']; ?>">

    <!-- Navigation -->
    <?php include $root . 'navbar/index.php'; ?>

    <main id="main-content">

        <section id="admissions-inquiry" class="admissions-inquiry">

            <?php require __DIR__ . '/partials/hero.php'; ?>

            <?php require __DIR__ . '/partials/form.php'; ?>

        </section>

    </main>

    <?php include $root . 'includes/footer.php'; ?>

    <?php include $root . 'includes/scripts.php'; ?>

    <script src="/USMCI-TMS/sections/admissions/inquiry/script.js"></script>

</body>

</html>
