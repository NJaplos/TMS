<?php

declare(strict_types=1);

require_once __DIR__ . '/../../../config/database.php';
require_once __DIR__ . '/../../../config/mail.php';

function clean_text(?string $value, int $maxLength): string
{
    $value = trim((string) $value);
    $value = preg_replace('/\s+/', ' ', $value) ?? '';
    return mb_substr($value, 0, $maxLength);
}

function generate_reference(PDO $pdo, string $sequenceCode): string
{
    $year = (int) date('Y');

    $pdo->beginTransaction();

    $select = $pdo->prepare(
        'SELECT id, current_value, prefix, padding_length
         FROM sequence_generator
         WHERE sequence_code = :code AND sequence_year = :year
         FOR UPDATE'
    );
    $select->execute([
        ':code' => $sequenceCode,
        ':year' => $year,
    ]);

    $sequence = $select->fetch();

    if (!$sequence) {
        $insert = $pdo->prepare(
            'INSERT INTO sequence_generator (sequence_code, sequence_year, current_value, prefix, padding_length)
             VALUES (:code, :year, 0, :prefix, 6)'
        );
        $insert->execute([
            ':code' => $sequenceCode,
            ':year' => $year,
            ':prefix' => $sequenceCode,
        ]);

        $select->execute([
            ':code' => $sequenceCode,
            ':year' => $year,
        ]);
        $sequence = $select->fetch();
    }

    $nextValue = ((int) $sequence['current_value']) + 1;

    $update = $pdo->prepare(
        'UPDATE sequence_generator SET current_value = :value WHERE id = :id'
    );
    $update->execute([
        ':value' => $nextValue,
        ':id' => $sequence['id'],
    ]);

    $reference = sprintf(
        '%s-%d-%s',
        $sequence['prefix'],
        $year,
        str_pad((string) $nextValue, (int) $sequence['padding_length'], '0', STR_PAD_LEFT)
    );

    $pdo->commit();

    return $reference;
}

function get_lookup_id(PDO $pdo, string $table, string $code): ?int
{
    $allowedTables = [
        'mnt_inquiry_type',
    ];

    if (!in_array($table, $allowedTables, true)) {
        return null;
    }

    $stmt = $pdo->prepare("SELECT id FROM {$table} WHERE code = :code LIMIT 1");
    $stmt->execute([':code' => $code]);
    $row = $stmt->fetch();

    return $row ? (int) $row['id'] : null;
}

function validate_inquiry(array $post): array
{
    $data = [
        'fullname' => clean_text($post['fullname'] ?? '', 200),
        'email' => clean_text($post['email'] ?? '', 150),
        'mobile' => clean_text($post['mobile'] ?? '', 50),
        'preferred_contact' => clean_text($post['preferred_contact'] ?? 'Email', 50),
        'course' => clean_text($post['course'] ?? '', 150),
        'schedule' => clean_text($post['schedule'] ?? 'No Preference', 50),
        'preferred_date' => clean_text($post['preferred_date'] ?? '', 20),
        'subject' => clean_text($post['subject'] ?? '', 255),
        'message' => trim((string) ($post['message'] ?? '')),
        'privacy_agree' => isset($post['privacy_agree']),
    ];

    $errors = [];

    if ($data['fullname'] === '') {
        $errors[] = 'Full name is required.';
    }

    if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'A valid email address is required.';
    }

    if ($data['mobile'] === '') {
        $errors[] = 'Mobile number is required.';
    }

    if ($data['course'] === '') {
        $errors[] = 'Preferred course is required.';
    }

    if ($data['subject'] === '') {
        $errors[] = 'Subject is required.';
    }

    if ($data['message'] === '') {
        $errors[] = 'Message is required.';
    }

    if (mb_strlen($data['message']) > 1000) {
        $errors[] = 'Message must not exceed 1000 characters.';
    }

    if (!$data['privacy_agree']) {
        $errors[] = 'Data privacy agreement is required.';
    }

    if ($data['preferred_date'] !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $data['preferred_date'])) {
        $errors[] = 'Preferred date is invalid.';
    }

    return [$data, $errors];
}

function save_inquiry(array $data): string
{
    $pdo = db();
    $inquiryNo = generate_reference($pdo, 'INQ');
    $inquiryTypeId = get_lookup_id($pdo, 'mnt_inquiry_type', 'ADMISSION');

    $message = "Preferred Contact: {$data['preferred_contact']}\n"
        . "Preferred Course: {$data['course']}\n"
        . "Preferred Schedule: {$data['schedule']}\n"
        . "Preferred Date: " . ($data['preferred_date'] !== '' ? $data['preferred_date'] : 'No preference') . "\n\n"
        . $data['message'];

    $pdo->beginTransaction();

    $stmt = $pdo->prepare(
        'INSERT INTO inquiry (
            inquiry_no, inquiry_type_id, full_name, email, mobile_no,
            preferred_contact, course_interest, preferred_schedule, preferred_date,
            subject, message, source, created_at, updated_at
        ) VALUES (
            :inquiry_no, :inquiry_type_id, :full_name, :email, :mobile_no,
            :preferred_contact, :course_interest, :preferred_schedule, :preferred_date,
            :subject, :message, :source, NOW(), NOW()
        )'
    );
    $stmt->execute([
        ':inquiry_no' => $inquiryNo,
        ':inquiry_type_id' => $inquiryTypeId,
        ':full_name' => $data['fullname'],
        ':email' => $data['email'],
        ':mobile_no' => $data['mobile'],
        ':preferred_contact' => $data['preferred_contact'],
        ':course_interest' => $data['course'],
        ':preferred_schedule' => $data['schedule'],
        ':preferred_date' => $data['preferred_date'] !== '' ? $data['preferred_date'] : null,
        ':subject' => $data['subject'],
        ':message' => $message,
        ':source' => 'website',
    ]);

    $inquiryId = (int) $pdo->lastInsertId();

    $comm = $pdo->prepare(
        'INSERT INTO communication_log (
            inquiry_id, channel, direction, subject, message, created_at
        ) VALUES (
            :inquiry_id, :channel, :direction, :subject, :message, NOW()
        )'
    );
    $comm->execute([
        ':inquiry_id' => $inquiryId,
        ':channel' => 'email',
        ':direction' => 'inbound',
        ':subject' => $data['subject'],
        ':message' => $message,
    ]);

    queue_admin_email($pdo, $inquiryNo, $data, $message);

    $pdo->commit();

    return $inquiryNo;
}

function queue_admin_email(PDO $pdo, string $inquiryNo, array $data, string $message): void
{
    $subject = "[{$inquiryNo}] New Admissions Inquiry: {$data['subject']}";
    $body = '<h2>New Admissions Inquiry</h2>'
        . '<p><strong>Inquiry No:</strong> ' . htmlspecialchars($inquiryNo, ENT_QUOTES, 'UTF-8') . '</p>'
        . '<p><strong>Name:</strong> ' . htmlspecialchars($data['fullname'], ENT_QUOTES, 'UTF-8') . '</p>'
        . '<p><strong>Email:</strong> ' . htmlspecialchars($data['email'], ENT_QUOTES, 'UTF-8') . '</p>'
        . '<p><strong>Mobile:</strong> ' . htmlspecialchars($data['mobile'], ENT_QUOTES, 'UTF-8') . '</p>'
        . '<p><strong>Reply-To:</strong> ' . htmlspecialchars($data['email'], ENT_QUOTES, 'UTF-8') . '</p>'
        . '<hr><pre style="font-family:Arial,sans-serif;white-space:pre-wrap;">'
        . htmlspecialchars($message, ENT_QUOTES, 'UTF-8')
        . '</pre>';

    $stmt = $pdo->prepare(
        'INSERT INTO email_queue (
            recipient_email, subject, body_html, status, scheduled_at, created_at
        ) VALUES (
            :recipient_email, :subject, :body_html, :status, NOW(), NOW()
        )'
    );
    $stmt->execute([
        ':recipient_email' => ADMIN_INQUIRY_EMAIL,
        ':subject' => $subject,
        ':body_html' => $body,
        ':status' => 'pending',
    ]);

    if (MAIL_SEND_IMMEDIATELY) {
        $headers = [
            'MIME-Version: 1.0',
            'Content-type: text/html; charset=UTF-8',
            'From: ' . WEBSITE_FROM_NAME . ' <' . WEBSITE_FROM_EMAIL . '>',
            'Reply-To: ' . $data['fullname'] . ' <' . $data['email'] . '>',
        ];

        @mail(ADMIN_INQUIRY_EMAIL, $subject, $body, implode("\r\n", $headers));
    }
}
