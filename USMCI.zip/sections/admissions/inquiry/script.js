document.addEventListener("DOMContentLoaded", () => {

    const message = document.getElementById("message");

    const counter = document.getElementById("messageCount");

    if(message){

        message.addEventListener("input",()=>{

            counter.textContent = message.value.length;

        });

    }

    /* --------------------------------------------------------
       Inquiry submission toast — auto-fades after a few
       seconds instead of sitting as a permanent inline message.
       Also cleans the ?status=... query string out of the URL
       once shown, so refreshing the page doesn't re-trigger it.
    -------------------------------------------------------- */

    const toast = document.getElementById("inquiry-toast");

    if(toast){

        const AUTO_DISMISS_MS = 4000;
        const FADE_DURATION_MS = 400;

        window.setTimeout(() => {

            toast.classList.add("is-hiding");

            window.setTimeout(() => {

                toast.remove();

            }, FADE_DURATION_MS);

        }, AUTO_DISMISS_MS);

        if(window.history && window.history.replaceState){

            const url = new URL(window.location.href);
            url.searchParams.delete("status");
            url.searchParams.delete("inquiry_no");
            url.searchParams.delete("message");
            window.history.replaceState({}, document.title, url.toString());

        }

    }

    /* Section sizing (fit-to-viewport, navbar clearance) is now
       handled entirely by the shared --hero-top-offset /
       --hero-total-height CSS variables — see
       sections/hero/modules/offset.js and
       sections/admissions/inquiry/css/layout.css. That module
       runs on every page (via includes/scripts.php), so nothing
       page-specific is needed here anymore. */

});