<?php

declare(strict_types=1);

require_once __DIR__ . '/inquiry_service.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: /USMCI-TMS/sections/admissions/inquiry/index.php');
    exit;
}

[$data, $errors] = validate_inquiry($_POST);

if ($errors) {
    $message = urlencode(implode(' ', $errors));
    header('Location: /USMCI-TMS/sections/admissions/inquiry/index.php?status=error&message=' . $message);
    exit;
}

try {
    $inquiryNo = save_inquiry($data);
    header('Location: /USMCI-TMS/sections/admissions/inquiry/index.php?status=success&inquiry_no=' . urlencode($inquiryNo));
    exit;
} catch (Throwable $exception) {
    error_log($exception->getMessage());
    header('Location: /USMCI-TMS/sections/admissions/inquiry/index.php?status=error&message=' . urlencode('Inquiry could not be sent right now. Please try again.'));
    exit;
}
