<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Invite Applicant to Enroll
 * ---------------------------------------------------------
 * Called when staff clicks "Create Applicant Account" /
 * "Create Applicant" in the Inquiry Queue. Creates a stub
 * `applicant` row (if one doesn't already exist for this
 * inquiry), generates a single-use registration token, stores
 * only its HASH, and queues the invitation email.
 *
 * SECURITY NOTE: the raw token only ever exists in memory and
 * in the emailed URL — it is never written to the database or
 * logged. Only sha256(token) is stored, in applicant_invitation
 * .token_hash. Even a full database leak can't be used to
 * register as someone else; the attacker would still need the
 * original token, which only exists in the recipient's inbox.
 * ---------------------------------------------------------
 */

declare(strict_types=1);

if (!defined('USMCI_BOOTSTRAP')) {
    require_once dirname(__DIR__, 2) . '/config/bootstrap.php';
}

const INVITATION_VALID_DAYS = 7;

/**
 * @return array{success: bool, message: string, inquiry_no?: string}
 */
function invite_applicant_to_enroll(int $inquiryId, int $staffId): array
{
    $pdo = db();

    $pdo->beginTransaction();

    try {
        $inquiryStmt = $pdo->prepare(
            "SELECT id, inquiry_no, applicant_id, full_name, email, status_id
             FROM inquiry WHERE id = :id FOR UPDATE"
        );
        $inquiryStmt->execute(['id' => $inquiryId]);
        $inquiry = $inquiryStmt->fetch();

        if (!$inquiry) {
            throw new RuntimeException('Inquiry not found.');
        }

        if ($inquiry['email'] === null || trim($inquiry['email']) === '') {
            throw new RuntimeException('This inquiry has no email address on file — cannot send an invitation.');
        }

        $applicantId = $inquiry['applicant_id'];

        if ($applicantId === null) {
            [$firstName, $lastName] = split_full_name($inquiry['full_name']);
            $applicantNo = generate_applicant_no($pdo);

            $insertApplicant = $pdo->prepare(
                "INSERT INTO applicant (applicant_no, first_name, last_name, email, created_at)
                 VALUES (:applicant_no, :first_name, :last_name, :email, NOW())"
            );
            $insertApplicant->execute([
                'applicant_no' => $applicantNo,
                'first_name' => $firstName,
                'last_name' => $lastName,
                'email' => $inquiry['email'],
            ]);

            $applicantId = (int) $pdo->lastInsertId();

            $pdo->prepare("UPDATE inquiry SET applicant_id = :applicant_id WHERE id = :id")
                ->execute(['applicant_id' => $applicantId, 'id' => $inquiryId]);
        }

        $pdo->prepare(
            "UPDATE applicant_invitation
             SET used_at = NOW()
             WHERE inquiry_id = :inquiry_id AND used_at IS NULL"
        )->execute(['inquiry_id' => $inquiryId]);

        $rawToken = bin2hex(random_bytes(32));
        $tokenHash = hash('sha256', $rawToken);
        $expiresAt = (new DateTimeImmutable("+" . INVITATION_VALID_DAYS . " days"))->format('Y-m-d H:i:s');

        $insertInvitation = $pdo->prepare(
            "INSERT INTO applicant_invitation
                (inquiry_id, applicant_id, token_hash, email, expires_at, created_by, created_at)
             VALUES
                (:inquiry_id, :applicant_id, :token_hash, :email, :expires_at, :created_by, NOW())"
        );
        $insertInvitation->execute([
            'inquiry_id' => $inquiryId,
            'applicant_id' => $applicantId,
            'token_hash' => $tokenHash,
            'email' => $inquiry['email'],
            'expires_at' => $expiresAt,
            'created_by' => $staffId,
        ]);

        $invitedStatusId = $pdo->query(
            "SELECT id FROM mnt_inquiry_status WHERE code = 'INVITED'"
        )->fetchColumn();

        $pdo->prepare("UPDATE inquiry SET status_id = :status_id, assigned_to = :staff_id WHERE id = :id")
            ->execute(['status_id' => $invitedStatusId, 'staff_id' => $staffId, 'id' => $inquiryId]);

        $registrationUrl = build_registration_url($rawToken);
        $bodyHtml = render_invitation_email($inquiry['full_name'], $registrationUrl, INVITATION_VALID_DAYS);

        $pdo->prepare(
            "INSERT INTO email_queue (recipient_email, subject, body_html, status, scheduled_at, created_at)
             VALUES (:email, :subject, :body, 'pending', NOW(), NOW())"
        )->execute([
            'email' => $inquiry['email'],
            'subject' => 'You\'re invited to create your USMCI Admissions account',
            'body' => $bodyHtml,
        ]);

        $pdo->commit();

        return [
            'success' => true,
            'message' => 'Invitation sent.',
            'inquiry_no' => $inquiry['inquiry_no'],
        ];
    } catch (Throwable $exception) {
        $pdo->rollBack();
        error_log('invite_applicant_to_enroll failed: ' . $exception->getMessage());

        return ['success' => false, 'message' => $exception->getMessage()];
    }
}

/** @return array{0: string, 1: string} */
function split_full_name(string $fullName): array
{
    $parts = preg_split('/\s+/', trim($fullName), 2);

    return [$parts[0] ?? $fullName, $parts[1] ?? ''];
}

function generate_applicant_no(PDO $pdo): string
{
    $year = date('Y');
    $count = (int) $pdo->query(
        "SELECT COUNT(*) FROM applicant WHERE applicant_no LIKE 'APP-{$year}-%'"
    )->fetchColumn();

    return sprintf('APP-%s-%06d', $year, $count + 1);
}

function build_registration_url(string $rawToken): string
{
    return rtrim(WEBSITE_BASE_URL, '/') . '/sections/admissions/register.php?token=' . urlencode($rawToken);
}

function render_invitation_email(string $fullName, string $registrationUrl, int $validDays): string
{
    $safeName = htmlspecialchars($fullName, ENT_QUOTES, 'UTF-8');
    $safeUrl = htmlspecialchars($registrationUrl, ENT_QUOTES, 'UTF-8');

    return <<<HTML
        <h2>You're invited to continue your application</h2>
        <p>Hi {$safeName},</p>
        <p>Thank you for your interest in USMCI's maritime training programs. You're invited to
        create your Admissions Portal account to continue your application online.</p>
        <p><a href="{$safeUrl}" style="display:inline-block;padding:12px 24px;background:#0D8A72;color:#fff;
        text-decoration:none;border-radius:8px;">Create My Account</a></p>
        <p style="color:#6B7280;font-size:.85rem;">This link is valid for {$validDays} days and can only
        be used once. If you didn't request this, you can safely ignore this email.</p>
    HTML;
}
