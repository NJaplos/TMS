<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Admissions Portal
 * ---------------------------------------------------------
 */

$pageTitle = "Admissions Portal";
?>


<link rel="stylesheet" href="/USMCI-TMS/sections/admissions/style.css">

<section id="admissions-portal" class="admissions-portal">

    <?php require 'partials/sidebar.php'; ?>

    <main class="portal-content">

        <?php require 'partials/status.php'; ?>

        <?php require 'partials/process.php'; ?>

        <?php require 'partials/requirements.php'; ?>

        <?php require 'partials/programs.php'; ?>

        <?php require 'partials/faq.php'; ?>

        <?php require 'partials/cta.php'; ?>

    </main>

    <?php require 'partials/right-panel.php'; ?>

</section>

<script src="/USMCI-TMS/sections/admissions/assets/js/portal.js"></script>

<script src="/USMCI-TMS/sections/admissions/assets/js/slideshow.js"></script>