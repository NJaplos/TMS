<?php
/*
|--------------------------------------------------------------------------
| HERO ACCREDITATION
|--------------------------------------------------------------------------
*/
?>

<section class="hero-partners">

    <h3 class="hero-partners__title">

        Accredited and Recognized By

    </h3>

    <div class="hero-partners__logos">

        <img
            src="assets/images/partners/tesda.png"
            alt="TESDA">

        
        <img
            src="assets/images/partners/marina.png"
            alt="MARINA">


        <img
            src="assets/images/partners/iso.png"
            alt="ISO 9001">

    </div>

</section>