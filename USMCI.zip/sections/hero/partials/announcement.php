<?php
/*
|--------------------------------------------------------------------------
| HERO ANNOUNCEMENT
|--------------------------------------------------------------------------
*/
?>

<div class="hero-announcement">

    <span class="hero-announcement__icon">

        📢

    </span>

    <span class="hero-announcement__text">

        Admissions for Academic Year 2026 are now officially open.

    </span>

</div>