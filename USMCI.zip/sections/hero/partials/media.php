<div class="hero__media">

    <div class="hero-panel">

        <div class="hero-carousel">

            <div class="hero-slide is-active">

                <img
                    src="assets/images/hero/hero-officer.png"
                    alt="USMCI">

            </div>

            <div class="hero-slide">

                <img
                    src="assets/images/hero/hero-training.jpg"
                    alt="Training">

            </div>

            <div class="hero-slide">

                <img
                    src="assets/images/hero/hero-simulator.jpg"
                    alt="Simulator">

            </div>

        </div>

        <div class="hero-badge">

            ★ 25+ Years

        </div>

        <div class="hero-info">

            <h3>

                Why Choose USMCI

            </h3>

            <ul>

                <li>International Standards</li>

                <li>Experienced Instructors</li>

                <li>Modern Training Facilities</li>

                <li>Career Development</li>

            </ul>

        </div>

        <?php include __DIR__ . '/accreditation.php'; ?>

    </div>

</div>