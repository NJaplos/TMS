<?php
/*
|--------------------------------------------------------------------------
| HERO STATISTICS
|--------------------------------------------------------------------------
*/
?>

<div class="hero-statistics">

    <article class="hero-stat">

        <div class="hero-stat__icon">⚓</div>

        <h3>25+</h3>

        <p>Training Programs</p>

    </article>

    <article class="hero-stat">

        <div class="hero-stat__icon">🌍</div>

        <h3>100%</h3>

        <p>Industry Standard</p>

    </article>

    <article class="hero-stat">

        <div class="hero-stat__icon">🎓</div>

        <h3>15K+</h3>

        <p>Cadets Trained</p>

    </article>

    <article class="hero-stat">

        <div class="hero-stat__icon">🛟</div>

        <h3>24/7</h3>

        <p>Learning Support</p>

    </article>

</div>