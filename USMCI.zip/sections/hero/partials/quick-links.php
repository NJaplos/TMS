<?php
/*
|--------------------------------------------------------------------------
| HERO QUICK LINKS
|--------------------------------------------------------------------------
*/
?>

<nav class="hero-quick-links">

    <a href="#courses">

        Courses

    </a>

    <a href="#admission">

        Admissions

    </a>

    <a href="#facilities">

        Facilities

    </a>

    <a href="#contact">

        Contact

    </a>

</nav>