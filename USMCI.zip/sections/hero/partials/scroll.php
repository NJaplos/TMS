<div class="hero__scroll">

    <span>

        Scroll to Explore

    </span>

    <div class="hero__mouse">

        <span></span>

    </div>

</div>