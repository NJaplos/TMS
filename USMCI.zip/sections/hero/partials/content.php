<?php
/*
|--------------------------------------------------------------------------
| HERO CONTENT
|--------------------------------------------------------------------------
*/
?>

<div class="hero__content">

    <p class="hero__eyebrow">

        Maritime Excellence Since 2010

    </p>

    <h1 class="hero__title">

        THERE IS

        <br>

        <span>A BETTER CHOICE!</span>

    </h1>

    <h2 class="hero__subtitle">

        United Searafers Maritime Center, Inc.

    </h2>

    <p class="hero__description">

        Delivering internationally recognized maritime education,
        professional certification programs, and industry-driven
        training that prepare cadets and professionals for global
        opportunities.

    </p>

    <div class="hero__actions">

        <a
            href="#courses"
            class="btn btn--primary">

            <span class="btn__icon">

                📚

            </span>

            <span class="btn__content">

                <strong>Explore Courses</strong>

                <small>View our training programs</small>

            </span>

        </a>

        <a
            href="sections/admissions/inquiry/index.php"
            class="btn btn--secondary">

            <span class="btn__icon">

                📝

            </span>

            <span class="btn__content">

                <strong>Make an Inquiry</strong>

                <small>Start your enrollment today</small>

            </span>

        </a>

    </div>

    <?php include __DIR__ . '/announcement.php'; ?>

</div>