<?php
/*
|--------------------------------------------------------------------------
| USMCI-TMS
|--------------------------------------------------------------------------
| Navigation Portal
|--------------------------------------------------------------------------
| Niel Japlos
|--------------------------------------------------------------------------
*/
?>

<section id="hero" class="hero">

    <div class="container">

        <div class="hero__grid">

            <?php include __DIR__ . '/partials/content.php'; ?>

            <?php include __DIR__ . '/partials/media.php'; ?>

        </div>

        <?php include __DIR__ . '/partials/statistics.php'; ?>

        <?php // include __DIR__ . '/partials/quick-links.php'; ?>

        <?php // include __DIR__ . '/partials/scroll.php'; ?>

    </div>

</section>