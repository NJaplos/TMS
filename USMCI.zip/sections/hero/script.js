/*=========================================================
    MTOUCH DESIGN SYSTEM
    HERO PORTAL
    -------------------------------------------------------

    Hero Portal Controller

    File        : script.js
    Version     : 1.0.0
    Author      : Niel Japlos
=========================================================*/

"use strict";

document.addEventListener("DOMContentLoaded",()=>{

    Hero.init();

});

const Hero={

    init(){

        HeroOffset.init();

        HeroCarousel.init();

        HeroCounter.init();

        HeroReveal.init();

        HeroScroll.init();

    }

};