const HeroReveal={

    init(){

        const observer=new IntersectionObserver(entries=>{

            entries.forEach(entry=>{

                if(entry.isIntersecting){

                    entry.target.classList.add("is-visible");

                }

            });

        },{

            threshold:HeroConfig.reveal.threshold

        });

        document.querySelectorAll(".reveal")

        .forEach(el=>observer.observe(el));

    }

};