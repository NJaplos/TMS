const HeroCounter={

    init(){

        document

        .querySelectorAll(".c-stat__value")

        .forEach(counter=>{

            this.animate(counter);

        });

    },

    animate(el){

        const target=parseInt(el.dataset.target);

        if(!target) return;

        let current=0;

        const step=Math.ceil(target/100);

        const timer=setInterval(()=>{

            current+=step;

            if(current>=target){

                current=target;

                clearInterval(timer);

            }

            el.textContent=current;

        },15);

    }

};