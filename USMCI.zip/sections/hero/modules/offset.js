/*=========================================================
    USMCI-TMS
    HERO PORTAL
    -------------------------------------------------------

    Hero Offset & Fit Module

    Two jobs, both replacing hardcoded guesses with real
    runtime measurements:

    1) --hero-top-offset: clears the fixed navbar (see
       navbar/css/desktop.css) using its REAL height instead
       of a guessed padding-top value.

    2) --hero-total-height: sizes the Hero section to the
       actual viewport height, the same fit-to-screen pattern
       used on the Admissions Inquiry page — instead of the
       old min-height:50vh, which let the section grow to
       whatever height its content demanded (the "doesn't fit
       my screen" bug).

    Recalculates on load, resize, orientation change, and
    when the navbar's sticky state changes (the sticky navbar
    is shorter — see sticky.css).

    File        : offset.js
    Version     : 2.0.0
=========================================================*/

"use strict";

const HeroOffset = {

    init(){

        this.measure();

        window.addEventListener("resize", () => this.measure());
        window.addEventListener("orientationchange", () => this.measure());

        const navbar = document.getElementById("navbar");

        if(navbar){

            const observer = new MutationObserver(() => this.measure());

            observer.observe(navbar, {
                attributes: true,
                attributeFilter: ["class"]
            });

        }

    },

    measure(){

        const navbar = document.getElementById("navbar");

        const navHeight = navbar ? navbar.getBoundingClientRect().height : 96;

        const offset = Math.round(navHeight + 24);

        document.documentElement.style.setProperty(
            "--hero-top-offset",
            offset + "px"
        );

        document.documentElement.style.setProperty(
            "--hero-total-height",
            window.innerHeight + "px"
        );

    }

};
