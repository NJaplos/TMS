const HeroCarousel={

    current:0,

    slides:[],

    timer:null,

    init(){

        this.slides=[

            ...document.querySelectorAll(".hero-slide")

        ];

        if(!this.slides.length) return;

        this.show(0);

        this.auto();

    },

    show(index){

        this.slides.forEach(slide=>{

            slide.classList.remove("is-active");

        });

        this.slides[index].classList.add("is-active");

        this.current=index;

    },

    next(){

        let next=this.current+1;

        if(next>=this.slides.length){

            next=0;

        }

        this.show(next);

    },

    auto(){

        if(!HeroConfig.carousel.autoplay) return;

        this.timer=setInterval(()=>{

            this.next();

        },HeroConfig.carousel.interval);

    }

};