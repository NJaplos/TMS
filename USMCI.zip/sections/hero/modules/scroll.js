const HeroScroll={

    init(){

        const scroll=document.querySelector(".hero__scroll");

        if(!scroll) return;

        scroll.onclick=()=>{

            document

            .querySelector("#about")

            ?.scrollIntoView({

                behavior:HeroConfig.scroll.behavior

            });

        };

    }

};