/*=========================================================
    HERO CONFIGURATION

=========================================================*/

"use strict";

const HeroConfig = {

    carousel:{

        autoplay:true,

        interval:5000,

        pauseOnHover:true,

        keyboard:true,

        touch:true

    },

    counter:{

        duration:1800

    },

    reveal:{

        threshold:.15

    },

    scroll:{

        behavior:"smooth"

    }

};