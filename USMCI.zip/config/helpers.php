<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Global Helper Functions
 * File : config/helpers.php
 * Version : 3.1
 *
 * Description
 * ---------------------------------------------------------
 * Global helper functions used throughout the
 * entire USMCI-TMS application.
 *
 * This file is automatically loaded by
 * config/bootstrap.php.
 * ---------------------------------------------------------
 */

if (!defined('USMCI_CONFIG')) {
    require_once __DIR__ . '/config.php';
}

/*
|--------------------------------------------------------------------------
| Ensure Paths are Available
|--------------------------------------------------------------------------
*/

if (!defined('BASE_PATH')) {
    require_once __DIR__ . '/paths.php';
}

/*==========================================================
Application URL
==========================================================*/

if (!function_exists('base_url')) {

    function base_url(string $path = ''): string
    {
        return rtrim(BASE_URL, '/') . '/' . ltrim($path, '/');
    }

}

/*==========================================================
Application Filesystem Path
==========================================================*/

if (!function_exists('base_path')) {

    function base_path(string $path = ''): string
    {
        return rtrim(BASE_PATH, DIRECTORY_SEPARATOR)
            . DIRECTORY_SEPARATOR
            . ltrim($path, DIRECTORY_SEPARATOR);
    }

}

/*==========================================================
Assets
==========================================================*/

if (!function_exists('asset')) {

    function asset(string $path): string
    {
        return base_url($path);
    }

}

/*==========================================================
Redirect
==========================================================*/

if (!function_exists('redirect')) {

    function redirect(string $url): void
    {
        header('Location: ' . $url);
        exit;
    }

}

/*==========================================================
HTML Escape
==========================================================*/

if (!function_exists('e')) {

    function e($value): string
    {
        return htmlspecialchars(
            (string)($value ?? ''),
            ENT_QUOTES,
            'UTF-8'
        );
    }

}

/*==========================================================
Flash Messages
==========================================================*/

if (!function_exists('flash')) {

    function flash(string $key, ?string $message = null)
    {
        if (!isset($_SESSION)) {
            return null;
        }

        if ($message !== null) {

            $_SESSION['_flash'][$key] = $message;

            return;
        }

        if (!isset($_SESSION['_flash'][$key])) {
            return null;
        }

        $value = $_SESSION['_flash'][$key];

        unset($_SESSION['_flash'][$key]);

        return $value;
    }

}

/*==========================================================
Current Timestamp
==========================================================*/

if (!function_exists('now')) {

    function now(): string
    {
        return date('Y-m-d H:i:s');
    }

}

/*==========================================================
Current Date
==========================================================*/

if (!function_exists('today')) {

    function today(): string
    {
        return date('Y-m-d');
    }

}

/*==========================================================
Dump & Die (Development Only)
==========================================================*/

if (!function_exists('dd')) {

    function dd($value): void
    {
        echo '<pre>';

        print_r($value);

        echo '</pre>';

        exit;
    }

}