<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Session Manager
 * File : config/session.php
 * Version : 3.0
 *
 * Description
 * ---------------------------------------------------------
 * Centralized session initialization.
 *
 * Every browser page automatically starts
 * a session through bootstrap.php.
 *
 * Future API and CLI scripts may disable
 * automatic sessions when required.
 * ---------------------------------------------------------
 */

if (!defined('USMCI_CONFIG')) {
    require_once __DIR__ . '/config.php';
}

/*
|--------------------------------------------------------------------------
| Auto Session
|--------------------------------------------------------------------------
|
| Change to FALSE only for API endpoints,
| CLI scripts or special background tasks.
|
*/

defined('AUTO_START_SESSION')
    || define('AUTO_START_SESSION', true);

/*
|--------------------------------------------------------------------------
| Session Initialization
|--------------------------------------------------------------------------
*/

if (AUTO_START_SESSION) {

    if (session_status() !== PHP_SESSION_ACTIVE) {

        session_name('USMCI_TMS');

        session_start();

    }

}