<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Application Configuration
 * File : config/config.php
 * Version : 3.0
 *
 * Description:
 * Global application settings.
 * This file DOES NOT load sessions,
 * paths or database connections.
 * ---------------------------------------------------------
 */

if (!defined('USMCI_CONFIG')) {
    define('USMCI_CONFIG', true);
}

/*==========================================================
Application Information
==========================================================*/

defined('APP_NAME')
    || define('APP_NAME', 'USMCI Training Management System');

defined('APP_SHORT_NAME')
    || define('APP_SHORT_NAME', 'USMCI-TMS');

defined('APP_VERSION')
    || define('APP_VERSION', '3.0');

defined('APP_ENV')
    || define('APP_ENV', 'development');

/*==========================================================
Timezone
==========================================================*/

date_default_timezone_set('Asia/Manila');

/*==========================================================
Error Reporting
==========================================================*/

if (APP_ENV === 'development') {

    ini_set('display_errors', 1);

    error_reporting(E_ALL);

} else {

    ini_set('display_errors', 0);

    error_reporting(0);

}