<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Global Constants
 * File : config/constants.php
 * Version : 3.0
 *
 * Description
 * ---------------------------------------------------------
 * Central repository for application-wide constants.
 *
 * This file stores values that are part of the
 * application's architecture and should not be
 * hardcoded throughout the system.
 *
 * NOTE:
 * Dynamic values such as Departments, Courses,
 * Roles, Statuses, etc. should come from the
 * database, NOT from this file.
 * ---------------------------------------------------------
 */

if (!defined('USMCI_CONFIG')) {
    require_once __DIR__ . '/config.php';
}

/*==========================================================
SYSTEM
==========================================================*/

defined('SYSTEM_ACTIVE')
    || define('SYSTEM_ACTIVE', 1);

defined('SYSTEM_INACTIVE')
    || define('SYSTEM_INACTIVE', 0);

/*==========================================================
USER TYPES
==========================================================*/

defined('USER_GUEST')
    || define('USER_GUEST', 'Guest');

defined('USER_APPLICANT')
    || define('USER_APPLICANT', 'Applicant');

defined('USER_TRAINEE')
    || define('USER_TRAINEE', 'Trainee');

defined('USER_STAFF')
    || define('USER_STAFF', 'Staff');

defined('USER_ADMIN')
    || define('USER_ADMIN', 'Administrator');

/*==========================================================
SESSION
==========================================================*/

defined('SESSION_USER')
    || define('SESSION_USER', 'usmci_user');

defined('SESSION_ROLE')
    || define('SESSION_ROLE', 'usmci_role');

defined('SESSION_LOGIN')
    || define('SESSION_LOGIN', 'usmci_logged_in');

/*==========================================================
INQUIRY
==========================================================*/

defined('INQUIRY_NEW')
    || define('INQUIRY_NEW', 'New');

defined('INQUIRY_PENDING')
    || define('INQUIRY_PENDING', 'Pending');

defined('INQUIRY_REPLIED')
    || define('INQUIRY_REPLIED', 'Replied');

defined('INQUIRY_CLOSED')
    || define('INQUIRY_CLOSED', 'Closed');

/*==========================================================
ADMISSION
==========================================================*/

defined('ADMISSION_DRAFT')
    || define('ADMISSION_DRAFT', 'Draft');

defined('ADMISSION_SUBMITTED')
    || define('ADMISSION_SUBMITTED', 'Submitted');

defined('ADMISSION_UNDER_REVIEW')
    || define('ADMISSION_UNDER_REVIEW', 'Under Review');

defined('ADMISSION_APPROVED')
    || define('ADMISSION_APPROVED', 'Approved');

defined('ADMISSION_REJECTED')
    || define('ADMISSION_REJECTED', 'Rejected');

/*==========================================================
ACCOUNT
==========================================================*/

defined('ACCOUNT_ACTIVE')
    || define('ACCOUNT_ACTIVE', 'Active');

defined('ACCOUNT_INACTIVE')
    || define('ACCOUNT_INACTIVE', 'Inactive');

defined('ACCOUNT_LOCKED')
    || define('ACCOUNT_LOCKED', 'Locked');

/*==========================================================
FILE UPLOADS
==========================================================*/

defined('UPLOAD_MAX_SIZE')
    || define('UPLOAD_MAX_SIZE', 10 * 1024 * 1024); // 10 MB

defined('UPLOAD_ALLOWED_TYPES')
    || define(
        'UPLOAD_ALLOWED_TYPES',
        [
            'jpg',
            'jpeg',
            'png',
            'pdf'
        ]
    );

/*==========================================================
MAIL
==========================================================*/

defined('MAIL_FROM_NAME')
    || define('MAIL_FROM_NAME', APP_NAME);

/*==========================================================
PAGINATION
==========================================================*/

defined('DEFAULT_PAGE_SIZE')
    || define('DEFAULT_PAGE_SIZE', 10);

defined('MAX_PAGE_SIZE')
    || define('MAX_PAGE_SIZE', 100);

/*==========================================================
DATE & TIME
==========================================================*/

defined('DATE_FORMAT')
    || define('DATE_FORMAT', 'M d, Y');

defined('DATETIME_FORMAT')
    || define('DATETIME_FORMAT', 'M d, Y h:i A');

/*==========================================================
APPLICATION
==========================================================*/

defined('PASSWORD_TEMP_LENGTH')
    || define('PASSWORD_TEMP_LENGTH', 10);

defined('PASSWORD_MIN_LENGTH')
    || define('PASSWORD_MIN_LENGTH', 8);