<?php
/**
 * Inquiry mail settings.
 *
 * Keep MAIL_SEND_IMMEDIATELY false until your local XAMPP mail or SMTP setup
 * is ready. Inquiries are still saved to the database and email_queue.
 */

declare(strict_types=1);

const ADMIN_INQUIRY_EMAIL = 'nieljaplos0924@gmail.com';
const WEBSITE_FROM_EMAIL = 'no-reply@usmci.test';
const WEBSITE_FROM_NAME = 'USMCI Admissions';
const MAIL_SEND_IMMEDIATELY = false;

// Must be a FULL absolute URL (scheme + host), not the relative
// BASE_URL from config/paths.php — links inside an email are read
// outside any browser session, so a relative path like "/USMCI-TMS"
// would be meaningless to the recipient. Update the host/port here
// if your local setup differs (e.g. a different XAMPP port).
const WEBSITE_BASE_URL = 'http://localhost/USMCI-TMS';

/*
 * Gmail SMTP development setup:
 *
 * Use a real Gmail address as WEBSITE_FROM_EMAIL while testing.
 * Create a Google App Password and store it outside public web files
 * before enabling live SMTP sending.
 *
 * The trainee email should be used as Reply-To, not From.
 */

// Left blank on purpose — send_queued_emails.php automatically falls
// back to PHP's built-in mail() while SMTP_HOST is empty. Fill these
// in once you're ready to send real mail through Gmail SMTP instead
// of local mail() (consider moving SMTP_PASSWORD into an untracked
// .env-style file rather than committing a real password here).
const SMTP_HOST = '';
const SMTP_PORT = 587;
const SMTP_ENCRYPTION = 'tls';
const SMTP_USERNAME = '';
const SMTP_PASSWORD = '';
