<?php
/*
|--------------------------------------------------------------------------
| USMCI Training Management System
|--------------------------------------------------------------------------
|
| Homepage Assembler
| Version : 1.0
|
*/

$page = [
    'title'       => 'USMCI Training Management System',
    'description' => 'Official website of USMCI Training Management System.',
    'bodyClass'   => 'homepage'
];
?>

<!DOCTYPE html>
<html lang="en">

<?php include 'includes/head.php'; ?>

<body class="<?= $page['bodyClass']; ?>">

    <!-- Navigation -->
    <?php include 'navbar/index.php'; ?>

    <main id="main-content">

        <!-- Hero -->
        <?php include 'sections/hero/index.php'; ?>

        <!-- About -->
        <?php
        if (file_exists('sections/about/index.php')) {
            include 'sections/about/index.php';
        }
        ?>

        <!-- Programs -->
        <?php
        if (file_exists('sections/programs/index.php')) {
            include 'sections/programs/index.php';
        }
        ?>

        <!-- Facilities -->
        <?php
        if (file_exists('sections/facilities/index.php')) {
            include 'sections/facilities/index.php';
        }
        ?>

        <!-- Testimonials -->
        <?php
        if (file_exists('sections/testimonials/index.php')) {
            include 'sections/testimonials/index.php';
        }
        ?>

        <!-- News -->
        <?php
        if (file_exists('sections/news/index.php')) {
            include 'sections/news/index.php';
        }
        ?>

        <!-- Call To Action -->
        <?php
        if (file_exists('sections/cta/index.php')) {
            include 'sections/cta/index.php';
        }
        ?>

    </main>

    <?php include 'includes/footer.php'; ?>

    <?php include 'includes/scripts.php'; ?>

</body>

</html>