<?php
/*
|--------------------------------------------------------------------------
| USMCI-TMS
|--------------------------------------------------------------------------
| Footer Loader
|--------------------------------------------------------------------------
|
| The visual footer will later become its own module
| under /sections/footer/.
|
*/
?>

<?php

if (file_exists('sections/footer/index.php')) {

    include 'sections/footer/index.php';

}

?>