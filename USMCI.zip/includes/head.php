<?php

if (!isset($page)) {
    $page = [];
}

$title = $page['title'] ?? 'USMCI Training Management System';

$description = $page['description']
    ?? 'Official Website of USMCI Training Management System';

$keywords = $page['keywords']
    ?? 'USMCI, Maritime, Training, Courses';

$author = 'USMCI';

?>

<head>

    <meta charset="UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <!-- Ensures relative asset paths (assets/css/main.css,
         navbar/style.css, etc.) resolve correctly from ANY
         page URL depth — e.g. a page nested under
         sections/admissions/inquiry/ — rather than only from
         the site root. Harmless no-op for pages already at
         the root, like the homepage. -->
    <base href="/USMCI-TMS/">

    <title><?= htmlspecialchars($title); ?></title>

    <meta name="description"
          content="<?= htmlspecialchars($description); ?>">

    <meta name="keywords"
          content="<?= htmlspecialchars($keywords); ?>">

    <meta name="author"
          content="<?= htmlspecialchars($author); ?>">

    <meta name="theme-color"
          content="#0f5d36">

    <!-- Favicon -->

    <link
        rel="icon"
        href="assets/images/branding/favicon.png">

    <!-- Google Fonts -->

    <link rel="preconnect"
          href="https://fonts.googleapis.com">

    <link rel="preconnect"
          href="https://fonts.gstatic.com"
          crossorigin>

    <link
        href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap"
        rel="stylesheet">

    <!-- Global CSS -->

    <link
        rel="stylesheet"
        href="assets/css/main.css">

    <!-- Navigation -->

    <link
        rel="stylesheet"
        href="navbar/style.css">

    <!-- Hero -->

    <link
        rel="stylesheet"
        href="sections/hero/style.css">

</head>