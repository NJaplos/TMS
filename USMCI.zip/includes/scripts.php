<?php
/*
|--------------------------------------------------------------------------
| USMCI-TMS
|--------------------------------------------------------------------------
| Global Script Loader
|--------------------------------------------------------------------------
|
| Loads all JavaScript modules required by the application.
| Add new section scripts here as the project grows.
|
*/
?>

<!-- ==================================================
     GLOBAL CORE
=================================================== -->

<!-- (Future)
<script src="assets/js/core/theme.js"></script>
<script src="assets/js/core/navigation.js"></script>
<script src="assets/js/core/api.js"></script>
-->

<!-- ==================================================
     NAVIGATION MODULE
=================================================== -->

<script src="navbar/config.js"></script>

<script src="navbar/modules/toggle.js"></script>

<script src="navbar/modules/sticky.js"></script>

<script src="navbar/modules/active.js"></script>

<script src="navbar/script.js"></script>

<!-- ==================================================
     HERO MODULE
=================================================== -->

<script src="sections/hero/config.js"></script>

<script src="sections/hero/modules/offset.js"></script>

<script src="sections/hero/modules/carousel.js"></script>

<script src="sections/hero/modules/counter.js"></script>

<script src="sections/hero/modules/reveal.js"></script>

<script src="sections/hero/modules/scroll.js"></script>

<script src="sections/hero/script.js"></script>

<!-- ==================================================
     PAGE SPECIFIC
=================================================== -->

<!-- Future Page Scripts -->