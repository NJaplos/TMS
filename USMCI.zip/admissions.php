<?php

$page = [

'title' => 'USMCI Admissions Portal',

'description' => 'Online Admissions Portal of USMCI',

'bodyClass' => 'admissions-page'

];

?>

<!DOCTYPE html>

<html lang="en">

<?php include 'includes/head.php'; ?>

<link rel="stylesheet" href="sections/admissions/style.css">

<body class="<?= $page['bodyClass']; ?>">

<?php include 'navbar/index.php'; ?>

<main id="main-content">

<?php include 'sections/admissions/index.php'; ?>

</main>

<?php include 'includes/footer.php'; ?>

<?php include 'includes/scripts.php'; ?>

<script src="sections/admissions/assets/js/portal.js"></script>

</body>

</html>