<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Environment / Database Diagnostics
 * File : diagnostics.php   (DEVELOPMENT TOOL — delete before deploy)
 * ---------------------------------------------------------
 * Shows exactly what state the database is in so we can tell
 * what went wrong without guessing. Load it like any page:
 *
 *     http://localhost/USMCI-TMS/diagnostics.php
 *
 * It only runs when APP_ENV === 'development' (config/config.php),
 * so it refuses to run in production.
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once __DIR__ . '/config/bootstrap.php';

/* Development-only guard */
if (!defined('APP_ENV') || APP_ENV !== 'development') {
    http_response_code(403);
    exit('Diagnostics are disabled outside development mode.');
}

function diag(string $label, bool $ok, string $detail = ''): void
{
    $icon = $ok ? '✅' : '❌';
    $detailHtml = $detail !== '' ? ' — <code>' . htmlspecialchars($detail, ENT_QUOTES, 'UTF-8') . '</code>' : '';
    echo '<div class="row">' . $icon . ' <strong>' . htmlspecialchars($label) . '</strong>' . $detailHtml . '</div>';
}

$pdo = null;
try {
    $pdo = db();
    $dbOk = true;
} catch (Throwable $e) {
    $dbOk = false;
    $dbError = $e->getMessage();
}

$exists = static function (string $table) use ($pdo): bool {
    if (!$pdo) return false;
    try {
        $pdo->query('SELECT 1 FROM `' . $table . '` LIMIT 1');
        return true;
    } catch (Throwable $e) {
        return false;
    }
};

$count = static function (string $sql) use ($pdo) {
    if (!$pdo) return 'n/a';
    try {
        return (int) $pdo->query($sql)->fetchColumn();
    } catch (Throwable $e) {
        return 'ERR: ' . $e->getMessage();
    }
};
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>USMCI-TMS Diagnostics</title>
<style>
    body { font-family: 'Segoe UI', Arial, sans-serif; background: #0B3C5D; margin: 0; padding: 32px 16px; }
    .card { max-width: 760px; margin: 0 auto 16px; background: #fff; border-radius: 12px; padding: 22px 26px; box-shadow: 0 10px 30px rgba(0,0,0,.25); }
    h1 { margin: 0 0 4px; font-size: 1.3rem; color: #0B3C5D; }
    h2 { font-size: .8rem; text-transform: uppercase; letter-spacing: .06em; color: #64748B; margin: 18px 0 8px; border-bottom: 1px solid #E2E8F0; padding-bottom: 6px; }
    .row { padding: 5px 0; font-size: .92rem; color: #334155; border-bottom: 1px solid #F1F5F9; }
    .row:last-child { border-bottom: none; }
    code { background: #F1F5F9; padding: 1px 6px; border-radius: 5px; font-size: .85rem; }
    .fail-card { background: #FEF2F2; border: 1px solid #FECACA; }
    pre { background: #0F172A; color: #E2E8F0; padding: 12px; border-radius: 8px; overflow-x: auto; font-size: .82rem; }
</style>
</head>
<body>

<div class="card">
    <h1>USMCI-TMS Diagnostics</h1>
    <p style="font-size:.85rem;color:#64748B;">Run after importing the database — tells you exactly what's missing.</p>
</div>

<div class="card <?= $dbOk ? '' : 'fail-card'; ?>">
    <h2>Environment</h2>
    <?php
    diag('PHP version >= 8.0', version_compare(PHP_VERSION, '8.0.0', '>='), PHP_VERSION);
    diag('PDO MySQL driver loaded', extension_loaded('pdo_mysql'));
    diag('Project folder detected', true, basename(BASE_PATH));
    diag('BASE_URL (auto-detected)', true, BASE_URL);
    diag('APP_ENV', true, APP_ENV);
    ?>

    <h2>Database connection (config/database.php)</h2>
    <?php
    if ($dbOk) {
        diag('Connected', true, DB_HOST . ' / ' . DB_NAME . ' / user: ' . DB_USER);
    } else {
        diag('CONNECTION FAILED', false, $dbError ?? 'unknown');
        echo '<p style="color:#B91C1C;font-size:.85rem;">Check DB_HOST, DB_NAME, DB_USER, DB_PASS in config/database.php.</p>';
    }
    ?>
</div>

<div class="card <?= $exists('mnt_inquiry_status') && $exists('applicant_invitation') && (int) $count('SELECT COUNT(*) FROM sys_user') > 0 ? '' : 'fail-card'; ?>">
    <h2>Required tables (from the fixes)</h2>
    <?php
    diag('mnt_inquiry_status exists', $exists('mnt_inquiry_status'));
    diag('applicant_invitation exists', $exists('applicant_invitation'));
    diag('sys_user has staff accounts', (int) $count('SELECT COUNT(*) FROM sys_user') > 0, 'count = ' . $count('SELECT COUNT(*) FROM sys_user'));
    diag('mnt_inquiry_status rows', true, 'count = ' . $count('SELECT COUNT(*) FROM mnt_inquiry_status'));
    diag('inquiry.status_id backfilled', true, 'non-null = ' . $count('SELECT COUNT(*) FROM inquiry WHERE status_id IS NOT NULL') . ' / total = ' . $count('SELECT COUNT(*) FROM inquiry'));
    ?>
</div>

<div class="card">
    <h2>Data counts</h2>
    <?php
    diag('Inquiries in table', true, 'count = ' . $count('SELECT COUNT(*) FROM inquiry'));
    diag('Email queue pending', true, 'count = ' . $count("SELECT COUNT(*) FROM email_queue WHERE status = 'pending'"));
    diag('Applicant accounts', true, 'count = ' . $count('SELECT COUNT(*) FROM applicant_account'));
    ?>
</div>

<div class="card">
    <h2>Login check</h2>
    <?php
    if ($pdo) {
        try {
            $hash = $pdo->query("SELECT password_hash FROM sys_user WHERE username = 'admin' LIMIT 1")->fetchColumn();
            diag('admin user exists', (bool) $hash);
            diag('admin password hash verifies (Admin@1234)', (bool) $hash && password_verify('Admin@1234', $hash));
        } catch (Throwable $e) {
            diag('admin lookup failed', false, $e->getMessage());
        }
    }
    ?>
    <p style="font-size:.82rem;color:#94A3B8;">If any row above is red, the easiest fix is: import <code>database/full_schema.sql</code> (it creates &amp; selects the <code>enrollsys</code> database itself and drops old tables, so it works even if your earlier attempts left a mess).</p>
</div>

</body>
</html>
