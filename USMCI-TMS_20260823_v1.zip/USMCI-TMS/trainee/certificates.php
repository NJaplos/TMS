<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Trainee: Certificates
 * File : trainee/certificates.php
 * ---------------------------------------------------------
 * Certificates are issued by the Admissions/Admin only. The
 * trainee can download the attached file, verify (in-app modal),
 * and print — no self-adding / editing / deleting.
 * ---------------------------------------------------------
 */

$activePage = 'certificates';
$tNavTitle  = 'Certificates';
$tNavSub    = 'Your certificates, their validity, and downloadable copies.';

include __DIR__ . '/partials/top.php';

$certsStmt = $pdo->prepare(
    "SELECT c.*, m.course_name,
            COALESCE(m.course_name, c.course_name_override) AS display_course,
            t.training_no, t.batch_name
     FROM certificate c
     LEFT JOIN mnt_course m ON m.id = c.course_id
     LEFT JOIN enrollment e ON e.id = c.enrollment_id
     LEFT JOIN training t ON t.id = e.training_id
     WHERE c.applicant_id = :id
     ORDER BY c.issued_date DESC LIMIT 30"
);
$certsStmt->execute(['id' => $applicantId]);
$certs = $certsStmt->fetchAll() ?: [];
?>
            <!-- ============ CERTIFICATES ============ -->
            <section id="certificates" class="t-panel">
                <div class="t-panel__head">
                    <h2>📜 Certificates</h2>
                    <span class="t-panel__tag">Validity & copies</span>
                </div>

                <p style="font-size:.85rem;color:#64748B;margin-bottom:14px;">
                    Certificates are issued by the Admissions / Admin office. You can download the official copy,
                    verify it, or print it.
                </p>

                <div class="table-responsive">
                    <table class="inquiry-table cert-table">
                        <thead>
                            <tr>
                                <th>Certificate No.</th>
                                <th>Course</th>
                                <th>Date Issued</th>
                                <th>Date Expiry</th>
                                <th>Status</th>
                                <th class="cert-table__actions">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!$certs): ?>
                                <tr><td colspan="6" class="cert-table__empty">No certificates issued yet — issued certificates will appear here.</td></tr>
                            <?php else: ?>
                                <?php foreach ($certs as $c):
                                    $expired = $c['expiry_date'] && strtotime($c['expiry_date']) < time();
                                    $near = !$expired && $c['expiry_date'] && (strtotime($c['expiry_date']) - time()) < 90 * 86400;
                                    $status = $c['status'] === 'issued' && $expired ? 'expired' : $c['status'];
                                ?>
                                    <tr id="cert-<?= e($c['certificate_no']); ?>">
                                        <td class="cert-table__no"><?= e($c['certificate_no']); ?></td>
                                        <td class="cert-table__course">
                                            <?= e($c['display_course'] ?? 'Course'); ?>
                                            <?php if (!empty($c['batch_name'])): ?><div class="course-desc"><?= e($c['batch_name']); ?></div><?php endif; ?>
                                        </td>
                                        <td><?= e($c['issued_date']); ?></td>
                                        <td>
                                            <span class="cert-expiry <?= $expired ? 'cert-expired' : ($near ? 'cert-near' : ''); ?>">
                                                <?= e($c['expiry_date'] ?? '—'); ?>
                                                <?php if ($expired): ?> · EXPIRED<?php elseif ($near): ?> · expiring soon<?php endif; ?>
                                            </span>
                                        </td>
                                        <td><span class="status-badge status-<?= e($status); ?>"><?= e(ucfirst($status)); ?></span></td>
                                        <td class="cert-table__actions">
                                            <?php if ($status !== 'void'): ?>
                                                <?php
                                                    $hasFile = !empty($c['file_path']) && is_file(BASE_PATH . '/' . ltrim((string) $c['file_path'], '/'));
                                                    $fileMissing = !empty($c['file_path']) && !$hasFile;
                                                ?>
                                                <?php if ($fileMissing): ?>
                                                    <span class="status-badge status-closed" title="The uploaded file was lost when the server uploads folder was replaced. Please contact Admissions to re-upload it.">⚠ File Missing</span>
                                                <?php endif; ?>
                                                <div class="cert-actions-2x2">
                                                    <a class="btn-secondary btn-sm" href="<?= e(base_url('download_certificate.php?ref=' . urlencode($c['certificate_no']) . '&view=1')); ?>" target="_blank" title="<?= $hasFile ? 'Open your uploaded certificate for printing' : 'Printable certificate with QR code — print or save as PDF'; ?>"><?= $hasFile ? '📄 View File' : '📱 View / Print (QR)'; ?></a>
                                                    <a class="btn-secondary btn-sm" href="<?= e(base_url('download_certificate.php?ref=' . urlencode($c['certificate_no']))); ?>" download="<?= e($c['file_name'] ?? ($c['certificate_no'] . '.html')); ?>" title="<?= e($c['file_name'] ?? 'Download digital copy'); ?>">⬇ Download</a>
                                                    <?php if ($c['verification_url']): ?>
                                                        <button type="button" class="btn-secondary btn-sm" data-cert-verify='<?= json_encode(['no'=>$c['certificate_no'],'name'=>$fullName,'course'=>$c['display_course']??'','batch'=>(($c['training_no']??'').($c['batch_name']?' · '.$c['batch_name']:'')),'issued'=>$c['issued_date'],'expiry'=>$c['expiry_date']??'','status'=>$status,'by'=>'USMCI','url'=>$c['verification_url']??'','remarks'=>$c['void_remarks']??''], JSON_HEX_APOS|JSON_HEX_QUOT); ?>'>🔎 Verify</button>
                                                    <?php endif; ?>
                                                </div>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </section>

    <!-- Verify modal -->
    <div id="verifyModal" class="portal-modal" style="display:none;">
        <div class="portal-modal__box">
            <div class="portal-modal__head">
                <h3>🔎 Certificate Verification</h3>
                <p id="verifyTarget">—</p>
                <button class="portal-modal__close" id="verifyClose">&times;</button>
            </div>
            <div class="portal-modal__body">
                <div id="verifyBadge" class="verify-badge">—</div>
                <div class="meta-grid">
                    <div class="meta-cell"><span>Certificate No.</span><b id="vmNo">—</b></div>
                    <div class="meta-cell"><span>Trainee</span><b id="vmName">—</b></div>
                    <div class="meta-cell"><span>Course</span><b id="vmCourse">—</b></div>
                    <div class="meta-cell"><span>Batch</span><b id="vmBatch">—</b></div>
                    <div class="meta-cell"><span>Date Issued</span><b id="vmIssued">—</b></div>
                    <div class="meta-cell"><span>Date Expiry</span><b id="vmExpiry">—</b></div>
                    <div class="meta-cell"><span>Issued By</span><b id="vmBy">—</b></div>
                    <div class="meta-cell"><span>Status</span><b id="vmStatus">—</b></div>
                    <div class="meta-cell meta-cell--full" id="vmRemarksWrap" style="display:none;"><span>Void Remarks</span><b id="vmRemarks" style="color:#B91C1C;">—</b></div>
                </div>
            </div>
            <div class="portal-modal__foot">
                <a href="#" id="vmPublic" target="_blank" class="btn-secondary" style="text-decoration:none;">Open Public Page</a>
                <button type="button" class="btn-primary" id="verifyCloseBtn">Close</button>
            </div>
        </div>
    </div>

<script>
(function () {
    // Verify modal
    var vModal = document.getElementById("verifyModal");
    function openVerify(d) {
        document.getElementById("verifyTarget").textContent = d.no;
        document.getElementById("vmNo").textContent = d.no;
        document.getElementById("vmName").textContent = d.name || "—";
        document.getElementById("vmCourse").textContent = d.course || "—";
        document.getElementById("vmBatch").textContent = d.batch || "—";
        document.getElementById("vmIssued").textContent = d.issued || "—";
        document.getElementById("vmExpiry").textContent = d.expiry || "—";
        document.getElementById("vmBy").textContent = d.by || "USMCI";
        var st = (d.status || "issued").toUpperCase();
        document.getElementById("vmStatus").textContent = st;
        var rmWrap = document.getElementById("vmRemarksWrap");
        var rm = (d.remarks || "").toString().trim();
        if (rmWrap) {
            if (rm) {
                document.getElementById("vmRemarks").textContent = rm;
                rmWrap.style.display = "";
            } else {
                rmWrap.style.display = "none";
            }
        }
        var badge = document.getElementById("verifyBadge");
        var map = {
            ISSUED:   ["✓ VALID CERTIFICATE", "#15803D", "#DCFCE7"],
            EXPIRED:  ["⚠ EXPIRED CERTIFICATE", "#B91C1C", "#FEE2E2"],
            VOID:     ["✗ VOID CERTIFICATE", "#64748B", "#F1F5F9"],
            DRAFT:    ["DRAFT", "#B45309", "#FEF3C7"],
            REISSUED: ["REISSUED", "#2563EB", "#E0F2FE"]
        };
        var m = map[st] || map.ISSUED;
        badge.textContent = m[0];
        badge.style.color = m[1];
        badge.style.background = m[2];
        document.getElementById("vmPublic").href = d.url || "#";
        vModal.style.display = "flex";
    }
    function closeVerify() { vModal.style.display = "none"; }
    document.querySelectorAll("[data-cert-verify]").forEach(function (b) {
        b.addEventListener("click", function () { try { openVerify(JSON.parse(b.dataset.certVerify)); } catch (e) {} });
    });
    document.getElementById("verifyClose").addEventListener("click", closeVerify);
    document.getElementById("verifyCloseBtn").addEventListener("click", closeVerify);
    if (vModal) vModal.addEventListener("click", function (e) { if (e.target === vModal) closeVerify(); });

})();
</script>

<?php include __DIR__ . '/partials/bottom.php'; ?>
