<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Trainee: My Inquiry & Conversation
 * File : trainee/inquiry.php
 * ---------------------------------------------------------
 */

$activePage = 'inquiry';
$tNavTitle  = 'My Inquiry';
$tNavSub    = 'Your reference number and the full conversation with Admissions.';

include __DIR__ . '/partials/top.php';

$replies = [];
if ($inquiry) {
    $rs = $pdo->prepare("SELECT sender_type, message, created_at FROM inquiry_reply WHERE inquiry_id = :iid ORDER BY created_at ASC");
    $rs->execute(['iid' => $inquiry['id']]);
    $replies = $rs->fetchAll() ?: [];
}
?>

            <!-- ============ INQUIRY ============ -->
            <section id="inquiry" class="t-panel">
                <div class="t-panel__head"><h2>📨 My Inquiry</h2><span class="t-panel__tag">Reference & conversation</span></div>

                <?php if (!$inquiry): ?>
                    <p class="t-empty">No inquiry on file yet. Submit one from the Admissions page and our team will respond.</p>
                <?php else: ?>
                    <div class="t-inquiry">
                        <p><strong>Reference:</strong> <?= e($inquiry['inquiry_no']); ?> · <strong>Status:</strong>
                            <span class="status-badge status-<?= e(strtolower($inquiry['status_code'] ?? 'new')); ?>"><?= e($inquiry['status_label'] ?? 'New'); ?></span></p>
                        <p><strong>Subject:</strong> <?= e($inquiry['subject'] ?? '—'); ?></p>
                        <p><strong>Message:</strong></p>
                        <pre><?= e($inquiry['message']); ?></pre>
                        <p class="t-inquiry__meta">Submitted <?= e(date('M d, Y h:i A', strtotime($inquiry['created_at']))); ?></p>
                    </div>

                    <div class="t-thread">
                        <h4>Conversation with Admissions</h4>
                        <?php if (!$replies): ?>
                            <p class="t-empty">No replies yet — the Admissions Office usually responds within one business day.</p>
                        <?php else: ?>
                            <?php foreach ($replies as $r): ?>
                                <div class="t-thread__item <?= $r['sender_type'] === 'staff' ? 't-thread__item--staff' : ''; ?>">
                                    <div class="t-thread__meta">
                                        <strong><?= $r['sender_type'] === 'staff' ? 'Admissions Office' : 'You'; ?></strong>
                                        <span><?= e(date('M d, Y h:i A', strtotime($r['created_at']))); ?></span>
                                    </div>
                                    <p><?= nl2br(e($r['message'])); ?></p>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </section>

<?php include __DIR__ . '/partials/bottom.php'; ?>
