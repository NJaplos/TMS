<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Trainee: Account Settings
 * File : trainee/account.php
 * ---------------------------------------------------------
 */

$activePage = 'account';
$tNavTitle  = 'Account Settings';
$tNavSub    = 'Change your password and manage your session.';

include __DIR__ . '/partials/top.php';
?>

            <!-- ============ ACCOUNT ============ -->
            <section id="account" class="t-panel">
                <div class="t-panel__head"><h2>⚙️ Account Settings</h2><span class="t-panel__tag">Security</span></div>

                <form method="post" action="<?= e(base_url('trainee/actions/change_password.php')); ?>" class="t-form t-form--narrow">
                    <?= csrf_field(); ?>
                    <div class="t-field"><label>Current Password</label><input type="password" name="current_password" required></div>
                    <div class="t-field"><label>New Password (min 8)</label><input type="password" name="new_password" minlength="8" required></div>
                    <div class="t-field"><label>Confirm New Password</label><input type="password" name="confirm_password" required></div>
                    <div class="t-form__actions"><button type="submit" class="btn-primary">Change Password</button></div>
                </form>

                <div class="t-panel__sub">
                    <h4>Session</h4>
                    <p class="t-empty">Signed in as <?= e($user['email'] ?? ''); ?>. <a href="<?= e(base_url('logout.php')); ?>" style="color:#0D8A72;font-weight:700;">Sign out</a></p>
                </div>
            </section>

<?php include __DIR__ . '/partials/bottom.php'; ?>
