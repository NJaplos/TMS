<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Trainee: Notifications
 * File : trainee/notifications.php
 * ---------------------------------------------------------
 * Lists the trainee's notifications (certificate issued,
 * enrollment confirmed, etc.). Auto-marks them read on view.
 * ---------------------------------------------------------
 */

declare(strict_types=1);

/* Bootstrap is loaded by partials/top.php (which needs trainee session).
   Set page vars first, then include the shell — same pattern as the
   other trainee pages. */

$activePage = 'notifications';
$tNavTitle  = 'Notifications';
$tNavSub    = 'Updates about your enrollment, payments, and certificates.';

include __DIR__ . '/partials/top.php';

$user = current_user();
$applicantId = (int) ($user['applicant_id'] ?? 0);

$pdo = db();

/* Mark all as read now (viewing the page = reading them) */
if ($applicantId > 0) {
    $pdo->prepare("UPDATE applicant_notification SET read_at = COALESCE(read_at, NOW()) WHERE applicant_id = :ap AND read_at IS NULL")
        ->execute(['ap' => $applicantId]);
}

$stmt = $pdo->prepare(
    "SELECT n.*, nt.name AS type_name
     FROM applicant_notification n
     LEFT JOIN mnt_notification_type nt ON nt.id = n.notification_type_id
     WHERE n.applicant_id = :ap
     ORDER BY n.created_at DESC LIMIT 100"
);
$stmt->execute(['ap' => $applicantId]);
$notifs = $stmt->fetchAll() ?: [];
?>
            <section class="t-panel">
                <div class="t-panel__head">
                    <h3>🔔 Notifications</h3>
                    <p><?= count($notifs); ?> total · newest first</p>
                </div>

                <?php if (!$notifs): ?>
                    <p class="t-empty">No notifications yet. You'll be alerted here when your certificate is issued or your enrollment status changes.</p>
                <?php endif; ?>

                <div style="display:flex;flex-direction:column;gap:10px;">
                    <?php foreach ($notifs as $n):
                        $unread = $n['read_at'] === null;
                    ?>
                        <div style="display:flex;gap:12px;align-items:flex-start;border:1px solid <?= $unread ? '#F4B400' : '#E2E8F0'; ?>;border-radius:12px;padding:14px 16px;background:<?= $unread ? '#FFFBEB' : '#F8FAFC'; ?>;">
                            <div style="font-size:1.3rem;"><?= $unread ? '🔔' : '✅'; ?></div>
                            <div style="flex:1;">
                                <div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap;">
                                    <strong style="color:#0B3C5D;font-size:.92rem;"><?= e($n['title']); ?></strong>
                                    <span style="font-size:.72rem;color:#5B6472;white-space:nowrap;"><?= e(date('M d, Y g:i A', strtotime($n['created_at']))); ?></span>
                                </div>
                                <p style="font-size:.84rem;color:#334155;margin-top:4px;line-height:1.5;"><?= e($n['message']); ?></p>
                                <?php if (!empty($n['type_name'])): ?>
                                    <span class="status-badge status-replied" style="margin-top:6px;"><?= e($n['type_name']); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </section>

<?php include __DIR__ . '/partials/bottom.php'; ?>
