<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Trainee: Registration & Enrollment
 * File : trainee/registration.php
 * ---------------------------------------------------------
 */

$activePage = 'registration';
$tNavTitle  = 'Registration & Enrollment';
$tNavSub    = 'Your enrollment slip — course, schedule, venue and status.';

include __DIR__ . '/partials/top.php';

$enrollments = $pdo->prepare(
    "SELECT e.*, c.course_name, c.code AS course_code, c.duration_hours,
            t.training_no, t.batch_name, t.start_date, t.end_date, t.venue
     FROM enrollment e
     LEFT JOIN mnt_course c ON c.id = e.course_id
     LEFT JOIN training t ON t.id = e.training_id
     WHERE e.applicant_id = :id
     ORDER BY e.id DESC LIMIT 5"
);
$enrollments->execute(['id' => $applicantId]);
$enrollments = $enrollments->fetchAll() ?: [];
?>

            <!-- ============ REGISTRATION ============ -->
            <section id="registration" class="t-panel">
                <div class="t-panel__head"><h2>📝 Registration & Enrollment</h2><span class="t-panel__tag">Slip</span></div>

                <?php if (!$enrollments): ?>
                    <p class="t-empty">No enrollment yet. Once the Admissions Office processes your application, your registration slip will appear here.</p>
                <?php else: ?>
                    <?php foreach ($enrollments as $enr): ?>
                        <div class="reg-slip">
                            <div class="reg-slip__head">
                                <span class="reg-slip__no"><?= e($enr['enrollment_no']); ?> · <?= e($enr['batch_name'] ?? ''); ?></span>
                                <span class="reg-slip__status reg-slip__status--<?= e($enr['status']); ?>"><?= e(ucfirst($enr['status'])); ?></span>
                            </div>
                            <div class="reg-slip__grid">
                                <div><label>Course</label><strong><?= e($enr['course_name'] ?? '—'); ?></strong></div>
                                <div><label>Course Code</label><strong><?= e($enr['course_code'] ?? '—'); ?></strong></div>
                                <div><label>Training No.</label><strong><?= e($enr['training_no'] ?? '—'); ?></strong></div>
                                <div><label>Duration</label><strong><?= e($enr['duration_hours'] ? $enr['duration_hours'] . ' hrs' : '—'); ?></strong></div>
                                <div><label>Start</label><strong><?= e($enr['start_date'] ?? '—'); ?></strong></div>
                                <div><label>End</label><strong><?= e($enr['end_date'] ?? '—'); ?></strong></div>
                                <div><label>Venue</label><strong><?= e($enr['venue'] ?? '—'); ?></strong></div>
                                <div><label>Enrolled On</label><strong><?= e($enr['enrollment_date'] ?? '—'); ?></strong></div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </section>

<?php include __DIR__ . '/partials/bottom.php'; ?>
