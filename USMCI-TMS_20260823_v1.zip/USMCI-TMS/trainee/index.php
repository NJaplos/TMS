<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Trainee: Overview
 * File : trainee/index.php
 * ---------------------------------------------------------
 */

$activePage = 'overview';
$tNavTitle  = 'My Dashboard';
$tNavSub    = 'Your admission, enrollment, and certificates at a glance.';

include __DIR__ . '/partials/top.php';

/* Overview extras */
$totalPaid = (int) $pdo->query("SELECT COALESCE(SUM(paid_amount),0) FROM payment WHERE applicant_id = " . (int) $applicantId)->fetchColumn();
$enrollCount = (int) $pdo->query("SELECT COUNT(*) FROM enrollment WHERE applicant_id = " . (int) $applicantId)->fetchColumn();
$certCount = (int) $pdo->query("SELECT COUNT(*) FROM certificate WHERE applicant_id = " . (int) $applicantId)->fetchColumn();
$replyCount = 0;
if ($inquiry) {
    $rs = $pdo->prepare("SELECT COUNT(*) FROM inquiry_reply WHERE inquiry_id = :i");
    $rs->execute(['i' => $inquiry['id']]);
    $replyCount = (int) $rs->fetchColumn();
}
?>

            <!-- ============ OVERVIEW ============ -->
            <section id="overview" class="t-panel">
                <div class="t-panel__head"><h2>🏠 Overview</h2><span class="t-panel__tag">At a glance</span></div>

                <div class="trainee-cards">
                    <div class="t-card">
                        <div class="t-card__icon" style="background:#EAF6F2;">📨</div>
                        <div><div class="t-card__value"><?= e($inquiry['status_label'] ?? '—'); ?></div><div class="t-card__label">Inquiry Status</div></div>
                    </div>
                    <div class="t-card">
                        <div class="t-card__icon" style="background:#EFF6FF;">📝</div>
                        <div><div class="t-card__value"><?= (int) $enrollCount; ?></div><div class="t-card__label">Enrollments</div></div>
                    </div>
                    <div class="t-card">
                        <div class="t-card__icon" style="background:#DCFCE7;">💳</div>
                        <div><div class="t-card__value">₱ <?= number_format((float) $totalPaid, 2); ?></div><div class="t-card__label">Total Paid</div></div>
                    </div>
                    <div class="t-card">
                        <div class="t-card__icon" style="background:#FEF3C7;">📜</div>
                        <div><div class="t-card__value"><?= (int) $certCount; ?></div><div class="t-card__label">Certificates</div></div>
                    </div>
                </div>

                <?php if ($inquiry): ?>
                    <div class="trainee-status-banner">
                        <span class="status-badge status-<?= e(strtolower($inquiry['status_code'] ?? 'new')); ?>">
                            <?= e($inquiry['status_label'] ?? 'New'); ?>
                        </span>
                        <div>
                            <strong>Inquiry <?= e($inquiry['inquiry_no']); ?> · <?= (int) $replyCount; ?> reply(ies)</strong>
                            <span><?= e($inquiry['course_interest'] ?? ''); ?> · submitted <?= e(date('M d, Y', strtotime($inquiry['created_at']))); ?></span>
                        </div>
                        <a class="btn-secondary btn-sm" href="<?= e(base_url('trainee/inquiry.php')); ?>">Open →</a>
                    </div>
                <?php endif; ?>

                <div class="t-quick-links">
                    <a href="<?= e(base_url('trainee/registration.php')); ?>">📝 Registration slip</a>
                    <a href="<?= e(base_url('trainee/payments.php')); ?>">💳 Payments</a>
                    <a href="<?= e(base_url('trainee/certificates.php')); ?>">📜 Certificates</a>
                    <a href="<?= e(base_url('trainee/profile.php')); ?>">👤 Profile</a>
                </div>
            </section>

<?php include __DIR__ . '/partials/bottom.php'; ?>
