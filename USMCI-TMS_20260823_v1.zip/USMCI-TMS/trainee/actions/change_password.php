<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Trainee
 * POST /trainee/actions/change_password.php
 * ---------------------------------------------------------
 * Changes the trainee's account password.
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/config/bootstrap.php';

require_trainee();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ' . base_url('trainee/index.php'));
    exit;
}

csrf_check();

$user = current_user();
$pdo  = db();
$accountId = (int) ($user['id'] ?? 0);

$current = (string) ($_POST['current_password'] ?? '');
$new     = (string) ($_POST['new_password'] ?? '');
$confirm = (string) ($_POST['confirm_password'] ?? '');

$fail = function (string $msg) {
    header('Location: ' . base_url('trainee/index.php?flash=err&msg=' . urlencode($msg)));
    exit;
};

if ($current === '' || $new === '' || $confirm === '') {
    $fail('All password fields are required.');
}

if (strlen($new) < 8) {
    $fail('New password must be at least 8 characters.');
}

if ($new !== $confirm) {
    $fail('New password and confirmation do not match.');
}

try {
    $stmt = $pdo->prepare('SELECT password_hash FROM applicant_account WHERE id = :id LIMIT 1');
    $stmt->execute(['id' => $accountId]);
    $row = $stmt->fetch();

    if (!$row || !password_verify($current, $row['password_hash'])) {
        $fail('Current password is incorrect.');
    }

    $pdo->prepare('UPDATE applicant_account SET password_hash = :h, updated_at = NOW() WHERE id = :id')
        ->execute(['h' => password_hash($new, PASSWORD_DEFAULT), 'id' => $accountId]);

    header('Location: ' . base_url('trainee/index.php?flash=ok&msg=' . urlencode('Password changed.')));
} catch (Throwable $e) {
    error_log('change_password failed: ' . $e->getMessage());
    $fail('Could not change password right now.');
}
exit;
