<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Trainee
 * POST /trainee/actions/upload_document.php
 * ---------------------------------------------------------
 * Lets the trainee upload a copy of a certificate/document for
 * safekeeping. Creates a `document` row owned by the applicant
 * and a `document_upload` row with the file. Redirects back to
 * the page the user came from (default: certificates).
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/config/bootstrap.php';

require_trainee();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ' . base_url('trainee/index.php'));
    exit;
}

csrf_check();

/* Return to the page the user came from (default: certificates) */
$referer = (string) ($_SERVER['HTTP_REFERER'] ?? '');
$back = base_url('trainee/certificates.php');
if ($referer !== '' && strpos($referer, '/trainee/') !== false && strpos($referer, 'actions/') === false) {
    $back = $referer;
}

$sep = strpos($back, '?') !== false ? '&' : '?';

$user = current_user();
$applicantId = (int) ($user['applicant_id'] ?? 0);

/* Optional: when uploading from a certificate row, the document
   title = certificate_no so the row can show its copy. */
$certNo = trim((string) ($_POST['cert_no'] ?? ''));

if (empty($_FILES['doc_file']) || $_FILES['doc_file']['error'] !== UPLOAD_ERR_OK) {
    header('Location: ' . $back . $sep . 'flash=err&msg=' . urlencode('No file selected.'));
    exit;
}

$file = $_FILES['doc_file'];
$tmp  = $file['tmp_name'];
$size = (int) $file['size'];

if ($size > 8 * 1024 * 1024) {
    header('Location: ' . $back . $sep . 'flash=err&msg=' . urlencode('File must be under 8 MB.'));
    exit;
}

$origName = basename($file['name']);
$ext = strtolower(pathinfo($origName, PATHINFO_EXTENSION));

if (!in_array($ext, ['pdf', 'jpg', 'jpeg', 'png'], true)) {
    header('Location: ' . $back . $sep . 'flash=err&msg=' . urlencode('Only PDF, JPG, or PNG allowed.'));
    exit;
}

$dir = BASE_PATH . '/uploads/trainee-docs';
if (!is_dir($dir)) {
    @mkdir($dir, 0775, true);
}

$name = 'trainee-' . $applicantId . '-' . time() . '-' . preg_replace('/[^A-Za-z0-9._-]/', '_', $origName);
$dest = $dir . '/' . $name;

if (!move_uploaded_file($tmp, $dest)) {
    header('Location: ' . $back . $sep . 'flash=err&msg=' . urlencode('Could not save the file.'));
    exit;
}

try {
    $pdo = db();
    $pdo->beginTransaction();

    $docTitle = $certNo !== '' ? $certNo : $origName;

    $pdo->prepare(
        "INSERT INTO document (owner_type, owner_id, document_type_id, title, status, created_at)
         VALUES ('applicant', :owner, 1, :title, 'submitted', NOW())"
    )->execute(['owner' => $applicantId, 'title' => $docTitle]);
    $docId = (int) $pdo->lastInsertId();

    $pdo->prepare(
        "INSERT INTO document_upload (document_id, file_name, file_path, mime_type, file_size, uploaded_at)
         VALUES (:doc, :fn, :fp, :mime, :sz, NOW())"
    )->execute([
        'doc'  => $docId,
        'fn'   => $origName,
        'fp'   => 'uploads/trainee-docs/' . $name,
        'mime' => $file['type'] ?? 'application/octet-stream',
        'sz'   => $size,
    ]);

    $pdo->commit();

    header('Location: ' . $back . $sep . 'flash=ok&msg=' . urlencode('Document uploaded for safekeeping.'));
} catch (Throwable $e) {
    if (isset($pdo)) { $pdo->rollBack(); }
    error_log('upload_document failed: ' . $e->getMessage());
    header('Location: ' . $back . $sep . 'flash=err&msg=' . urlencode('Could not upload the document.'));
}
exit;
