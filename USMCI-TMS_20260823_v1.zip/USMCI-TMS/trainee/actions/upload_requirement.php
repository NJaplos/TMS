<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Trainee
 * POST /trainee/actions/upload_requirement.php
 * ---------------------------------------------------------
 * Upload a requirement document for the trainee's course
 * (Valid ID, Passport, SIRB, CDC, Medical, Photo, Previous
 * Certificate, Sea Service, Payment Proof). Stores a `document`
 * row (owner=applicant, document_type_id) + `document_upload`
 * row. Redirects back to the Documents page with a toast.
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/config/bootstrap.php';

require_trainee();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ' . base_url('trainee/documents.php'));
    exit;
}

csrf_check();

$user = current_user();
$applicantId = (int) ($user['applicant_id'] ?? 0);

$typeId = (int) ($_POST['document_type_id'] ?? 0);

$back = base_url('trainee/documents.php');

if (!$typeId) {
    header('Location: ' . $back . '?flash=err&msg=' . urlencode('Select a document type.'));
    exit;
}

if (empty($_FILES['req_file']) || $_FILES['req_file']['error'] !== UPLOAD_ERR_OK) {
    header('Location: ' . $back . '?flash=err&msg=' . urlencode('No file selected.'));
    exit;
}

$file = $_FILES['req_file'];
$size = (int) $file['size'];

if ($size > 8 * 1024 * 1024) {
    header('Location: ' . $back . '?flash=err&msg=' . urlencode('File must be under 8 MB.'));
    exit;
}

$origName = basename($file['name']);
$ext = strtolower(pathinfo($origName, PATHINFO_EXTENSION));
if (!in_array($ext, ['pdf', 'jpg', 'jpeg', 'png'], true)) {
    header('Location: ' . $back . '?flash=err&msg=' . urlencode('Only PDF, JPG, or PNG allowed.'));
    exit;
}

$dir = BASE_PATH . '/uploads/trainee-docs';
if (!is_dir($dir)) { @mkdir($dir, 0775, true); }

$name = 'trainee-' . $applicantId . '-' . time() . '-' . preg_replace('/[^A-Za-z0-9._-]/', '_', $origName);
$dest = $dir . '/' . $name;

if (!move_uploaded_file($file['tmp_name'], $dest)) {
    header('Location: ' . $back . '?flash=err&msg=' . urlencode('Could not save the file.'));
    exit;
}

try {
    $pdo = db();
    $pdo->beginTransaction();

    $pdo->prepare(
        "INSERT INTO document (owner_type, owner_id, document_type_id, title, status, created_at)
         VALUES ('applicant', :owner, :t, :title, 'submitted', NOW())"
    )->execute(['owner' => $applicantId, 't' => $typeId, 'title' => $origName]);
    $docId = (int) $pdo->lastInsertId();

    $pdo->prepare(
        "INSERT INTO document_upload (document_id, file_name, file_path, mime_type, file_size, uploaded_at)
         VALUES (:doc, :fn, :fp, :mime, :sz, NOW())"
    )->execute([
        'doc'  => $docId,
        'fn'   => $origName,
        'fp'   => 'uploads/trainee-docs/' . $name,
        'mime' => $file['type'] ?? 'application/octet-stream',
        'sz'   => $size,
    ]);

    $pdo->commit();
    header('Location: ' . $back . '?flash=ok&msg=' . urlencode('Document uploaded.'));
} catch (Throwable $e) {
    if (isset($pdo) && $pdo->inTransaction()) { $pdo->rollBack(); }
    error_log('upload_requirement failed: ' . $e->getMessage());
    header('Location: ' . $back . '?flash=err&msg=' . urlencode('Could not upload the document.'));
}
exit;
