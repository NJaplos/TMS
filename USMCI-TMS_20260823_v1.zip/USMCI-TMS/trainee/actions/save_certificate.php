<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Trainee
 * POST /trainee/actions/save_certificate.php
 * ---------------------------------------------------------
 * Adds or updates a certificate record owned by the trainee
 * (self-recorded). Trainees can track certificates from any
 * source, or record ones issued by USMCI.
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/config/bootstrap.php';

require_trainee();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ' . base_url('trainee/certificates.php'));
    exit;
}

csrf_check();

$user = current_user();
$applicantId = (int) ($user['applicant_id'] ?? 0);

$certId   = (int) ($_POST['cert_id'] ?? 0);
$certNo   = trim((string) ($_POST['certificate_no'] ?? ''));
$courseId = (int) ($_POST['course_id'] ?? 0) ?: null;
$courseTxt= trim((string) ($_POST['course_name_override'] ?? ''));
$issued   = trim((string) ($_POST['issued_date'] ?? ''));
$expiry   = trim((string) ($_POST['expiry_date'] ?? ''));
$status   = in_array($_POST['status'] ?? '', ['draft','issued','void','expired','reissued'], true) ? $_POST['status'] : 'issued';

$sep = '?';
$back = base_url('trainee/certificates.php');

$fail = function (string $msg) use ($back, $sep) {
    header('Location: ' . $back . $sep . 'flash=err&msg=' . urlencode($msg));
    exit;
};

if ($certNo === '') {
    $fail('Certificate number is required.');
}
if ($courseId === null && $courseTxt === '') {
    $fail('Please choose a course or enter a course name.');
}
if ($issued === '' || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $issued)) {
    $fail('A valid issue date is required.');
}
if ($expiry !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $expiry)) {
    $fail('Expiry date is not valid.');
}

try {
    $pdo = db();
    $pdo->beginTransaction();

    if ($certId > 0) {
        /* EDIT — only own records */
        $own = $pdo->prepare('SELECT id FROM certificate WHERE id = :id AND applicant_id = :aid LIMIT 1');
        $own->execute(['id' => $certId, 'aid' => $applicantId]);
        if (!$own->fetch()) {
            throw new RuntimeException('Certificate not found.');
        }

        $pdo->prepare(
            "UPDATE certificate
             SET certificate_no = :no, course_id = :cid, course_name_override = :co,
                 issued_date = :issued, expiry_date = :exp, status = :status, updated_at = NOW()
             WHERE id = :id"
        )->execute([
            'no' => $certNo, 'cid' => $courseId, 'co' => $courseTxt,
            'issued' => $issued, 'exp' => $expiry !== '' ? $expiry : null,
            'status' => $status, 'id' => $certId,
        ]);
    } else {
        /* ADD */
        $pdo->prepare(
            "INSERT INTO certificate
                (certificate_no, enrollment_id, course_id, course_name_override, applicant_id,
                 issued_date, expiry_date, status, is_self_recorded, created_at, updated_at)
             VALUES
                (:no, NULL, :cid, :co, :aid, :issued, :exp, :status, 1, NOW(), NOW())"
        )->execute([
            'no' => $certNo, 'cid' => $courseId, 'co' => $courseTxt, 'aid' => $applicantId,
            'issued' => $issued, 'exp' => $expiry !== '' ? $expiry : null, 'status' => $status,
        ]);
    }

    $pdo->commit();

    header('Location: ' . $back . $sep . 'flash=ok&msg=' . urlencode('Certificate saved.'));
} catch (Throwable $e) {
    if (isset($pdo)) { $pdo->rollBack(); }
    error_log('save_certificate failed: ' . $e->getMessage());
    $fail('Could not save the certificate: ' . (strpos($e->getMessage(), 'certificate_no') !== false ? 'That certificate number already exists.' : 'please try again.'));
}
exit;
