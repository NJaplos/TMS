<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Trainee
 * POST /trainee/actions/update_profile.php
 * ---------------------------------------------------------
 * Saves the trainee's personal profile (applicant + profile).
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/config/bootstrap.php';

require_trainee();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ' . base_url('trainee/index.php'));
    exit;
}

csrf_check();

$user = current_user();
$pdo  = db();
$applicantId = (int) ($user['applicant_id'] ?? 0);

$fields = [
    'first_name'   => trim((string) ($_POST['first_name'] ?? '')),
    'middle_name'  => trim((string) ($_POST['middle_name'] ?? '')),
    'last_name'    => trim((string) ($_POST['last_name'] ?? '')),
    'suffix'       => trim((string) ($_POST['suffix'] ?? '')),
    'birth_date'   => trim((string) ($_POST['birth_date'] ?? '')),
    'mobile_no'    => trim((string) ($_POST['mobile_no'] ?? '')),
    'gender_id'        => (int) ($_POST['gender_id'] ?? 0) ?: null,
    'civil_status_id'  => (int) ($_POST['civil_status_id'] ?? 0) ?: null,
    'nationality_id'   => (int) ($_POST['nationality_id'] ?? 0) ?: null,
    'relationship_id'  => (int) ($_POST['relationship_id'] ?? 0) ?: null,
    'place_of_birth'      => trim((string) ($_POST['place_of_birth'] ?? '')),
    'address_line1'       => trim((string) ($_POST['address_line1'] ?? '')),
    'rank_position'       => trim((string) ($_POST['rank_position'] ?? '')),
    'seafarer_id_no'      => trim((string) ($_POST['seafarer_id_no'] ?? '')),
    'sirb_no'             => trim((string) ($_POST['sirb_no'] ?? '')),
    'cdc_no'              => trim((string) ($_POST['cdc_no'] ?? '')),
    'passport_no'         => trim((string) ($_POST['passport_no'] ?? '')),
    'passport_expiry'     => trim((string) ($_POST['passport_expiry'] ?? '')),
    'medical_certificate_no' => trim((string) ($_POST['medical_certificate_no'] ?? '')),
    'medical_expiry'      => trim((string) ($_POST['medical_expiry'] ?? '')),
    'emergency_contact_name' => trim((string) ($_POST['emergency_contact_name'] ?? '')),
    'emergency_contact_no'   => trim((string) ($_POST['emergency_contact_no'] ?? '')),
];

if ($fields['first_name'] === '' || $fields['last_name'] === '') {
    header('Location: ' . base_url('trainee/index.php?flash=err&msg=' . urlencode('First and last name are required.')));
    exit;
}

try {
    $pdo->beginTransaction();

    $pdo->prepare(
        "UPDATE applicant SET first_name = :fn, middle_name = :mn, last_name = :ln, suffix = :sx,
                birth_date = :bd, mobile_no = :mb, gender_id = :gid, civil_status_id = :csid,
                nationality_id = :nid, updated_at = NOW()
         WHERE id = :id"
    )->execute([
        'fn' => $fields['first_name'],
        'mn' => $fields['middle_name'],
        'ln' => $fields['last_name'],
        'sx' => $fields['suffix'],
        'bd' => $fields['birth_date'] !== '' ? $fields['birth_date'] : null,
        'mb' => $fields['mobile_no'],
        'gid' => $fields['gender_id'],
        'csid' => $fields['civil_status_id'],
        'nid' => $fields['nationality_id'],
        'id' => $applicantId,
    ]);

    // Upsert profile
    $pdo->prepare(
        "INSERT INTO applicant_profile (applicant_id, place_of_birth, address_line1, rank_position, seafarer_id_no, sirb_no,
                cdc_no, passport_no, passport_expiry, medical_certificate_no, medical_expiry,
                emergency_contact_name, emergency_contact_no, relationship_id, created_at, updated_at)
         VALUES (:aid, :pob, :addr, :rank, :sid, :sirb, :cdc, :ppn, :ppe, :mcn, :mexp, :ecn, :ecno, :rel, NOW(), NOW())
         ON DUPLICATE KEY UPDATE
                place_of_birth = VALUES(place_of_birth), address_line1 = VALUES(address_line1),
                rank_position = VALUES(rank_position),
                seafarer_id_no = VALUES(seafarer_id_no), sirb_no = VALUES(sirb_no), cdc_no = VALUES(cdc_no),
                passport_no = VALUES(passport_no), passport_expiry = VALUES(passport_expiry),
                medical_certificate_no = VALUES(medical_certificate_no), medical_expiry = VALUES(medical_expiry),
                emergency_contact_name = VALUES(emergency_contact_name), emergency_contact_no = VALUES(emergency_contact_no),
                relationship_id = VALUES(relationship_id),
                updated_at = NOW()"
    )->execute([
        'aid'  => $applicantId,
        'pob'  => $fields['place_of_birth'],
        'addr' => $fields['address_line1'],
        'rank' => $fields['rank_position'],
        'sid'  => $fields['seafarer_id_no'],
        'sirb' => $fields['sirb_no'],
        'cdc'  => $fields['cdc_no'],
        'ppn'  => $fields['passport_no'],
        'ppe'  => $fields['passport_expiry'] !== '' ? $fields['passport_expiry'] : null,
        'mcn'  => $fields['medical_certificate_no'],
        'mexp' => $fields['medical_expiry'] !== '' ? $fields['medical_expiry'] : null,
        'ecn'  => $fields['emergency_contact_name'],
        'ecno' => $fields['emergency_contact_no'],
        'rel'  => $fields['relationship_id'],
    ]);

    $pdo->commit();

    header('Location: ' . base_url('trainee/index.php?flash=ok&msg=' . urlencode('Profile updated.')));
} catch (Throwable $e) {
    if (isset($pdo)) { $pdo->rollBack(); }
    error_log('update_profile failed: ' . $e->getMessage());
    header('Location: ' . base_url('trainee/index.php?flash=err&msg=' . urlencode('Could not save profile. Please try again.')));
}
exit;
