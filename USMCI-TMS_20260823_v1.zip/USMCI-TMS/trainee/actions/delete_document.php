<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Trainee
 * POST /trainee/actions/delete_document.php (AJAX)
 * ---------------------------------------------------------
 * Delete one of the trainee's own uploaded requirement
 * documents (only rows owned by the current applicant).
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/config/bootstrap.php';

require_trainee();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'POST required.']);
    exit;
}

csrf_check();

$docId = (int) ($_POST['document_id'] ?? 0);
$user = current_user();
$applicantId = (int) ($user['applicant_id'] ?? 0);

if (!$docId) {
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => 'Document id is required.']);
    exit;
}

try {
    $pdo = db();

    $stmt = $pdo->prepare('SELECT id FROM document WHERE id = :id AND owner_type = \'applicant\' AND owner_id = :oid');
    $stmt->execute(['id' => $docId, 'oid' => $applicantId]);
    if (!$stmt->fetch()) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'Document not found.']);
        exit;
    }

    $pdo->prepare('DELETE FROM document_upload WHERE document_id = :id')->execute(['id' => $docId]);
    $pdo->prepare('DELETE FROM document WHERE id = :id')->execute(['id' => $docId]);

    echo json_encode(['success' => true, 'message' => 'Document deleted.']);
} catch (Throwable $e) {
    error_log('delete_document: ' . $e->getMessage());
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => 'Could not delete the document.']);
}
exit;
