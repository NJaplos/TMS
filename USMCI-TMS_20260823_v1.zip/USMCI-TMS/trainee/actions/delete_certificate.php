<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Trainee
 * POST /trainee/actions/delete_certificate.php
 * ---------------------------------------------------------
 * Deletes a certificate record owned by the trainee.
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/config/bootstrap.php';

require_trainee();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ' . base_url('trainee/certificates.php'));
    exit;
}

csrf_check();

$user = current_user();
$applicantId = (int) ($user['applicant_id'] ?? 0);
$certId = (int) ($_POST['cert_id'] ?? 0);

$back = base_url('trainee/certificates.php');

if (!$certId) {
    header('Location: ' . $back . '?flash=err&msg=' . urlencode('Invalid certificate.'));
    exit;
}

try {
    $pdo = db();
    $stmt = $pdo->prepare('DELETE FROM certificate WHERE id = :id AND applicant_id = :aid AND is_self_recorded = 1');
    $stmt->execute(['id' => $certId, 'aid' => $applicantId]);

    header('Location: ' . $back . '?flash=ok&msg=' . urlencode('Certificate removed.'));
} catch (Throwable $e) {
    error_log('delete_certificate failed: ' . $e->getMessage());
    header('Location: ' . $back . '?flash=err&msg=' . urlencode('Could not remove the certificate.'));
}
exit;
