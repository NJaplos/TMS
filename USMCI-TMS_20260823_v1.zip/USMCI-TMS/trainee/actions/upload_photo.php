<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Trainee
 * POST /trainee/actions/upload_photo.php
 * ---------------------------------------------------------
 * Uploads a profile photo (file input OR camera capture sent
 * as a blob). Saves to /uploads/trainee-photos/ and records
 * the path in applicant_profile.photo_path (schema v3).
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/config/bootstrap.php';

require_trainee();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'POST required.']);
    exit;
}

csrf_check();

$user = current_user();
$applicantId = (int) ($user['applicant_id'] ?? 0);

if (empty($_FILES['photo']) || $_FILES['photo']['error'] !== UPLOAD_ERR_OK) {
    echo json_encode(['success' => false, 'message' => 'No photo received.']);
    exit;
}

$file = $_FILES['photo'];
$tmp  = $file['tmp_name'];
$size = (int) $file['size'];

if ($size > 4 * 1024 * 1024) {
    echo json_encode(['success' => false, 'message' => 'Photo must be under 4 MB.']);
    exit;
}

/* Validate it's really an image */
$info = @getimagesize($tmp);
if ($info === false || !in_array($info[2], [IMAGETYPE_JPEG, IMAGETYPE_PNG, IMAGETYPE_WEBP], true)) {
    echo json_encode(['success' => false, 'message' => 'File must be a JPG, PNG, or WEBP image.']);
    exit;
}

$ext = image_type_to_extension($info[2], false); // jpg / png / webp

$dir = BASE_PATH . '/uploads/trainee-photos';
if (!is_dir($dir)) {
    @mkdir($dir, 0775, true);
}

$name = 'trainee-' . $applicantId . '-' . time() . '.' . $ext;
$dest = $dir . '/' . $name;

if (!move_uploaded_file($tmp, $dest)) {
    echo json_encode(['success' => false, 'message' => 'Could not save the photo.']);
    exit;
}

$relPath = 'uploads/trainee-photos/' . $name;

try {
    $pdo = db();
    $pdo->prepare(
        "INSERT INTO applicant_profile (applicant_id, photo_path, created_at, updated_at)
         VALUES (:aid, :path, NOW(), NOW())
         ON DUPLICATE KEY UPDATE photo_path = VALUES(photo_path), updated_at = NOW()"
    )->execute(['aid' => $applicantId, 'path' => $relPath]);

    echo json_encode([
        'success' => true,
        'message' => 'Photo updated.',
        'photo'   => base_url($relPath),
    ]);
} catch (Throwable $e) {
    error_log('upload_photo failed: ' . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Photo saved but could not update profile.']);
}
exit;
