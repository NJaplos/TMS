<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Trainee: Personal Profile
 * File : trainee/profile.php
 * ---------------------------------------------------------
 */

$activePage = 'profile';
$tNavTitle  = 'Personal Profile';
$tNavSub    = 'Your details, seafarer documents, and emergency contact.';

include __DIR__ . '/partials/top.php';

/* Dropdown lookups */
$genders     = $pdo->query("SELECT id, name FROM mnt_gender WHERE is_active = 1 ORDER BY sort_order")->fetchAll();
$civilStatus = $pdo->query("SELECT id, name FROM mnt_civil_status WHERE is_active = 1 ORDER BY sort_order")->fetchAll();
$nationality = $pdo->query("SELECT id, name FROM mnt_nationality WHERE is_active = 1 ORDER BY sort_order")->fetchAll();
$relations   = $pdo->query("SELECT id, name FROM mnt_relationship WHERE is_active = 1 ORDER BY sort_order")->fetchAll();
?>

            <!-- ============ PROFILE ============ -->
            <section id="profile" class="t-panel">
                <div class="t-panel__head"><h2>👤 Personal Profile</h2><span class="t-panel__tag">Your details</span></div>

                <form method="post" action="<?= e(base_url('trainee/actions/update_profile.php')); ?>" class="t-form">
                    <?= csrf_field(); ?>
                    <div class="t-form__grid">
                        <div class="t-field"><label>First Name *</label><input name="first_name" value="<?= e($applicant['first_name'] ?? ''); ?>" required></div>
                        <div class="t-field"><label>Middle Name</label><input name="middle_name" value="<?= e($applicant['middle_name'] ?? ''); ?>"></div>
                        <div class="t-field"><label>Last Name *</label><input name="last_name" value="<?= e($applicant['last_name'] ?? ''); ?>" required></div>
                        <div class="t-field"><label>Suffix</label><input name="suffix" value="<?= e($applicant['suffix'] ?? ''); ?>"></div>
                        <div class="t-field"><label>Birth Date</label><input type="date" name="birth_date" value="<?= e($applicant['birth_date'] ?? ''); ?>"></div>
                        <div class="t-field"><label>Mobile No.</label><input name="mobile_no" value="<?= e($applicant['mobile_no'] ?? ''); ?>"></div>
                        <div class="t-field">
                            <label>Gender</label>
                            <select name="gender_id">
                                <option value="">— select —</option>
                                <?php foreach ($genders as $g): ?>
                                    <option value="<?= (int) $g['id']; ?>" <?= (int) ($applicant['gender_id'] ?? 0) === (int) $g['id'] ? 'selected' : ''; ?>><?= e($g['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="t-field">
                            <label>Civil Status</label>
                            <select name="civil_status_id">
                                <option value="">— select —</option>
                                <?php foreach ($civilStatus as $c): ?>
                                    <option value="<?= (int) $c['id']; ?>" <?= (int) ($applicant['civil_status_id'] ?? 0) === (int) $c['id'] ? 'selected' : ''; ?>><?= e($c['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="t-field">
                            <label>Nationality</label>
                            <select name="nationality_id">
                                <option value="">— select —</option>
                                <?php foreach ($nationality as $n): ?>
                                    <option value="<?= (int) $n['id']; ?>" <?= (int) ($applicant['nationality_id'] ?? 0) === (int) $n['id'] ? 'selected' : ''; ?>><?= e($n['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="t-field"><label>Place of Birth</label><input name="place_of_birth" value="<?= e($applicant['place_of_birth'] ?? ''); ?>"></div>
                        <div class="t-field"><label>Address</label><input name="address_line1" value="<?= e($applicant['address_line1'] ?? ''); ?>"></div>
                        <div class="t-field"><label>Rank / Position</label><input name="rank_position" value="<?= e($applicant['rank_position'] ?? ''); ?>" placeholder="e.g. Chief Engineer, Deck Cadet"></div>
                        <div class="t-field"><label>SRN No. (Seafarer's Registration No.)</label><input name="seafarer_id_no" value="<?= e($applicant['seafarer_id_no'] ?? ''); ?>"></div>
                        <div class="t-field"><label>SIRB No.</label><input name="sirb_no" value="<?= e($applicant['sirb_no'] ?? ''); ?>"></div>
                        <div class="t-field"><label>CDC No.</label><input name="cdc_no" value="<?= e($applicant['cdc_no'] ?? ''); ?>"></div>
                        <div class="t-field"><label>Passport No.</label><input name="passport_no" value="<?= e($applicant['passport_no'] ?? ''); ?>"></div>
                        <div class="t-field"><label>Passport Expiry</label><input type="date" name="passport_expiry" value="<?= e($applicant['passport_expiry'] ?? ''); ?>"></div>
                        <div class="t-field"><label>Medical Cert No.</label><input name="medical_certificate_no" value="<?= e($applicant['medical_certificate_no'] ?? ''); ?>"></div>
                        <div class="t-field"><label>Medical Expiry</label><input type="date" name="medical_expiry" value="<?= e($applicant['medical_expiry'] ?? ''); ?>"></div>
                        <div class="t-field"><label>Emergency Contact</label><input name="emergency_contact_name" value="<?= e($applicant['emergency_contact_name'] ?? ''); ?>"></div>
                        <div class="t-field"><label>Emergency Contact No.</label><input name="emergency_contact_no" value="<?= e($applicant['emergency_contact_no'] ?? ''); ?>"></div>
                        <div class="t-field">
                            <label>Relationship</label>
                            <select name="relationship_id">
                                <option value="">— select —</option>
                                <?php foreach ($relations as $r): ?>
                                    <option value="<?= (int) $r['id']; ?>" <?= (int) ($applicant['relationship_id'] ?? 0) === (int) $r['id'] ? 'selected' : ''; ?>><?= e($r['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="t-form__actions">
                        <button type="submit" class="btn-primary">Save Profile</button>
                    </div>
                </form>
            </section>

<?php include __DIR__ . '/partials/bottom.php'; ?>
