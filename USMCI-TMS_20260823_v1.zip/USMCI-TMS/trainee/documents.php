<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Trainee: Documents / Requirements
 * File : trainee/documents.php
 * ---------------------------------------------------------
 * Upload the documents required for your course (Valid ID,
 * Passport, SIRB, CDC, Medical, Photo, Previous Certificate,
 * Sea Service, Payment Proof). Listed per type with
 * Download + Delete (system modal).
 * ---------------------------------------------------------
 */

$activePage = 'documents';
$tNavTitle  = 'Documents';
$tNavSub    = 'Upload the requirements needed for your course.';

include __DIR__ . '/partials/top.php';

$docTypes = $pdo->query("SELECT id, code, name, description FROM mnt_document_type WHERE is_active = 1 ORDER BY sort_order")->fetchAll() ?: [];

$docsStmt = $pdo->prepare(
    "SELECT d.id AS doc_id, d.document_type_id, d.title, d.status, d.created_at,
            dt.name AS type_name, dt.code AS type_code,
            du.id AS upload_id, du.file_name, du.file_path, du.uploaded_at
     FROM document d
     LEFT JOIN mnt_document_type dt ON dt.id = d.document_type_id
     LEFT JOIN document_upload du ON du.document_id = d.id
     WHERE d.owner_type = 'applicant' AND d.owner_id = :id
     ORDER BY d.created_at DESC LIMIT 50"
);
$docsStmt->execute(['id' => $applicantId]);
$docs = $docsStmt->fetchAll() ?: [];

/* Required documents for this trainee's enrolled course(s) — visible
   hint panel with the document description (V5.48). */
$requiredDocTypes = [];
$enrCourses = $pdo->prepare(
    "SELECT e.course_id, c.course_name FROM enrollment e
     JOIN mnt_course c ON c.id = e.course_id
     WHERE e.applicant_id = :ap AND e.status IN ('pending','enrolled')
     ORDER BY e.id DESC LIMIT 3"
);
$enrCourses->execute(['ap' => $applicantId]);
foreach ($enrCourses->fetchAll() ?: [] as $ec) {
    foreach (course_required_docs($pdo, (int) $ec['course_id']) as $req) {
        $requiredDocTypes[(int) $req['id']] = [
            'name'        => $req['name'],
            'code'        => $req['code'],
            'description' => $req['description'] ?? '',
            'course'      => $ec['course_name'] ?? '',
        ];
    }
}
?>
            <!-- ============ DOCUMENTS / REQUIREMENTS ============ -->
            <section id="documents" class="t-panel">
                <div class="t-panel__head">
                    <h2>📎 My Documents</h2>
                    <span class="t-panel__tag">Course requirements</span>
                </div>

                <p style="font-size:.85rem;color:#64748B;margin-bottom:16px;">
                    Upload the documents required for your course. The Admissions / Admin office reviews these against your enrollment.
                </p>

                <?php if ($requiredDocTypes): ?>
                <div class="t-panel__sub" style="margin-top:0;">
                    <h4>📋 Required documents for your course</h4>
                    <ul style="list-style:none;margin:8px 0 0;padding:0;display:flex;flex-direction:column;gap:6px;">
                        <?php foreach ($requiredDocTypes as $req): ?>
                            <li style="background:#F8FAFC;border:1px solid #E2E8F0;border-radius:8px;padding:8px 12px;font-size:.84rem;">
                                <strong style="color:#0B3C5D;"><?= e($req['name']); ?></strong>
                                <?php if (!empty($req['course'])): ?>
                                    <span class="course-desc"> — <?= e($req['course']); ?></span>
                                <?php endif; ?>
                                <?php if (!empty($req['description'])): ?>
                                    <div class="field-hint" style="margin-top:2px;"><?= e($req['description']); ?></div>
                                <?php endif; ?>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <?php endif; ?>

                <div class="t-panel__sub" style="margin-top:0;">
                    <h4>＋ Upload a requirement document</h4>
                    <form method="post" enctype="multipart/form-data" action="<?= e(base_url('trainee/actions/upload_requirement.php')); ?>" class="doc-upload" style="margin-top:12px;">
                        <?= csrf_field(); ?>
                        <select name="document_type_id" required style="flex:1;min-width:200px;padding:11px 14px;border:1px solid #CBD5E1;border-radius:10px;font-family:inherit;">
                            <option value="">— document type —</option>
                            <?php foreach ($docTypes as $dt): ?>
                                <option value="<?= (int) $dt['id']; ?>" <?= !empty($dt['description']) ? 'title="' . e($dt['description']) . '"' : ''; ?>><?= e($dt['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                        <input type="file" name="req_file" accept=".pdf,.jpg,.jpeg,.png" required style="flex:2;min-width:220px;">
                        <button type="submit" class="btn-primary btn-sm">Upload</button>
                    </form>
                    <small class="field-hint">PDF, JPG, or PNG — max 8 MB.</small>
                </div>

                <div class="t-panel__sub">
                    <h4>Uploaded documents (<?= count($docs); ?>)</h4>
                    <?php if (!$docs): ?>
                        <p class="t-empty">No documents uploaded yet.</p>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="inquiry-table">
                                <thead><tr><th>Type</th><th>File</th><th>Uploaded</th><th>Status</th><th>Actions</th></tr></thead>
                                <tbody>
                                    <?php foreach ($docs as $d): ?>
                                        <tr id="doc-<?= (int) $d['doc_id']; ?>">
                                            <td><strong><?= e($d['type_name'] ?? 'Document'); ?></strong></td>
                                            <td><?= e($d['file_name'] ?? '—'); ?></td>
                                            <td><?= e(date('M d, Y', strtotime($d['uploaded_at'] ?? $d['created_at']))); ?></td>
                                            <td><span class="status-badge status-<?= $d['status'] === 'verified' ? 'converted' : ($d['status'] === 'rejected' ? 'closed' : 'pending'); ?>"><?= e(ucfirst($d['status'] ?? 'pending')); ?></span></td>
                                            <td class="cert-table__actions">
                                                <?php if (!empty($d['file_path'])): ?>
                                                    <a class="btn-secondary btn-sm" href="<?= e(base_url($d['file_path'])); ?>" target="_blank" title="<?= e($d['file_name']); ?>">⬇ Download</a>
                                                <?php endif; ?>
                                                <button type="button" class="btn-secondary btn-sm" data-doc-delete='<?= json_encode(['id'=>(int)$d['doc_id'],'name'=>$d['type_name'] ?? 'document'], JSON_HEX_APOS|JSON_HEX_QUOT); ?>'>🗑 Delete</button>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </section>

<script>
(function () {
    var DELETE_URL = <?= json_encode(base_url('trainee/actions/delete_document.php')); ?>;
    var CSRF = <?= json_encode(csrf_token()); ?>;
    document.querySelectorAll("[data-doc-delete]").forEach(function (btn) {
        btn.addEventListener("click", function () {
            var d = JSON.parse(btn.dataset.docDelete);
            usmciConfirm({
                title: "Delete document?",
                message: "Delete your " + d.name + " document? This removes the upload.",
                confirmText: "Delete",
                danger: true
            }).then(function (ok) {
                if (!ok) return;
                var fd = new FormData();
                fd.append("csrf_token", CSRF);
                fd.append("document_id", d.id);
                fetch(DELETE_URL, { method: "POST", body: fd })
                    .then(function (r) { return r.json(); })
                    .then(function (res) {
                        window.usmciToast(res.message, res.success ? "success" : "error");
                        if (res.success) {
                            var tr = btn.closest("tr");
                            if (tr) tr.remove();
                        }
                    })
                    .catch(function () { window.usmciToast("Could not delete the document.", "error"); });
            });
        });
    });
})();
</script>

<?php include __DIR__ . '/partials/bottom.php'; ?>
