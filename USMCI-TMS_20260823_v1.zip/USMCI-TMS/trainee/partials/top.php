<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Trainee shell (unified portal)
 * ---------------------------------------------------------
 * Uses assets/css/portal.css + includes/portal-sidebar.php —
 * the SAME shell as the staff dashboards, so the sidebar,
 * navbar clearance, and padding are identical everywhere.
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/config/bootstrap.php';

require_trainee();

$user = current_user();
$pdo  = db();
$applicantId = (int) ($user['applicant_id'] ?? 0);

/* ---- Applicant + profile ---- */
$applicant = $pdo->prepare(
    "SELECT a.*, ap.*, g.name AS gender_name
     FROM applicant a
     LEFT JOIN applicant_profile ap ON ap.applicant_id = a.id
     LEFT JOIN mnt_gender g ON g.id = a.gender_id
     WHERE a.id = :id LIMIT 1"
);
$applicant->execute(['id' => $applicantId]);
$applicant = $applicant->fetch() ?: [];

$fullName = trim(($applicant['first_name'] ?? '') . ' ' . ($applicant['last_name'] ?? ''));
$photo = !empty($applicant['photo_path']) ? base_url(ltrim($applicant['photo_path'], '/')) : '';

/* Latest inquiry (shared by trainee pages) */
$inquiry = null;
$inqStmt = $pdo->prepare(
    "SELECT i.*, s.label AS status_label, s.code AS status_code
     FROM inquiry i
     LEFT JOIN mnt_inquiry_status s ON s.id = i.status_id
     WHERE i.applicant_id = :id OR i.email = :email
     ORDER BY i.id DESC LIMIT 1"
);
$inqStmt->execute(['id' => $applicantId, 'email' => $user['email'] ?? '']);
$inquiry = $inqStmt->fetch() ?: null;

$flash = $_GET['flash'] ?? '';
$flashMsg = $_GET['msg'] ?? '';

/* Unread notification count for the bell badge (V5.41) */
$unreadNotifs = ($applicantId > 0) ? applicant_unread_notifications($pdo, $applicantId) : 0;

/* Unified portal nav (same structure as staff sidebar) */
$portalNav = [
    ['href' => base_url('trainee/index.php'),       'icon' => '🏠', 'label' => 'Overview',      'desc' => 'My status at a glance',   'active' => ($activePage ?? '') === 'overview'],
    ['href' => base_url('trainee/inquiry.php'),     'icon' => '📨', 'label' => 'My Inquiry',    'desc' => 'Reference & conversation','active' => ($activePage ?? '') === 'inquiry'],
    ['href' => base_url('trainee/registration.php'),'icon' => '📝', 'label' => 'Registration',  'desc' => 'Enrollment slip',         'active' => ($activePage ?? '') === 'registration'],
    ['href' => base_url('trainee/payments.php'),    'icon' => '💳', 'label' => 'Payments',      'desc' => 'Fees & balance',          'active' => ($activePage ?? '') === 'payments'],
    ['href' => base_url('trainee/documents.php'),   'icon' => '📎', 'label' => 'Documents',     'desc' => 'Course requirements',    'active' => ($activePage ?? '') === 'documents'],
    ['href' => base_url('trainee/certificates.php'),'icon' => '📜', 'label' => 'Certificates',  'desc' => 'Validity & copies',       'active' => ($activePage ?? '') === 'certificates'],
    ['href' => base_url('trainee/notifications.php'),'icon' => '🔔', 'label' => 'Notifications','desc' => ($unreadNotifs ? $unreadNotifs . ' unread' : 'Updates & alerts'), 'active' => ($activePage ?? '') === 'notifications', 'badge' => $unreadNotifs],
    ['href' => base_url('trainee/profile.php'),     'icon' => '👤', 'label' => 'Profile',       'desc' => 'Personal info',          'active' => ($activePage ?? '') === 'profile'],
    ['href' => base_url('trainee/account.php'),     'icon' => '⚙️', 'label' => 'Account',       'desc' => 'Password & security',    'active' => ($activePage ?? '') === 'account'],
];

$portalUser = [
    'name'  => $fullName !== '' ? $fullName : ($user['username'] ?? 'Trainee'),
    'role_label' => 'Trainee',
    'sub'   => $applicant['applicant_no'] ?? '',
    'photo' => $photo,
];

$page = [
    'title'       => ($tNavTitle ?? 'My Dashboard') . ' | USMCI-TMS',
    'description' => 'Trainee Dashboard',
    'bodyClass'   => 'trainee-page',
];
?>
<!DOCTYPE html>
<html lang="en">

<?php include INCLUDES_PATH . '/head.php'; ?>

<link rel="stylesheet" href="<?= e(base_url('assets/css/portal.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('trainee/trainee.css?v=' . ASSET_VERSION)); ?>">

<body class="<?= e($page['bodyClass']); ?>">

    <?php include NAVBAR_PATH . '/index.php'; ?>

    <div class="portal-shell">

        <?php include INCLUDES_PATH . '/portal-sidebar.php'; ?>

        <main class="portal-content">

            <header class="trainee-header">
                <div>
                    <span class="section-badge">Welcome</span>
                    <h2><?= e($tNavTitle ?? 'My Dashboard'); ?></h2>
                    <p><?= e($tNavSub ?? 'Monitor your admission, enrollment, payments, and certificates.'); ?></p>
                </div>
                <div class="trainee-header__right">
                    <a href="<?= e(base_url('trainee/notifications.php')); ?>" class="trainee-bell" title="Notifications">
                        🔔
                        <?php if ($unreadNotifs > 0): ?>
                            <span class="trainee-bell__count"><?= (int) $unreadNotifs; ?></span>
                        <?php endif; ?>
                    </a>
                    <span class="trainee-chip"><?= e($user['email'] ?? ''); ?></span>
                </div>
            </header>

            <?php if ($flash === 'ok'): ?>
                <div class="t-alert t-alert--ok">✅ <?= htmlspecialchars($flashMsg, ENT_QUOTES, 'UTF-8'); ?></div>
            <?php elseif ($flash === 'err'): ?>
                <div class="t-alert t-alert--err">⚠️ <?= htmlspecialchars($flashMsg, ENT_QUOTES, 'UTF-8'); ?></div>
            <?php endif; ?>
