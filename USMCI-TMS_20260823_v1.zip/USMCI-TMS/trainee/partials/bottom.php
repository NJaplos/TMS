        </main>

        <!-- ================= RIGHT RAIL ================= -->
        <aside class="portal-right">
            <div class="trainee-rail__card">
                <div class="trainee-rail__photo">
                    <?php if ($photo): ?>
                        <img src="<?= e($photo); ?>" alt="My photo" id="railPhoto" data-photo>
                    <?php else: ?>
                        <div class="trainee-rail__photo-placeholder" id="railPhotoPlaceholder">📷</div>
                    <?php endif; ?>
                </div>
                <h3><?= e($fullName !== '' ? $fullName : 'Trainee'); ?></h3>
                <p class="trainee-rail__srn"><?= e($applicant['applicant_no'] ?? ''); ?></p>

                <div class="trainee-rail__actions">
                    <button type="button" class="btn-secondary btn-sm" id="btnUploadPhoto">📤 Upload Photo</button>
                    <button type="button" class="btn-secondary btn-sm" id="btnCameraPhoto">📷 Use Camera</button>
                </div>
                <input type="file" id="photoInput" accept="image/*" style="display:none">

                <div id="cameraModal" class="cam-modal" style="display:none;">
                    <div class="cam-modal__box">
                        <div class="cam-select-row">
                            <label for="cameraSelect">Camera:</label>
                            <select id="cameraSelect"><option value="">— choose a camera —</option></select>
                            <button type="button" class="btn-secondary btn-sm" id="btnSwitchCamera">↻</button>
                        </div>
                        <video id="cameraVideo" autoplay playsinline></video>
                        <canvas id="cameraCanvas" style="display:none;"></canvas>
                        <div class="cam-modal__actions">
                            <button type="button" class="btn-secondary btn-sm" id="btnCapture">📸 Capture</button>
                            <button type="button" class="btn-secondary btn-sm" id="btnCamClose">✖ Close</button>
                        </div>
                        <button type="button" class="btn-primary btn-sm" id="btnSavePhoto" style="display:none;">💾 Save Photo</button>
                    </div>
                </div>
            </div>

            <div class="trainee-rail__card trainee-rail__info">
                <h4>Quick Info</h4>
                <ul>
                    <li><span>Email</span><strong><?= e($user['email'] ?? '—'); ?></strong></li>
                    <li><span>Mobile</span><strong><?= e($applicant['mobile_no'] ?? '—'); ?></strong></li>
                    <li><span>Rank / Position</span><strong><?= e($applicant['rank_position'] ?? '—'); ?></strong></li>
                    <li><span>Gender</span><strong><?= e($applicant['gender_name'] ?? '—'); ?></strong></li>
                    <li><span>Passport Expiry</span><strong class="<?= !empty($applicant['passport_expiry']) && strtotime($applicant['passport_expiry']) < time() ? 'cert-expired' : ''; ?>"><?= e($applicant['passport_expiry'] ?? '—'); ?></strong></li>
                    <li><span>Medical Expiry</span><strong class="<?= !empty($applicant['medical_expiry']) && strtotime($applicant['medical_expiry']) < time() ? 'cert-expired' : ''; ?>"><?= e($applicant['medical_expiry'] ?? '—'); ?></strong></li>
                </ul>
            </div>
        </aside>
    </div>

    <?php include INCLUDES_PATH . '/footer.php'; ?>
    <?php include INCLUDES_PATH . '/scripts.php'; ?>

    <script>
        (function () {
            var photoInput = document.getElementById("photoInput");
            var btnUpload = document.getElementById("btnUploadPhoto");
            var btnCamera = document.getElementById("btnCameraPhoto");
            var camModal = document.getElementById("cameraModal");
            var video = document.getElementById("cameraVideo");
            var canvas = document.getElementById("cameraCanvas");
            var btnCapture = document.getElementById("btnCapture");
            var btnSave = document.getElementById("btnSavePhoto");
            var btnCamClose = document.getElementById("btnCamClose");
            var cameraSelect = document.getElementById("cameraSelect");
            var btnSwitch = document.getElementById("btnSwitchCamera");
            var cameras = [];
            var currentCamIndex = 0;
            var stream = null;

            // Shared UDS toast (assets/js/usmci-toast.js)
            function showTraineeToast(msg, type) { window.usmciToast(msg, type || "success"); }

            function uploadPhoto(file) {
                if (!file) return;
                var fd = new FormData();
                fd.append("photo", file);
                fd.append("csrf_token", <?= json_encode(csrf_token()); ?>);
                fetch(<?= json_encode(base_url('trainee/actions/upload_photo.php')); ?>, { method: "POST", body: fd })
                    .then(function (r) { return r.json(); })
                    .then(function (res) {
                        if (res.success) {
                            document.querySelectorAll("img[data-photo]").forEach(function (im) { im.src = res.photo + "?t=" + Date.now(); im.style.display = "block"; });
                            var ph = document.getElementById("railPhotoPlaceholder");
                            if (ph) ph.style.display = "none";
                            showTraineeToast("Photo updated!");
                        } else {
                            showTraineeToast(res.message || "Upload failed.", "danger");
                        }
                    })
                    .catch(function () { showTraineeToast("Upload failed.", "danger"); });
            }

            if (btnUpload) btnUpload.addEventListener("click", function () { photoInput.click(); });
            if (photoInput) photoInput.addEventListener("change", function () { uploadPhoto(this.files[0]); this.value = ""; });

            function loadCameras() {
                if (!navigator.mediaDevices || !navigator.mediaDevices.enumerateDevices) return;
                navigator.mediaDevices.enumerateDevices().then(function (devices) {
                    cameras = devices.filter(function (d) { return d.kind === "videoinput"; });
                    cameraSelect.innerHTML = "";
                    if (cameras.length === 0) {
                        var opt = document.createElement("option");
                        opt.value = ""; opt.textContent = "No camera detected";
                        cameraSelect.appendChild(opt);
                        return;
                    }
                    cameras.forEach(function (cam, i) {
                        var opt = document.createElement("option");
                        opt.value = String(i);
                        opt.textContent = cam.label || ("Camera " + (i + 1));
                        cameraSelect.appendChild(opt);
                    });
                    cameraSelect.value = "0";
                }).catch(function () {});
            }

            function startCamera(deviceId) {
                if (stream) { stream.getTracks().forEach(function (t) { t.stop(); }); }
                var constraints = { video: { width: { ideal: 640 }, height: { ideal: 480 } } };
                if (deviceId) constraints.video.deviceId = { exact: deviceId };
                return navigator.mediaDevices.getUserMedia(constraints)
                    .then(function (s) {
                        stream = s;
                        video.srcObject = s;
                        video.play();
                        btnSave.style.display = "none";
                        btnCapture.style.display = "inline-block";
                    })
                    .catch(function () { showTraineeToast("Could not start that camera.", "warning"); });
            }

            if (btnCamera) btnCamera.addEventListener("click", function () {
                camModal.style.display = "flex";
                btnSave.style.display = "none";
                btnCapture.style.display = "inline-block";
                loadCameras();
                startCamera().catch(function () { showTraineeToast("Camera not available.", "warning"); camModal.style.display = "none"; });
            });

            if (cameraSelect) cameraSelect.addEventListener("change", function () {
                var idx = parseInt(cameraSelect.value, 10);
                if (!isNaN(idx) && cameras[idx]) startCamera(cameras[idx].deviceId);
            });

            if (btnSwitch) btnSwitch.addEventListener("click", function () {
                if (cameras.length <= 1) { showTraineeToast("Only one camera detected.", "warning"); return; }
                currentCamIndex = (currentCamIndex + 1) % cameras.length;
                cameraSelect.value = String(currentCamIndex);
                startCamera(cameras[currentCamIndex].deviceId);
            });

            if (btnCapture) btnCapture.addEventListener("click", function () {
                canvas.width = video.videoWidth || 640;
                canvas.height = video.videoHeight || 480;
                canvas.getContext("2d").drawImage(video, 0, 0, canvas.width, canvas.height);
                btnSave.style.display = "inline-block";
            });

            if (btnSave) btnSave.addEventListener("click", function () {
                canvas.toBlob(function (blob) {
                    if (blob) uploadPhoto(new File([blob], "camera-photo.jpg", { type: "image/jpeg" }));
                }, "image/jpeg", 0.85);
                if (stream) { stream.getTracks().forEach(function (t) { t.stop(); }); }
                camModal.style.display = "none";
            });

            if (btnCamClose) btnCamClose.addEventListener("click", function () {
                if (stream) { stream.getTracks().forEach(function (t) { t.stop(); }); }
                camModal.style.display = "none";
            });
        })();
    </script>

</body>
</html>
