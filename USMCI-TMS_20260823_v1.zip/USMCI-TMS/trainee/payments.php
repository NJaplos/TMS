<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Trainee: Payments
 * File : trainee/payments.php
 * ---------------------------------------------------------
 */

$activePage = 'payments';
$tNavTitle  = 'Payments';
$tNavSub    = 'Your payment ledger — amounts paid, balance, and status.';

include __DIR__ . '/partials/top.php';

$payments = $pdo->prepare(
    "SELECT p.*, ps.name AS status_name
     FROM payment p
     LEFT JOIN mnt_payment_status ps ON ps.id = p.payment_status_id
     WHERE p.applicant_id = :id
     ORDER BY p.id DESC LIMIT 15"
);
$payments->execute(['id' => $applicantId]);
$payments = $payments->fetchAll() ?: [];

$totalPaid = array_sum(array_map(fn($p) => (float) $p['paid_amount'], $payments));
$totalBal  = array_sum(array_map(fn($p) => (float) $p['balance_amount'], $payments));
?>

            <!-- ============ PAYMENTS ============ -->
            <section id="payments" class="t-panel">
                <div class="t-panel__head"><h2>💳 Payment Ledger</h2><span class="t-panel__tag">Fees</span></div>

                <div class="t-pay-summary">
                    <div class="t-pay-box"><span>Total Paid</span><strong style="color:#15803D;">₱ <?= number_format($totalPaid, 2); ?></strong></div>
                    <div class="t-pay-box"><span>Outstanding Balance</span><strong style="color:#B45309;">₱ <?= number_format($totalBal, 2); ?></strong></div>
                </div>

                <?php if (!$payments): ?>
                    <p class="t-empty">No payments recorded yet.</p>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="inquiry-table">
                            <thead><tr><th>Payment No.</th><th>Total</th><th>Paid</th><th>Balance</th><th>Status</th><th>Due</th></tr></thead>
                            <tbody>
                                <?php foreach ($payments as $p): ?>
                                    <tr>
                                        <td><?= e($p['payment_no']); ?></td>
                                        <td>₱ <?= number_format((float) $p['total_amount'], 2); ?></td>
                                        <td style="color:#15803D;">₱ <?= number_format((float) $p['paid_amount'], 2); ?></td>
                                        <td style="color:#B45309;">₱ <?= number_format((float) $p['balance_amount'], 2); ?></td>
                                        <td><span class="status-badge"><?= e($p['status_name'] ?? $p['status']); ?></span></td>
                                        <td><?= e($p['due_date'] ?? '—'); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>

                <p class="t-empty" style="margin-top:12px;">For payment inquiries, please contact the Accounting Office or email the Admissions Office.</p>
            </section>

<?php include __DIR__ . '/partials/bottom.php'; ?>
