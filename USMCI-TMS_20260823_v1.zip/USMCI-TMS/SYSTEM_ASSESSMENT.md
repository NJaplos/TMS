# USMCI-TMS — System Assessment & Improvement Roadmap
**Prepared:** 2026-08-14 · Scope: Admissions · Enrollment · Accounts (staff + trainee)

---

## How to read this
- **P0 = Correctness / money risk** — fix first, can cost or confuse records.
- **P1 = Operational efficiency** — saves staff time every day.
- **P2 = Completeness / polish** — makes the system feel finished.

Each item is verified against the current code (file references included).

---

## A. ADMISSIONS (Inquiry Queue · Applicants)

### A1 — [P1] Duplicate-inquiry detection (real gap)
**Problem:** anyone can submit the same email/name repeatedly → the same person stacks up as several "New" inquiries. This inflates the **Awaiting Reply** KPI and forces staff to answer the same question N times.
**Current code:** inquiry insert has no check (only `inquiry_no` uniqueness).
**Recommendation:** on public inquiry submit, look for an existing **open** inquiry (`status NEW/REPLIED`) with the same normalized email (`LOWER(TRIM())`). If found, return a friendly "We already have your inquiry — reference INQ-… " message instead of creating a duplicate. Keep creating new ones only when the previous is CLOSED/CONVERTED.

### A2 — [P1] Applicant 360° profile page
**Problem:** an applicant's story is spread across 6 modules (Inquiries, Applicants, Enrollment, Payments, Documents, Certificates). Staff jump between pages to see one person.
**Recommendation:** add "👁 View" on the Applicants row that opens a **one-screen timeline**: applicant info → inquiries + conversation → enrollments (with batch/status) → payment obligations (paid/balance) → requirement documents (submitted/verified) → certificates. Read-mostly, one click. This is the single biggest daily time-saver for admissions.

### A3 — [P1] Inquiry aging indicator
**Problem:** nothing shows **how long** an inquiry has been waiting. The queue has a date filter but no "3 days old" cue.
**Recommendation:** add an "Age" column (e.g. `2d`, colored amber >3d, red >7d) + a "Pending > 3 days" quick filter chip.

### A4 — [P2] Batch actions in the queue
**Recommendation:** checkboxes + "Mark as Replied" / "Create codes" for multiple rows, so staff don't open N modals one by one.

### A5 — [P2] Inquiry attachments surfaced
The `inquiry_attachment` table exists but nothing in the UI uses it. If you want trainees to attach files when inquiring (e.g. a scanned requirement), wire it up.

---

## B. ENROLLMENT

### B1 — [P0] No hard slot-capacity block (real risk)
**Problem:** the batch dropdown shows `filled/max` but **nothing stops enrolling into a full batch** — the count is informational only.
**Current code:** enrollment POST only validates applicant/course/date; no `filled >= max_slots` check server-side.
**Recommendation:** server-side guard: if the batch's active-enrollment count ≥ max_slots → reject with a toast "Batch full (30/30)". Also mark full batches as `disabled` in the dropdown.

### B2 — [P0] Duplicate-enrollment → double-billing (real money risk)
**Problem:** the same trainee enrolled twice for the same course (e.g. two batches) creates **two auto-payments** — the payment generator checks per-enrollment, not per (applicant, course). The certificate module already blocks a 2nd live cert, but payments don't.
**Current code:** `create_payment_for_enrollment()` dedups only by `enrollment_id`.
**Recommendation:** (a) server-side guard in enrollment create: block a new **active** enrollment for the same (applicant, course) unless the old one is cancelled/completed; (b) in the payment auto-creator, skip if an unpaid/partial payment already exists for the same (applicant, course). This closes the double-bill.

### B3 — [P1] Requirements gate
**Problem:** trainees upload requirement documents (Documents module) but nothing links them to enrollment — a trainee can be fully enrolled with zero documents uploaded.
**Recommendation:** on the Enrollment page show per-applicant "Docs: 2/5 submitted" and let the status update require the mandatory set (or at least flag it). Tie in a future **Document Review** (staff marks verified/rejected — statuses already exist in `document.status`).

### B4 — [P1] Payment gate option
Currently enrollment can proceed with ₱0 collected (payments auto-create as Unpaid — fine for "pay later"). Consider a setting: **"Require down payment before Enrolled"** so the status stays Pending until a partial payment is recorded. Optional — many schools prefer flexibility.

### B5 — [P2] Waitlist
When a batch is full, offer "Add to waitlist" (a `waitlist` table or reuse enrollment with `pending` + flag) and auto-notify when a slot frees up. Nice-to-have.

### B6 — [P2] Class schedule visibility
The `training_schedule` table (session dates/times/topics) has **no UI at all**. Staff can't set sessions, trainees can't see them. Worth building a simple "Sessions" tab on Training Batches + a read-only schedule on the trainee's Registration page.

---

## C. ACCOUNTS (Staff + Trainee)

### C1 — [P1] Role-based access (RBAC) — biggest accounts gap
**Problem:** `sys_role` has ADMIN, ADMISSIONS, REGISTRAR, ACCOUNTING, INSTRUCTOR, HR — but **every role sees the same sidebar and pages** (only Staff Accounts itself is admin-gated). An Accounting user can open Certificates; a Registrar can open Payments.
**Recommendation:** role → menu mapping (e.g. Accounting sees Payments/Reports only; Registrar sees Enrollment/Certificates). Enforce in the sidebar (`$portalNav` filtered by `role_code`) AND a `require_role()` guard per page. Low code, high correctness.

### C2 — [P1] Staff audit trail
**Problem:** only `enrollment_history` and the applicant-delete write an audit trail. **Payment voids, certificate voids, staff account changes, and payment records have no audit log** — if a receipt is voided there's no "who/when/why" record beyond the toast.
**Recommendation:** a lightweight `audit_log` (user_id, action, module, record_id, detail, ip, created_at) written in payment_record, payment_void, certificate_void, applicant_delete, staff create/toggle/reset. Cheap to add, invaluable for accounting.

### C3 — [P1] Password policy upgrade
**Current:** min 8 chars only; no complexity, no expiry, no "must change on first login".
**Recommendation:** (a) require at least one letter + one number (keep it simple); (b) optional expiry (90/180d) — defer if school doesn't want it; (c) a `must_change_password` flag so the password the admin hands out forces a change on first login (fits the existing "give this to staff" flow).

### C4 — [P2] Self-service password reset
Staff can't recover their own password (admin must reset; trainee must know the old one). With SMTP already in place, add "Forgot password?" → emailed one-time reset token (expires 30 min, single-use). Low effort, removes a real support burden.

### C5 — [P2] Trainee email change / re-verify
`email_verified_at` is set implicitly at registration (fine, since they registered via invite). But there's no way to change an email or resend anything. Only worth adding if trainees report changing email addresses.

### C6 — [P2] Session hardening
Add configurable session timeout (e.g. idle 60 min → re-login) and "Sign out everywhere" (invalidate other sessions) for staff. Moderate effort.

---

## D. CROSS-CUTTING

### D1 — [P1] Reports: real exports + filters
**Current:** Reports is read-only tiles (counts + status breakdown). No CSV export, no date range, no per-course/batch filter, no revenue-by-month.
**Recommendation:** add "Export CSV" (inquiries, applicants, enrollments, payments, certificates) + a date-range filter + a revenue-by-month mini chart. This is what the school will actually print for management.

### D2 — [P1] Pagination on Applicants
**Current:** `LIMIT 100` with no pagination — the list silently truncates as data grows.
**Recommendation:** server-side pagination like the Inquiry Queue already has.

### D3 — [P2] QR code on printed certificates
`qr_code_value` is stored and the verify link works, but the **printed certificate is text-only** — no QR image. Rendering the QR (e.g. a small pure-PHP QR generator or an image endpoint) makes the paper cert verifiable by phone scan. High visual value.

### D4 — [P2] Failed-email retry
`email_queue` has failed rows with no retry. Add a "Retry failed" button in Email Center (already lists them).

### D5 — [P2] Notifications
`applicant_notification` table is unused. When a cert is issued / enrollment completed, insert a notification row → show a bell/count on the trainee dashboard. Nice finishing touch.

---

## Recommended build order
| Priority | Item | Effort |
|---|---|---|
| 🔴 P0 | B1 slot-capacity block | Small |
| 🔴 P0 | B2 duplicate-enrollment / double-bill guard | Small |
| 🟠 P1 | C1 role-based menu + guards | Medium |
| 🟠 P1 | A2 applicant 360° profile | Medium |
| 🟠 P1 | A1 duplicate-inquiry detection | Small |
| 🟠 P1 | C2 audit trail (voids/payments/staff) | Medium |
| 🟠 P1 | D1 reports export + date range | Medium |
| 🟠 P1 | D2 applicants pagination | Small |
| 🟡 P2 | A3 aging indicator · A4 batch actions · C3 password policy | Small |
| 🟡 P2 | B6 schedule UI · D3 QR on cert · D4 retry · D5 notifications | Medium |

I can implement any of these in the next build — the two P0 items (slot capacity + duplicate-enrollment double-bill guard) are the ones I'd do first because they protect money and record integrity.
