# ✅ USMCI-TMS — Acceptance Test Checklist

> **🔴 CURRENT BUILD IN THIS ZIP: V5.71 (Aug 20, 2026) — sections A → BS.**
> If the section headers on YOUR screen stop at an earlier letter (e.g. ##AB),
> you are looking at an OLD copy of the checklist from an OLD install —
> fully replace `htdocs/USMCI-TMS` with the new zip contents (do not merge),
> run `database/apply_all_updates.sql`, then hard-refresh (Ctrl+F5).

Use this to verify each module after installing the build. Tick each box ✅
(or mark ❌ + note what happened). Send me the filled list — that's the fastest
way to close issues.

**Setup first:** replace `htdocs/USMCI-TMS` → run `database/apply_all_updates.sql`
in phpMyAdmin (SQL tab, click Go) → hard-refresh browser (`Ctrl+F5`).

---

## A. Database / Schema
- [ ] Ran `database/apply_all_updates.sql` with **no error** (green, no red message)
- [ ] Ran it **a second time** — still no error (proves it's safe to re-run)
- [ ] phpMyAdmin → `enrollsys` → `applicant_invitation` has `registration_code` column
- [ ] `applicant_profile` has `photo_path` + `rank_position` columns
- [ ] `certificate` has `course_name_override` + `is_self_recorded` columns
- [ ] `certificate` still has its 4 foreign keys (enrollment, course, applicant, user)

## B. Login & Account Creation
- [ ] `http://localhost/USMCI-TMS/login.php` shows **Sign In** + **Create Account** tabs
- [ ] Staff login works: `admin` / `Admin@1234` → lands on **Admin Dashboard**
- [ ] Second staff: `admissions` / `Admissions@1234` → also Admin Dashboard
- [ ] Wrong password shows "Invalid username or password" (no crash)
- [ ] Create Account tab: entering a **valid registration code** + password creates the account
- [ ] Using the **same code twice** → rejected ("already been used")
- [ ] After creating an account, trainee is auto-logged-in to **Trainee Dashboard**

## C. Public Website
- [ ] Homepage loads, navbar does **not** change size on scroll
- [ ] "Admissions" navbar button → Admissions Portal page
- [ ] Admissions Portal: sidebar + right bar stay **fixed** while scrolling (they never move)
- [ ] "Inquire Now" button is **centered** in the portal sidebar
- [ ] Public Inquiry form: submit → instant redirect with reference number (no hang)
- [ ] Inquiry page content does **not** overlap the navbar (hero + form use same offset+32 padding)

## D. Admin Dashboard
- [ ] Logged-in admin lands on Dashboard (Welcome + KPI cards)
- [ ] Sidebar stays **fixed** while scrolling the content
- [ ] KPI numbers match the database (Total/Today/Awaiting/Replied…)
- [ ] **Replied** KPI = distinct inquiries with a staff reply + valid email (one-to-one)
- [ ] **Applicants** KPI = distinct unique emails (one-to-one, no duplicates)
- [ ] "Recent Inquiries" table lists real rows

## E. Inquiry Queue (staff)
- [ ] Queue page: sidebar **fixed**, table scrolls internally, page does not scroll
- [ ] Table has a visible horizontal scrollbar when needed
- [ ] Search box filters rows; Status dropdown filters; Date filters
- [ ] Pagination: next/prev/last work; "Rows per page" changes page size
- [ ] Open an inquiry → modal shows details + conversation
- [ ] **Send Reply** → toast appears (readable, ~4s) → status becomes "Replied"
- [ ] Reply email (when SMTP set) contains the registration code if one exists
- [ ] **Create Registration Code** → code appears **inside the modal** (Applicant tab) with Copy + Use-in-Reply
- [ ] Toast is readable and disappears in exactly ~4 seconds (staff + trainee)

## F. Email Center (under Admissions Settings)
- [ ] Sidebar highlights "Admissions Settings", title shows "Email Center"
- [ ] Can save SMTP settings (test with Mailtrap/Gmail)
- [ ] "Send Test Email" delivers to the inbox
- [ ] "Send Pending Now" flushes the queue

## G. Trainee Dashboard
- [ ] Sidebar + right rail stay **fixed** on every trainee page (Overview, Inquiry, Registration, Payments, Certificates, Profile, Account)
- [ ] Overview shows inquiry status + counts
- [ ] My Inquiry shows reference + conversation (no PHP warnings)
- [ ] Registration shows enrollment slip (if enrollment exists)
- [ ] Payments shows ledger (if payments exist)
- [ ] **Profile photo** uploads → auto-refreshes everywhere (sidebar + right rail)
- [ ] **Use Camera** lets you pick which camera + capture
- [ ] Profile form saves (incl. **Rank/Position**, Gender, Civil Status, Nationality)
- [ ] Change Password works (old + new + confirm)
- [ ] Quick Info (right rail) matches Profile after saving

## H. Trainee Certificates
- [ ] **＋ Add Certificate** opens the form modal
- [ ] Add with **free-text course** (no catalog course) → appears in grid
- [ ] Add with **catalog course** → appears in grid
- [ ] **Edit** pre-fills and saves changes
- [ ] **Delete** removes only your own record
- [ ] **Upload Copy** per row → **Download** appears
- [ ] Expiry shows **EXPIRED** / **expiring soon** coloring
- [ ] **Print** opens a clean printable certificate view

## I. Role Security
- [ ] Trainee trying to open staff pages → redirected to Trainee Dashboard
- [ ] Staff trying to open Trainee pages → redirected to Admin Dashboard
- [ ] Logged-out user visiting any dashboard → redirected to login

## J. V5.10 — Content clipping + Tabs + Modals (regression check)
- [ ] **Staff Accounts**: the **Create Account** button is fully visible — it now opens from **＋ Add Staff** (modal) and never moves
- [ ] Staff Accounts page does **NOT** scroll — only the staff list scrolls (its own scrollbar, sticky header)
- [ ] **Reset PW** → modal opens with a navy header, the field, and **Reset Password + Cancel pinned at the bottom**
- [ ] Staff list: bounded scroll area with sticky header + visible scrollbar (no pagination needed)
- [ ] **Instructors & Venues** default tab: clicking **＋ Add Instructor** opens the modal
- [ ] Clicking the **🏢 Venues** tab switches to the Venues list (does NOT go to the homepage)
- [ ] Venues tab: **＋ Add Venue** opens the modal; ✏️ Edit on a venue row opens ONLY the venue modal
- [ ] Instructors tab: ✏️ Edit on an instructor row opens ONLY the instructor modal (pre-fills License Expiry + Bio)
- [ ] Batches are creatable in **Training Batches** (sidebar) and the count appears in the course grid + modal
- [ ] **Email Center**: the All/Pending/Sent/Failed filter chips switch the list (do not jump to homepage)

## K. V5.11 — Staff list scroll + Editable course batches + Course IDs
- [ ] Staff Accounts: **page never scrolls**; only the staff list scrolls internally (create form is a modal, stays put)
- [ ] **＋ Add Staff** opens the Create modal with **Create Account pinned at the bottom**
- [ ] Course Management → Edit a course that has batches → each batch row shows **✏️ Edit** and **🗑 Delete**
- [ ] Clicking **✏️ Edit** on a batch opens the inline form prefilled → change dates/slots → **Update Batch** → toast + list refreshes (no page reload)
- [ ] Clicking **🗑 Delete** on a batch → confirm → toast + row disappears (only when the batch has no enrollments)
- [ ] Trying to edit/delete a batch **from the wrong course's modal** → error toast (batch locked to its course)
- [ ] **Training Batches** course dropdown shows `#1 · BT-01 — Basic Training` (ID first) in the filter, the form, and the table
- [✅] Saving a batch with an **inactive course** → not possible (deactivated courses no longer appear in the course dropdown — good) — server-side check stays as backstop
- [ ] Course grid "Upcoming Batches" count is a link → opens Training Batches filtered to that course
- [ ] Create a new course → add a batch for it in Training Batches → reopen the course → batch appears in the modal
- [ ] Re-run `database/apply_all_updates.sql` twice → no error and **venues are NOT duplicated** (3 rows)

## L. V5.12 — Payments + Batch delete toast
- [✅] Sidebar shows **💰 Payments** (between Enrollment and Reports) and highlights it on the Payments page
- [✅] Payments page: 3 KPI cards (Total Collected / Outstanding / Fully Paid) load
- [✅] Payment obligations are **auto-created** when an enrollment is marked **Enrolled** (the manual "Record Payment Obligation" step was removed — see M)
- [✅] Create → toast "Payment PAY-… created" → row appears in the table (status **Unpaid**)
- [✅] Row shows applicant, course/enrollment, total, paid, balance, due, status, receipts count
- [✅] **💳 Record Payment** opens the modal **prefilled with the remaining balance** → pick method (GCash etc.), optional ref → **Record & Issue Receipt**
- [✅] After recording: toast mentions the **OR-… receipt** → paid/balance/status update (Partial → then **Paid** when balance hits 0)
- [✅] Record button disappears when balance is 0; Delete disappears once a receipt exists
- [✅] Over-payment attempt (amount > balance) → error toast, nothing saved
- [✅] **🗑 Delete** on a fresh payment → confirm → toast → row removed (AJAX, no reload)
- [✅] Payments **with receipts** → **🚫 Void** button (voids receipts + marks VOID) — no more dead rows
- [✅] **Trainee portal → Payments**: the recorded payment appears (number, amounts, status)
- [✅] Training Batches **🗑 Delete** → confirm → ✅ toast + row removed without reload; deleting a batch **with enrollments** → ❌ toast explaining why
- [ ] Re-run `database/apply_all_updates.sql` → no error (adds the OR receipt counter)

## M. V5.13 — Auto payment on Enrolled + Unified design toasts
- [ ] **Enrollment** → Create an enrollment with status **Enrolled** → toast says "Payment PAY-… **auto-created**." → it appears in Payments (Unpaid, total = course price) and the trainee's ledger
- [ ] Change an existing **Pending** enrollment → **Enrolled** → same auto-payment, no duplicate on re-saving
- [ ] The Payments page has **no** "Record Payment Obligation" button anymore (header explains auto-creation)
- [ ] **Unified toast** (top-right, white card, icon + title + message + progress bar, auto-dismiss ~4s):
  - Training Batches delete → ✅ "Batch … deleted."
  - Batch delete with enrollments → ❌ "Cannot delete — this batch has N enrollment(s)…"
  - Payments delete / void / record → ✅/❌ toasts
  - Course modal batch edit/delete → toasts
  - Trainee photo upload / camera → toasts (success green, warnings amber)
- [ ] Toast **never overlaps the navbar** (sits below it), stacks if two appear, and closes with ×
- [ ] Payments row with receipts shows **🚫 Void** → confirm → ✅ "voided — N official receipt(s) voided" → status shows **Void**, row actions disappear
- [ ] Voided payment cannot be voided again ("already void")

## N. V5.14 — Void KPI + System confirm modal
- [ ] Payments page shows **4 KPI cards** — Total Collected / Outstanding / Fully Paid / **🚫 Voided** (count + ₱)
- [ ] Clicking **🚫 Void** opens the app's **system modal** (navy header, message, red "Void" button) — NOT the browser popup
- [ ] Cancel / × / Escape / click-outside closes the modal and changes nothing
- [ ] Confirm void → ✅ toast → page **auto-refreshes** (~1.2s) → KPI recalculated: the voided ₱ moves from Total Collected into **Voided**, outstanding drops, row shows **Void** with no actions
- [ ] Batch delete (Training Batches + course modal) uses the **system modal** too, not the browser popup
- [✅] Trainee Certificates **🗑 Delete** uses the system modal (no browser popup)
- [✅] No browser-native confirm popups anywhere (all replaced by system modal)

## O. V5.15 — Certificate Issuing (final module)
- [ ] Sidebar shows **📜 Certificates** (between Payments and Reports) and highlights it on the page
- [ ] Certificates page: 4 KPI cards (Total Issued / Currently Valid / Expiring ≤90d / Voided)
- [ ] **＋ Issue Certificate** opens the modal → pick an **enrolled/completed** enrollment → course name + expiry **auto-fill** (issued + validity months)
- [ ] Issue → ✅ toast "Certificate **CRT-…** issued to …" → row appears (Issued) → trainee sees it in **Trainee → Certificates**
- [ ] Issuing the **same enrollment again** → blocked ("already issued")
- [ ] **🔎 Verify** opens the public **verify.php** page → shows **VALID CERTIFICATE** with trainee name, course, dates, issued by
- [ ] verify.php with a **wrong token** → rejected; **no ref** → shows the lookup form
- [ ] **🚫 Void** uses the **system confirm modal** (no browser popup) → status **Void** → auto-refresh → verify.php now shows **VOID CERTIFICATE**
- [ ] Voiding twice → blocked ("already void")
- [ ] Trainee Certificates shows the admin-issued cert with Upload/Download/Verify/Print (admin certs aren't editable/deletable by the trainee)

## P. V5.16 — Issuing v2 (filters + file + verify modal) & Trainee Documents
- [ ] Issue modal has **Course + Batch filters** that narrow the trainee dropdown live (shows "N eligible")
- [ ] A trainee with a **live cert for a course can't be re-selected** — even under a different batch ("already has a valid certificate for this course")
- [ ] Admin cert list has **Course + Batch filters** in addition to Status + search
- [ ] **＋ Issue Certificate** has an optional **file upload** (PDF/JPG/PNG) → toast "…File attached." → trainee gets a **⬇ Download** button for it
- [ ] **🔎 Verify** opens the **in-app system modal** (badge VALID/EXPIRED/VOID + cert no, trainee, course, batch, dates, issued by + Open Public Page link) — no new tab
- [ ] Trainee Certificates is **read-only**: no ＋ Add / Edit / Delete / Upload-copy; only Download / Verify / Print
- [ ] Trainee sidebar shows **📎 Documents** (between Payments and Certificates)
- [ ] Documents page: upload a requirement (Valid ID, Passport, SIRB, CDC, Medical, Photo, Previous Cert, Sea Service, Payment Proof) → appears with type/file/date/status
- [ ] Documents page: **Download** works; **Delete** uses the system confirm modal
- [ ] Re-run `database/apply_all_updates.sql` → no error (adds certificate.file_path / file_name)

## Q. V5.17 — Cert filters + download + KPI/design polish
- [ ] Certificates list filters are **left-aligned** (search + Course + Batch + Status in one row, like Inquiry Queue)
- [ ] No Filter button — changing Course/Batch/Status **auto-filters**; typing in search auto-filters after a pause
- [ ] **Trainee Certificates** — every row has a **⬇ Download** button (attached file, or a generated digital copy when none)
- [ ] Admin cert list also has **⬇ Download**; staff can download any cert; trainee can only download their own (403 otherwise)
- [ ] Dashboard **Replied / Progressed** KPI = one per replied/progressed inquiry (validated by status + inquiry number)
- [ ] Enrollment page KPIs are a **single row** of summary cards (like Inquiry Queue), not stacked cards
- [ ] Applicants page: each row has **🗑 Delete** (system confirm modal) → clears the applicant + its enrollments from the grid
- [ ] Deleting an applicant **with receipts or issued certificates** → blocked with a clear toast

## R. V5.18 — Issue modal align + Void remarks + KPI/applicant polish
- [ ] **Issue Certificate** modal: Filter Course + Filter Batch are **side-by-side (horizontal)**, fields aligned in 2 columns
- [ ] **Void** a certificate → the system modal now has a **Reason / remarks** textarea → saved
- [ ] Trainee **🔎 Verify** on a voided cert shows the **Void Remarks** (red) with the reason
- [ ] Trainee **voided cert has NO Download and NO Print** (Verify only)
- [ ] Dashboard **Replied / Progressed** — inquiry with 2 replies counts as **1**
- [ ] Issuing a certificate → the enrollment automatically becomes **Completed** (Enrollment KPI reflects it)
- [ ] Applicants grid **auto-hides already-enrolled** applicants; **"Show already-enrolled"** checkbox reveals them
- [ ] Re-run `database/apply_all_updates.sql` → no error (adds certificate.void_remarks)

## S. V5.19 — Cert filter single row + Enrollment applicant consistency
- [ ] Certificates filter toolbar is **one single row** (search + Course + Batch + Status + Clear, left-to-right, aligned) — no wrapping
- [ ] **Create Enrollment** modal Applicant dropdown shows only **non-enrolled** applicants — matches the Applicants module count exactly
- [ ] Already-enrolled applicants don't appear in the enrollment dropdown; editing an existing enrollment still shows the locked applicant label

## T. V5.20 — P0 fixes (slot capacity + duplicate-enrollment guard)
- [ ] New batch **Max Slots defaults to 24** (Training Batches modal)
- [ ] Enrolling into a **full batch** → blocked with "Batch is full (n/n) — no slots left."
- [ ] Full batches show **disabled + "(FULL)"** in the Create/Edit Enrollment modal
- [ ] Editing an enrollment **into a full batch** → blocked; re-saving in its own batch still works (excludes itself)
- [ ] Creating a **2nd active enrollment for the same trainee + course** → blocked ("already has an active enrollment…")
- [ ] Re-enroll is allowed after the old enrollment is cancelled/completed
- [ ] The auto-payment only creates **one obligation per applicant+course** (no double billing) — verify the trainee's Payments ledger has a single Unpaid row

## U. V5.21 — P1: Duplicate-inquiry + 360° view + Audit + Pagination
- [ ] Public inquiry form: submitting again with an **email that has an open inquiry** → shows "We already have your inquiry" + existing reference (no new row created)
- [ ] A **new email** still creates an inquiry normally
- [ ] Applicants: each row has **👁 View** → 360° modal shows info + inquiries + enrollments + payments + documents + certificates (when they exist)
- [ ] Applicants list is **paginated** (25/page, Prev/Next) — no more silent 100-row truncation
- [ ] **Audit Log** (Reports → 📋 Audit Log): payment record/void, certificate void, applicant delete, staff create/reset/toggle are logged with who/what/when/IP
- [ ] Audit Log page filter (module dropdown) works; entries read-only
- [ ] Re-run `database/apply_all_updates.sql` → no error (v13 ensures audit_log exists)

## V. V5.22 — Batch No. reuse guard + Walk-in enrollment form
- [ ] Training Batches: entering an **already-used Batch No.** → blocked in-modal ("already in use") without a reload; editing a batch keeps its own number
- [ ] Create Enrollment has a **👤 Existing / ➕ Walk-in** toggle
- [ ] **Walk-in** mode: fill name + course → submit → creates applicant (APP-…), enrollment, and auto-payment — **no inquiry needed**
- [ ] Walk-in with an **existing email** → blocked ("use Existing Applicant")
- [ ] Enrollment modal shows the **full form**: Personal (name/birth/gender/civil/nationality/mobile/email), Address & Emergency (birthplace, address, postal, country, emergency contact, relationship), Seafarer/Credentials (rank, seafarer ID, SIRB, CDC, passport, medical)
- [ ] Selecting an **existing applicant** auto-fills the form from their account (editable); saving updates their profile with completed fields
- [ ] Course/Batch section still filters batches by course and disables full ones

## W. V5.23 — Walk-in creates a Trainee account
- [ ] Walk-in enrollment with **email** → creates a trainee account (username = email) that can log in to the Trainee Portal
- [ ] Walk-in with **no email** → creates account with username = applicant no (APP-…) and an **auto-generated temp password** shown in the success toast
- [ ] Setting a **Temporary Password** in the walk-in form → that password works for login
- [ ] Walk-in logs in → sees their enrollment / payment in the Trainee Portal
- [ ] Existing applicant with an account → form auto-fills; completing fields saves back to their profile (no duplicate account)

## X. V5.24 — Ranks + Endorser role + RBAC + Walk-in UX
- [ ] **Admissions Settings → 🎖️ Rank/Position**: add/edit/activate ranks; they appear as a **dropdown** in Create Enrollment (with "Other" option)
- [ ] Walk-in with a **duplicate email** → error toast, **modal stays open** to correct; fixing it submits normally
- [ ] Enrollment form has **Endorsed By** + **Charge To** (Trainee/Company); choosing Company shows the company dropdown → saved + shown in the list
- [ ] **Endorser** role exists and is assignable in Staff Accounts
- [ ] **Admissions Settings → 👤 Roles & Access**: add/edit/delete roles, active/inactive toggle
- [ ] Per-role **Access checkboxes** (one per sidebar button) → saving restricts that role's sidebar + pages (a Payments-only user sees only Payments; other pages redirect to their first allowed module)
- [ ] Role with no checkboxes = full access (backward compat); ADMIN always full
- [ ] Existing applicant auto-fill fills **all** available fields (personal/address/emergency/seafarer + rank), not just name
- [ ] Re-run `database/apply_all_updates.sql` → no error (v14)

## Y. V5.25 — Registration form (ISO) + emails + SRN + endorser types
- [ ] Walk-in **email is mandatory** (modal + server) — needed for the Trainee account
- [ ] Walk-in with auto-generated temp password → **email** sent (username + temp password) from the admission staff email
- [ ] Marking an enrollment **Enrolled** → **confirmation email** to the trainee with registration no, batch, schedule dates, location, course fee + due
- [ ] **SRN No. (Seafarer's Registration No.)** label used in Enrollment form + Trainee Profile (was "Seafarer ID No.")
- [ ] **Endorser Type**: Company-Endorsed (no payment mandatory, charge to company, no auto-payment) vs Marketing/Endorser (payment required — can only become Enrolled after a payment is recorded)
- [ ] **Photo** field in Seafarer section: upload saves to profile; auto-fetches from profile when available (preview)
- [ ] **🖨 Print** per enrollment → ISO registration slip (USMCI header + PHOTO, Reg No/SRN#/Batch/Date, Rank/Name/Address/Contact/Birth/Email/Endorser/Course/Time/Sched/Fee/Payment/Balance/Remark, forfeiture note, certify line)
- [ ] Slip "**Assessed by**" = logged-in staff's full name; photo appears if the trainee has one
- [ ] Re-run `database/apply_all_updates.sql` → no error (v15: remarks + endorser_type)

## Z. V5.26 — Endorser dropdown + Affiliated Companies + Access levels
- [ ] Enrollment **Endorsed By** is a dropdown of staff with the **ENDORSER** role
- [ ] Sidebar shows **🏭 Affiliated Companies** — grid with 👁 View profile (contact person/number/email), ✏️ Edit, ➕ Add, activate/deactivate
- [ ] Company list feeds the Enrollment "Charge To: Company" dropdown
- [ ] **Role access levels**: per module **None / View / Full** — View-only users can open the page but Add/Edit/Delete buttons are hidden and POST actions are blocked ("view-only access")
- [ ] **Photo required**: enrollment blocked without a photo (upload or auto-fetch from profile); walk-in without photo → clear error
- [ ] **Existing applicant auto-suggest**: typing name/email/applicant-no shows matches; selecting fills the WHOLE form (incl. Rank, SRN, photo)
- [ ] Print form title = **"REGISTRATION FORM / FORM NO: WI 8.1-02-01 rev.01"**
- [ ] Re-run `database/apply_all_updates.sql` → no error (v16: company contacts + role levels)

## AA. V5.27 — Email send + payment gate + print format
- [ ] Walk-in enrollment → trainee RECEIVES the temp-credentials email (once SMTP is set; otherwise it's PENDING in Email Center)
- [ ] Marking an enrollment **Enrolled** → trainee receives the confirmation email (reg no, batch, schedule, location, fee)
- [ ] **Marketing-endorsed** enrollment CANNOT be marked Enrolled with ₱0 paid — blocked; after recording payment → Enrolled works
- [ ] **Company-endorsed** can be Enrolled without payment (bypass)
- [ ] Print form shows the **USMCI logo** (logo-light3.png) + trainee **photo** (both embedded) — page renders without errors
- [ ] Print form matches the client image: REGISTRATION SLIP / FORM NO: W18.1-01-01 rev. 01 with all fields + Assessed by (staff)

## AB. V5.28 — Marketing auto-pend + print photo/time
- [x] Create Enrollment with **Marketing/Endorser + Status=Enrolled** → auto-saves as **Pending** (status locked + hint) and creates the enrollment + payment — then record payment and mark Enrolled  *(verified live in V5.31)*
- [x] Marketing+Enrolled can't happen with ₱0 (status gate still blocks until paid); company bypasses  *(verified: blocked + toast reason)*
- [x] Print form shows the trainee **photo** (fetched from account) and **Time of Training** from the batch schedule (e.g. 8:00 AM – 5:00 PM) when sessions exist  *(verified live)*

## AC. V5.29 — Photo upload + batch training time + auto-suggest scope
- [x] Create Enrollment form uploads a **photo** (form now has enctype) — new enrollment succeeds  *(verified live)*
- [x] Training Batches create/edit has **Training Time Start/End**; saved as one training_schedule row per day; print shows the times  *(verified live)*
- [x] Applicant auto-suggest lists **all applicants incl. already-enrolled** (badge "already enrolled: …") and auto-fills the form  *(verified live)*

## AD. V5.30 — Status loop + walk-in email + print polish + co/endorser
- [x] Status modal saves via AJAX (`getAttribute('action')`) and **auto-reloads** — no more loop, no sign-out needed  *(verified live: enrolled→pending updated, badge refreshed)*
- [x] Walk-in temp-credentials email always queued (typed or auto password) — arrives once SMTP is set (else PENDING in Email Center)
- [ ] Trainee actually **receives** the emails on your machine (needs SMTP in Email Center → Mailtrap or Gmail app password)
- [x] Print: centered letterhead **address | TEL/MOBILE | EMAIL** (3 lines), title **REGISTRATION FORM**, trainee name above **Trainee's Signature**  *(verified live)*

## AE. V5.31 — Status toast feedback + endorser droplist (final polish)
- [x] Blocked status change (unpaid marketing → Enrolled) shows a **red toast with the exact reason**, modal closes, page kept — no silent reload  *(verified live)*
- [x] Successful status change shows a **green toast** after the auto-reload  *(verified live)*
- [x] "Endorsed By" has two groups: **Endorser Staff** (ENDORSER role) + **Company Contacts**; label switches to match the type  *(verified live)*
- [x] Company-Endorsed: picking the company **auto-fills** its contact person; saved value restored when editing  *(verified live: TransOcean → "Capt. Reyes")*

## AF. V5.32 — AUTO-UPDATE STATUS ON PAYMENT (new)
- [x] Record a payment on a **Pending** marketing enrollment → enrollment **auto-updates to Enrolled** (no manual Status step), history logged, confirmation email queued  *(verified live: pending → payment ₱15,000 → Enrolled)*
- [x] Flash shows "The enrollment was auto-updated to Enrolled." so the staff sees it happen  *(verified live)*
- [x] Voiding/deleting the payment with nothing else paid → enrollment **auto-reverts to Pending** (consistent with the payment gate)  *(verified live)*
- [ ] On your machine: confirm the confirmation email is queued in Email Center after a payment (SMTP set → it sends; otherwise PENDING)

## AG. V5.33 — PROCESS RULES (configurable company-endorsed workflow)
**New page: Settings → ⚖️ Process Rules.** 7 toggles, defaults = current policy; the property can change them anytime without code.

Company-Endorsed (defaults):
- [x] Pending → **Enrolled manually with ₱0** (rule "company require paid" = OFF)  *(verified: status action succeeded)*
- [x] Pending + payment → **auto Enrolled**  *(verified: payment recorded → enrolled)*
- [x] **Certificate issued on a Pending, unpaid** company enrollment  *(verified: cert issued, enrollment → Completed)*
- [x] Auto-update to **Completed** when cert issued (rule ON)  *(verified)*

Marketing / Endorser (defaults):
- [x] Pending cannot be Enrolled with ₱0 — blocked with reason  *(verified)*
- [x] Payment → auto Enrolled  *(verified)*
- [x] Certificate blocked until paid  *(verified)*

Rule switching:
- [x] Set "Company cert allowed without payment" = OFF → company unpaid cert **blocked**; restore → allowed again  *(verified live)*
- [x] Certificate issuer lists company **Pending** enrollments (was hidden before)  *(verified)*
- [x] Process Rules page renders 7 toggles with correct ON/OFF states  *(verified)*

## AH. V5.34 — Company in Payments + centered letterhead + company cert confirmed
- [x] Company-endorsed enrollment → **payment record auto-created at create** (appears in Payments list)  *(verified live)*
- [x] Payments page **lists the company-endorsed enrollment**  *(verified live)*
- [x] Recording payment for company-endorsed → **auto-updated to Enrolled** + payment status **Paid**  *(verified live)*
- [x] Company-endorsed **Pending + unpaid** → **certificate issued** → enrollment auto-Completed  *(verified live)*
- [x] Print form letterhead **perfectly centered** (logo left | org center | photo right, 1fr-auto-1fr grid)  *(verified in DOM/CSS)*

---

**If anything fails**, write: module + item number + what you saw (screenshot helps).
I'll fix precisely and you re-test only that item.

## AI. V5.35 — Enrollment search/filter fatal fix
- [x] Enrollment **search box** no longer crashes — typing a keyword (enrollment no., applicant, email, course) returns matching rows  *(verified: q=dela → rows; q=zzz → empty)*
- [x] Enrollment **status filter** returns only the chosen status  *(verified: pending/enrolled)*
- [x] Applicants page search fixed too (same latent bug)  *(verified: q=juan → Juan Dela Cruz)*
- [ ] On your machine: search + filter on Enrollment and Applicants — should work with no fatal error

---

**If anything fails**, write: module + item number + what you saw (screenshot helps).
I'll fix precisely and you re-test only that item.

## AJ. V5.36 — Enrollment search by name confirmed + full-name match
- [x] `?q=grace` (first name) → **no fatal**, returns matching enrollments  *(verified live)*
- [x] `?q=Grace Lacsoc` (full name) → **no fatal**, returns the row (CONCAT match)  *(verified live)*
- [x] Last name / email / enrollment no. / course search all return 200 with no HY093  *(verified live)*
- [ ] On your machine: replace the folder with this zip → Ctrl+F5 → search a name at Enrollment — must work

---

**If anything fails**, write: module + item number + what you saw (screenshot helps).
I'll fix precisely and you re-test only that item.

## AK. V5.37 — P1 closeout (Reports export · Inquiry aging · Requirements gate)
**D1 — Reports**
- [x] Reports page has **From/To date range + module selector**; KPIs and lists respect the range  *(verified live)*
- [x] **Export CSV** button streams the module within the range (UTF-8 BOM, opens in Excel)  *(verified: payments CSV contains rows + headers)*
- [x] **Revenue by Month** bar chart (last 6 months, pure CSS)  *(verified live)*
- [ ] Date-range export: pick a range on your machine and open the CSV in Excel

**A3 — Inquiry aging**
- [x] Queue table has an **Age** column (badge: grey ≤3d / amber 4–7d / red >7d)  *(verified live)*
- [x] **⏱ Pending > 3 days** chip filters to open inquiries older than 3 days  *(verified: chip → only >3d rows)*
- [ ] On your machine: open Inquiry Queue → check the Age badges and click the chip

**B3 — Requirements gate**
- [x] Enrollment list shows **Docs: X/Y** badge per applicant (green/amber/grey)  *(verified live)*
- [x] New rule **"Require documents before Enrolled"** (default OFF): when ON, Enrolled is blocked until ALL docs submitted; create is auto-saved Pending with hint  *(verified: 0 docs blocked → 1/9 blocked → all docs OK)*
- [ ] Toggle the rule at Settings → ⚖️ Process Rules and test with an applicant who has few documents

---

**If anything fails**, write: module + item number + what you saw (screenshot helps).
I'll fix precisely and you re-test only that item.

## AL. V5.38 — Audit Log polish · Printable reports · Letterhead & Requirements maintenance
**Audit Log**
- [x] User column shows the **user name** (not "User #id")  *(verified live)*
- [x] Filter includes **Enrollments** and **Requirements** modules + a search box  *(verified)*
- [x] Certificate **issue**, enrollment **create/status**, requirement **mark/unmark** are now audited  *(verified: certificates filter shows issue; enrollments shows status)*

**Printable form reports (Reports → Printable Form Reports)**
- [x] **Enrollment List**: Reg No · SRN · Name · Contact · Signature + Slots(24) + **Lead Instructor** + **Prepared by** signature blocks; filters course/batch/date  *(verified live)*
- [x] **Enrollment Status**: same layout with the status column  *(verified live)*
- [x] Both have a Print button and CSV export  *(verified: CSV has headers + rows)*

**Report Letterhead maintenance (Settings → Report Letterhead)**
- [x] Org name / address / tel / mobile / email / footer editable at runtime; new reports + registration slip use it  *(verified: edited → report shows new address + footer)*

**Requirements Matrix (Settings → Requirements Matrix) + staff update**
- [x] Per-course required-doc checkboxes saved to course_prerequisite  *(verified: saved 2 docs for BT)*
- [x] Enrollment list **Docs: X/Y** badge uses the course's own required set  *(verified: 0/2 → 1/2 after mark)*
- [x] **📄 Req** button per enrollment: checklist shows uploads (🟢) and staff can mark **received** (☑)  *(verified: marked → modal + badge update)*

---

**If anything fails**, write: module + item number + what you saw (screenshot helps).
I'll fix precisely and you re-test only that item.

## AM. V5.39 — Undefined-variable warnings on enrollment create (fixed)
- [x] Creating an enrollment for an **Existing Applicant** → **no "Undefined variable $loginUsername/$accountPassword" warnings**  *(verified live)*
- [x] Creating a **Walk-in** enrollment → no warnings, temp password still shown in the flash + emailed  *(verified live: "Trainee portal: username walkintest@example.com — temporary password: Walk-XXXX")*
- [ ] On your machine: create an enrollment using an existing applicant → no yellow warnings on the page

---

**If anything fails**, write: module + item number + what you saw (screenshot helps).
I'll fix precisely and you re-test only that item.

## AN. V5.40 — Requirements: doc-type CRUD · course-only · auto-update
- [x] Requirements page (Settings → Requirements) lets the user **add / edit / deactivate / reactivate document types**  *(verified: added NBI, renamed it, deactivated, reactivated)*
- [x] Duplicate doc-type codes are blocked  *(verified)*
- [x] **Deactivating a doc type instantly removes it from every course** — enrollment "Docs: X/Y" badge denominator drops automatically (1/3 → 1/2)  *(verified live)*
- [x] "Docs: X/Y" badge **auto-updates** after any requirements-matrix change (live-computed, no stale)  *(verified: 3→2 required → badge updated on next load)*
- [x] Requirements are **course-based only** — matrix, badge and 📄 Req checklist all keyed by course, no batch coupling  *(verified: no batch reference in the requirements path)*
- [x] Enrollment page loads with no SQL error when requirements data exists  *(verified live)*

---

**If anything fails**, write: module + item number + what you saw (screenshot helps).
I'll fix precisely and you re-test only that item.

## AO. V5.41 — P2: QR on certificates + trainee notifications
- [x] **QR code embedded on the digital certificate** — pure-PHP generator, no external service; scans to the live verify page  *(verified: QR decodes to verify.php?ref=CRT-…&t=…)*
- [x] Certificate issued → trainee gets a **🔔 notification**  *(verified: applicant_notification row created)*
- [x] Enrollment → Enrolled → trainee gets an **"Enrollment Confirmed"** notification  *(verified)*
- [x] Trainee sidebar shows **🔔 Notifications with an unread badge** (count)  *(verified: badge = 1)*
- [x] **trainee/notifications.php** lists notifications and **marks them read** on view  *(verified: unread 1 → 0)*

---

**If anything fails**, write: module + item number + what you saw (screenshot helps).
I'll fix precisely and you re-test only that item.

## AP. V5.42 — Fixes: blank edit form · photos · docs refresh · req toggle · QR access · bell
- [x] **Enrollment Edit modal is NOT blank** — applicant name, email, SRN, rank, credentials + photo preview all load  *(verified: Juan Dela Cruz / 715@g.com / photo preview)*
- [x] **Trainee photo shows** in the right rail (and enrollment form)  *(verified: img loads width=120)*
- [x] **Docs badge auto-refreshes** after marking a requirement (no reload)  *(verified 0/3 → 1/3)*
- [x] Requirements Matrix hint has no "batch" wording — "per course only"  *(verified)*
- [x] **Explicit ✓ Mark Received / ✗ Mark Missing buttons** in the 📄 Req modal; toggling works both ways  *(verified)*
- [x] **📱 View / Print (QR)** button on admin + trainee Certificates — printable cert with QR + Print/Save PDF  *(verified: QR decodes to verify URL)*
- [x] **🔔 header bell** with unread count on every trainee page  *(verified)*
- [x] uploads/README.txt shipped so the folder survives installs — **back up uploads/ before replacing htdocs**

---

**If anything fails**, write: module + item number + what you saw (screenshot helps).
I'll fix precisely and you re-test only that item.

## AQ. V5.43 — Certificate issuance: uploaded file is the certificate
- [x] Issue a certificate **by uploading a file** → the file is saved + linked; **View File opens the uploaded PDF/image inline** (not the system cert)  *(verified: Content-Type application/pdf; inline)*
- [x] Issue **without a file** → **View / Print (QR)** shows the system certificate with QR + Print/Save PDF (fallback)  *(verified: QR decodes to verify URL)*
- [x] Admin + trainee Certificates pages show the right button label (📄 View File vs 📱 View / Print (QR))  *(verified in browser)*
- [x] 🖨 Print button on the trainee page opens the real certificate (file-aware)  *(verified)*
- [x] ⬇ Download streams the uploaded file when present  *(verified)*
- [ ] On your machine: upload a PDF when issuing → View File must show your PDF; without upload → system cert with QR

---

**If anything fails**, write: module + item number + what you saw (screenshot helps).
I'll fix precisely and you re-test only that item.

## AR. V5.44 — Cert view/download/print · enrollment save · notifications · matrix batch
- [x] **Admin Certificates: View File / Download work again** — links now use the root download endpoint (were 404). Uploaded PDF opens inline with Print; Download streams the attachment  *(verified: application/pdf inline + attachment)*
- [x] **Admin 🖨 Print** now opens the REAL certificate (uploaded file if present, else system cert with QR) — no more table-built system cert  *(verified)*
- [x] **Enrollment Edit → Save works** — hidden applicant_id now set; Save persists changes (DB verified)  *(verified: remarks saved)*
- [x] **Trainee notifications + cert list confirmed working** — bell badge count, notifications page, and cert list with View File/Download all verified for a matching trainee account  *(verified)*
- [x] **Requirements Matrix has no "batch"** — main content zero mentions; hint reads "per course only"  *(verified)*

---

**If anything fails**, write: module + item number + what you saw (screenshot helps).
I'll fix precisely and you re-test only that item.

## AS. V5.45 — Edit-save root cause · cert missing-file diagnosis · create-notification
- [x] **Enrollment Edit saves even with NO photo** — the photo gate now applies only to create. Verified: applicant with no photo → edit opens + Save persists to DB  *(verified)*
- [x] **Create still requires a photo** (no regression)  *(verified: blocked without photo, succeeds with photo)*
- [x] **⚠ File Missing badge** on admin + trainee Certificates rows when the uploaded file is lost on disk  *(verified)*
- [x] View File / Print fall back to the system cert **with an explicit amber notice** explaining the missing upload  *(verified: notice + QR shown)*
- [x] When the file EXISTS → View File opens the PDF inline, Download streams it  *(verified, admin + trainee)*
- [x] Creating an enrollment directly as **Enrolled now notifies** the trainee ("Enrollment Confirmed")  *(verified)*
- [ ] On your machine: re-upload a cert file at issuance → View File / Download work; edit an enrollment (even photo-less) → Save works

---

**If anything fails**, write: module + item number + what you saw (screenshot helps).
I'll fix precisely and you re-test only that item.

## AT. V5.46 — Document-type description + course description
- [x] **Document Types now have a Description field** in the add form AND an editable Description column in the list  *(verified: added + edited, saved to DB)*
- [x] Stored for future development (mnt_document_type.description)  *(verified)*
- [x] **Course Management description** confirmed fully working (modal, create/update, list preview)  *(verified: create + update saved)*
- [x] Trainee Documents dropdown shows the description as a hover tooltip  *(verified)*

---

**If anything fails**, write: module + item number + what you saw (screenshot helps).
I'll fix precisely and you re-test only that item.

## AU. V5.47 — Certificates actions: Print removed, 2x2 grid
- [x] **Print button removed** from admin Certificates (printing is inside View File / View & Print QR)  *(verified: no 🖨 Print in the row)*
- [x] Admin actions in a **2x2 grid**: View File · Download · Verify · Void  *(verified: 4 buttons, 2 columns)*
- [x] Trainee Certificates: **2-column grid** with View · Download · Verify (no Void, no Print)  *(verified)*
- [x] Unused Print JS handlers removed  *(verified)*

---

**If anything fails**, write: module + item number + what you saw (screenshot helps).
I'll fix precisely and you re-test only that item.

## AV. V5.48 — Enrollment actions 2x2 + compact grids everywhere + File Missing explainer
- [x] **Enrollment actions are now 2×2** — Edit · Slip · Status · Req in a compact grid  *(verified: 2 columns)*
- [x] **All admin modules use the compact 2×2 action grid** — Applicants, Payments, Companies, Staff Accounts (Certificates/Courses already had it)  *(verified)*
- [x] Long button labels shortened (Record Payment → Record) to keep rows compact  *(verified)*
- [x] **"⚠ File Missing" explained** — it appears when the uploaded cert file is not on disk (uploads/ replaced); View falls back to the system cert with an amber notice  *(verified)*
- [ ] On your machine: open Enrollment → actions are 2×2; re-check a cert whose file is missing → see the ⚠ badge + notice

---

**If anything fails**, write: module + item number + what you saw (screenshot helps).
I'll fix precisely and you re-test only that item.

## AW. V5.49 — Public website: ABOUT section (one-page anchor) + Website Content
- [x] **#about section renders** on the homepage — Story, Mission, Vision, Core Values, ISO quality band, Accreditations, Leadership, stats, CTA  *(verified in browser, all blocks FOUND)*
- [x] Content uses the **official company profile** (SEC CS201008536, 20+ years, exact M&V wording, Engr. Audie M. Macatol)  *(verified)*
- [x] **Settings → 🌐 Website Content** maintenance page with all 10 About fields; saves live  *(verified: save → DB updated)*
- [x] **Graceful fallback** — empty fields still render the official text (no broken page)  *(verified by wiping values)*
- [x] **Partial-POST safe** — updating one field can't wipe the others  *(verified)*
- [x] Story photo renders (assets/images/site/facility-1.jpg)  *(verified: img loads)*
- [ ] On your machine: open the homepage → scroll to About; edit Settings → Website Content → About and save → refresh homepage to see your copy

---

**If anything fails**, write: module + item number + what you saw (screenshot helps).
I'll fix precisely and you re-test only that item.

## AX. V5.50 — About refinements: carousel · manager block · 3D effects
- [x] **Photo carousel** auto-fetches every image from assets/images/site/carousel (4 slides ship) — auto-advance 4.5s, prev/next, dots, pause on hover  *(verified live)*
- [x] **Managing Director block**: placeholder photo + name/role + welcome message at the bottom of About  *(verified: photo, name, message render)*
- [x] **Maintenance**: Settings → Website Content now has carousel folder + MD photo + MD message fields  *(verified: seeded v22)*
- [x] **3D tilt** on Mission/Vision + Core Values cards (cursor-driven)  *(verified: 8 tilt elements)*
- [x] **Scroll-reveal** fade-up on all About blocks (IntersectionObserver, reduced-motion aware)  *(verified)*
- [ ] On your machine: drop a new JPG into assets/images/site/carousel → it appears in the carousel; add the real MD photo via Website Content

---

**If anything fails**, write: module + item number + what you saw (screenshot helps).
I'll fix precisely and you re-test only that item.

## AY. V5.51 — Website Courses + News + Category maintenance
- [x] **#courses** renders live courses grouped by category (STCW, MARINA…), no fees  *(verified: 3 cards, 2 groups)*
- [x] **Course modal** opens on card click — description, duration, validity, medical, STCW/MARINA refs, **required documents** (from matrix), Inquire button  *(verified: BT shows Valid ID + Medical Certificate, STCW A-VI/1)*
- [x] **#news** shows live enrolling batches with fee + slots left; "View Course" opens the course modal  *(verified: 2 batches, ₱15,000 / ₱8,000)*
- [x] **Settings → 🗂 Course Categories** — add/rename/reorder/activate; duplicate codes blocked; selectable in Course Management  *(verified)*
- [x] **Inquiry form** course dropdown is dynamic + `?course=` pre-selects  *(verified: ?course=Basic Training (BT) → selected)*
- [ ] On your machine: homepage → Courses (click a card → modal → Inquire) · News (fees + View Course) · Settings → Course Categories

---

**If anything fails**, write: module + item number + what you saw (screenshot helps).
I'll fix precisely and you re-test only that item.

## AZ. V5.52 — Courses flip-card layout (per client reference)
- [x] Course cards show **only Course Name + Description** — no course code  *(verified)*
- [x] Grouped by **category heading** (+ optional category blurb)  *(verified: STCW, MARINA)*
- [x] **"View Details →" flips the card** (3D) revealing duration, validity, medical, STCW/MARINA refs, required docs, Inquire  *(verified)*
- [x] **"← Back"** flips the card closed  *(verified)*
- [x] News **"View Course"** scrolls + flips the matching course card  *(verified)*
- [x] Keyboard accessible + reduced-motion aware  *(verified)*

---

**If anything fails**, write: module + item number + what you saw (screenshot helps).
I'll fix precisely and you re-test only that item.

## BA. V5.53 — Courses + News redesign (bg, split-front cards, batch-no news)
- [x] **Courses background image** applied (site_courses_bg)  *(verified)*
- [x] **Card front split**: photo (top) + Name/Description (bottom), no "View Details" text  *(verified: photo loads, no code/view-details)*
- [x] **Card back readable**: Duration · Validity · STCW · Required docs · Inquire; **Medical + MARINA removed**  *(verified)*
- [x] **No Back button** — moving the cursor away flips the card back  *(verified: hover-out flips back)*
- [x] **Placeholder image** when a course has no photo  *(verified: course-placeholder.jpg)*
- [x] **Course Management photo upload** in the Add/Edit modal (preview + remove), saved to uploads/courses/, fetched on the website  *(verified: FF photo saved)*
- [x] **News card**: Batch Number (not code) · Location · Date · Lead Instructor · slots kept · fee  *(verified: TRN-2026-050, Cavite, Magalona, 0/24, ₱15,000)*
- [x] **News button = Inquiry** → pre-selects the course  *(verified)*

---

**If anything fails**, write: module + item number + what you saw (screenshot helps).
I'll fix precisely and you re-test only that item.

## BB. V5.54 — Course-card refinements + Facilities (initial design)
- [x] **Category title** = navy pill + gold text  *(verified)*
- [x] **Front card whole-card hover** (lift + shadow + green border); photo still zooms  *(verified: 0.25s transition)*
- [x] **Back card**: STCW Ref + course description removed; course **name white** on navy; Duration/Validity/Required docs/Inquire kept  *(verified)*
- [x] Hover-out still flips the card back  *(verified)*
- [x] **#facilities initial design**: photo wall (1 feature + 3 wall) + 6 feature cards + CTA  *(verified)*
- [x] Facilities text editable at Website Content  *(verified: v25 seeded)*

---

**If anything fails**, write: module + item number + what you saw (screenshot helps).
I'll fix precisely and you re-test only that item.

## BC. V5.55 — Facilities: rotating carousel + category cards + gallery page
- [x] **Rotating carousel** (auto-advance 4.2s, 3D rotate, arrows/dots, pause on hover) fed from the training-center folder  *(verified: 3 slides, auto-advances)*
- [x] **Card per image category** — Training Center · Classroom · Simulators · Fire & Safety · Equipment, each auto-fetching from its own folder  *(verified: 5 cards, links to gallery)*
- [x] **New public page facilities.php** — category tabs + image grid + lightbox; filterable by ?cat=  *(verified: classroom shows 3 images, lightbox opens/closes)*
- [x] **Navbar "Gallery" link** added  *(verified)*
- [x] **Title gradient gold** — "World-Class Training Facilities" (better visual)  *(verified: gradient text)*
- [ ] On your machine: homepage → Facilities (watch carousel rotate) → click a category card → browse the gallery page; drop new photos into assets/images/site/facilities/<cat>/ to add more

---

**If anything fails**, write: module + item number + what you saw (screenshot helps).
I'll fix precisely and you re-test only that item.

## BD. V5.56 — Facilities: 3D rotating wheel carousel + category photo modals
- [x] **3D rotating wheel carousel** — front photo large & bright; SIDE photos angled + faded (~50%); BACK photos faded to near-invisible; wheel auto-rotates every 4s; pauses on hover  *(superseded by BE — geometry reworked in V5.57)*
- [x] **Click a side photo** → it rotates to the front  *(verified)*
- [x] **Arrows + gold dots** work; dots show the active photo  *(verified)*
- [x] **Touch swipe** on mobile rotates the wheel  *(verified)*
- [x] **Category cards now open a MODAL** (not a gallery page) — Training Center · Classroom · Simulators · Fire & Safety · Equipment; each shows its own photos (auto-fetched)  *(verified: modal title + 4 images)*
- [x] **Lightbox inside the modal** — click a photo to view large; prev/next arrows + counter (e.g. 2/5); Esc closes lightbox first, then the modal; click-outside / ✕ closes modal  *(verified: 1/4 + Esc + backdrop)*
- [x] **Card 3D tilt + glare** on hover  *(removed in V5.57 per client — back to original card design)*
- [x] **Navbar "Gallery" link removed** — nav now: Home · About · Courses · Facilities · News · Contact  *(verified)*
- [x] **Mobile** — wheel scales down, no sideways scroll, modal grid 2-col  *(verified: overflow 0px)*
- [x] On your machine: homepage → Facilities → watch the wheel rotate → click side photos → open each category card → browse photos → lightbox prev/next; drop new photos into assets/images/site/facilities/<cat>/ to add more

---

**If anything fails**, write: module + item number + what you saw (screenshot helps).
I'll fix precisely and you re-test only that item.

## BE. V5.57 — Facilities review fixes: wheel lapping · original cards · 3-color modal
- [ ] **Wheel no longer "lapping"** — the FRONT photo is centered inside the gold frame (was shifted right); SIDE photos sit BESIDE the frame with a small gap, faded (~55%), and never cover the frame or front photo; BACK photo is a faint depth layer only  *(verified: front x[464–966] centered on stage 715; sides x[61–444] / x[986–1369]; back x[903–1129] op .12)*
- [ ] **Gold frame wraps only the front photo** — side/back photos extend past it into the section background (fade out)  *(verified)*
- [ ] **Category cards back to original design** — flat card: photo + icon circle + gold title + "N photos · Explore →"; hover lifts card + zooms photo (no 3D tilt, no glare, no count badge)  *(verified: "4 photos · Explore →")*
- [ ] **Photo modal uses all 3 theme colors** — navy gradient body, gold border + gold→teal top accent bar, TEAL count pill, gold photo outlines with teal glow on hover, teal caption/close in lightbox  *(verified via computed styles: dialog navy 11,60,93 / border gold 244,180,0 / count pill teal 13,138,114)*
- [ ] **Wheel pauses while modal is open** and **resumes after closing** (no more spinning behind the modal)  *(verified: active slide frozen at 1 during modal, advanced 1→2 after close)*
- [ ] **No console errors** on the homepage  *(verified: 0 errors)*
- [ ] **Mobile** — wheel centered, sides peek at edges, no sideways scroll, modal grid 2-col  *(verified: overflow 0px)*
- [ ] On your machine: homepage → Facilities → verify the front photo is centered in the gold frame, side photos fade at the edges without touching the frame → open each category card → check the navy/gold/teal modal → lightbox prev/next

---

**If anything fails**, write: module + item number + what you saw (screenshot helps).
I'll fix precisely and you re-test only that item.

## BF. V5.58 — Contact section + footer
- [ ] **#contact section** renders after News (nav: Home · About · Courses · Facilities · News · Contact)  *(verified: section present)*
- [ ] **Title + intro** — "Get in Touch With Us" animated navy→teal title; intro editable at Settings → Website Content → Contact  *(verified)*
- [ ] **3 info cards** — Visit (navy, address + Get Directions), Call (white, landline 8241-0881 + mobile 09971201553 as tel: links), Email (teal, usmci2010@gmail.com mailto)  *(verified: computed bg navy/white/teal; tel:+6382410881, tel:+639971201553)*
- [ ] **Left panel** — office name + address, business hours (Mon–Fri 8–5 · Sat 8–12 · Sun Closed), walk-in note, Get Directions + Call buttons, "1 business day" promise  *(verified)*
- [ ] **Inquiry form embedded** — all 3 sections (Personal / Training Interest / Inquiry Details), live course dropdown, privacy checkbox, "Send Inquiry →"  *(verified: 9 controls)*
- [ ] **Form returns to #contact** — after submit you land back on index.php#contact with a success toast showing the reference number (was: bounced to inquiry page)  *(verified: toast "Inquiry sent successfully. INQ-2026-000012")*
- [ ] **Course pre-select** — index.php?course=NAME pre-selects the course in the contact form  *(verified on the inquiry page pattern)*
- [ ] **Footer** — navy with gold top border: brand + SEC/ISO badges · Quick Links · Popular Courses (live) · Contact block; bottom © line  *(verified: 4 columns, email + address present)*
- [ ] **Responsive** — cards stack 1-col on mobile; grid becomes single column (form first, panel second); no sideways scroll  *(verified: overflow 0px)*
- [ ] **No console errors**  *(verified: 0)*
- [ ] On your machine: homepage → scroll to Contact → check info cards + panel + form → submit a test inquiry → confirm you return to #contact with the toast → check the footer; then edit Settings → Website Content → Contact and see the changes live

---

**If anything fails**, write: module + item number + what you saw (screenshot helps).
I'll fix precisely and you re-test only that item.

## BG. V5.59 — Universal cache-busting (the "old wheel still showing" fix)
> **Why this build exists:** the V5.57 fixes for the wheel / cards / modal were already
> correct, but the section CSS/JS files had no `?v=` version query, so your browser kept
> loading the OLD cached files and the lapping wheel kept coming back. This build adds
> `ASSET_VERSION` (v63) to EVERY css/js include on the site. After ONE hard refresh,
> future updates force-refresh themselves automatically.
- [ ] **Page source shows `?v=63`** on all section assets — e.g. `sections/facilities/style.css?v=63`, `facilities.js?v=63`, `about/style.css?v=63`, `navbar/script.js?v=63` (right-click → View Page Source, Ctrl+F `v=63`)  *(verified: 0 unversioned section assets)*
- [ ] **Wheel no longer laps at any window size** — front photo centered in the gold frame; side photos sit BESIDE the frame faded (~55%); back photo is a faint layer (12%); tested at 2542px wide  *(verified: front x[1015–1517] = frame, sides x[612–995]/[1537–1920], back x[1454–1680] op .12)*
- [ ] **Category cards = original design** — flat card, icon circle, gold title, "4 photos · Explore →" (no 3D tilt / glare / count badge)  *(verified)*
- [ ] **Photo modal = 3-color theme** — navy body + gold border/accent + teal pill/glow  *(verified)*
- [ ] **Contact section + footer still render** after the asset changes  *(verified)*
- [ ] **No console errors**  *(verified: 0)*
- [ ] On your machine: **fully replace htdocs/USMCI-TMS** (do NOT merge) → run `database/apply_all_updates.sql` → **Ctrl+F5** → homepage → Facilities → the wheel must show the centered frame with side photos fading outside it; open a category card → 3-color modal; check Contact + footer. If the OLD lapping wheel still appears after that, tell me the exact page URL and I'll look again.

---

**If anything fails**, write: module + item number + what you saw (screenshot helps).
I'll fix precisely and you re-test only that item.

## BH. V5.60 — Facilities cards/arrows + News announcements row
**Facilities — category cards (per reference image)**
- [ ] Card photo is TALLER (148px) with a subtle navy scrim at the bottom  *(verified)*
- [ ] Circular icon badge is BIGGER (52px, navy gradient + gold ring + gold glyph) lower-left on the photo  *(verified: 52px, linear-gradient navy)*
- [ ] Body still original: gold title + "4 photos · Explore →"; clicking opens the 3-color modal  *(verified)*

**Facilities — carousel arrows outside the image**
- [ ] Prev/next arrows sit OUTSIDE the carousel (left/right of the stage), not on the photo  *(verified: prev x[105–151] left of stage x[169]; next x[1279–1325] right of stage x[1261]; no overlap with front photo)*
- [ ] On smaller screens arrows tuck to the edges and stay compact  *(verified: ≤700px 38px at 4px)*

**News — Training Center Announcements row**
- [ ] Second row under the enrolling batches on #news titled "Training Center Announcements" with 3 seeded notices (Class Suspension, Training Center Closed — National Holiday, FF Batch 12 Venue Change)  *(verified: 3 items render, proper em-dashes)*
- [ ] Each notice: gold 📢 icon circle + title + message + gold date pill  *(verified)*
- [ ] **Maintenance page** — Settings → "📢 Training Center Announcements": add, edit, show/hide, delete (with toast + audit log)  *(verified: add → appears, hide → hidden, delete → removed)*
- [ ] Hidden/deleted announcements do NOT appear on the website  *(verified: homepage count 3 after hiding the test row)*
- [ ] Row title + intro editable at Settings → Website Content → News — Announcements row  *(verified: fields added)*
- [ ] On your machine: replace htdocs → run apply_all_updates.sql (adds v27 table + 3 demo announcements) → Ctrl+F5 → homepage → check the bigger card icons + arrows outside the carousel → scroll to News → see the 3 announcements → go to Settings → Training Center Announcements → add one → refresh the homepage → it appears; hide it → it disappears

---

**If anything fails**, write: module + item number + what you saw (screenshot helps).
I'll fix precisely and you re-test only that item.

## BI. V5.61 — Facility card icon badge · arrows fade · Contact map + affiliates
**Facility category cards (per reference image)**
- [ ] Card has a BIG circular medallion badge (72px navy gradient + gold ring + gold glyph) CENTERED, overlapping the photo's bottom edge  *(verified: 72px, badge center = card center)*
- [ ] Title + "4 photos · Explore →" centered under the badge; hover enlarges the badge + lifts the card; click opens the 3-color modal  *(verified)*

**Carousel arrows (fade effect)**
- [ ] Arrows are ~35% opacity by default (never block the photos); they fade to 100% when you hover/focus the carousel  *(verified: 0.35 → 1.0 on hover)*

**Contact — inquiry form removed, Google Map added**
- [ ] The inquiry form is GONE from #contact  *(verified: no #inquiryForm in the section)*
- [ ] Right column shows an embedded Google Map of the office address (output=embed, no API key) with "Open in Google Maps" + email buttons  *(verified: iframe src uses the maintainable address)*
- [ ] Left panel (office, hours, walk-in note, Get Directions / Call) unchanged  *(verified)*

**Affiliated Companies row + maintenance**
- [ ] "Our Affiliations & Partners" row shows logo + NAME cards for MARINA · IMO · PCG · ISO (demo)  *(verified: 4 cards)*
- [ ] The website link is NOT shown in the card — clicking the card opens the partner site in a new tab  *(verified: raw URLs absent from card text; links marina.gov.ph / imo.org / coastguard.gov.ph / iso.org)*
- [ ] **Maintenance page** — Settings → "🤝 Affiliated Companies": add / edit / logo upload (JPG/PNG/WebP/SVG ≤4MB) / remove logo / show-hide / delete / reorder  *(verified: add → list, hide → hidden, delete → removed)*
- [ ] Hidden/deleted affiliates don't appear on the site  *(verified)*
- [ ] Row title + intro editable at Settings → Website Content → Contact  *(verified: fields added)*
- [ ] On your machine: replace htdocs → run apply_all_updates.sql (adds v28 affiliates table + 4 demo) → Ctrl+F5 → homepage → Facilities: cards now show the big centered icon badge, arrows are faint until you hover → scroll to Contact: no form, a live Google Map, and the affiliations row → Settings → Affiliated Companies → add your own partner with a real logo → refresh homepage → click the card → it opens the partner site

---

**If anything fails**, write: module + item number + what you saw (screenshot helps).
I'll fix precisely and you re-test only that item.

## BJ. V5.62 — Facility category cards (per your reference image)
- [ ] Card = TALL rounded panel on the navy→teal section (NO big centered medallion)  *(verified)*
- [ ] **Photo header** (~168px) fills the card top with the facility photo  *(verified: 168px)*
- [ ] **Brand overlay** top-left on the photo: small circular icon (navy + gold ring + gold glyph) + **GOLD category name** (uppercase) + **WHITE sub-label** ("USMCI TRAINING FACILITY")  *(verified: icon 34px, gold text uppercase, white sub)*
- [ ] **Body** below: **GOLD title** (category name) + **WHITE "N photos · Explore →"**  *(verified)*
- [ ] Hover lifts the card + zooms the photo; click opens the 3-color modal  *(verified: modal opens, 4 items)*
- [ ] All 5 categories render (Training Center · Classroom · Simulators · Fire & Safety · Equipment)  *(verified: 5 cards)*
- [ ] Responsive: photo 140px + smaller gold text on mobile; grid 5 → 3 → 2 → 1  *(verified: no overflow)*
- [ ] On your machine: homepage → Facilities → the cards should now show the photo header with the icon + gold name + white sub-label at the top-left, then the gold title + photo count below — same style as the image you attached. Tell me if the copy ("USMCI Training Facility" sub-label) should say something else

---

**If anything fails**, write: module + item number + what you saw (screenshot helps).
I'll fix precisely and you re-test only that item.

## BK. V5.63 — Facility cards restored to the reference layout
> **Yes — I can see the image you attached.** It shows the simple design:
> 3 WIDE cards side-by-side on the navy section, each with a photo header,
> a small icon + gold category name + white sub-label overlaid at the
> top-left of the photo, then a roomy body with a gold title + white
> subtitle, and ONE centered gold button below the row. This build returns
> to exactly that layout.
- [ ] **3-column grid** of wide cards (5 categories → 3 + 2), not 5 skinny columns  *(verified: 349px × 3 columns)*
- [ ] **Tall cards ~440px** — photo header 210px + roomy ~230px body (reference proportions ~48/52)  *(verified: card 440px, photo 210px, body 228px)*
- [ ] **Photo header** with small icon + GOLD uppercase category name + white sub-label top-left  *(verified)*
- [ ] **Body**: gold title + white "N photos · Explore →" left-aligned with generous whitespace  *(verified)*
- [ ] **Single centered GOLD button** below the grid ("Explore Our Facilities →", navy text) — no more two-button row  *(verified: 1 gold button)*
- [ ] Hover lifts card + zooms photo; click opens the 3-color modal  *(verified: modal opens, 4 items)*
- [ ] Responsive: grid 3 → 2 → 2 → 1; photo 160px on mobile  *(verified: no overflow)*
- [ ] On your machine: replace htdocs → Ctrl+F5 → homepage → Facilities → the cards should now look like the image you attached (3 wide cards per row, tall, simple, one gold button below). If any detail is still off, point at it and I'll adjust that exact piece

---

**If anything fails**, write: module + item number + what you saw (screenshot helps).
I'll fix precisely and you re-test only that item.

## BL. V5.64 — Facility cards → 6 simple icon feature cards
> Matching your note: **6 feature cards with icons — 🏫 Classrooms · ⚙️ Simulators ·
> 🧯 Fire & Safety · ⚓ Equipment · 📚 Library & Study · ☕ Amenities** (the original
> simple design).
- [ ] **6 cards in 3×2 grid** — Classrooms, Simulators, Fire & Safety, Equipment, Library & Study, Amenities  *(verified: 6 cards, 3 columns × 2 rows)*
- [ ] Each card: **big emoji icon** top-left, **GOLD title**, **white description**, on a subtle lighter-navy panel  *(verified)*
- [ ] No photos on the cards (simple icon style, not photo cards)  *(verified)*
- [ ] **Classrooms / Simulators / Fire & Safety / Equipment** are clickable → open the 3-color photo modal with a "View photos →" link  *(verified: modal opens, title "Classrooms")*
- [ ] **Library & Study / Amenities** are static informational cards (no image folder yet)  *(verified)*
- [ ] Card text editable at Settings → Website Content → Facilities → "Facilities — Feature cards"  *(verified: read from site_facilities_features)*
- [ ] Carousel + arrow fade + single gold CTA unchanged  *(verified: arrows 0.35→1, CTA present)*
- [ ] Responsive: 3 → 2 → 2 → 1 columns, no overflow  *(verified: overflow 0px)*
- [ ] On your machine: replace htdocs → run apply_all_updates.sql → Ctrl+F5 → homepage → Facilities → the cards are now the simple icon cards from your note. If the copy/icons are right, we're done with this card design; tell me if you want any card renamed or reworded (edit it in Settings → Website Content, or I can change the defaults)

---

**If anything fails**, write: module + item number + what you saw (screenshot helps).
I'll fix precisely and you re-test only that item.

## BM. V5.65 — Facility cards reset to the reference photo
> Reset to match Screenshot 145240 exactly (I decoded it with OCR):
> 6 cards in a 3×2 grid — 🏫 Classrooms · ⚙️ Simulators · 🧯 Fire & Safety /
> ⚓ Equipment · 📚 Library & Study · ☕ Amenities — then TWO buttons below:
> **Explore Courses** (gold) + **Send an Inquiry** (teal).
- [ ] **6 cards, 3×2 grid**, titles + descriptions exactly as the photo:
  Classrooms "Modern, air-conditioned lecture rooms with audio-visual aids." · Simulators "State-of-the-art bridge, engine-room and cargo simulators." · Fire & Safety "Dedicated fire-fighting and survival training grounds." · Equipment "Up-to-date onboard technology and life-saving appliances." · Library & Study "Reference library and quiet study areas." · Amenities "Convenient facilities for trainees and assessors."  *(verified: all 6 with exact text)*
- [ ] Card = plain emoji icon top → gold title → white description; NO photo, NO link text, NO badge  *(verified: no .fac-cat__link on any card)*
- [ ] **Two CTA buttons**: "Explore Courses" (gold bg, navy text) + "Send an Inquiry" (teal bg, white text)  *(verified: computed gold #F4B400 + teal #0D8A72)*
- [ ] Clicking Classrooms/Simulators/Fire & Safety/Equipment still opens the 3-color photo modal (silent — no visible link)  *(verified: modal opens, title "Classrooms")*
- [ ] Content editable at Settings → Website Content → Facilities → "Facilities — Feature cards"  *(verified)*
- [ ] Responsive 3 → 2 → 2 → 1, no overflow; carousel + arrow fade unchanged  *(verified: overflow 0px, arrows 0.35→1)*
- [ ] On your machine: replace htdocs → Ctrl+F5 → homepage → Facilities → should now look exactly like Screenshot 145240 (6 simple icon cards + Explore Courses / Send an Inquiry buttons). If this matches, we're done with Facilities

---

**If anything fails**, write: module + item number + what you saw (screenshot helps).
I'll fix precisely and you re-test only that item.

## BN. V5.66 — Facility sizes + Contact 3-row layout
**Facilities (sizes tuned)**
- [ ] Card height ~20% shorter — min-height 206px (was 258px)  *(verified: 206px)*
- [ ] Carousel ~30% taller — 325px on desktop (was 250px)  *(verified: 325px)*
- [ ] Cards still look like the reference photo (6 simple icon cards)  *(verified)*

**Contact — ROW 1: single info-card line (7 cards)**
- [ ] One line of 7 cards: 📍 Main Office · 🏗️ Training Site · 📘 Facebook · 📸 Instagram · 📱 Mobile Number · ☎️ Telephone · ✉️ Email  *(verified: 7 cards, 7 equal columns)*
- [ ] Main Office shows the address + "Get Directions →" (Google Maps); Mobile/Tel are tel: links; Email is mailto:; Facebook/Instagram open in a new tab  *(verified)*
- [ ] Training Site / Facebook / Instagram URLs editable at Settings → Website Content → Contact  *(verified: fields added)*
- [ ] The old map iframe + 3 info cards + panel are gone (location shared via Get Directions)  *(verified: no .contact__map-frame)*

**Contact — ROW 2: Affiliations, ROW 3: Partners**
- [ ] Row 2 "Our Affiliations" shows MARINA · IMO · PCG · ISO (logo + name, link hidden, card clickable)  *(verified: 4 cards)*
- [ ] Row 3 "Our Partners" shows the 3 demo partners — replace with real ones  *(verified: 3 cards)*
- [ ] **Maintenance**: Settings → Affiliated Companies has a Type selector (🏛 Affiliation / 🤝 Partner), color-coded Type badges in the list, add/edit/delete works per type  *(verified: added a Partner, badge showed, deleted)*
- [ ] Responsive: info line 7 → 4 → 3 → 2 → 1 columns; no overflow  *(verified: overflow 0px)*
- [ ] On your machine: replace htdocs → run apply_all_updates.sql (adds v29 type column + partner demos + settings) → Ctrl+F5 → homepage → Facilities: shorter cards + taller carousel → Contact: the 7-card info line, then Affiliations, then Partners; go to Settings → Affiliated Companies to add real partners

---

**If anything fails**, write: module + item number + what you saw (screenshot helps).
I'll fix precisely and you re-test only that item.

## BO. V5.67 — Carousel arrow fix + 5 photos · Contact teal cards · Logo auto-fit
**Facilities carousel**
- [ ] **Prev/next arrows now WORK** (they were bound to a null element before — buttons live outside the carousel)  *(verified: next 1→2, prev 2→1)*
- [ ] **5 photos visible at once** — front + 2 sides + 2 backs (added 05-center.jpg; back tier opacity .30)  *(verified: 5 slides, opacities .55/1/.55/.30/.30)*
- [ ] Auto-rotate, click-to-front, dots, swipe still work  *(verified)*

**Contact info cards (Home-Card style, teal)**
- [ ] Cards look like the approved Home feature cards but **teal**: teal gradient icon circle, teal uppercase label, navy value, teal CTA  *(verified: teal #0D8A72 icon gradient + label)*
- [ ] **Full-width line, centered** — each card max-width = affiliate card width (231px); 7 cards wrap centered (4+3)  *(verified: 231px vs affiliate 232px; center offsets symmetric)*
- [ ] Hover lifts + teal glow; links still tel:/mailto:/social  *(verified)*

**Affiliate / Partner cards**
- [ ] **Uploaded logo auto-fits the circle** — object-fit:cover fills the round frame (no letterbox for rectangular photos)  *(verified: object-fit cover)*
- [ ] **Distinct per category** — Affiliations: white + gold ring/glow; Partners: teal gradient card + teal ring/glow  *(verified via computed styles)*
- [ ] Responsive: info cards wrap 4→3→2→1; grids 4→2→1; no overflow  *(verified: overflow 0px)*
- [ ] On your machine: replace htdocs → Ctrl+F5 → homepage → click the carousel arrows (should move now; 5 photos show) → Contact: teal info cards centered, Affiliations gold vs Partners teal, upload a rectangular logo for a partner → it fills the circle

---

**If anything fails**, write: module + item number + what you saw (screenshot helps).
I'll fix precisely and you re-test only that item.

## BP. V5.68 — Carousel 5-photo fan + Contact info maintenance + 3 distinct rows
**Facilities carousel**
- [ ] **All 5 photos visible** — front + 2 inner + 2 outer as a fan (outer tier is now outside, not hidden behind)  *(verified: widths 393/336/336/254/254, ops 1/.78/.78/.55/.55, all in viewport)*
- [ ] Prev/next arrows work; auto-rotate + dots + swipe unchanged  *(verified)*

**Contact info cards — maintenance**
- [ ] New **Settings → 📇 Contact Info Cards** page: add / edit / show-hide / delete / reorder with toasts  *(verified: add Hotline → list, toggle, delete; homepage back to 7)*
- [ ] Website row renders from the DB; Main Office/Mobile/Tel/Email stay synced to letterhead settings  *(verified: 7 cards render, labels correct)*

**Contact — single row, full width, centered**
- [ ] The 7 cards are in ONE row, auto-fitting the full screen width (no wrap), equal height, centered  *(verified: all 7 same top; fills 169→1261; mobile still 1 row, overflow 0)*

**Three distinct card designs per row**
- [ ] **Contact** = teal gradient card, white text, white icon circle  *(verified: linear-gradient teal, white text)*
- [ ] **Affiliations** = navy gradient card, gold logo ring + gold name  *(verified: navy gradient, gold name)*
- [ ] **Partners** = white card, teal logo ring + teal name  *(verified: white bg, teal name)*
- [ ] On your machine: replace htdocs → run apply_all_updates.sql (adds v30 contact-info table + 7 seeded) → Ctrl+F5 → homepage → Facilities: 5 photos visible in the carousel → Contact: one teal row of 7 cards → navy Affiliations → white Partners → Settings → Contact Info Cards → add/edit/delete a card and watch the site update

---

**If anything fails**, write: module + item number + what you saw (screenshot helps).
I'll fix precisely and you re-test only that item.

## BQ. V5.69 — Full-width cards + carousel spacing + move-up
**Facilities + Contact — full width, centered**
- [ ] Cards grid now fills the screen width (container 1140→1560px) and stays centered — at 1881px the grid spans 1512px  *(verified: grid 180–1692)*
- [ ] Contact info line also spans the full width  *(verified: 1512px)*

**Carousel — spacing between photos**
- [ ] Photos no longer overlap — gaps ~20px outer↔inner, ~39px inner↔front, all 5 inside the viewport  *(verified: gaps [20,39,38,20])*
- [ ] Arrows still work; auto-rotate + dots + click-to-front unchanged  *(verified: next 1→2)*

**Carousel — moved up**
- [ ] Section top padding 84→52px, head margin 44→26px — the carousel sits ~240px below the section top (was ~390px)  *(verified: carouselTop − sectionTop ≈ 241px)*

**Mobile**
- [ ] 3 photos visible (front + 2 sides) with ~9px gaps; outer 2 fade out; no clipping, no sideways scroll  *(verified: 3 visible, gaps 9px, overflow 0)*
- [ ] On your machine: replace htdocs → Ctrl+F5 → homepage → Facilities: cards fill the width, the carousel has space between the 5 photos and sits higher; on your phone the carousel shows 3 clean photos

---

**If anything fails**, write: module + item number + what you saw (screenshot helps).
I'll fix precisely and you re-test only that item.

## BR. V5.70 — Carousel arrows to side + shadow fix + +50% height · cards centered/shortened
**Carousel — arrows**
- [ ] **Prev/next arrows are now at the far left/right edges** of the screen, OUTSIDE the photos (was on the 1st/5th image)  *(verified: prev x[9-55], next x[1816-1862], fan x[71-1800])*
- [ ] Arrows still work (next/prev advance the wheel)  *(verified: 1→2→1)*

**Carousel — shadow**
- [ ] **No more fixed shadow at the 1st and 5th slots** — only the front photo keeps a shadow  *(verified: front has shadow, others none)*

**Carousel — height**
- [ ] Carousel **+50% taller** — 488px on desktop (was 325px), tablet 468px, phone 410px  *(verified: 488px)*

**Facility cards**
- [ ] **Content centered** — icon/title/description centered horizontally AND vertically  *(verified: align center, justify center, text-align center)*
- [ ] **Height ~30% shorter** — 144px (was 206px), mobile 108px  *(verified: 144px)*

**Contact cards**
- [ ] **Content centered** — each card vertically centers its icon/label/value  *(verified: justify center)*
- [ ] On your machine: replace htdocs → Ctrl+F5 → homepage → Facilities: arrows at the screen sides, no shadow blobs on the outer photos, taller carousel, cards centered + shorter → Contact: card content centered

---

**If anything fails**, write: module + item number + what you saw (screenshot helps).
I'll fix precisely and you re-test only that item.

## BS. V5.71 — Carousel photos +50% (container right-sized) + card content left / cards centered
**Carousel — the PHOTOS are bigger now (not just the container)**
- [ ] Front photo is **660×283px (+50%)** — was 440×189px; slides uncapped to max-width 660  *(verified: 660×283)*
- [ ] **Container right-sized** to the bigger photo (clamp 320–380px) — no more big empty padding above/below the photos  *(verified: carH 380 with 283px photo)*
- [ ] On WIDE screens (≥1900px, your 2279px monitor): **all 5 photos visible** with ~20–49px gaps  *(verified: 5 visible, gaps 49/21/20/49)*
- [ ] Smaller screens: front + 2 side photos (outers fade)  *(verified: 3 visible at 1881px)*
- [ ] Prev/next arrows pinned to the far left/right of the viewport, clear of the photos  *(verified: prev x[9-55], next x[2214-2260])*
- [ ] Arrows still work (1→2→1)  *(verified)*

**Facility cards — content NOT centered, cards centered**
- [ ] Card content back to **LEFT-aligned** (icon top-left, gold title, description left)  *(verified: align flex-start, text-align left)*
- [ ] The **cards themselves centered** in the grid  *(verified: grid centered)*
- [ ] Height stays ~144px (the −30% from the previous request)  *(verified: 152px incl. padding)*

**Contact — same treatment**
- [ ] **Get in Touch** info cards: content **LEFT-aligned**, the single centered row kept  *(verified: align flex-start, 7 cards in 1 row)*
- [ ] **Affiliations & Partners** card groups centered in the container  *(verified: both grids centered)*
- [ ] On your machine: replace htdocs → Ctrl+F5 → homepage → Facilities: the photos are now visibly ~50% bigger with the container hugging them, 5 photos on your wide screen, arrows at the far edges; card text is left-aligned inside centered cards → Contact: same

---

**If anything fails**, write: module + item number + what you saw (screenshot helps).
I'll fix precisely and you re-test only that item.