<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Certificate Download
 * File : download_certificate.php
 * ---------------------------------------------------------
 * Downloads a certificate:
 *   - If the admin attached a file → streams that file.
 *   - If no file was attached → generates a clean printable
 *     HTML certificate and downloads it as <cert-no>.html
 *     (a digital copy).
 * Access: any logged-in staff, or the trainee who owns the
 * certificate.
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once __DIR__ . '/config/bootstrap.php';

require_login();

$ref = trim((string) ($_GET['ref'] ?? ''));

if ($ref === '') {
    http_response_code(400);
    exit('Missing certificate reference.');
}

try {
    $pdo = db();

    $stmt = $pdo->prepare(
        "SELECT c.*, COALESCE(m.course_name, c.course_name_override) AS course,
                a.first_name, a.middle_name, a.last_name,
                t.training_no, t.batch_name
         FROM certificate c
         LEFT JOIN mnt_course m ON m.id = c.course_id
         JOIN applicant a ON a.id = c.applicant_id
         LEFT JOIN enrollment e ON e.id = c.enrollment_id
         LEFT JOIN training t ON t.id = e.training_id
         WHERE c.certificate_no = :ref LIMIT 1"
    );
    $stmt->execute(['ref' => $ref]);
    $c = $stmt->fetch();

    if (!$c) {
        http_response_code(404);
        exit('Certificate not found.');
    }

    /* Permission: staff can download any; trainee only their own */
    $user = current_user();
    $isStaff = ($user['role'] ?? '') === 'staff';
    $isOwner = ((int) ($user['applicant_id'] ?? 0)) === (int) $c['applicant_id'];

    if (!$isStaff && !$isOwner) {
        http_response_code(403);
        exit('You are not allowed to download this certificate.');
    }

    $name = trim(($c['first_name'] ?? '') . ' ' . ($c['middle_name'] ?? '') . ' ' . ($c['last_name'] ?? ''));
    $name = trim(preg_replace('/\s+/', ' ', $name));

    /* View mode (?view=1) → open the certificate for printing:
       1) if a FILE was uploaded at issuance, stream THAT file inline
          (the school's own certificate is the certificate of record —
          no system format is used when a file exists);
       2) only when NO file was attached, render the system-generated
          certificate (with QR) as a fallback. */
    $viewMode = (($_GET['view'] ?? '') === '1');

    /* Track whether a file was attached at issuance but is MISSING on disk
       (e.g. the uploads/ folder was replaced during an update) — this is
       the #1 reason "View File" shows the system certificate. */
    $fileMissing = (!empty($c['file_path']) && !is_file(BASE_PATH . '/' . ltrim((string) $c['file_path'], '/')));

    if ($viewMode && !empty($c['file_path']) && !$fileMissing) {
        $abs = BASE_PATH . '/' . ltrim($c['file_path'], '/');
        if (is_file($abs)) {
            $mime = 'application/octet-stream';
            $ext = strtolower(pathinfo($c['file_path'], PATHINFO_EXTENSION));
            if ($ext === 'pdf') { $mime = 'application/pdf'; }
            elseif ($ext === 'png') { $mime = 'image/png'; }
            elseif ($ext === 'jpg' || $ext === 'jpeg') { $mime = 'image/jpeg'; }
            header('Content-Type: ' . $mime);
            /* inline (not attachment) so the browser shows it with Print */
            header('Content-Disposition: inline; filename="' . ($c['file_name'] ?: basename($c['file_path'])) . '"');
            header('Content-Length: ' . filesize($abs));
            readfile($abs);
            exit;
        }
    }

    /* 1) Attached file exists → stream it (unless in view mode) */
    if (!$viewMode && !empty($c['file_path']) && !$fileMissing) {
        $abs = BASE_PATH . '/' . ltrim($c['file_path'], '/');
        if (is_file($abs)) {
            $orig = $c['file_name'] ?: (basename($c['file_path']));
            header('Content-Type: application/octet-stream');
            header('Content-Disposition: attachment; filename="' . $orig . '"');
            header('Content-Length: ' . filesize($abs));
            readfile($abs);
            exit;
        }
    }

    /* 2) Generate a clean HTML certificate (digital copy) */
    $fileMissNote = $fileMissing
        ? '<p style="margin-top:14px;font-size:11px;color:#B45309;border:1px dashed #F4B400;border-radius:8px;padding:8px 12px;background:#FFFBEB;">⚠ The uploaded certificate file for this record is missing on the server (the uploads/ folder was likely replaced during an update). Showing the system certificate as a fallback. Please contact Admissions to re-upload the official file.</p>'
        : '';
    $statusLabel = ucfirst($c['status'] === 'issued' && $c['expiry_date'] && strtotime($c['expiry_date']) < time() ? 'expired' : $c['status']);
    $qrSrc = '';
    $verifyUrl = (string) ($c['verification_url'] ?? '');
    if ($verifyUrl !== '') {
        $qrSrc = qr_png_base64($verifyUrl, 6, 2);
    }
    $html = '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8">'
        . '<title>Certificate ' . htmlspecialchars($c['certificate_no'], ENT_QUOTES) . '</title>'
        . '<style>'
        . 'body{font-family:Arial,sans-serif;color:#0B3C5D;display:flex;align-items:center;justify-content:center;min-height:100vh;background:#F1F5F9;}'
        . '.cert{border:3px solid #0D8A72;border-radius:16px;padding:44px 52px;max-width:640px;background:#fff;text-align:center;box-shadow:0 20px 50px rgba(11,60,93,.15);}'
        . '.org{font-size:12px;letter-spacing:3px;color:#0D8A72;font-weight:700;}'
        . 'h1{font-size:24px;margin:8px 0 2px;letter-spacing:.04em;}'
        . '.no{color:#94A3B8;font-size:12px;margin-bottom:18px;}'
        . '.trainee{font-size:22px;font-weight:800;color:#0B3C5D;margin:8px 0;}'
        . '.row{margin:8px 0;font-size:14px;} .row b{color:#0B3C5D;}'
        . '.status{display:inline-block;margin-top:14px;padding:6px 16px;border-radius:999px;font-weight:800;font-size:12px;'
        . (strpos($statusLabel, 'Void') !== false ? 'background:#F1F5F9;color:#64748B;' : (strpos($statusLabel, 'Expired') !== false ? 'background:#FEE2E2;color:#B91C1C;' : 'background:#DCFCE7;color:#15803D;'))
        . '}'
        . '.qr{margin-top:18px;}'
        . '.qr img{width:128px;height:128px;image-rendering:pixelated;}'
        . '.qr .qrlabel{font-size:10px;color:#94A3B8;margin-top:4px;}'
        . '.foot{margin-top:18px;font-size:11px;color:#94A3B8;}'
        . '@media print{.qr{display:block !important;}}'
        . '</style></head><body><div class="cert">'
        . '<div class="org">USMCI TRAINING MANAGEMENT SYSTEM</div>'
        . '<h1>CERTIFICATE OF TRAINING</h1>'
        . '<div class="no">' . htmlspecialchars($c['certificate_no'], ENT_QUOTES) . '</div>'
        . '<div class="row"><b>Trainee:</b> ' . htmlspecialchars($name, ENT_QUOTES) . '</div>'
        . '<div class="row"><b>Course:</b> ' . htmlspecialchars((string) $c['course'], ENT_QUOTES) . '</div>'
        . ($c['batch_name'] ? '<div class="row"><b>Batch:</b> ' . htmlspecialchars((string) $c['batch_name'], ENT_QUOTES) . '</div>' : '')
        . '<div class="row"><b>Date Issued:</b> ' . htmlspecialchars((string) $c['issued_date'], ENT_QUOTES) . '</div>'
        . '<div class="row"><b>Date Expiry:</b> ' . htmlspecialchars((string) ($c['expiry_date'] ?? '—'), ENT_QUOTES) . '</div>'
        . '<div class="status">' . htmlspecialchars($statusLabel, ENT_QUOTES) . '</div>'
        . ($qrSrc !== '' ? '<div class="qr"><img src="' . htmlspecialchars($qrSrc, ENT_QUOTES) . '" alt="QR verification"><div class="qrlabel">Scan to verify · ' . htmlspecialchars($c['certificate_no'], ENT_QUOTES) . '</div></div>' : '')
        . '<div class="foot">Official certificate issued through the USMCI Training Management System</div>'
        . $fileMissNote
        . '</div></body></html>';

    if ($viewMode) {
        /* printable view: render inline (no attachment header) so the user
           can print with the QR — also add a print button */
        $html = str_replace('</head>',
            '<style>.printbar{position:fixed;top:0;left:0;right:0;background:#0B3C5D;padding:10px;text-align:center;z-index:9;}'
            . '.printbar button{background:#F4B400;color:#0B3C5D;border:none;padding:8px 18px;border-radius:8px;font-weight:800;cursor:pointer;font-size:13px;margin:0 4px;}'
            . '@media print{.printbar{display:none;}}</style></head>',
            $html);
        $html = str_replace('<body>', '<body><div class="printbar"><button onclick="window.print()">🖨 Print / Save PDF</button><button onclick="window.close()">Close</button></div>', $html);
        header('Content-Type: text/html; charset=UTF-8');
        echo $html;
    } else {
        header('Content-Type: text/html; charset=UTF-8');
        header('Content-Disposition: attachment; filename="' . $c['certificate_no'] . '.html"');
        echo $html;
    }
} catch (Throwable $e) {
    error_log('download_certificate: ' . $e->getMessage());
    http_response_code(500);
    exit('Could not download the certificate.');
}
exit;
