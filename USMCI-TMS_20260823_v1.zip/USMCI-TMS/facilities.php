<?php
/**
 * -------------------------------------------------------------------------
 * USMCI-TMS — PUBLIC PAGE: Facilities Gallery
 * -------------------------------------------------------------------------
 * Explores the facility images by category. Each category auto-fetches
 * from its own folder:
 *   assets/images/site/facilities/<category>/
 *     training-center · classroom · simulators · fire-safety · equipment
 * Optionally filtered: facilities.php?cat=classroom
 * Clicking any image opens a lightbox to view it large.
 * -------------------------------------------------------------------------
 */

declare(strict_types=1);

require_once __DIR__ . '/config/bootstrap.php';

$page = [
    'title'       => 'Facilities Gallery | USMCI',
    'description' => 'Explore the USMCI training facilities.',
    'bodyClass'   => 'facilities-page',
];

$catBase = 'assets/images/site/facilities';
$cats    = site_gallery_categories($catBase);
$catOrder = ['training-center', 'classroom', 'simulators', 'fire-safety', 'equipment'];
$keys = array_keys($cats ?: []);
usort($keys, fn($a, $b) => array_search($a, $catOrder) <=> array_search($b, $catOrder));

$activeCat = trim((string) ($_GET['cat'] ?? ''));
if ($activeCat !== '' && !isset($cats[$activeCat])) { $activeCat = ''; }

/* Auto-fetch images per category */
$gallery = [];
foreach ($keys as $slug) {
    $gallery[$slug] = [
        'name'  => $slug === 'fire-safety' ? 'Fire & Safety' : ($slug === 'training-center' ? 'Training Center' : ucwords(str_replace(['-', '_'], ' ', $slug))),
        'images'=> site_gallery_images("$catBase/$slug", 60),
    ];
}
if ($activeCat === '') { $activeCat = $keys[0] ?? ''; }
?>
<!DOCTYPE html>
<html lang="en">

<?php include 'includes/head.php'; ?>

<?php if (file_exists('sections/facilities/style.css')): ?>
    <link rel="stylesheet" href="sections/facilities/style.css?v=<?= ASSET_VERSION; ?>">
<?php endif; ?>
<link rel="stylesheet" href="facilities.css?v=<?= ASSET_VERSION; ?>">

<body class="<?= e($page['bodyClass']); ?>">

    <?php include 'navbar/index.php'; ?>

    <main id="main-content">

        <section class="fpage">
            <div class="fpage__head">
                <span class="facilities__eyebrow">Facilities Gallery</span>
                <h1 class="facilities__title">Explore Our Facilities</h1>
                <p class="fpage__intro">Browse the training environment at USMCI — select a category to view its photos.</p>
            </div>

            <!-- category tabs -->
            <div class="fpage__tabs">
                <?php foreach ($keys as $slug): ?>
                    <a href="<?= e(base_url('facilities.php?cat=' . urlencode($slug))); ?>"
                       class="fpage__tab <?= $slug === $activeCat ? 'is-active' : ''; ?>">
                        <?= e($gallery[$slug]['name']); ?>
                        <span><?= count($gallery[$slug]['images']); ?></span>
                    </a>
                <?php endforeach; ?>
            </div>

            <!-- image grid for the active category -->
            <div class="fpage__cat-title"><?= e($gallery[$activeCat]['name'] ?? ''); ?></div>
            <?php $imgs = $gallery[$activeCat]['images'] ?? []; ?>
            <?php if (!$imgs): ?>
                <p class="fpage__empty">No photos in this category yet — check back soon.</p>
            <?php else: ?>
                <div class="fpage__grid">
                    <?php foreach ($imgs as $i => $src): ?>
                        <button type="button" class="fpage__item" data-full="<?= e($src); ?>" aria-label="View photo">
                            <img src="<?= e($src); ?>" alt="<?= e(($gallery[$activeCat]['name'] ?? 'Facility') . ' ' . ($i + 1)); ?>" loading="lazy">
                        </button>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <div class="fpage__back">
                <a class="facilities__btn facilities__btn--ghost" href="<?= e(base_url('index.php#facilities')); ?>">← Back to Home</a>
            </div>
        </section>

        <!-- lightbox -->
        <div class="fpage-lightbox" id="fpageLightbox" hidden>
            <button class="fpage-lightbox__close" data-lb-close aria-label="Close">&times;</button>
            <img id="fpageLightboxImg" src="" alt="Facility photo">
        </div>

    </main>

    <?php include 'includes/footer.php'; ?>
    <?php include 'includes/scripts.php'; ?>

    <script>
        (function () {
            "use strict";
            var lb = document.getElementById("fpageLightbox");
            var img = document.getElementById("fpageLightboxImg");
            document.querySelectorAll(".fpage__item").forEach(function (btn) {
                btn.addEventListener("click", function () {
                    img.src = btn.dataset.full;
                    lb.hidden = false;
                    document.body.style.overflow = "hidden";
                });
            });
            function close() { lb.hidden = true; document.body.style.overflow = ""; }
            lb.querySelector("[data-lb-close]").addEventListener("click", close);
            lb.addEventListener("click", function (e) { if (e.target === lb) close(); });
            document.addEventListener("keydown", function (e) { if (e.key === "Escape" && !lb.hidden) close(); });
        })();
    </script>

</body>
</html>
