# USMCI-TMS Fix Pack

Ready-to-copy files that fix the issues found in the 2026-08-01 review of
`github.com/NJaplos/TMS`. Each file mirrors the project structure — copy it
over the file with the same path in your project folder.

| File (copy to your project) | What it fixes |
|---|---|
| `config/auth.php` | **NEW** — login/logout/session guard + CSRF helpers |
| `config/bootstrap.php` | Now loads `auth.php` |
| `login.php` | **NEW** — staff login page (uses `sys_user` + `password_verify`) |
| `logout.php` | **NEW** — staff logout |
| `sections/admissions/register.php` | **NEW** — the missing page the invitation email links to (validates token, creates `applicant_account`) |
| `sections/admissions/inquiry-queue/index.php` | Requires login; loads the queue sidebar partial; exposes CSRF to JS |
| `sections/admissions/inquiry-queue/partials/sidebar.php` | Same design language as the Admissions sidebar + workspace nav + sign-out |
| `sections/admissions/inquiry-queue/partials/summary.php` | Live DB counts instead of hardcoded 128/14/37/91 |
| `sections/admissions/inquiry-queue/partials/toolbar.php` | Working status filter (was a dead dropdown) |
| `sections/admissions/inquiry-queue/partials/table.php` | Unique button IDs (duplicate `btnConvert` bug), select-all checkbox |
| `sections/admissions/inquiry-queue/partials/pagination.php` | Live record count instead of the hardcoded "128" |
| `sections/admissions/inquiry-queue/actions/list.php` | Login-guarded; adds search/status/date filters; graceful error |
| `sections/admissions/inquiry-queue/actions/detail.php` | Login-guarded; no more DB error leak |
| `sections/admissions/inquiry-queue/actions/reply.php` | Login + CSRF; staff id from session; no error leak; no header injection |
| `sections/admissions/inquiry-queue/actions/convert.php` | Login + CSRF; staff id from session |
| `sections/admissions/inquiry-queue/script.js` | Wires toolbar actions (Reply / Create Applicant / Export CSV / filters) + CSRF on every POST |
| `sections/admissions/inquiry-queue/assets/css/page.css` | **Complete restyle** — fixes the layout conflict that left gaps at the sides; styles summary, table, badges, modal, sidebar |
| `sections/admissions/inquiry/inquiry_service.php` | Strips CR/LF from email headers (header-injection fix) |
| `sections/admissions/inquiry/submit.php` | Uses `base_url()` (no hardcoded path) + CSRF check |
| `sections/admissions/inquiry/partials/form.php` | Includes CSRF token field |
| `sections/admissions/inquiry_invite.php` | Applicant numbers from `sequence_generator` (no race condition); registration URL fallback |
| `includes/head.php` | Dynamic `<base href>` — works with any project folder name |
| `database/seed_admin.php` | **NEW** — creates your first admin account |
| `.gitignore` | Stops committing zips, backups, `.env`, etc. |

---

## Install steps (in order)

1. **Import the database** if you haven't:
   - Import `enrollsys (2).sql` into phpMyAdmin (database `enrollsys`), then
   - run the SQL in `database/migration_applicant_invitation.sql`
     (adds `mnt_inquiry_status` + `applicant_invitation` — the queue and
     invitation flow need these).
2. **Copy the files** from this pack over the same paths in your project.
3. **Create your admin account** (from the project folder in a terminal):
   ```
   php database/seed_admin.php
   ```
   Default login: `admin` / `Admin@1234` — change it after first login.
4. **Test the flow**:
   - `http://localhost/USMCI-TMS/login.php` — log in.
   - `http://localhost/USMCI-TMS/sections/admissions/inquiry-queue/index.php`
     — the queue now requires login; summary shows real counts; search /
     status / date filters work; rows load from the DB.
   - Open an inquiry → **Reply** sends & queues the email → status becomes
     Replied.
   - **Create Applicant Account** → the invitation email links to
     `sections/admissions/register.php?token=...` which now exists and works.
5. **For real email delivery**, fill in `SMTP_HOST` / `SMTP_USERNAME` /
   `SMTP_PASSWORD` in `config/mail.php` (put the password in a non-committed
   file — never in git), and schedule the mail worker:
   ```
   php sections/admissions/mailer/send_queued_emails.php
   ```
   (every 1–2 minutes via cron / Task Scheduler).

---

## Why `validate_invitation.php` was blank

`validate_invitation.php` only **defines functions** — it is a library, not a
page, so loading it directly prints nothing (that is normal). It is meant to be
`require`d by `register.php`, which did not exist. `register.php` in this pack
uses it, so the invitation link now works end-to-end:

```
inquiry-queue  --convert.php-->  inquiry_invite.php  --email link-->  register.php  --uses-->  validate_invitation.php
```

## Still to do (out of scope of this pack)

- `sections/admissions/register.php` shows the flow works, but a full
  applicant portal (dashboard, application form, document upload) is future work.
- Spam protection on the public inquiry form (honeypot + rate limit).
- The `#` navigation links in the sidebar (Applicants, Reports, etc.) are
  placeholders for future modules.

---

## Round 3 — Inquiry Queue redesign (2026-08-01)

### Files changed
| File | Change |
|---|---|
| `logout.php` | **Sign out now goes to the main page (`index.php`)** instead of the login page |
| `sections/admissions/inquiry-queue/partials/sidebar.php` | Rebuilt to **mirror the Admissions/Inquiry sidebar**: navy gradient, gold-circle pill navigation, Sign Out + Back to Website buttons, staff info-card |
| `sections/admissions/inquiry-queue/partials/header.php` | Added "Admissions" badge + signed-in user chip (name + role) |
| `sections/admissions/inquiry-queue/partials/summary.php` | Added per-card accent colors (today=blue, awaiting=amber, replied=green) |
| `sections/admissions/inquiry-queue/assets/css/page.css` | Full redesign v4.0: sidebar pill nav, search icon, hover states, refined summary cards, table, badges, pagination, modal — all using the Admissions design tokens |

### Apply either
- **Patch zip** (`queue-redesign-patch.zip`) — unzip over your project folder (only the 5 files above), or
- **Full project** (`USMCI-TMS-complete.zip`) — replace `htdocs/USMCI-TMS` entirely (keep your database, no re-import needed).

### Verified
- Login → queue renders new sidebar + header + summary + live data
- Logout → redirects to the main website page
- All PHP lints pass

---

## Round 4 — Email Center + design tweaks (2026-08-01)

### Design tweaks (from your feedback)
| # | Fix |
|---|---|
| 1 | **Content maximized** — the shared layout's right-panel column was still reserved (CSS specificity bug). Fixed with `#admissions-portal.admissions-portal--workspace` → content fills the full width. |
| 2 | **Table scrollbar** — table min-width 1080px + visible themed horizontal scrollbar. |
| 3 | **Toolbar single row** — Status → Date → Refresh left, **Search in the last column (right)**. |
| 4 | **"Back to Website"** — centered, spaced down from the navigation. |

### NEW: Email Center (staff)
`http://localhost/USMCI-TMS/sections/admissions/email-center/index.php`
- **1 · SMTP Settings** — host/port/encryption/username/password/from/admin-email, saved to the `mnt_system_setting` table (no file edits). Includes quick **presets** for Mailtrap / Gmail / Company.
- **2 · Send a Test Email** — verifies the SMTP account immediately.
- **3 · Email Queue** — pending/sent/failed counts, full table with filter, **Send Pending Now**, **Retry Failed**.
- Adds an **Email Center** item to the sidebar nav (auto-highlights the active page).

### How to test email delivery
1. Open the Email Center → 1 · SMTP Settings.
2. Apply a preset (e.g. **Mailtrap**) → enter the username/password Mailtrap gives you → **Save Settings**.
   - *Mailtrap (free test inbox):* host `sandbox.smtp.mailtrap.io`, port `2525`, TLS, username/password from your Mailtrap inbox page.
   - *Gmail:* `smtp.gmail.com`, `587`, TLS, your Gmail + an **App Password** (Google Account → Security → App passwords). Use App Password, never your real password.
3. **Send a Test Email** → open your Mailtrap inbox → see it.
4. **Send Pending Now** → all queued emails (new-inquiry alerts, replies, invitations) send.
5. Before going live: just change the settings to the **company SMTP** — no code changes.

### Verified
- Settings saved to DB and read back ✓
- Test email + full queue (10 pending) sent through the SMTP client, captured by a mock SMTP server ✓

---

## Round 6 — Unified login + trainee dashboard (v2)

- **Unified login** (`login.php`): one page, two tabs (Sign In / Create Account). Staff (sys_user) and trainee (applicant_account) both sign in here; after login each is routed to their own dashboard.
- **Invite-only account creation**: a unique, auto-generated **registration code** (related to the inquiry number, e.g. `USMCI-INQ2026000011-0FB5`) is created when staff converts an inquiry, emailed to the applicant, and is **single-use** (consumed on account creation). No public self-signup.
- **Trainee dashboard** (`trainee/index.php`): account summary, inquiry/admission status, enrollment & course details, payment ledger, inquiry conversation.
- **Admin dashboard** (`sections/admissions/admin/index.php`): KPI cards, recent inquiries, quick actions — staff land here after login.
- **Email Center moved under Admissions Settings** (`sections/admissions/settings/index.php`).
- **Role enforcement**: `require_staff()` / `require_trainee()` guards.
- **Schema v2**: `database/schema_v2_accounts.sql` (idempotent ALTER adding `registration_code`).

---

## Round 7 — Trainee portal, speed, sidebar fix (v3)

- **Trainee dashboard redesign**: 3-column layout (nav | content | right rail with photo + quick info). Sections: Overview, My Inquiry + full conversation thread, Registration/Enrollment slip, Payment ledger, Certificates (validity, print, safekeeping upload), editable Personal Profile (seafarer/SIRB/CDC/passport/medical), Account settings (change password).
- **Photo upload + camera capture** for trainees (schema v3 adds `applicant_profile.photo_path`).
- **Document upload** for certificate copies (owner_type='applicant').
- **Speed**: registration-code creation and replies now return instantly (~20ms); emails deliver in the background via `actions/send_email.php` (fire-and-forget) — no more SMTP-induced UI delays.
- **Sidebar fix**: Email Center page shows "Email Center" title/desc while Admissions Settings stays highlighted.
