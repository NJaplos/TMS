<?php
/*
|--------------------------------------------------------------------------
| USMCI-TMS
|--------------------------------------------------------------------------
| Navigation Portal
|--------------------------------------------------------------------------
| Niel Japlos
|--------------------------------------------------------------------------
*/
?>

<header class="navbar" id="navbar">

    <div class="container">

        <div class="navbar__wrapper">

            <!-- ==========================================
                 BRAND
            =========================================== -->

            <a href="index.php" class="navbar__brand">

                <img
                    src="assets/images/branding/logo-light.png"
                    alt="USMCI Logo"
                    class="navbar__logo">

                <div class="navbar__brand-content">

                    <span class="navbar__brand-name">

                        UNITED SEAFARERS
                        <br>
                        MARITIME CENTER, INC.

                    </span>

                    <span class="navbar__brand-system">

                        Training Management System

                    </span>

                </div>

            </a>

            <!-- ==========================================
                 NAVIGATION
            =========================================== -->

            <nav class="navbar__navigation">

                <ul class="navbar__menu">

                    <li>

                        <a href="#hero"
                           class="navbar__link is-active">

                            Home

                        </a>

                    </li>

                    <li>

                        <a href="#about"
                           class="navbar__link">

                            About

                        </a>

                    </li>

                    <li>

                        <a href="#courses"
                           class="navbar__link">

                            Courses

                        </a>

                    </li>

                    <li>

                        <a href="#facilities"
                           class="navbar__link">

                            Facilities

                        </a>

                    </li>

                    <li>

                        <a href="#news"
                           class="navbar__link">

                            News

                        </a>

                    </li>

                    <li>

                        <a href="#contact"
                           class="navbar__link">

                            Contact

                        </a>

                    </li>

                </ul>

            </nav>

            <!-- ==========================================
                 ACTIONS
            =========================================== -->

            <div class="navbar__actions">

                <a
                    href="login.php"
                    class="c-btn c-btn--ghost">

                    Login

                </a>

                <a
                    href="admissions.php"
                    class="c-btn c-btn--primary">

                    Admissions

                </a>

            </div>

            <!-- ==========================================
                 MOBILE TOGGLE
            =========================================== -->

            <button
                class="navbar__toggle"
                id="navbarToggle"
                aria-label="Toggle Navigation">

                <span></span>

                <span></span>

                <span></span>

            </button>

        </div>

    </div>

</header>