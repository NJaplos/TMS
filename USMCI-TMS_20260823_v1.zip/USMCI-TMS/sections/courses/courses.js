/*=========================================================
   USMCI-TMS — Courses section interactions
   - click card → flips (3D) to details
   - hover-out (cursor leaves the card) → flips back
   - #news "View Course" flips the matching course card
=========================================================*/
(function () {
    "use strict";

    var courseCards = document.querySelectorAll(".courses__card");
    var courseLookup = {};

    function flipCard(card, open) {
        if (!card) return;
        if (open) {
            card.classList.add("is-flipped");
        } else {
            card.classList.remove("is-flipped");
        }
    }

    courseCards.forEach(function (card) {
        try {
            var d = JSON.parse(card.dataset.course);
            courseLookup[d.id] = card;
        } catch (e) {}

        /* click toggles open */
        card.addEventListener("click", function (e) {
            if (e.target.closest("a")) return; /* let Inquire link work */
            flipCard(card, !card.classList.contains("is-flipped"));
        });
        /* hover-out → flip back (no Back button) */
        card.addEventListener("mouseleave", function () {
            if (card.classList.contains("is-flipped")) {
                setTimeout(function () { flipCard(card, false); }, 220);
            }
        });
        /* keyboard */
        card.addEventListener("keydown", function (e) {
            if (e.key === "Enter" || e.key === " ") {
                e.preventDefault();
                flipCard(card, !card.classList.contains("is-flipped"));
            }
        });
    });

    /* #news "View Course" buttons flip the matching course card */
    document.querySelectorAll("[data-news-course]").forEach(function (btn) {
        btn.addEventListener("click", function () {
            try {
                var d = JSON.parse(btn.dataset.newsCourse);
                var card = courseLookup[d.course_id];
                if (!card) {
                    window.open("sections/admissions/inquiry/index.php?course=" + encodeURIComponent(d.name), "_blank");
                    return;
                }
                document.getElementById("courses").scrollIntoView({ behavior: "smooth", block: "start" });
                setTimeout(function () { flipCard(card, true); }, 350);
            } catch (e) {}
        });
    });
})();
