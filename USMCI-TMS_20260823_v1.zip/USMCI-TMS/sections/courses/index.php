<?php
/**
 * -------------------------------------------------------------------------
 * USMCI-TMS — Website Section: Courses (one-page anchor #courses)
 * -------------------------------------------------------------------------
 * V5.53 layout:
 *   - Section background image (site_courses_bg, default course-bg.jpg)
 *   - Category heading + blurb
 *   - Card FRONT: split in two — PHOTO (top) + Course Name/Description
 *     (bottom). No "View Details" text (whole card is a button).
 *   - Click → flips (3D) to the BACK: readable details (duration,
 *     validity, STCW ref, required documents, Inquire). Hover-out
 *     flips it back automatically (no Back button).
 *   - Placeholder image when a course has no photo.
 * Courses come LIVE from Course Management (is_active = 1), grouped
 * by mnt_course_category. Photos set in Course Management.
 * -------------------------------------------------------------------------
 */
declare(strict_types=1);

$pdo = function_exists('db') ? db() : null;

$coursesIntro  = site_content('site_courses_intro', 'Explore our full range of maritime training programs. Click a course to see its details and send an inquiry.');
$coursesBg     = site_content('site_courses_bg', 'assets/images/site/course-bg.jpg');
$coursesBgUrl  = $coursesBg !== '' ? base_url(ltrim($coursesBg, '/')) : '';
$placeholderUrl= base_url('assets/images/site/course-placeholder.jpg');

$groups = [];
$order  = [];
if ($pdo) {
    $stmt = $pdo->query(
        "SELECT c.id, c.code, c.course_name, c.description, c.photo_path, c.duration_hours, c.validity_months,
                c.stcw_reference, c.requires_medical,
                c.course_category_id, cc.name AS cat_name, cc.description AS cat_desc, cc.sort_order
         FROM mnt_course c
         LEFT JOIN mnt_course_category cc ON cc.id = c.course_category_id
         WHERE c.is_active = 1
         ORDER BY cc.sort_order, c.course_name"
    );
    foreach ($stmt->fetchAll() ?: [] as $c) {
        $cat = trim((string) ($c['cat_name'] ?? ''));
        $key = $cat !== '' ? $cat : 'Other Programs';
        if (!isset($groups[$key])) {
            $groups[$key] = ['sort' => (int) ($c['sort_order'] ?? 999), 'desc' => (string) ($c['cat_desc'] ?? ''), 'courses' => []];
            $order[] = $key;
        }
        $reqs = course_required_docs($pdo, (int) $c['id']);
        $groups[$key]['courses'][] = [
            'id'       => (int) $c['id'],
            'code'     => $c['code'],
            'name'     => $c['course_name'],
            'desc'     => (string) ($c['description'] ?? ''),
            'photo'    => trim((string) ($c['photo_path'] ?? '')),
            'duration' => $c['duration_hours'] !== null ? (float) $c['duration_hours'] : null,
            'validity' => $c['validity_months'] !== null ? (int) $c['validity_months'] : null,
            'stcw'     => (string) ($c['stcw_reference'] ?? ''),
            'reqs'     => array_map(fn($r) => $r['name'], $reqs),
        ];
    }
}
usort($order, fn($a, $b) => $groups[$a]['sort'] <=> $groups[$b]['sort']);
?>
<section id="courses" class="courses">

    <?php if ($coursesBgUrl !== ''): ?>
        <div class="courses__bg" style="background-image:url('<?= e($coursesBgUrl); ?>');"></div>
    <?php endif; ?>

    <div class="container">

        <div class="courses__head">
            <span class="courses__eyebrow">Our Programs</span>
            <h2 class="courses__title">Courses &amp; Services</h2>
            <p class="courses__intro"><?= htmlspecialchars($coursesIntro, ENT_QUOTES, 'UTF-8'); ?></p>
        </div>

        <?php if (!$groups): ?>
            <p class="courses__empty">Our course list is being updated — please check back soon or send us an inquiry.</p>
        <?php endif; ?>

        <?php foreach ($order as $catName):
            $g = $groups[$catName];
        ?>
            <div class="courses__cat">
                <h3 class="courses__cat-title"><?= htmlspecialchars($catName, ENT_QUOTES, 'UTF-8'); ?></h3>
                <div class="courses__cat-line"></div>
                <?php if (trim($g['desc']) !== ''): ?>
                    <p class="courses__cat-desc"><?= htmlspecialchars(trim($g['desc']), ENT_QUOTES, 'UTF-8'); ?></p>
                <?php endif; ?>

                <div class="courses__grid">
                    <?php foreach ($g['courses'] as $c):
                        $json = json_encode($c, JSON_HEX_APOS | JSON_HEX_QUOT);
                        $desc = trim($c['desc']) !== '' ? $c['desc'] : 'Details coming soon.';
                        $photoSrc = $c['photo'] !== '' ? base_url(ltrim($c['photo'], '/')) : $placeholderUrl;
                    ?>
                        <div class="courses__card" data-course='<?= $json; ?>' tabindex="0" role="button" aria-label="<?= e($c['name']); ?>">
                            <div class="courses__flip">

                                <!-- FRONT: photo (top) + name/description (bottom) -->
                                <div class="courses__face courses__face--front">
                                    <div class="courses__front-photo">
                                        <img src="<?= e($photoSrc); ?>" alt="<?= e($c['name']); ?>" loading="lazy">
                                    </div>
                                    <div class="courses__front-body">
                                        <h3 class="courses__card-name"><?= htmlspecialchars($c['name'], ENT_QUOTES, 'UTF-8'); ?></h3>
                                        <p class="courses__card-desc"><?= htmlspecialchars($desc, ENT_QUOTES, 'UTF-8'); ?></p>
                                    </div>
                                </div>

                                <!-- BACK: course name + details (STCW ref + description removed) -->
                                <div class="courses__face courses__face--back">
                                    <span class="courses__back-label">Course Details</span>
                                    <h3 class="courses__back-name"><?= htmlspecialchars($c['name'], ENT_QUOTES, 'UTF-8'); ?></h3>

                                    <div class="courses__back-meta">
                                        <div><span>Duration</span><strong><?= $c['duration'] ? (int) $c['duration'] . ' hrs' : '—'; ?></strong></div>
                                        <div><span>Validity</span><strong><?= $c['validity'] ? (int) $c['validity'] . ' months' : '—'; ?></strong></div>
                                    </div>

                                    <div class="courses__back-reqs">
                                        <h4>Required Documents</h4>
                                        <?php if ($c['reqs']): ?>
                                            <ul>
                                                <?php foreach ($c['reqs'] as $r): ?><li><?= e($r); ?></li><?php endforeach; ?>
                                            </ul>
                                        <?php else: ?>
                                            <p class="courses__back-reqs-none">No specific documents required.</p>
                                        <?php endif; ?>
                                    </div>

                                    <div class="courses__back-actions">
                                        <a class="courses__btn courses__btn--primary"
                                           href="<?= e(base_url('sections/admissions/inquiry/index.php?course=' . urlencode($c['name']))); ?>"
                                           target="_blank">📩 Inquire</a>
                                        <span class="courses__back-hint">move cursor away to flip back</span>
                                    </div>
                                </div>

                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endforeach; ?>

    </div>

</section>
