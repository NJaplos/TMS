<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Admissions Settings: Rank / Position
 * File : sections/admissions/settings/ranks.php
 * ---------------------------------------------------------
 * Maintains mnt_rank_position — the dropdown used in the
 * Create Enrollment form (Seafarer/Credentials → Rank).
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/config/bootstrap.php';

require_access('settings');
if ($_SERVER['REQUEST_METHOD'] === 'POST') { require_edit('settings'); }

$pdo = db();

$flash = ['type' => null, 'message' => null];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = $_POST['action'] ?? '';
    try {
        if ($action === 'save') {
            $id   = (int) ($_POST['rank_id'] ?? 0);
            $name = trim((string) ($_POST['name'] ?? ''));
            if ($name === '') {
                $flash = ['type' => 'error', 'message' => 'Rank name is required.'];
            } elseif ($id > 0) {
                $pdo->prepare('UPDATE mnt_rank_position SET name = :n, updated_at = NOW() WHERE id = :id')
                    ->execute(['n' => $name, 'id' => $id]);
                audit_log('settings', 'rank_update', $id, "Rank '{$name}' updated");
                $flash = ['type' => 'success', 'message' => "Rank '{$name}' updated."];
            } else {
                $pdo->prepare('INSERT INTO mnt_rank_position (name, is_active, sort_order) VALUES (:n, 1, 0)')
                    ->execute(['n' => $name]);
                audit_log('settings', 'rank_create', (int) $pdo->lastInsertId(), "Rank '{$name}' created");
                $flash = ['type' => 'success', 'message' => "Rank '{$name}' added."];
            }
        } elseif ($action === 'toggle') {
            $id = (int) ($_POST['rank_id'] ?? 0);
            $cur = (int) $pdo->prepare('SELECT is_active FROM mnt_rank_position WHERE id = :id')->execute(['id' => $id]) ? 0 : 0;
            $stmt = $pdo->prepare('SELECT is_active FROM mnt_rank_position WHERE id = :id');
            $stmt->execute(['id' => $id]);
            $cur = (int) $stmt->fetchColumn();
            $pdo->prepare('UPDATE mnt_rank_position SET is_active = :a, updated_at = NOW() WHERE id = :id')
                ->execute(['a' => $cur ? 0 : 1, 'id' => $id]);
            audit_log('settings', 'rank_toggle', $id, 'Rank ' . ($cur ? 'deactivated' : 'activated'));
            $flash = ['type' => 'success', 'message' => 'Rank ' . ($cur ? 'deactivated.' : 'activated.')];
        }
    } catch (Throwable $e) {
        error_log('ranks.php: ' . $e->getMessage());
        $flash = ['type' => 'error', 'message' => strpos($e->getMessage(), 'Duplicate') !== false ? 'That rank already exists.' : 'Could not save the rank.'];
    }
}

$ranks = $pdo->query('SELECT * FROM mnt_rank_position ORDER BY is_active DESC, sort_order, name')->fetchAll() ?: [];

$page = ['title' => 'Ranks | USMCI-TMS', 'description' => 'Rank Maintenance', 'bodyClass' => 'admissions-page'];
?>
<!DOCTYPE html>
<html lang="en">
<?php include INCLUDES_PATH . '/head.php'; ?>
<link rel="stylesheet" href="<?= e(base_url('assets/css/portal.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/workspace.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/inquiry-queue/assets/css/page.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/admin/dashboard.css?v=' . ASSET_VERSION)); ?>">
<body class="<?= e($page['bodyClass']); ?>">
    <?php include NAVBAR_PATH . '/index.php'; ?>
    <section class="portal-shell portal-shell--2col">
        <?php require ADMISSIONS_PATH . '/inquiry-queue/partials/sidebar.php'; ?>
        <main class="portal-content">
            <header class="workspace-header">
                <div class="workspace-header__left">
                    <span class="section-badge">Settings</span>
                    <h1>Rank / Position</h1>
                    <p>Maintain the rank/position list used in the Enrollment form.</p>
                </div>
                <div class="workspace-header__right">
                    <a class="btn-secondary btn-sm" style="text-decoration:none;" href="<?= e(base_url('sections/admissions/settings/roles.php')); ?>">👤 Roles &amp; Access</a>
                    <button type="button" class="btn-primary" id="btnAddRank">＋ Add Rank</button>
                </div>
            </header>

            <?php if ($flash['message']): ?>
                <div id="rankFlash" data-type="<?= $flash['type']; ?>" style="display:none;"><?= htmlspecialchars($flash['message'], ENT_QUOTES, 'UTF-8'); ?></div>
            <?php endif; ?>

            <section class="workspace-table">
                <div class="dash-panel__head"><h2>Ranks (<?= count($ranks); ?>)</h2></div>
                <div class="table-responsive">
                    <table class="inquiry-table">
                        <thead><tr><th>Rank / Position</th><th>Status</th><th>Actions</th></tr></thead>
                        <tbody>
                            <?php if (!$ranks): ?>
                                <tr><td colspan="3" style="text-align:center;color:#94A3B8;padding:28px;">No ranks yet.</td></tr>
                            <?php endif; ?>
                            <?php foreach ($ranks as $r): ?>
                                <tr>
                                    <td><strong><?= e($r['name']); ?></strong></td>
                                    <td><span class="status-badge status-<?= $r['is_active'] ? 'converted' : 'closed'; ?>"><?= $r['is_active'] ? 'Active' : 'Inactive'; ?></span></td>
                                    <td class="cert-table__actions">
                                        <button type="button" class="btn-secondary btn-sm" data-rank-edit='<?= json_encode(['id'=>(int)$r['id'],'name'=>$r['name']], JSON_HEX_APOS|JSON_HEX_QUOT); ?>'>✏️ Edit</button>
                                        <button type="button" class="btn-secondary btn-sm" data-rank-toggle='<?= json_encode(['id'=>(int)$r['id']], JSON_HEX_APOS|JSON_HEX_QUOT); ?>'><?= $r['is_active'] ? 'Deactivate' : 'Activate'; ?></button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </section>
        </main>
    </section>

    <?php include INCLUDES_PATH . '/footer.php'; ?>
    <?php include INCLUDES_PATH . '/scripts.php'; ?>

    <!-- Rank modal -->
    <div id="rankModal" class="portal-modal" style="display:none;">
        <div class="portal-modal__box">
            <div class="portal-modal__head">
                <h3 id="rankModalTitle">Add Rank</h3>
                <p>Rank / position used in the Enrollment form</p>
                <button class="portal-modal__close" id="rankClose">&times;</button>
            </div>
            <form method="post" action="<?= e(base_url('sections/admissions/settings/ranks.php')); ?>">
                <?= csrf_field(); ?>
                <input type="hidden" name="action" value="save">
                <input type="hidden" name="rank_id" id="rfId" value="0">
                <div class="portal-modal__body">
                    <div class="t-field"><label>Rank / Position *</label><input name="name" id="rfName" required placeholder="e.g. Pumpman"></div>
                </div>
                <div class="portal-modal__foot">
                    <button type="button" class="btn-secondary" id="rankCancel">Cancel</button>
                    <button type="submit" class="btn-primary">Save Rank</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        (function () {
            function showToast(msg, type) { window.usmciToast(msg, type); }
            var fl = document.getElementById("rankFlash");
            if (fl && fl.textContent.trim() !== "") showToast(fl.textContent.trim(), fl.dataset.type);

            var modal = document.getElementById("rankModal");
            function openRank(d) {
                document.getElementById("rankModalTitle").textContent = d ? "Edit Rank" : "Add Rank";
                document.getElementById("rfId").value = d ? d.id : 0;
                document.getElementById("rfName").value = d ? d.name : "";
                modal.style.display = "flex";
            }
            function closeRank() { modal.style.display = "none"; }
            document.getElementById("btnAddRank").addEventListener("click", function () { openRank(null); });
            document.querySelectorAll("[data-rank-edit]").forEach(function (b) {
                b.addEventListener("click", function () { try { openRank(JSON.parse(b.dataset.rankEdit)); } catch (e) {} });
            });
            document.getElementById("rankClose").addEventListener("click", closeRank);
            document.getElementById("rankCancel").addEventListener("click", closeRank);
            modal.addEventListener("click", function (e) { if (e.target === modal) closeRank(); });

            // Toggle (AJAX + toast + reload)
            var CSRF = <?= json_encode(csrf_token()); ?>;
            document.querySelectorAll("[data-rank-toggle]").forEach(function (b) {
                b.addEventListener("click", function () {
                    var d = JSON.parse(b.dataset.rankToggle);
                    var fd = new FormData();
                    fd.append("csrf_token", CSRF);
                    fd.append("action", "toggle");
                    fd.append("rank_id", d.id);
                    fetch(window.location.href, { method: "POST", body: fd })
                        .then(function () { window.location.reload(); })
                        .catch(function () { showToast("Could not toggle the rank.", "error"); });
                });
            });
        })();
    </script>
</body>
</html>
