<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Admissions Settings: Training Center Announcements
 * File : sections/admissions/settings/announcements.php
 * ---------------------------------------------------------
 * Maintain the "Training Center Announcements" row on the public
 * website News section — class cancellations, no-class days,
 * venue changes, holiday closures, etc. Add / edit / toggle /
 * delete; active rows (is_active = 1) show on the site.
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/config/bootstrap.php';

require_access('settings');
if ($_SERVER['REQUEST_METHOD'] === 'POST') { require_edit('settings'); }

$pdo = db();

$flash = ['type' => null, 'message' => null];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = (string) ($_POST['action'] ?? '');
    try {
        if ($action === 'save') {
            $id    = (int) ($_POST['ann_id'] ?? 0);
            $title = trim((string) ($_POST['title'] ?? ''));
            $msg   = trim((string) ($_POST['message'] ?? ''));
            $date  = trim((string) ($_POST['announcement_date'] ?? ''));
            $active = isset($_POST['is_active']) ? 1 : 0;

            if ($title === '') {
                $flash = ['type' => 'error', 'message' => 'Title is required.'];
            } else {
                if ($id > 0) {
                    $pdo->prepare("UPDATE mnt_announcement SET title = :t, message = :m, announcement_date = :d, is_active = :a, updated_at = NOW() WHERE id = :id")
                        ->execute(['t' => $title, 'm' => $msg !== '' ? $msg : null, 'd' => $date !== '' ? $date : null, 'a' => $active, 'id' => $id]);
                    audit_log('settings', 'announcement_update', $id, "Announcement '{$title}' updated");
                    $flash = ['type' => 'success', 'message' => "Announcement '{$title}' updated."];
                } else {
                    $pdo->prepare("INSERT INTO mnt_announcement (title, message, announcement_date, is_active, created_at) VALUES (:t, :m, :d, :a, NOW())")
                        ->execute(['t' => $title, 'm' => $msg !== '' ? $msg : null, 'd' => $date !== '' ? $date : null, 'a' => $active]);
                    audit_log('settings', 'announcement_create', (int) $pdo->lastInsertId(), "Announcement '{$title}' created");
                    $flash = ['type' => 'success', 'message' => "Announcement '{$title}' added — it now shows on the website News section."];
                }
            }
        } elseif ($action === 'toggle') {
            $id = (int) ($_POST['ann_id'] ?? 0);
            $st = $pdo->prepare('SELECT title, is_active FROM mnt_announcement WHERE id = :id');
            $st->execute(['id' => $id]);
            $row = $st->fetch();
            if ($row) {
                $new = (int) $row['is_active'] ? 0 : 1;
                $pdo->prepare('UPDATE mnt_announcement SET is_active = :a, updated_at = NOW() WHERE id = :id')
                    ->execute(['a' => $new, 'id' => $id]);
                audit_log('settings', 'announcement_' . ($new ? 'activate' : 'deactivate'), $id, "Announcement '{$row['title']}' " . ($new ? 'activated' : 'deactivated'));
                $flash = ['type' => 'success', 'message' => "Announcement '{$row['title']}' " . ($new ? 'shown on the website.' : 'hidden from the website.')];
            } else {
                $flash = ['type' => 'error', 'message' => 'Announcement not found.'];
            }
        } elseif ($action === 'delete') {
            $id = (int) ($_POST['ann_id'] ?? 0);
            $st = $pdo->prepare('SELECT title FROM mnt_announcement WHERE id = :id');
            $st->execute(['id' => $id]);
            $row = $st->fetch();
            if ($row) {
                $pdo->prepare('DELETE FROM mnt_announcement WHERE id = :id')->execute(['id' => $id]);
                audit_log('settings', 'announcement_delete', $id, "Announcement '{$row['title']}' deleted");
                $flash = ['type' => 'success', 'message' => "Announcement '{$row['title']}' deleted."];
            } else {
                $flash = ['type' => 'error', 'message' => 'Announcement not found.'];
            }
        }
    } catch (Throwable $e) {
        error_log('announcements.php: ' . $e->getMessage());
        $flash = ['type' => 'error', 'message' => 'Could not save the announcement.'];
    }
}

/* one announcement for the edit form */
$editing = null;
$editId  = (int) ($_GET['edit'] ?? 0);
if ($editId > 0) {
    $st = $pdo->prepare('SELECT * FROM mnt_announcement WHERE id = :id');
    $st->execute(['id' => $editId]);
    $editing = $st->fetch() ?: null;
}

$rows = $pdo->query("SELECT * FROM mnt_announcement ORDER BY is_active DESC, COALESCE(announcement_date, created_at) DESC, id DESC")->fetchAll() ?: [];

$page = [
    'title'       => 'Training Center Announcements | USMCI-TMS',
    'description' => 'Manage public website announcements',
    'bodyClass'   => 'admissions-page',
];
?>
<!DOCTYPE html>
<html lang="en">

<?php include INCLUDES_PATH . '/head.php'; ?>

<link rel="stylesheet" href="<?= e(base_url('assets/css/portal.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/workspace.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/inquiry-queue/assets/css/page.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/email-center/style.css?v=9')); ?>">

<body class="<?= e($page['bodyClass']); ?>">

    <?php include NAVBAR_PATH . '/index.php'; ?>

    <section class="portal-shell portal-shell--2col">

        <?php require ADMISSIONS_PATH . '/inquiry-queue/partials/sidebar.php'; ?>

        <main class="portal-content email-center">

            <header class="workspace-header">
                <div class="workspace-header__left">
                    <span class="section-badge">Administration</span>
                    <h1>Training Center Announcements</h1>
                    <p>Notices shown in the public website News section — class cancellations, no-class days, venue changes, holiday closures. Active announcements appear on <code>index.php#news</code>.</p>
                </div>
            </header>

            <div id="annFlash" data-type="<?= $flash['type']; ?>" style="display:none;"><?= htmlspecialchars($flash['message'] ?? '', ENT_QUOTES, 'UTF-8'); ?></div>

            <!-- add / edit form -->
            <section class="email-card email-card--wide" style="margin-top:16px;">
                <h2><?= $editing ? '✏️ Edit Announcement' : '＋ Add Announcement'; ?></h2>
                <form method="post" action="<?= e(base_url('sections/admissions/settings/announcements.php')); ?>" class="cert-form" style="margin-top:12px;">
                    <?= csrf_field(); ?>
                    <input type="hidden" name="action" value="save">
                    <input type="hidden" name="ann_id" value="<?= (int) ($editing['id'] ?? 0); ?>">

                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;">
                        <div class="t-field">
                            <label>Title <span class="required">*</span></label>
                            <input name="title" value="<?= e($editing['title'] ?? ''); ?>" required placeholder="e.g. Class Suspension — Friday Afternoon Batch" style="width:100%;height:40px;padding:0 12px;border:1px solid #CBD5E1;border-radius:8px;font-family:inherit;">
                        </div>
                        <div class="t-field">
                            <label>Date (shown on the site)</label>
                            <input type="date" name="announcement_date" value="<?= e($editing['announcement_date'] ?? ''); ?>" style="width:100%;height:40px;padding:0 12px;border:1px solid #CBD5E1;border-radius:8px;font-family:inherit;">
                        </div>
                    </div>

                    <div class="t-field t-field--full" style="margin-top:14px;">
                        <label>Message</label>
                        <textarea name="message" rows="4" placeholder="What trainees/visitors need to know…" style="width:100%;padding:10px 12px;border:1px solid #CBD5E1;border-radius:8px;font-family:inherit;"><?= e($editing['message'] ?? ''); ?></textarea>
                    </div>

                    <div style="margin-top:12px;display:flex;align-items:center;gap:8px;">
                        <input type="checkbox" name="is_active" id="is_active" value="1" <?= (!isset($editing) || (int) $editing['is_active'] === 1) ? 'checked' : ''; ?>>
                        <label for="is_active" style="font-size:.85rem;font-weight:600;">Active — shown on the website</label>
                    </div>

                    <div style="margin-top:16px;display:flex;gap:10px;">
                        <button type="submit" class="btn-primary" style="height:42px;padding:0 22px;border-radius:10px;font-weight:700;background:#0D8A72;color:#fff;border:none;cursor:pointer;">💾 <?= $editing ? 'Save Changes' : 'Add Announcement'; ?></button>
                        <?php if ($editing): ?>
                            <a class="btn-secondary btn-sm" style="text-decoration:none;display:inline-flex;align-items:center;padding:0 16px;border-radius:10px;" href="<?= e(base_url('sections/admissions/settings/announcements.php')); ?>">← Cancel</a>
                        <?php endif; ?>
                        <a class="btn-secondary btn-sm" style="text-decoration:none;display:inline-flex;align-items:center;padding:0 16px;border-radius:10px;margin-left:auto;" href="<?= e(base_url('index.php#news')); ?>" target="_blank">👁 Preview on Website</a>
                    </div>
                </form>
            </section>

            <!-- list -->
            <section class="email-card email-card--wide" style="margin-top:16px;">
                <h2>📢 Existing Announcements (<?= count($rows); ?>)</h2>
                <?php if (!$rows): ?>
                    <p class="email-card__hint" style="margin-top:10px;">No announcements yet — add one above.</p>
                <?php else: ?>
                    <table class="portal-table" style="width:100%;border-collapse:collapse;margin-top:12px;">
                        <thead>
                            <tr style="text-align:left;color:#64748B;font-size:.75rem;text-transform:uppercase;letter-spacing:.05em;border-bottom:2px solid #E2E8F0;">
                                <th style="padding:10px 8px;">Title</th>
                                <th style="padding:10px 8px;">Date</th>
                                <th style="padding:10px 8px;">Status</th>
                                <th style="padding:10px 8px;text-align:right;">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($rows as $r): ?>
                                <tr style="border-bottom:1px solid #F1F5F9;vertical-align:top;">
                                    <td style="padding:10px 8px;">
                                        <strong style="font-size:.9rem;"><?= e($r['title']); ?></strong>
                                        <?php if (trim((string) $r['message']) !== ''): ?>
                                            <p style="margin:3px 0 0;font-size:.78rem;color:#64748B;max-width:520px;"><?= e(mb_strimwidth((string) $r['message'], 0, 110, '…')); ?></p>
                                        <?php endif; ?>
                                    </td>
                                    <td style="padding:10px 8px;font-size:.85rem;white-space:nowrap;"><?= $r['announcement_date'] ? e(date('M d, Y', strtotime((string) $r['announcement_date']))) : '—'; ?></td>
                                    <td style="padding:10px 8px;">
                                        <span style="display:inline-block;padding:3px 10px;border-radius:999px;font-size:.72rem;font-weight:700;<?= (int) $r['is_active'] ? 'background:#D1FAE5;color:#065F46;' : 'background:#F1F5F9;color:#64748B;'; ?>">
                                            <?= (int) $r['is_active'] ? '● Visible' : '○ Hidden'; ?>
                                        </span>
                                    </td>
                                    <td style="padding:10px 8px;text-align:right;white-space:nowrap;">
                                        <form method="post" action="<?= e(base_url('sections/admissions/settings/announcements.php')); ?>" style="display:inline;">
                                            <?= csrf_field(); ?>
                                            <input type="hidden" name="action" value="toggle">
                                            <input type="hidden" name="ann_id" value="<?= (int) $r['id']; ?>">
                                            <button type="submit" class="btn-secondary btn-sm" style="padding:5px 12px;border-radius:8px;border:1px solid #CBD5E1;background:#fff;cursor:pointer;font-size:.75rem;font-weight:700;"><?= (int) $r['is_active'] ? 'Hide' : 'Show'; ?></button>
                                        </form>
                                        <a class="btn-secondary btn-sm" style="padding:5px 12px;border-radius:8px;border:1px solid #CBD5E1;background:#fff;text-decoration:none;font-size:.75rem;font-weight:700;display:inline-flex;" href="<?= e(base_url('sections/admissions/settings/announcements.php?edit=' . (int) $r['id'])); ?>">Edit</a>
                                        <form method="post" action="<?= e(base_url('sections/admissions/settings/announcements.php')); ?>" style="display:inline;" onsubmit="return confirm('Delete this announcement?');">
                                            <?= csrf_field(); ?>
                                            <input type="hidden" name="action" value="delete">
                                            <input type="hidden" name="ann_id" value="<?= (int) $r['id']; ?>">
                                            <button type="submit" class="btn-secondary btn-sm" style="padding:5px 12px;border-radius:8px;border:1px solid #FECACA;background:#FEF2F2;color:#991B1B;cursor:pointer;font-size:.75rem;font-weight:700;">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </section>

        </main>
    </section>

    <?php include INCLUDES_PATH . '/footer.php'; ?>
    <?php include INCLUDES_PATH . '/scripts.php'; ?>

    <script>
        (function () {
            function showToast(msg, type) { window.usmciToast(msg, type); }
            var fl = document.getElementById("annFlash");
            if (fl && fl.textContent.trim() !== "") showToast(fl.textContent.trim(), fl.dataset.type);
        })();
    </script>

</body>
</html>
