<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Admissions Settings: Affiliated Companies
 * File : sections/admissions/settings/affiliates.php
 * ---------------------------------------------------------
 * Maintain the "Our Affiliations & Partners" row on the public
 * website Contact section. Each affiliate shows its LOGO + NAME
 * on the site (the website link is NOT displayed — the whole card
 * is clickable and opens the partner site in a new tab).
 * Add / edit / upload logo / show-hide / delete / reorder.
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/config/bootstrap.php';

require_access('settings');
if ($_SERVER['REQUEST_METHOD'] === 'POST') { require_edit('settings'); }

$pdo = db();

$flash = ['type' => null, 'message' => null];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = (string) ($_POST['action'] ?? '');
    try {
        if ($action === 'save') {
            $id     = (int) ($_POST['aff_id'] ?? 0);
            $name   = trim((string) ($_POST['name'] ?? ''));
            $url    = trim((string) ($_POST['website_url'] ?? ''));
            $sort   = (int) ($_POST['sort_order'] ?? 0);
            $active = isset($_POST['is_active']) ? 1 : 0;
            $type   = in_array(($_POST['type'] ?? ''), ['affiliation', 'partner'], true) ? $_POST['type'] : 'affiliation';
            $removeLogo = isset($_POST['remove_logo']) ? 1 : 0;

            if ($name === '') {
                $flash = ['type' => 'error', 'message' => 'Company name is required.'];
            } else {
                /* ---- optional logo upload ---- */
                $logoPath = null;
                if (!empty($_FILES['logo']) && $_FILES['logo']['error'] === UPLOAD_ERR_OK) {
                    $f = $_FILES['logo'];
                    $ext = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
                    if (!in_array($ext, ['jpg', 'jpeg', 'png', 'webp', 'svg'], true) || $f['size'] > 4 * 1024 * 1024) {
                        $flash = ['type' => 'error', 'message' => 'Logo must be JPG/PNG/WebP/SVG under 4 MB.'];
                        goto affiliate_skip;
                    }
                    $dir = BASE_PATH . '/uploads/affiliates';
                    if (!is_dir($dir)) { @mkdir($dir, 0775, true); }
                    $pname = 'aff_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
                    if (move_uploaded_file($f['tmp_name'], $dir . '/' . $pname)) {
                        $logoPath = 'uploads/affiliates/' . $pname;
                    }
                }

                if ($id > 0) {
                    /* keep existing logo unless replaced or removed */
                    if (!$logoPath && !$removeLogo) {
                        $cur = $pdo->prepare('SELECT logo_path FROM mnt_affiliate WHERE id = :id');
                        $cur->execute(['id' => $id]);
                        $logoPath = $cur->fetchColumn() ?: null;
                    }
                    if ($removeLogo) { $logoPath = null; }
                    $pdo->prepare('UPDATE mnt_affiliate SET name = :n, logo_path = :l, website_url = :u, type = :t, is_active = :a, sort_order = :s, updated_at = NOW() WHERE id = :id')
                        ->execute(['n' => $name, 'l' => $logoPath, 'u' => $url !== '' ? $url : null, 't' => $type, 'a' => $active, 's' => $sort, 'id' => $id]);
                    audit_log('settings', 'affiliate_update', $id, "Affiliate '{$name}' updated");
                    $flash = ['type' => 'success', 'message' => "Affiliate '{$name}' updated."];
                } else {
                    $pdo->prepare('INSERT INTO mnt_affiliate (name, logo_path, website_url, type, is_active, sort_order, created_at) VALUES (:n, :l, :u, :t, :a, :s, NOW())')
                        ->execute(['n' => $name, 'l' => $logoPath, 'u' => $url !== '' ? $url : null, 't' => $type, 'a' => $active, 's' => $sort]);
                    audit_log('settings', 'affiliate_create', (int) $pdo->lastInsertId(), "Affiliate '{$name}' created");
                    $flash = ['type' => 'success', 'message' => "Affiliate '{$name}' added — it now shows on the website Contact section."];
                }
            }
        } elseif ($action === 'toggle') {
            $id = (int) ($_POST['aff_id'] ?? 0);
            $st = $pdo->prepare('SELECT name, is_active FROM mnt_affiliate WHERE id = :id');
            $st->execute(['id' => $id]);
            $row = $st->fetch();
            if ($row) {
                $new = (int) $row['is_active'] ? 0 : 1;
                $pdo->prepare('UPDATE mnt_affiliate SET is_active = :a, updated_at = NOW() WHERE id = :id')
                    ->execute(['a' => $new, 'id' => $id]);
                audit_log('settings', 'affiliate_' . ($new ? 'activate' : 'deactivate'), $id, "Affiliate '{$row['name']}' " . ($new ? 'activated' : 'deactivated'));
                $flash = ['type' => 'success', 'message' => "Affiliate '{$row['name']}' " . ($new ? 'shown on the website.' : 'hidden from the website.')];
            } else {
                $flash = ['type' => 'error', 'message' => 'Affiliate not found.'];
            }
        } elseif ($action === 'delete') {
            $id = (int) ($_POST['aff_id'] ?? 0);
            $st = $pdo->prepare('SELECT name FROM mnt_affiliate WHERE id = :id');
            $st->execute(['id' => $id]);
            $row = $st->fetch();
            if ($row) {
                $pdo->prepare('DELETE FROM mnt_affiliate WHERE id = :id')->execute(['id' => $id]);
                audit_log('settings', 'affiliate_delete', $id, "Affiliate '{$row['name']}' deleted");
                $flash = ['type' => 'success', 'message' => "Affiliate '{$row['name']}' deleted."];
            } else {
                $flash = ['type' => 'error', 'message' => 'Affiliate not found.'];
            }
        }
    } catch (Throwable $e) {
        error_log('affiliates.php: ' . $e->getMessage());
        $flash = ['type' => 'error', 'message' => 'Could not save the affiliate.'];
    }
    affiliate_skip:
}

/* one affiliate for the edit form */
$editing = null;
$editId  = (int) ($_GET['edit'] ?? 0);
if ($editId > 0) {
    $st = $pdo->prepare('SELECT * FROM mnt_affiliate WHERE id = :id');
    $st->execute(['id' => $editId]);
    $editing = $st->fetch() ?: null;
}

$rows = $pdo->query("SELECT * FROM mnt_affiliate ORDER BY is_active DESC, type, sort_order, name")->fetchAll() ?: [];

$page = [
    'title'       => 'Affiliated Companies | USMCI-TMS',
    'description' => 'Manage website affiliated companies',
    'bodyClass'   => 'admissions-page',
];
?>
<!DOCTYPE html>
<html lang="en">

<?php include INCLUDES_PATH . '/head.php'; ?>

<link rel="stylesheet" href="<?= e(base_url('assets/css/portal.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/workspace.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/inquiry-queue/assets/css/page.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/email-center/style.css?v=9')); ?>">

<body class="<?= e($page['bodyClass']); ?>">

    <?php include NAVBAR_PATH . '/index.php'; ?>

    <section class="portal-shell portal-shell--2col">

        <?php require ADMISSIONS_PATH . '/inquiry-queue/partials/sidebar.php'; ?>

        <main class="portal-content email-center">

            <header class="workspace-header">
                <div class="workspace-header__left">
                    <span class="section-badge">Administration</span>
                    <h1>Affiliated Companies</h1>
                    <p>Partners shown in the public website Contact section. On the site each card shows the LOGO + NAME (the link is hidden) — the whole card is clickable and opens the partner site in a new tab.</p>
                </div>
            </header>

            <div id="affFlash" data-type="<?= $flash['type']; ?>" style="display:none;"><?= htmlspecialchars($flash['message'] ?? '', ENT_QUOTES, 'UTF-8'); ?></div>

            <!-- add / edit form -->
            <section class="email-card email-card--wide" style="margin-top:16px;">
                <h2><?= $editing ? '✏️ Edit Affiliate' : '＋ Add Affiliate'; ?></h2>
                <form method="post" action="<?= e(base_url('sections/admissions/settings/affiliates.php')); ?>" class="cert-form" enctype="multipart/form-data" style="margin-top:12px;">
                    <?= csrf_field(); ?>
                    <input type="hidden" name="action" value="save">
                    <input type="hidden" name="aff_id" value="<?= (int) ($editing['id'] ?? 0); ?>">

                    <div style="display:grid;grid-template-columns:1fr 1fr 120px 90px;gap:14px;">
                        <div class="t-field">
                            <label>Company Name <span class="required">*</span></label>
                            <input name="name" value="<?= e($editing['name'] ?? ''); ?>" required placeholder="e.g. MARINA" style="width:100%;height:40px;padding:0 12px;border:1px solid #CBD5E1;border-radius:8px;font-family:inherit;">
                        </div>
                        <div class="t-field">
                            <label>Website Link (hidden on the site — click redirects here)</label>
                            <input name="website_url" value="<?= e($editing['website_url'] ?? ''); ?>" placeholder="https://…" style="width:100%;height:40px;padding:0 12px;border:1px solid #CBD5E1;border-radius:8px;font-family:inherit;">
                        </div>
                        <div class="t-field">
                            <label>Type</label>
                            <select name="type" style="width:100%;height:40px;padding:0 10px;border:1px solid #CBD5E1;border-radius:8px;font-family:inherit;background:#fff;">
                                <option value="affiliation" <?= (($editing['type'] ?? 'affiliation') === 'affiliation') ? 'selected' : ''; ?>>🏛 Affiliation</option>
                                <option value="partner" <?= (($editing['type'] ?? '') === 'partner') ? 'selected' : ''; ?>>🤝 Partner</option>
                            </select>
                        </div>
                        <div class="t-field">
                            <label>Sort</label>
                            <input type="number" name="sort_order" value="<?= (int) ($editing['sort_order'] ?? 0); ?>" min="0" style="width:100%;height:40px;padding:0 12px;border:1px solid #CBD5E1;border-radius:8px;font-family:inherit;">
                        </div>
                    </div>

                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-top:14px;">
                        <div class="t-field">
                            <label>Logo (JPG/PNG/WebP/SVG, max 4 MB)</label>
                            <input type="file" name="logo" accept=".jpg,.jpeg,.png,.webp,.svg" style="width:100%;padding:8px;border:1px solid #CBD5E1;border-radius:8px;background:#fff;font-family:inherit;">
                            <?php if (!empty($editing['logo_path'])): ?>
                                <div style="margin-top:8px;display:flex;align-items:center;gap:10px;">
                                    <img src="<?= e(base_url($editing['logo_path'])); ?>" alt="logo" style="width:44px;height:44px;object-fit:contain;border:1px solid #E2E8F0;border-radius:8px;background:#F8FAFC;">
                                    <label style="font-size:.78rem;display:flex;align-items:center;gap:5px;"><input type="checkbox" name="remove_logo" value="1"> Remove current logo</label>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="t-field" style="display:flex;align-items:flex-end;">
                            <label style="display:flex;align-items:center;gap:8px;font-size:.85rem;font-weight:600;">
                                <input type="checkbox" name="is_active" id="is_active" value="1" <?= (!isset($editing) || (int) $editing['is_active'] === 1) ? 'checked' : ''; ?>>
                                Active — shown on the website
                            </label>
                        </div>
                    </div>

                    <div style="margin-top:16px;display:flex;gap:10px;">
                        <button type="submit" class="btn-primary" style="height:42px;padding:0 22px;border-radius:10px;font-weight:700;background:#0D8A72;color:#fff;border:none;cursor:pointer;">💾 <?= $editing ? 'Save Changes' : 'Add Affiliate'; ?></button>
                        <?php if ($editing): ?>
                            <a class="btn-secondary btn-sm" style="text-decoration:none;display:inline-flex;align-items:center;padding:0 16px;border-radius:10px;" href="<?= e(base_url('sections/admissions/settings/affiliates.php')); ?>">← Cancel</a>
                        <?php endif; ?>
                        <a class="btn-secondary btn-sm" style="text-decoration:none;display:inline-flex;align-items:center;padding:0 16px;border-radius:10px;margin-left:auto;" href="<?= e(base_url('index.php#contact')); ?>" target="_blank">👁 Preview on Website</a>
                    </div>
                </form>
            </section>

            <!-- list -->
            <section class="email-card email-card--wide" style="margin-top:16px;">
                <h2>🤝 Existing Affiliates (<?= count($rows); ?>)</h2>
                <?php if (!$rows): ?>
                    <p class="email-card__hint" style="margin-top:10px;">No affiliates yet — add one above.</p>
                <?php else: ?>
                    <table class="portal-table" style="width:100%;border-collapse:collapse;margin-top:12px;">
                        <thead>
                            <tr style="text-align:left;color:#64748B;font-size:.75rem;text-transform:uppercase;letter-spacing:.05em;border-bottom:2px solid #E2E8F0;">
                                <th style="padding:10px 8px;">Logo</th>
                                <th style="padding:10px 8px;">Name</th>
                                <th style="padding:10px 8px;">Link (hidden on site)</th>
                                <th style="padding:10px 8px;">Type</th>
                                <th style="padding:10px 8px;">Sort</th>
                                <th style="padding:10px 8px;">Status</th>
                                <th style="padding:10px 8px;text-align:right;">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($rows as $r): ?>
                                <tr style="border-bottom:1px solid #F1F5F9;vertical-align:middle;">
                                    <td style="padding:8px;">
                                        <?php if (!empty($r['logo_path'])): ?>
                                            <img src="<?= e(base_url($r['logo_path'])); ?>" alt="logo" style="width:40px;height:40px;object-fit:contain;border:1px solid #E2E8F0;border-radius:8px;background:#F8FAFC;">
                                        <?php else: ?>
                                            <span style="display:inline-flex;width:40px;height:40px;border-radius:50%;background:#0B3C5D;color:#F4B400;font-weight:800;align-items:center;justify-content:center;font-size:.8rem;"><?= e(mb_strimwidth((string) $r['name'], 0, 2, '')); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td style="padding:8px;font-weight:700;font-size:.88rem;"><?= e($r['name']); ?></td>
                                    <td style="padding:8px;font-size:.78rem;color:#64748B;max-width:220px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"><?= e($r['website_url'] ?? '—'); ?></td>
                                    <td style="padding:8px;">
                                        <span style="display:inline-block;padding:3px 10px;border-radius:999px;font-size:.72rem;font-weight:700;<?= (($r['type'] ?? 'affiliation') === 'partner') ? 'background:#E0F2FE;color:#075985;' : 'background:#FEF3C7;color:#92400E;'; ?>">
                                            <?= (($r['type'] ?? 'affiliation') === 'partner') ? '🤝 Partner' : '🏛 Affiliation'; ?>
                                        </span>
                                    </td>
                                    <td style="padding:8px;font-size:.85rem;"><?= (int) $r['sort_order']; ?></td>
                                    <td style="padding:8px;">
                                        <span style="display:inline-block;padding:3px 10px;border-radius:999px;font-size:.72rem;font-weight:700;<?= (int) $r['is_active'] ? 'background:#D1FAE5;color:#065F46;' : 'background:#F1F5F9;color:#64748B;'; ?>">
                                            <?= (int) $r['is_active'] ? '● Visible' : '○ Hidden'; ?>
                                        </span>
                                    </td>
                                    <td style="padding:8px;text-align:right;white-space:nowrap;">
                                        <form method="post" action="<?= e(base_url('sections/admissions/settings/affiliates.php')); ?>" style="display:inline;">
                                            <?= csrf_field(); ?>
                                            <input type="hidden" name="action" value="toggle">
                                            <input type="hidden" name="aff_id" value="<?= (int) $r['id']; ?>">
                                            <button type="submit" class="btn-secondary btn-sm" style="padding:5px 12px;border-radius:8px;border:1px solid #CBD5E1;background:#fff;cursor:pointer;font-size:.75rem;font-weight:700;"><?= (int) $r['is_active'] ? 'Hide' : 'Show'; ?></button>
                                        </form>
                                        <a class="btn-secondary btn-sm" style="padding:5px 12px;border-radius:8px;border:1px solid #CBD5E1;background:#fff;text-decoration:none;font-size:.75rem;font-weight:700;display:inline-flex;" href="<?= e(base_url('sections/admissions/settings/affiliates.php?edit=' . (int) $r['id'])); ?>">Edit</a>
                                        <form method="post" action="<?= e(base_url('sections/admissions/settings/affiliates.php')); ?>" style="display:inline;" onsubmit="return confirm('Delete this affiliate?');">
                                            <?= csrf_field(); ?>
                                            <input type="hidden" name="action" value="delete">
                                            <input type="hidden" name="aff_id" value="<?= (int) $r['id']; ?>">
                                            <button type="submit" class="btn-secondary btn-sm" style="padding:5px 12px;border-radius:8px;border:1px solid #FECACA;background:#FEF2F2;color:#991B1B;cursor:pointer;font-size:.75rem;font-weight:700;">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </section>

        </main>
    </section>

    <?php include INCLUDES_PATH . '/footer.php'; ?>
    <?php include INCLUDES_PATH . '/scripts.php'; ?>

    <script>
        (function () {
            function showToast(msg, type) { window.usmciToast(msg, type); }
            var fl = document.getElementById("affFlash");
            if (fl && fl.textContent.trim() !== "") showToast(fl.textContent.trim(), fl.dataset.type);
        })();
    </script>

</body>
</html>
