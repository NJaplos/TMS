<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Module      : Admissions
 * Page        : Admissions Settings
 * File        : index.php
 * Version     : 1.0
 *
 * Description :
 * Central settings hub for the admissions operation.
 * Currently hosts:
 *   - Email Center (SMTP + queue) — moved here from its own nav item
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/config/bootstrap.php';

/* Staff only */
require_access('settings');
if ($_SERVER['REQUEST_METHOD'] === 'POST') { require_edit('settings'); }

$user = current_user();

$page = [
    'title'       => 'Admissions Settings | USMCI-TMS',
    'description' => 'Admissions Settings',
    'bodyClass'   => 'admissions-page',
];
?>
<!DOCTYPE html>
<html lang="en">

<?php include INCLUDES_PATH . '/head.php'; ?>

<link rel="stylesheet" href="<?= e(base_url('assets/css/portal.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/workspace.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/inquiry-queue/assets/css/page.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/email-center/style.css?v=9')); ?>">

<body class="<?= e($page['bodyClass']); ?>">

    <?php include NAVBAR_PATH . '/index.php'; ?>

    <section class="portal-shell portal-shell--2col">

        <?php require ADMISSIONS_PATH . '/inquiry-queue/partials/sidebar.php'; ?>

        <main class="portal-content email-center">

            <header class="workspace-header">
                <div class="workspace-header__left">
                    <span class="section-badge">Administration</span>
                    <h1>Admissions Settings</h1>
                    <p>Manage email delivery and other admissions system settings.</p>
                </div>
            </header>

            <!-- ================= EMAIL SETTINGS CARD ================= -->
            <section class="email-card email-card--wide">
                <h2>📧 Email Delivery (SMTP)</h2>
                <p class="email-card__hint">
                    The Email Center lives here now. Test with Mailtrap or a Gmail App Password;
                    switch to the company SMTP before going live — all saved in the database.
                </p>
                <div style="margin: 12px 0;">
                    <a class="btn-primary" style="text-decoration:none;display:inline-flex;align-items:center;height:40px;padding:0 18px;border-radius:10px;font-weight:700;font-size:.88rem;"
                       href="<?= e(base_url('sections/admissions/email-center/index.php')); ?>">
                        Open Email Center →
                    </a>
                </div>
                <p class="email-card__hint" style="margin-top:8px;">
                    Manage SMTP host/port, from-address, admin notification email, test delivery,
                    and the outgoing email queue.
                </p>
            </section>

            <!-- ================= MORE SETTINGS ================= -->
            <section class="email-card email-card--wide">
                <h2>⚙️ System Settings</h2>
                <p class="email-card__hint">Course catalog, enrollment parameters, and system preferences.</p>
                <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:12px;">
                    <a class="btn-primary" style="text-decoration:none;display:inline-flex;align-items:center;height:40px;padding:0 18px;border-radius:10px;font-weight:700;font-size:.88rem;"
                       href="<?= e(base_url('sections/admissions/settings/ranks.php')); ?>">
                        🎖️ Rank / Position
                    </a>
                    <a class="btn-primary" style="text-decoration:none;display:inline-flex;align-items:center;height:40px;padding:0 18px;border-radius:10px;font-weight:700;font-size:.88rem;"
                       href="<?= e(base_url('sections/admissions/settings/roles.php')); ?>">
                        👤 Roles &amp; Access
                    </a>
                    <a class="btn-primary" style="text-decoration:none;display:inline-flex;align-items:center;height:40px;padding:0 18px;border-radius:10px;font-weight:700;font-size:.88rem;background:#0D8A72;"
                       href="<?= e(base_url('sections/admissions/settings/process-rules.php')); ?>">
                        ⚖️ Process Rules
                    </a>
                    <a class="btn-primary" style="text-decoration:none;display:inline-flex;align-items:center;height:40px;padding:0 18px;border-radius:10px;font-weight:700;font-size:.88rem;"
                       href="<?= e(base_url('sections/admissions/settings/requirements.php')); ?>">
                        📄 Requirements Matrix
                    </a>
                    <a class="btn-primary" style="text-decoration:none;display:inline-flex;align-items:center;height:40px;padding:0 18px;border-radius:10px;font-weight:700;font-size:.88rem;"
                       href="<?= e(base_url('sections/admissions/settings/report-settings.php')); ?>">
                        🏛️ Report Letterhead
                    </a>
                    <a class="btn-primary" style="text-decoration:none;display:inline-flex;align-items:center;height:40px;padding:0 18px;border-radius:10px;font-weight:700;font-size:.88rem;background:#0B3C5D;color:#F4B400;"
                       href="<?= e(base_url('sections/admissions/settings/website-content.php')); ?>">
                        🌐 Website Content
                    </a>
                    <a class="btn-primary" style="text-decoration:none;display:inline-flex;align-items:center;height:40px;padding:0 18px;border-radius:10px;font-weight:700;font-size:.88rem;"
                       href="<?= e(base_url('sections/admissions/settings/course-categories.php')); ?>">
                        🗂 Course Categories
                    </a>
                    <a class="btn-primary" style="text-decoration:none;display:inline-flex;align-items:center;height:40px;padding:0 18px;border-radius:10px;font-weight:700;font-size:.88rem;background:#B45309;"
                       href="<?= e(base_url('sections/admissions/settings/announcements.php')); ?>">
                        📢 Training Center Announcements
                    </a>
                    <a class="btn-primary" style="text-decoration:none;display:inline-flex;align-items:center;height:40px;padding:0 18px;border-radius:10px;font-weight:700;font-size:.88rem;background:#0D8A72;"
                       href="<?= e(base_url('sections/admissions/settings/affiliates.php')); ?>">
                        🤝 Affiliated Companies
                    </a>
                    <a class="btn-primary" style="text-decoration:none;display:inline-flex;align-items:center;height:40px;padding:0 18px;border-radius:10px;font-weight:700;font-size:.88rem;background:#0B3C5D;color:#F4B400;"
                       href="<?= e(base_url('sections/admissions/settings/contact-info.php')); ?>">
                        📇 Contact Info Cards
                    </a>
                </div>
            </section>

        </main>
    </section>

    <?php include INCLUDES_PATH . '/footer.php'; ?>
    <?php include INCLUDES_PATH . '/scripts.php'; ?>

</body>
</html>
