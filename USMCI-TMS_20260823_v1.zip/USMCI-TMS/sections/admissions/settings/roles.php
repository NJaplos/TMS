<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Admissions Settings: Roles & Access
 * File : sections/admissions/settings/roles.php
 * ---------------------------------------------------------
 * RBAC maintenance:
 *   - Add / edit / delete roles (name, code, description)
 *   - Active / inactive toggle
 *   - Per-role ACCESS: checkbox per sidebar button (page_key)
 *     stored in role_permission. ADMIN always has full access.
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/config/bootstrap.php';

require_access('settings');
if ($_SERVER['REQUEST_METHOD'] === 'POST') { require_edit('settings'); }

$pdo = db();
$flash = ['type' => null, 'message' => null];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = $_POST['action'] ?? '';
    try {
        if ($action === 'save') {
            $id   = (int) ($_POST['role_id'] ?? 0);
            $name = trim((string) ($_POST['name'] ?? ''));
            $code = strtoupper(trim((string) ($_POST['code'] ?? '')));
            $desc = trim((string) ($_POST['description'] ?? ''));
            if ($name === '' || $code === '') {
                $flash = ['type' => 'error', 'message' => 'Role name and code are required.'];
            } elseif (!preg_match('/^[A-Z_]{2,30}$/', $code)) {
                $flash = ['type' => 'error', 'message' => 'Code must be uppercase letters/underscore (2–30 chars).'];
            } elseif ($id > 0) {
                $pdo->prepare('UPDATE sys_role SET name = :n, code = :c, description = :d, updated_at = NOW() WHERE id = :id')
                    ->execute(['n' => $name, 'c' => $code, 'd' => $desc !== '' ? $desc : null, 'id' => $id]);
                audit_log('settings', 'role_update', $id, "Role '{$name}' ({$code}) updated");
                $flash = ['type' => 'success', 'message' => "Role '{$name}' updated."];
            } else {
                $pdo->prepare('INSERT INTO sys_role (code, name, description, is_active) VALUES (:c, :n, :d, 1)')
                    ->execute(['c' => $code, 'n' => $name, 'd' => $desc !== '' ? $desc : null]);
                audit_log('settings', 'role_create', (int) $pdo->lastInsertId(), "Role '{$name}' ({$code}) created");
                $flash = ['type' => 'success', 'message' => "Role '{$name}' added."];
            }
        } elseif ($action === 'toggle') {
            $id = (int) ($_POST['role_id'] ?? 0);
            if ($id === 1) { $flash = ['type' => 'error', 'message' => 'Cannot deactivate the Administrator role.']; }
            else {
                $stmt = $pdo->prepare('SELECT is_active FROM sys_role WHERE id = :id');
                $stmt->execute(['id' => $id]);
                $cur = (int) $stmt->fetchColumn();
                $pdo->prepare('UPDATE sys_role SET is_active = :a, updated_at = NOW() WHERE id = :id')
                    ->execute(['a' => $cur ? 0 : 1, 'id' => $id]);
                audit_log('settings', 'role_toggle', $id, 'Role ' . ($cur ? 'deactivated' : 'activated'));
                $flash = ['type' => 'success', 'message' => 'Role ' . ($cur ? 'deactivated.' : 'activated.')];
            }
        } elseif ($action === 'delete') {
            $id = (int) ($_POST['role_id'] ?? 0);
            if ($id === 1) { $flash = ['type' => 'error', 'message' => 'Cannot delete the Administrator role.']; }
            elseif ($id === (int) (current_user()['role_id'] ?? 0)) { $flash = ['type' => 'error', 'message' => 'Cannot delete your own role.']; }
            else {
                $users = (int) $pdo->prepare('SELECT COUNT(*) FROM sys_user WHERE role_id = :id')->execute(['id' => $id]) ? 0 : 0;
                $stmt = $pdo->prepare('SELECT COUNT(*) FROM sys_user WHERE role_id = :id');
                $stmt->execute(['id' => $id]);
                $users = (int) $stmt->fetchColumn();
                if ($users > 0) {
                    $flash = ['type' => 'error', 'message' => "Cannot delete — {$users} staff account(s) use this role. Reassign them first."];
                } else {
                    $pdo->prepare('DELETE FROM role_permission WHERE role_id = :id')->execute(['id' => $id]);
                    $pdo->prepare('DELETE FROM sys_role WHERE id = :id')->execute(['id' => $id]);
                    audit_log('settings', 'role_delete', $id, 'Role deleted');
                    $flash = ['type' => 'success', 'message' => 'Role deleted.'];
                }
            }
        } elseif ($action === 'save_access') {
            $roleId = (int) ($_POST['role_id'] ?? 0);
            if ($roleId) {
                $pdo->prepare('DELETE FROM role_permission WHERE role_id = :id')->execute(['id' => $roleId]);
                $levels = (array) ($_POST['perm_level'] ?? []);   // page_key => 'none'|'view'|'full'
                $ins = $pdo->prepare('INSERT INTO role_permission (role_id, page_key, can_view, can_edit) VALUES (:rid, :k, :v, :e)');
                $count = 0;
                foreach ($levels as $k => $lvl) {
                    if (!is_string($k) || !array_key_exists($k, rbac_pages())) { continue; }
                    if ($lvl === 'view')      { $v = 1; $e = 0; }
                    elseif ($lvl === 'full')  { $v = 1; $e = 1; }
                    else                      { continue; }   // none → no row
                    $ins->execute(['rid' => $roleId, 'k' => $k, 'v' => $v, 'e' => $e]);
                    $count++;
                }
                audit_log('settings', 'role_access', $roleId, 'Role access updated (' . $count . ' pages)');
                $flash = ['type' => 'success', 'message' => 'Role access updated.'];
            }
        }
    } catch (Throwable $e) {
        error_log('roles.php: ' . $e->getMessage());
        $flash = ['type' => 'error', 'message' => strpos($e->getMessage(), 'Duplicate') !== false ? 'That role code already exists.' : 'Could not save the role.'];
    }
}

$roles = $pdo->query('SELECT r.*, (SELECT COUNT(*) FROM sys_user u WHERE u.role_id = r.id) AS user_count FROM sys_role r ORDER BY r.id')->fetchAll() ?: [];
$pages = rbac_pages();

/* current permissions per role */
$permMap = [];
foreach ($roles as $r) {
    $stmt = $pdo->prepare('SELECT page_key, can_view, can_edit FROM role_permission WHERE role_id = :id');
    $stmt->execute(['id' => (int) $r['id']]);
    $permMap[(int) $r['id']] = $stmt->fetchAll();
}

$page = ['title' => 'Roles & Access | USMCI-TMS', 'description' => 'Role Maintenance', 'bodyClass' => 'admissions-page'];
?>
<!DOCTYPE html>
<html lang="en">
<?php include INCLUDES_PATH . '/head.php'; ?>
<link rel="stylesheet" href="<?= e(base_url('assets/css/portal.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/workspace.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/inquiry-queue/assets/css/page.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/admin/dashboard.css?v=' . ASSET_VERSION)); ?>">
<body class="<?= e($page['bodyClass']); ?>">
    <?php include NAVBAR_PATH . '/index.php'; ?>
    <section class="portal-shell portal-shell--2col">
        <?php require ADMISSIONS_PATH . '/inquiry-queue/partials/sidebar.php'; ?>
        <main class="portal-content">
            <header class="workspace-header">
                <div class="workspace-header__left">
                    <span class="section-badge">Settings</span>
                    <h1>Roles &amp; Access</h1>
                    <p>Add/edit/delete roles and control which sidebar buttons each role can see.</p>
                </div>
                <div class="workspace-header__right">
                    <a class="btn-secondary btn-sm" style="text-decoration:none;" href="<?= e(base_url('sections/admissions/settings/ranks.php')); ?>">🎖️ Ranks</a>
                    <button type="button" class="btn-primary" id="btnAddRole">＋ Add Role</button>
                </div>
            </header>

            <?php if ($flash['message']): ?>
                <div id="roleFlash" data-type="<?= $flash['type']; ?>" style="display:none;"><?= htmlspecialchars($flash['message'], ENT_QUOTES, 'UTF-8'); ?></div>
            <?php endif; ?>

            <?php foreach ($roles as $r): $rid = (int) $r['id']; ?>
                <section class="workspace-table" style="margin-bottom:20px;">
                    <div class="dash-panel__head">
                        <h2>
                            <?= e($r['name']); ?> <span class="course-desc"><?= e($r['code']); ?></span>
                            <span class="status-badge status-<?= $r['is_active'] ? 'converted' : 'closed'; ?>"><?= $r['is_active'] ? 'Active' : 'Inactive'; ?></span>
                            <span class="course-desc"><?= (int) $r['user_count']; ?> staff</span>
                        </h2>
                        <div class="cert-table__actions">
                            <button type="button" class="btn-secondary btn-sm" data-role-edit='<?= json_encode(['id'=>$rid,'name'=>$r['name'],'code'=>$r['code'],'description'=>$r['description']??''], JSON_HEX_APOS|JSON_HEX_QUOT); ?>'>✏️ Edit</button>
                            <?php if ($rid !== 1): ?>
                                <button type="button" class="btn-secondary btn-sm" data-role-toggle='<?= json_encode(['id'=>$rid], JSON_HEX_APOS|JSON_HEX_QUOT); ?>'><?= $r['is_active'] ? 'Deactivate' : 'Activate'; ?></button>
                                <button type="button" class="btn-secondary btn-sm" data-role-delete='<?= json_encode(['id'=>$rid,'name'=>$r['name']], JSON_HEX_APOS|JSON_HEX_QUOT); ?>'>🗑 Delete</button>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php if ($rid === 1): ?>
                        <div style="padding:16px 20px;font-size:.85rem;color:#64748B;">Administrator always has full access to every module.</div>
                    <?php else: ?>
                        <form method="post" action="<?= e(base_url('sections/admissions/settings/roles.php')); ?>" style="padding:16px 20px;">
                            <?= csrf_field(); ?>
                            <input type="hidden" name="action" value="save_access">
                            <input type="hidden" name="role_id" value="<?= $rid; ?>">
                            <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:8px 14px;">
                                <?php
                                    $pm = [];
                                    foreach ($permMap[$rid] ?? [] as $pr) { $pm[$pr['page_key']] = $pr; }
                                ?>
                                <?php foreach ($pages as $key => $label): ?>
                                    <?php $lvl = isset($pm[$key]) ? ($pm[$key]['can_edit'] ? 'full' : 'view') : 'none'; ?>
                                    <label style="display:flex;align-items:center;gap:8px;font-size:.86rem;color:#334155;cursor:pointer;padding:6px 8px;border:1px solid #E2E8F0;border-radius:8px;background:#FBFCFE;">
                                        <span style="flex:1;"><?= e($label); ?></span>
                                        <select name="perm_level[<?= e($key); ?>]" style="height:30px;padding:0 6px;border:1px solid #CBD5E1;border-radius:8px;font-family:inherit;font-size:.8rem;">
                                            <option value="none" <?= $lvl === 'none' ? 'selected' : ''; ?>>None</option>
                                            <option value="view" <?= $lvl === 'view' ? 'selected' : ''; ?>>View</option>
                                            <option value="full" <?= $lvl === 'full' ? 'selected' : ''; ?>>Full</option>
                                        </select>
                                    </label>
                                <?php endforeach; ?>
                            </div>
                            <div style="margin-top:12px;display:flex;gap:8px;align-items:center;">
                                <button type="submit" class="btn-primary btn-sm">Save Access</button>
                                <span class="course-desc">None = hidden · View = read-only · Full = add/edit/delete.</span>
                            </div>
                        </form>
                    <?php endif; ?>
                </section>
            <?php endforeach; ?>
        </main>
    </section>

    <?php include INCLUDES_PATH . '/footer.php'; ?>
    <?php include INCLUDES_PATH . '/scripts.php'; ?>

    <!-- Role modal -->
    <div id="roleModal" class="portal-modal" style="display:none;">
        <div class="portal-modal__box">
            <div class="portal-modal__head">
                <h3 id="roleModalTitle">Add Role</h3>
                <p>Role name + code (shown in Staff Accounts)</p>
                <button class="portal-modal__close" id="roleClose">&times;</button>
            </div>
            <form method="post" action="<?= e(base_url('sections/admissions/settings/roles.php')); ?>">
                <?= csrf_field(); ?>
                <input type="hidden" name="action" value="save">
                <input type="hidden" name="role_id" id="rfRoleId" value="0">
                <div class="portal-modal__body">
                    <div class="cert-form__grid">
                        <div class="t-field"><label>Role Name *</label><input name="name" id="rfName" required placeholder="e.g. Endorser"></div>
                        <div class="t-field"><label>Code *</label><input name="code" id="rfCode" required placeholder="e.g. ENDORSER" style="text-transform:uppercase;"></div>
                        <div class="t-field t-field--full"><label>Description</label><textarea name="description" id="rfDesc" rows="2" placeholder="What this role does"></textarea></div>
                    </div>
                </div>
                <div class="portal-modal__foot">
                    <button type="button" class="btn-secondary" id="roleCancel">Cancel</button>
                    <button type="submit" class="btn-primary">Save Role</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        (function () {
            function showToast(msg, type) { window.usmciToast(msg, type); }
            var fl = document.getElementById("roleFlash");
            if (fl && fl.textContent.trim() !== "") showToast(fl.textContent.trim(), fl.dataset.type);

            var modal = document.getElementById("roleModal");
            function openRole(d) {
                document.getElementById("roleModalTitle").textContent = d ? "Edit Role" : "Add Role";
                document.getElementById("rfRoleId").value = d ? d.id : 0;
                document.getElementById("rfName").value = d ? d.name : "";
                document.getElementById("rfCode").value = d ? d.code : "";
                document.getElementById("rfDesc").value = d ? d.description : "";
                modal.style.display = "flex";
            }
            function closeRole() { modal.style.display = "none"; }
            document.getElementById("btnAddRole").addEventListener("click", function () { openRole(null); });
            document.querySelectorAll("[data-role-edit]").forEach(function (b) {
                b.addEventListener("click", function () { try { openRole(JSON.parse(b.dataset.roleEdit)); } catch (e) {} });
            });
            document.getElementById("roleClose").addEventListener("click", closeRole);
            document.getElementById("roleCancel").addEventListener("click", closeRole);
            modal.addEventListener("click", function (e) { if (e.target === modal) closeRole(); });

            var CSRF = <?= json_encode(csrf_token()); ?>;
            function post(data, done) {
                var fd = new FormData();
                fd.append("csrf_token", CSRF);
                Object.keys(data).forEach(function (k) { fd.append(k, data[k]); });
                fetch(window.location.href, { method: "POST", body: fd })
                    .then(function () { done(); })
                    .catch(function () { showToast("Could not save.", "error"); });
            }
            document.querySelectorAll("[data-role-toggle]").forEach(function (b) {
                b.addEventListener("click", function () {
                    var d = JSON.parse(b.dataset.roleToggle);
                    usmciConfirm({ title: "Toggle role?", message: "Change this role's active status?", confirmText: "Toggle" })
                        .then(function (ok) { if (ok) post({ action: "toggle", role_id: d.id }, function () { window.location.reload(); }); });
                });
            });
            document.querySelectorAll("[data-role-delete]").forEach(function (b) {
                b.addEventListener("click", function () {
                    var d = JSON.parse(b.dataset.roleDelete);
                    usmciConfirm({ title: "Delete role?", message: "Delete role '" + d.name + "'? Staff accounts using it must be reassigned first.", confirmText: "Delete", danger: true })
                        .then(function (ok) { if (ok) post({ action: "delete", role_id: d.id }, function () { window.location.reload(); }); });
                });
            });
        })();
    </script>
</body>
</html>
