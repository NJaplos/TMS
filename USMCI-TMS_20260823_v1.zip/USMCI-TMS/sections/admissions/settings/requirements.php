<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Admissions Settings: Requirements Matrix (V5.40)
 * File : sections/admissions/settings/requirements.php
 * ---------------------------------------------------------
 * 1) DOCUMENT TYPES — add / edit / deactivate the document types
 *    themselves (mnt_document_type). Deactivating a type removes
 *    it from every course's required set immediately.
 * 2) COURSE MATRIX — per course, tick which documents are required
 *    (course_prerequisite). Requirements are COURSE-based only
 *    (never batch). The Enrollment page reads this for the
 *    "Docs: X/Y" badge and the 📄 Requirements checklist.
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/config/bootstrap.php';

require_access('settings');
if ($_SERVER['REQUEST_METHOD'] === 'POST') { require_edit('settings'); }

$pdo = db();

$flash = ['type' => null, 'message' => null];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = (string) ($_POST['action'] ?? '');
    try {
        /* ---- Save the course × doc matrix ---- */
        if ($action === 'save_matrix') {
            $pdo->beginTransaction();
            $del = $pdo->prepare(
                "DELETE FROM course_prerequisite WHERE course_id = :cid AND required_document_type_id IS NOT NULL"
            );
            $ins = $pdo->prepare(
                "INSERT INTO course_prerequisite (course_id, required_document_type_id, created_at)
                 VALUES (:cid, :tid, NOW())"
            );
            $activeTypeIds = $pdo->query("SELECT id FROM mnt_document_type WHERE is_active = 1")->fetchAll(PDO::FETCH_COLUMN);
            $activeTypeIds = array_map('intval', $activeTypeIds);
            $saved = 0;
            $courses = $pdo->query("SELECT id FROM mnt_course WHERE is_active = 1")->fetchAll() ?: [];
            foreach ($courses as $c) {
                $cid = (int) $c['id'];
                $del->execute(['cid' => $cid]);
                $checked = array_map('intval', (array) ($_POST['req'][$cid] ?? []));
                foreach ($checked as $tid) {
                    if (!in_array($tid, $activeTypeIds, true)) { continue; }
                    $ins->execute(['cid' => $cid, 'tid' => $tid]);
                    $saved++;
                }
            }
            $pdo->commit();
            audit_log('requirements', 'matrix_update', null, "Requirements matrix saved ({$saved} required-doc rows)");
            $flash = ['type' => 'success', 'message' => "Requirements matrix saved ({$saved} required-document rows)."];
        }

        /* ---- Add / update a document type ---- */
        elseif ($action === 'doc_save') {
            $id   = (int) ($_POST['doc_id'] ?? 0);
            $code = strtoupper(trim((string) ($_POST['code'] ?? '')));
            $name = trim((string) ($_POST['name'] ?? ''));
            $desc = trim((string) ($_POST['description'] ?? ''));
            $sort = (int) ($_POST['sort_order'] ?? 0);

            if ($code === '' || $name === '') {
                $flash = ['type' => 'error', 'message' => 'Code and name are required.'];
            } else {
                $dup = $pdo->prepare("SELECT id FROM mnt_document_type WHERE code = :c AND id <> :id");
                $dup->execute(['c' => $code, 'id' => $id ?: 0]);
                if ($dup->fetch()) {
                    $flash = ['type' => 'error', 'message' => "A document type with code '{$code}' already exists."];
                } elseif ($id > 0) {
                    $pdo->prepare("UPDATE mnt_document_type SET code = :c, name = :n, description = :d, sort_order = :s, updated_at = NOW() WHERE id = :id")
                        ->execute(['c' => $code, 'n' => $name, 'd' => $desc !== '' ? $desc : null, 's' => $sort, 'id' => $id]);
                    audit_log('requirements', 'doc_type_update', $id, "Document type '{$name}' ({$code}) updated");
                    $flash = ['type' => 'success', 'message' => "Document type '{$name}' updated."];
                } else {
                    $pdo->prepare("INSERT INTO mnt_document_type (code, name, description, sort_order, is_active, created_at) VALUES (:c, :n, :d, :s, 1, NOW())")
                        ->execute(['c' => $code, 'n' => $name, 'd' => $desc !== '' ? $desc : null, 's' => $sort]);
                    audit_log('requirements', 'doc_type_create', (int) $pdo->lastInsertId(), "Document type '{$name}' ({$code}) created");
                    $flash = ['type' => 'success', 'message' => "Document type '{$name}' added."];
                }
            }
        }

        /* ---- Activate / deactivate a document type ---- */
        elseif ($action === 'doc_toggle') {
            $id = (int) ($_POST['doc_id'] ?? 0);
            $st = $pdo->prepare('SELECT code, name, is_active FROM mnt_document_type WHERE id = :id');
            $st->execute(['id' => $id]);
            $row = $st->fetch();
            if ($row) {
                $new = (int) $row['is_active'] ? 0 : 1;
                $pdo->prepare('UPDATE mnt_document_type SET is_active = :a, updated_at = NOW() WHERE id = :id')
                    ->execute(['a' => $new, 'id' => $id]);
                audit_log('requirements', 'doc_type_' . ($new ? 'activate' : 'deactivate'), $id,
                    "Document type '{$row['name']}' ({$row['code']}) " . ($new ? 'activated' : 'deactivated'));
                $flash = ['type' => 'success', 'message' => "Document type '{$row['name']}' " . ($new ? 'activated — now required wherever ticked.' : 'deactivated — removed from all courses immediately.')];
            } else {
                $flash = ['type' => 'error', 'message' => 'Document type not found.'];
            }
        }
    } catch (Throwable $e) {
        if (isset($pdo) && $pdo->inTransaction()) { $pdo->rollBack(); }
        error_log('requirements.php: ' . $e->getMessage());
        $flash = ['type' => 'error', 'message' => 'Could not save the requirements.'];
    }
}

$courses = $pdo->query("SELECT id, code, course_name FROM mnt_course WHERE is_active = 1 ORDER BY course_name")->fetchAll() ?: [];
$docTypes = $pdo->query("SELECT id, code, name, description, sort_order, is_active FROM mnt_document_type ORDER BY is_active DESC, sort_order, name")->fetchAll() ?: [];

/* Current matrix (course → required doc type ids) */
$current = [];
$stmt = $pdo->query(
    "SELECT cp.course_id, cp.required_document_type_id
     FROM course_prerequisite cp
     JOIN mnt_document_type dt ON dt.id = cp.required_document_type_id
     WHERE cp.required_document_type_id IS NOT NULL AND dt.is_active = 1"
);
foreach ($stmt->fetchAll() ?: [] as $r) {
    $current[(int) $r['course_id']][] = (int) $r['required_document_type_id'];
}

$page = [
    'title'       => 'Requirements Matrix | USMCI-TMS',
    'description' => 'Per-course required documents + document types',
    'bodyClass'   => 'admissions-page',
];
?>
<!DOCTYPE html>
<html lang="en">

<?php include INCLUDES_PATH . '/head.php'; ?>

<link rel="stylesheet" href="<?= e(base_url('assets/css/portal.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/workspace.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/inquiry-queue/assets/css/page.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/email-center/style.css?v=9')); ?>">

<body class="<?= e($page['bodyClass']); ?>">

    <?php include NAVBAR_PATH . '/index.php'; ?>

    <section class="portal-shell portal-shell--2col">

        <?php require ADMISSIONS_PATH . '/inquiry-queue/partials/sidebar.php'; ?>

        <main class="portal-content email-center">

            <header class="workspace-header">
                <div class="workspace-header__left">
                    <span class="section-badge">Administration</span>
                    <h1>Requirements</h1>
                    <p>Manage the document types, then tick per course which are required (course-based only). The Enrollment page uses this for the "Docs: X/Y" badge and the 📄 Req checklist.</p>
                </div>
            </header>

            <div id="reqFlash" data-type="<?= $flash['type']; ?>" style="display:none;"><?= htmlspecialchars($flash['message'] ?? '', ENT_QUOTES, 'UTF-8'); ?></div>

            <!-- ================= DOCUMENT TYPES ================= -->
            <section class="email-card email-card--wide" style="margin-top:16px;">
                <h2>📄 Document Types</h2>
                <p class="email-card__hint">Add, rename, or deactivate document types. Deactivating removes the type from every course's required set immediately (existing uploads are kept).</p>

                <!-- add form -->
                <form method="post" action="<?= e(base_url('sections/admissions/settings/requirements.php')); ?>" class="cert-form" style="display:flex;flex-direction:column;gap:10px;margin-top:12px;">
                    <?= csrf_field(); ?>
                    <input type="hidden" name="action" value="doc_save">
                    <input type="hidden" name="doc_id" value="0">
                    <div style="display:flex;gap:10px;flex-wrap:wrap;">
                        <input name="code" placeholder="CODE (e.g. NBI)" style="width:110px;height:38px;padding:0 10px;border:1px solid #CBD5E1;border-radius:8px;font-family:inherit;" maxlength="50" required>
                        <input name="name" placeholder="Name (e.g. NBI Clearance)" style="flex:1;min-width:180px;height:38px;padding:0 10px;border:1px solid #CBD5E1;border-radius:8px;font-family:inherit;" maxlength="150" required>
                        <input name="sort_order" type="number" placeholder="Sort" style="width:80px;height:38px;padding:0 10px;border:1px solid #CBD5E1;border-radius:8px;font-family:inherit;" value="0">
                        <button type="submit" class="btn-primary" style="height:38px;padding:0 16px;border:none;border-radius:8px;font-weight:700;background:#0D8A72;color:#fff;cursor:pointer;">＋ Add Type</button>
                    </div>
                    <input name="description" placeholder="Description (for future use — e.g. 'Government-issued photo ID valid for 5 years')" style="width:100%;height:38px;padding:0 10px;border:1px solid #CBD5E1;border-radius:8px;font-family:inherit;" maxlength="255">
                </form>

                <!-- hidden edit forms (inputs associate via form="df-{id}") -->
                <?php foreach ($docTypes as $dt): ?>
                    <form id="df-<?= (int) $dt['id']; ?>" method="post" action="<?= e(base_url('sections/admissions/settings/requirements.php')); ?>">
                        <?= csrf_field(); ?>
                        <input type="hidden" name="action" value="doc_save">
                        <input type="hidden" name="doc_id" value="<?= (int) $dt['id']; ?>">
                    </form>
                <?php endforeach; ?>

                <div class="table-responsive" style="margin-top:12px;">
                    <table class="inquiry-table">
                        <thead><tr><th style="width:90px;">Code</th><th>Name</th><th>Description</th><th style="width:70px;">Sort</th><th>Status</th><th style="width:230px;">Actions</th></tr></thead>
                        <tbody>
                            <?php if (!$docTypes): ?>
                                <tr><td colspan="6" style="text-align:center;color:#94A3B8;padding:20px;">No document types yet — add one above.</td></tr>
                            <?php endif; ?>
                            <?php foreach ($docTypes as $dt): ?>
                                <tr style="<?= $dt['is_active'] ? '' : 'opacity:.55;'; ?>">
                                    <td><input name="code" form="df-<?= (int) $dt['id']; ?>" value="<?= e($dt['code']); ?>" style="width:84px;height:32px;padding:0 6px;border:1px solid #E2E8F0;border-radius:6px;font-family:inherit;font-size:.8rem;" maxlength="50"></td>
                                    <td><input name="name" form="df-<?= (int) $dt['id']; ?>" value="<?= e($dt['name']); ?>" style="width:100%;min-width:120px;height:32px;padding:0 6px;border:1px solid #E2E8F0;border-radius:6px;font-family:inherit;font-size:.8rem;" maxlength="150"></td>
                                    <td><input name="description" form="df-<?= (int) $dt['id']; ?>" value="<?= e($dt['description'] ?? ''); ?>" style="width:100%;min-width:160px;height:32px;padding:0 6px;border:1px solid #E2E8F0;border-radius:6px;font-family:inherit;font-size:.8rem;" maxlength="255" placeholder="—"></td>
                                    <td><input name="sort_order" form="df-<?= (int) $dt['id']; ?>" type="number" value="<?= (int) $dt['sort_order']; ?>" style="width:60px;height:32px;padding:0 6px;border:1px solid #E2E8F0;border-radius:6px;font-family:inherit;font-size:.8rem;"></td>
                                    <td><span class="status-badge <?= $dt['is_active'] ? 'status-converted' : 'status-closed'; ?>"><?= $dt['is_active'] ? 'Active' : 'Inactive'; ?></span></td>
                                    <td>
                                        <button type="submit" form="df-<?= (int) $dt['id']; ?>" class="btn-secondary btn-sm">💾 Save</button>
                                        <form method="post" action="<?= e(base_url('sections/admissions/settings/requirements.php')); ?>" style="display:inline;">
                                            <?= csrf_field(); ?>
                                            <input type="hidden" name="action" value="doc_toggle">
                                            <input type="hidden" name="doc_id" value="<?= (int) $dt['id']; ?>">
                                            <button type="submit" class="btn-secondary btn-sm" <?= $dt['is_active'] ? 'title="Remove from all courses"' : 'title="Re-enable"'; ?>><?= $dt['is_active'] ? '🚫 Deactivate' : '✅ Activate'; ?></button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </section>

            <!-- ================= COURSE MATRIX ================= -->
            <section class="email-card email-card--wide" style="margin-top:16px;">
                <h2>🎓 Course Requirements (course-based)</h2>
                <p class="email-card__hint">Tick which of the active document types each course requires. Requirements are <strong>per course</strong> only.</p>

                <form method="post" action="<?= e(base_url('sections/admissions/settings/requirements.php')); ?>" id="matrixForm">
                    <?= csrf_field(); ?>
                    <input type="hidden" name="action" value="save_matrix">

                    <div class="table-responsive" style="overflow-x:auto;margin-top:10px;">
                        <table class="inquiry-table" style="min-width:760px;">
                            <thead>
                                <tr>
                                    <th style="min-width:200px;">Course</th>
                                    <?php foreach ($docTypes as $dt): if (!$dt['is_active']) continue; ?>
                                        <th style="text-align:center;font-size:.72rem;" title="<?= e($dt['name']); ?>"><?= e($dt['code']); ?></th>
                                    <?php endforeach; ?>
                                    <th>Required</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!$courses): ?>
                                    <tr><td colspan="<?= count($docTypes) + 2; ?>" style="text-align:center;color:#94A3B8;padding:24px;">No active courses.</td></tr>
                                <?php endif; ?>
                                <?php foreach ($courses as $c):
                                    $sel = $current[(int) $c['id']] ?? [];
                                ?>
                                    <tr>
                                        <td>
                                            <strong style="color:#0B3C5D;"><?= e($c['course_name']); ?></strong>
                                            <div class="course-desc">Course code: <?= e($c['code']); ?></div>
                                        </td>
                                        <?php foreach ($docTypes as $dt): if (!$dt['is_active']) continue; ?>
                                            <td style="text-align:center;">
                                                <input type="checkbox" name="req[<?= (int) $c['id']; ?>][]" value="<?= (int) $dt['id']; ?>"
                                                       <?= in_array((int) $dt['id'], $sel, true) ? 'checked' : ''; ?>
                                                       style="width:18px;height:18px;accent-color:#0D8A72;cursor:pointer;"
                                                       title="<?= e($dt['name']); ?>">
                                            </td>
                                        <?php endforeach; ?>
                                        <td><span class="docs-badge <?= count($sel) ? 'docs-part' : 'docs-none'; ?>"><?= count($sel); ?></span></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                    <div style="margin-top:16px;text-align:right;">
                        <button type="submit" class="btn-primary" style="height:42px;padding:0 22px;border-radius:10px;font-weight:700;background:#0D8A72;color:#fff;border:none;cursor:pointer;">💾 Save Requirements Matrix</button>
                    </div>
                </form>
            </section>

        </main>
    </section>

    <?php include INCLUDES_PATH . '/footer.php'; ?>
    <?php include INCLUDES_PATH . '/scripts.php'; ?>

    <script>
        (function () {
            function showToast(msg, type) { window.usmciToast(msg, type); }
            var fl = document.getElementById("reqFlash");
            if (fl && fl.textContent.trim() !== "") showToast(fl.textContent.trim(), fl.dataset.type);
            /* live per-row count on the matrix */
            document.querySelectorAll("#matrixForm tbody tr").forEach(function (tr) {
                var boxes = tr.querySelectorAll('input[type=checkbox]');
                var badge = tr.querySelector(".docs-badge");
                function refresh() {
                    var n = 0;
                    boxes.forEach(function (b) { if (b.checked) n++; });
                    if (badge) { badge.textContent = n; badge.className = "docs-badge " + (n ? "docs-part" : "docs-none"); }
                }
                boxes.forEach(function (b) { b.addEventListener("change", refresh); });
            });
        })();
    </script>

</body>
</html>
