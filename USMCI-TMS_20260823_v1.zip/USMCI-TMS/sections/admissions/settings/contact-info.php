<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Admissions Settings: Contact Info Cards
 * File : sections/admissions/settings/contact-info.php
 * ---------------------------------------------------------
 * Maintain the single-row contact cards on the public website
 * Contact section (Main Office · Training Site · Facebook ·
 * Instagram · Mobile · Telephone · Email). Add / edit / upload
 * icon / show-hide / delete / reorder.
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/config/bootstrap.php';

require_access('settings');
if ($_SERVER['REQUEST_METHOD'] === 'POST') { require_edit('settings'); }

$pdo = db();

$flash = ['type' => null, 'message' => null];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = (string) ($_POST['action'] ?? '');
    try {
        if ($action === 'save') {
            $id     = (int) ($_POST['ci_id'] ?? 0);
            $icon   = trim((string) ($_POST['icon'] ?? '📍'));
            $label  = trim((string) ($_POST['label'] ?? ''));
            $value  = trim((string) ($_POST['value'] ?? ''));
            $href   = trim((string) ($_POST['href'] ?? ''));
            $cta    = trim((string) ($_POST['cta'] ?? ''));
            $ext    = isset($_POST['external']) ? 1 : 0;
            $sort   = (int) ($_POST['sort_order'] ?? 0);
            $active = isset($_POST['is_active']) ? 1 : 0;

            if ($icon === '' || $label === '' || $value === '') {
                $flash = ['type' => 'error', 'message' => 'Icon, label and value are required.'];
            } elseif ($id > 0) {
                $pdo->prepare('UPDATE mnt_contact_info SET icon = :i, label = :l, value = :v, href = :h, cta = :c, external = :e, sort_order = :s, is_active = :a, updated_at = NOW() WHERE id = :id')
                    ->execute(['i' => $icon, 'l' => $label, 'v' => $value, 'h' => $href !== '' ? $href : null, 'c' => $cta !== '' ? $cta : null, 'e' => $ext, 's' => $sort, 'a' => $active, 'id' => $id]);
                audit_log('settings', 'contact_info_update', $id, "Contact card '{$label}' updated");
                $flash = ['type' => 'success', 'message' => "Contact card '{$label}' updated."];
            } else {
                $pdo->prepare('INSERT INTO mnt_contact_info (icon, label, value, href, cta, external, sort_order, is_active, created_at) VALUES (:i, :l, :v, :h, :c, :e, :s, :a, NOW())')
                    ->execute(['i' => $icon, 'l' => $label, 'v' => $value, 'h' => $href !== '' ? $href : null, 'c' => $cta !== '' ? $cta : null, 'e' => $ext, 's' => $sort, 'a' => $active]);
                audit_log('settings', 'contact_info_create', (int) $pdo->lastInsertId(), "Contact card '{$label}' created");
                $flash = ['type' => 'success', 'message' => "Contact card '{$label}' added — it now shows on the website Contact section."];
            }
        } elseif ($action === 'toggle') {
            $id = (int) ($_POST['ci_id'] ?? 0);
            $st = $pdo->prepare('SELECT label, is_active FROM mnt_contact_info WHERE id = :id');
            $st->execute(['id' => $id]);
            $row = $st->fetch();
            if ($row) {
                $new = (int) $row['is_active'] ? 0 : 1;
                $pdo->prepare('UPDATE mnt_contact_info SET is_active = :a, updated_at = NOW() WHERE id = :id')->execute(['a' => $new, 'id' => $id]);
                audit_log('settings', 'contact_info_' . ($new ? 'activate' : 'deactivate'), $id, "Contact card '{$row['label']}' " . ($new ? 'activated' : 'deactivated'));
                $flash = ['type' => 'success', 'message' => "Contact card '{$row['label']}' " . ($new ? 'shown on the website.' : 'hidden from the website.')];
            } else {
                $flash = ['type' => 'error', 'message' => 'Contact card not found.'];
            }
        } elseif ($action === 'delete') {
            $id = (int) ($_POST['ci_id'] ?? 0);
            $st = $pdo->prepare('SELECT label FROM mnt_contact_info WHERE id = :id');
            $st->execute(['id' => $id]);
            $row = $st->fetch();
            if ($row) {
                $pdo->prepare('DELETE FROM mnt_contact_info WHERE id = :id')->execute(['id' => $id]);
                audit_log('settings', 'contact_info_delete', $id, "Contact card '{$row['label']}' deleted");
                $flash = ['type' => 'success', 'message' => "Contact card '{$row['label']}' deleted."];
            } else {
                $flash = ['type' => 'error', 'message' => 'Contact card not found.'];
            }
        }
    } catch (Throwable $e) {
        error_log('contact-info.php: ' . $e->getMessage());
        $flash = ['type' => 'error', 'message' => 'Could not save the contact card.'];
    }
}

/* one card for the edit form */
$editing = null;
$editId  = (int) ($_GET['edit'] ?? 0);
if ($editId > 0) {
    $st = $pdo->prepare('SELECT * FROM mnt_contact_info WHERE id = :id');
    $st->execute(['id' => $editId]);
    $editing = $st->fetch() ?: null;
}

$rows = $pdo->query("SELECT * FROM mnt_contact_info ORDER BY is_active DESC, sort_order, id")->fetchAll() ?: [];

$page = [
    'title'       => 'Contact Info Cards | USMCI-TMS',
    'description' => 'Manage public website contact cards',
    'bodyClass'   => 'admissions-page',
];
?>
<!DOCTYPE html>
<html lang="en">

<?php include INCLUDES_PATH . '/head.php'; ?>

<link rel="stylesheet" href="<?= e(base_url('assets/css/portal.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/workspace.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/inquiry-queue/assets/css/page.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/email-center/style.css?v=9')); ?>">

<body class="<?= e($page['bodyClass']); ?>">

    <?php include NAVBAR_PATH . '/index.php'; ?>

    <section class="portal-shell portal-shell--2col">

        <?php require ADMISSIONS_PATH . '/inquiry-queue/partials/sidebar.php'; ?>

        <main class="portal-content email-center">

            <header class="workspace-header">
                <div class="workspace-header__left">
                    <span class="section-badge">Administration</span>
                    <h1>Contact Info Cards</h1>
                    <p>Maintain the single-row contact cards on the public website Contact section. Add, edit, reorder, show/hide or delete — the website updates live.</p>
                </div>
            </header>

            <div id="ciFlash" data-type="<?= $flash['type']; ?>" style="display:none;"><?= htmlspecialchars($flash['message'] ?? '', ENT_QUOTES, 'UTF-8'); ?></div>

            <!-- add / edit form -->
            <section class="email-card email-card--wide" style="margin-top:16px;">
                <h2><?= $editing ? '✏️ Edit Contact Card' : '＋ Add Contact Card'; ?></h2>
                <form method="post" action="<?= e(base_url('sections/admissions/settings/contact-info.php')); ?>" class="cert-form" style="margin-top:12px;">
                    <?= csrf_field(); ?>
                    <input type="hidden" name="action" value="save">
                    <input type="hidden" name="ci_id" value="<?= (int) ($editing['id'] ?? 0); ?>">

                    <div style="display:grid;grid-template-columns:90px 1fr 1fr 100px;gap:14px;">
                        <div class="t-field">
                            <label>Icon (emoji)</label>
                            <input name="icon" value="<?= e($editing['icon'] ?? '📍'); ?>" style="width:100%;height:40px;text-align:center;border:1px solid #CBD5E1;border-radius:8px;font-size:1.1rem;font-family:inherit;">
                        </div>
                        <div class="t-field">
                            <label>Label <span class="required">*</span></label>
                            <input name="label" value="<?= e($editing['label'] ?? ''); ?>" required placeholder="e.g. Main Office" style="width:100%;height:40px;padding:0 12px;border:1px solid #CBD5E1;border-radius:8px;font-family:inherit;">
                        </div>
                        <div class="t-field">
                            <label>Value <span class="required">*</span></label>
                            <input name="value" value="<?= e($editing['value'] ?? ''); ?>" required placeholder="e.g. 09971201553" style="width:100%;height:40px;padding:0 12px;border:1px solid #CBD5E1;border-radius:8px;font-family:inherit;">
                        </div>
                        <div class="t-field">
                            <label>Sort</label>
                            <input type="number" name="sort_order" value="<?= (int) ($editing['sort_order'] ?? 0); ?>" min="0" style="width:100%;height:40px;padding:0 12px;border:1px solid #CBD5E1;border-radius:8px;font-family:inherit;">
                        </div>
                    </div>

                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-top:14px;">
                        <div class="t-field">
                            <label>Link (href) — optional, e.g. tel:+63… / mailto:… / https://…</label>
                            <input name="href" value="<?= e($editing['href'] ?? ''); ?>" placeholder="https://…" style="width:100%;height:40px;padding:0 12px;border:1px solid #CBD5E1;border-radius:8px;font-family:inherit;">
                        </div>
                        <div class="t-field">
                            <label>Link label (shown on the card, e.g. "Get Directions →")</label>
                            <input name="cta" value="<?= e($editing['cta'] ?? ''); ?>" placeholder="Get Directions →" style="width:100%;height:40px;padding:0 12px;border:1px solid #CBD5E1;border-radius:8px;font-family:inherit;">
                        </div>
                    </div>

                    <div style="margin-top:12px;display:flex;align-items:center;gap:18px;">
                        <label style="display:flex;align-items:center;gap:6px;font-size:.85rem;font-weight:600;">
                            <input type="checkbox" name="external" value="1" <?= !empty($editing['external']) ? 'checked' : ''; ?>> Opens in a new tab
                        </label>
                        <label style="display:flex;align-items:center;gap:6px;font-size:.85rem;font-weight:600;">
                            <input type="checkbox" name="is_active" value="1" <?= (!isset($editing) || (int) $editing['is_active'] === 1) ? 'checked' : ''; ?>> Active — shown on the website
                        </label>
                    </div>

                    <div style="margin-top:16px;display:flex;gap:10px;">
                        <button type="submit" class="btn-primary" style="height:42px;padding:0 22px;border-radius:10px;font-weight:700;background:#0D8A72;color:#fff;border:none;cursor:pointer;">💾 <?= $editing ? 'Save Changes' : 'Add Card'; ?></button>
                        <?php if ($editing): ?>
                            <a class="btn-secondary btn-sm" style="text-decoration:none;display:inline-flex;align-items:center;padding:0 16px;border-radius:10px;" href="<?= e(base_url('sections/admissions/settings/contact-info.php')); ?>">← Cancel</a>
                        <?php endif; ?>
                        <a class="btn-secondary btn-sm" style="text-decoration:none;display:inline-flex;align-items:center;padding:0 16px;border-radius:10px;margin-left:auto;" href="<?= e(base_url('index.php#contact')); ?>" target="_blank">👁 Preview on Website</a>
                    </div>
                </form>
            </section>

            <!-- list -->
            <section class="email-card email-card--wide" style="margin-top:16px;">
                <h2>📇 Existing Contact Cards (<?= count($rows); ?>)</h2>
                <?php if (!$rows): ?>
                    <p class="email-card__hint" style="margin-top:10px;">No contact cards yet — add one above.</p>
                <?php else: ?>
                    <table class="portal-table" style="width:100%;border-collapse:collapse;margin-top:12px;">
                        <thead>
                            <tr style="text-align:left;color:#64748B;font-size:.75rem;text-transform:uppercase;letter-spacing:.05em;border-bottom:2px solid #E2E8F0;">
                                <th style="padding:10px 8px;">Icon</th>
                                <th style="padding:10px 8px;">Label</th>
                                <th style="padding:10px 8px;">Value</th>
                                <th style="padding:10px 8px;">Sort</th>
                                <th style="padding:10px 8px;">Status</th>
                                <th style="padding:10px 8px;text-align:right;">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($rows as $r): ?>
                                <tr style="border-bottom:1px solid #F1F5F9;vertical-align:middle;">
                                    <td style="padding:8px;font-size:1.2rem;text-align:center;"><?= e($r['icon']); ?></td>
                                    <td style="padding:8px;font-weight:700;font-size:.88rem;"><?= e($r['label']); ?></td>
                                    <td style="padding:8px;font-size:.78rem;color:#64748B;max-width:260px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"><?= e($r['value']); ?></td>
                                    <td style="padding:8px;font-size:.85rem;"><?= (int) $r['sort_order']; ?></td>
                                    <td style="padding:8px;">
                                        <span style="display:inline-block;padding:3px 10px;border-radius:999px;font-size:.72rem;font-weight:700;<?= (int) $r['is_active'] ? 'background:#D1FAE5;color:#065F46;' : 'background:#F1F5F9;color:#64748B;'; ?>">
                                            <?= (int) $r['is_active'] ? '● Visible' : '○ Hidden'; ?>
                                        </span>
                                    </td>
                                    <td style="padding:8px;text-align:right;white-space:nowrap;">
                                        <form method="post" action="<?= e(base_url('sections/admissions/settings/contact-info.php')); ?>" style="display:inline;">
                                            <?= csrf_field(); ?>
                                            <input type="hidden" name="action" value="toggle">
                                            <input type="hidden" name="ci_id" value="<?= (int) $r['id']; ?>">
                                            <button type="submit" class="btn-secondary btn-sm" style="padding:5px 12px;border-radius:8px;border:1px solid #CBD5E1;background:#fff;cursor:pointer;font-size:.75rem;font-weight:700;"><?= (int) $r['is_active'] ? 'Hide' : 'Show'; ?></button>
                                        </form>
                                        <a class="btn-secondary btn-sm" style="padding:5px 12px;border-radius:8px;border:1px solid #CBD5E1;background:#fff;text-decoration:none;font-size:.75rem;font-weight:700;display:inline-flex;" href="<?= e(base_url('sections/admissions/settings/contact-info.php?edit=' . (int) $r['id'])); ?>">Edit</a>
                                        <form method="post" action="<?= e(base_url('sections/admissions/settings/contact-info.php')); ?>" style="display:inline;" onsubmit="return confirm('Delete this contact card?');">
                                            <?= csrf_field(); ?>
                                            <input type="hidden" name="action" value="delete">
                                            <input type="hidden" name="ci_id" value="<?= (int) $r['id']; ?>">
                                            <button type="submit" class="btn-secondary btn-sm" style="padding:5px 12px;border-radius:8px;border:1px solid #FECACA;background:#FEF2F2;color:#991B1B;cursor:pointer;font-size:.75rem;font-weight:700;">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </section>

        </main>
    </section>

    <?php include INCLUDES_PATH . '/footer.php'; ?>
    <?php include INCLUDES_PATH . '/scripts.php'; ?>

    <script>
        (function () {
            function showToast(msg, type) { window.usmciToast(msg, type); }
            var fl = document.getElementById("ciFlash");
            if (fl && fl.textContent.trim() !== "") showToast(fl.textContent.trim(), fl.dataset.type);
        })();
    </script>

</body>
</html>
