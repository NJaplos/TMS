<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Admissions Settings: Report Letterhead
 * File : sections/admissions/settings/report-settings.php
 * ---------------------------------------------------------
 * Lets the school edit the printable report letterhead WITHOUT
 * touching PHP code. Stored in mnt_system_setting (report_*)
 * and read at runtime by report_form.php via report_setting().
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/config/bootstrap.php';

require_access('settings');
if ($_SERVER['REQUEST_METHOD'] === 'POST') { require_edit('settings'); }

$pdo = db();

$flash = ['type' => null, 'message' => null];

/* default letterhead (same as the printed registration form) */
$fields = [
    'report_org_name'    => ['label' => 'Organization Name', 'default' => 'UNITED SEAFARERS MARITIME CENTER INC'],
    'report_org_address' => ['label' => 'Address',            'default' => 'G/F YMCA OF MANILA BLDG 350 ANTONIO VILLEGAS ST ERMITA MANILA'],
    'report_tel_no'      => ['label' => 'Telephone',          'default' => 'TEL NO: 8241-0881'],
    'report_mobile_no'   => ['label' => 'Mobile',             'default' => 'MOBILE NO: 09971201553'],
    'report_email'       => ['label' => 'Email',              'default' => 'usmci2010@gmail.com'],
    'report_footer'      => ['label' => 'Footer Note (optional)', 'default' => ''],
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    try {
        $upd = $pdo->prepare(
            "INSERT INTO mnt_system_setting (setting_key, setting_value, data_type, description, updated_at)
             VALUES (:k, :v, 'string', :d, NOW())
             ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = NOW()"
        );
        foreach ($fields as $key => $f) {
            $val = trim((string) ($_POST[$key] ?? ''));
            $upd->execute(['k' => $key, 'v' => $val, 'd' => $f['label']]);
        }
        audit_log('settings', 'report_letterhead_update', null, 'Report letterhead updated');
        $flash = ['type' => 'success', 'message' => 'Report letterhead saved — printable reports will use it immediately.'];
    } catch (Throwable $e) {
        error_log('report-settings.php: ' . $e->getMessage());
        $flash = ['type' => 'error', 'message' => 'Could not save the letterhead.'];
    }
}

$values = [];
foreach (array_keys($fields) as $key) {
    $values[$key] = report_setting($key, $fields[$key]['default']);
}

$page = [
    'title'       => 'Report Letterhead | USMCI-TMS',
    'description' => 'Printable report letterhead',
    'bodyClass'   => 'admissions-page',
];
?>
<!DOCTYPE html>
<html lang="en">

<?php include INCLUDES_PATH . '/head.php'; ?>

<link rel="stylesheet" href="<?= e(base_url('assets/css/portal.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/workspace.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/inquiry-queue/assets/css/page.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/email-center/style.css?v=9')); ?>">

<body class="<?= e($page['bodyClass']); ?>">

    <?php include NAVBAR_PATH . '/index.php'; ?>

    <section class="portal-shell portal-shell--2col">

        <?php require ADMISSIONS_PATH . '/inquiry-queue/partials/sidebar.php'; ?>

        <main class="portal-content email-center">

            <header class="workspace-header">
                <div class="workspace-header__left">
                    <span class="section-badge">Administration</span>
                    <h1>Report Letterhead</h1>
                    <p>The school can update the printable report header here — no PHP code changes needed.</p>
                </div>
            </header>

            <div id="lhFlash" data-type="<?= $flash['type']; ?>" style="display:none;"><?= htmlspecialchars($flash['message'] ?? '', ENT_QUOTES, 'UTF-8'); ?></div>

            <form method="post" action="<?= e(base_url('sections/admissions/settings/report-settings.php')); ?>" id="lhForm">
                <?= csrf_field(); ?>

                <section class="email-card email-card--wide" style="margin-top:16px;">
                    <div class="cert-form__grid" style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">
                        <div class="t-field t-field--full"><label>Organization Name *</label><input name="report_org_name" value="<?= e($values['report_org_name']); ?>" required></div>
                        <div class="t-field t-field--full"><label>Address *</label><input name="report_org_address" value="<?= e($values['report_org_address']); ?>" required></div>
                        <div class="t-field"><label>Telephone</label><input name="report_tel_no" value="<?= e($values['report_tel_no']); ?>"></div>
                        <div class="t-field"><label>Mobile</label><input name="report_mobile_no" value="<?= e($values['report_mobile_no']); ?>"></div>
                        <div class="t-field t-field--full"><label>Email</label><input name="report_email" value="<?= e($values['report_email']); ?>"></div>
                        <div class="t-field t-field--full"><label>Footer Note (optional)</label><input name="report_footer" value="<?= e($values['report_footer']); ?>" placeholder="e.g. THIS FORM IS NOT VALID WITHOUT THE OFFICIAL SEAL"></div>
                    </div>
                </section>

                <!-- live preview -->
                <section class="email-card email-card--wide" style="margin-top:16px;">
                    <h2>👁 Preview</h2>
                    <div style="border:1px solid #CBD5E1;border-radius:10px;padding:16px 20px;margin-top:10px;text-align:center;">
                        <img src="<?= e(base_url('assets/images/branding/logo-light3.png')); ?>" alt="logo" style="height:56px;object-fit:contain;">
                        <div style="font-weight:800;letter-spacing:.4px;color:#0B3C5D;margin-top:6px;" id="pv_name"><?= e($values['report_org_name']); ?></div>
                        <div style="font-size:.78rem;color:#5B6472;" id="pv_addr"><?= e($values['report_org_address']); ?></div>
                        <div style="font-size:.78rem;color:#5B6472;" id="pv_contacts"><?= e($values['report_tel_no']); ?> · <?= e($values['report_mobile_no']); ?> · <?= e($values['report_email']); ?></div>
                    </div>
                </section>

                <div style="margin-top:18px;text-align:right;">
                    <button type="submit" class="btn-primary" style="height:42px;padding:0 22px;border-radius:10px;font-weight:700;background:#0D8A72;color:#fff;border:none;cursor:pointer;">💾 Save Letterhead</button>
                </div>
            </form>

        </main>
    </section>

    <?php include INCLUDES_PATH . '/footer.php'; ?>
    <?php include INCLUDES_PATH . '/scripts.php'; ?>

    <script>
        (function () {
            function showToast(msg, type) { window.usmciToast(msg, type); }
            var fl = document.getElementById("lhFlash");
            if (fl && fl.textContent.trim() !== "") showToast(fl.textContent.trim(), fl.dataset.type);
            ["report_org_name", "report_org_address", "report_tel_no", "report_mobile_no", "report_email"].forEach(function (id) {
                var el = document.querySelector('[name="' + id + '"]');
                if (!el) return;
                el.addEventListener("input", function () {
                    var v = el.value || "";
                    if (id === "report_org_name") document.getElementById("pv_name").textContent = v;
                    if (id === "report_org_address") document.getElementById("pv_addr").textContent = v;
                    if (id === "report_tel_no" || id === "report_mobile_no" || id === "report_email") {
                        document.getElementById("pv_contacts").textContent =
                            [document.querySelector('[name="report_tel_no"]').value,
                             document.querySelector('[name="report_mobile_no"]').value,
                             document.querySelector('[name="report_email"]').value].filter(Boolean).join(" · ");
                    }
                });
            });
        })();
    </script>

</body>
</html>
