<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Admissions Settings: Website Content
 * File : sections/admissions/settings/website-content.php
 * ---------------------------------------------------------
 * Lets the school edit the PUBLIC website copy without touching
 * code (one-page anchor model). Content is stored in
 * mnt_system_setting (site_* keys) and rendered by the site
 * sections (sections/about/… etc.).
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/config/bootstrap.php';

require_access('settings');
if ($_SERVER['REQUEST_METHOD'] === 'POST') { require_edit('settings'); }

$pdo = db();

$flash = ['type' => null, 'message' => null];

/* About-page fields (one card per page as the site grows) */
$fields = [
    'site_about_intro'    => ['label' => 'About — Intro / Tagline', 'kind' => 'text',     'hint' => 'Short paragraph shown at the top of the About section.'],
    'site_about_story'    => ['label' => 'About — Our Story',       'kind' => 'textarea', 'hint' => 'Company history, SEC registration, experience.'],
    'site_about_mission'  => ['label' => 'About — Mission',         'kind' => 'list',     'hint' => 'One mission item per line.'],
    'site_about_vision'   => ['label' => 'About — Vision statement','kind' => 'text',     'hint' => 'The one-sentence vision.'],
    'site_about_vision_points' => ['label' => 'About — Vision pillars', 'kind' => 'list', 'hint' => 'One pillar per line.'],
    'site_about_quality'  => ['label' => 'About — Quality / ISO commitment', 'kind' => 'textarea', 'hint' => 'ISO 9001:2015 commitment paragraph.'],
    'site_about_core_values'   => ['label' => 'About — Core Values','kind' => 'list',     'hint' => 'One value per line, format: Title: description'],
    'site_about_accreditations' => ['label' => 'About — Accreditations', 'kind' => 'list', 'hint' => 'One accreditation per line (e.g. SEC Registered — CS201008536).'],
    'site_about_leader'   => ['label' => 'About — Leadership',      'kind' => 'list',     'hint' => 'Line 1 = name, line 2 = role.'],
    'site_about_photo'    => ['label' => 'About — Story photo path','kind' => 'text',     'hint' => 'Path under the web root, e.g. assets/images/site/facility-1.jpg'],
    'site_courses_bg'     => ['label' => 'Courses — Background image', 'kind' => 'text', 'hint' => 'Path to the Courses section background, e.g. assets/images/site/course-bg.jpg'],
    'site_facilities_title' => ['label' => 'Facilities — Title', 'kind' => 'text', 'hint' => 'Heading for the Facilities section.'],
    'site_facilities_intro' => ['label' => 'Facilities — Intro', 'kind' => 'textarea', 'hint' => 'Short paragraph introducing the facilities.'],
    'site_facilities_features' => ['label' => 'Facilities — Feature cards', 'kind' => 'list', 'hint' => 'One per line, format: Title: description'],
    'site_about_carousel_dir' => ['label' => 'About — Carousel folder', 'kind' => 'text', 'hint' => 'Folder scanned automatically for carousel photos. Drop JPGs in and they appear.'],
    'site_about_manager_photo' => ['label' => 'About — Managing Director photo', 'kind' => 'text', 'hint' => 'Path to the MD photo (placeholder used until a real one is provided).'],
    'site_about_manager_message' => ['label' => 'About — Managing Director message', 'kind' => 'textarea', 'hint' => 'Welcome message signed by the Managing Director.'],
    'site_news_announce_title' => ['label' => 'News — Announcements row title', 'kind' => 'text', 'hint' => 'Heading of the Training Center Announcements row (e.g. Training Center Announcements).'],
    'site_news_announce_intro' => ['label' => 'News — Announcements intro', 'kind' => 'textarea', 'hint' => 'Small line under the announcements heading.'],
    'site_contact_intro'    => ['label' => 'Contact — Intro', 'kind' => 'textarea', 'hint' => 'Short paragraph shown at the top of the Contact section.'],
    'site_contact_hours'    => ['label' => 'Contact — Business hours', 'kind' => 'list', 'hint' => 'One line per day/hours (e.g. Monday – Friday: 8:00 AM – 5:00 PM).'],
    'site_contact_map_query' => ['label' => 'Contact — Directions address', 'kind' => 'text', 'hint' => 'Address used for the "Get Directions" Google Maps link.'],
    'site_contact_note'     => ['label' => 'Contact — Walk-in note', 'kind' => 'textarea', 'hint' => 'Small note shown under the office details.'],
    'site_contact_affiliates_title' => ['label' => 'Contact — Affiliations row title', 'kind' => 'text', 'hint' => 'Heading of the affiliated companies row (e.g. Our Affiliations & Partners).'],
    'site_contact_affiliates_intro' => ['label' => 'Contact — Affiliations intro', 'kind' => 'textarea', 'hint' => 'Small line under the affiliations heading.'],
    'site_contact_partners_title' => ['label' => 'Contact — Partners row title', 'kind' => 'text', 'hint' => 'Heading of the partners row (e.g. Our Partners).'],
    'site_contact_partners_intro' => ['label' => 'Contact — Partners intro', 'kind' => 'textarea', 'hint' => 'Small line under the partners heading.'],
    'site_contact_training_site' => ['label' => 'Contact — Training site address', 'kind' => 'text', 'hint' => 'Address of the training site (shown in the info line).'],
    'site_contact_facebook' => ['label' => 'Contact — Facebook URL', 'kind' => 'text', 'hint' => 'Full URL of the official Facebook page.'],
    'site_contact_instagram' => ['label' => 'Contact — Instagram URL', 'kind' => 'text', 'hint' => 'Full URL of the official Instagram profile.'],
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    try {
        $upd = $pdo->prepare(
            "INSERT INTO mnt_system_setting (setting_key, setting_value, data_type, description, updated_at)
             VALUES (:k, :v, 'string', :d, NOW())
             ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = NOW()"
        );
        $saved = 0;
        foreach ($fields as $key => $f) {
            /* only update keys actually present in the POST — a partial
               submit must never wipe the other fields */
            if (!array_key_exists($key, $_POST)) { continue; }
            $val = trim((string) ($_POST[$key] ?? ''));
            $upd->execute(['k' => $key, 'v' => $val, 'd' => $f['label']]);
            $saved++;
        }
        audit_log('settings', 'website_content_update', null, "Website content saved ($saved fields)");
        $flash = ['type' => 'success', 'message' => "Website content saved — the site now shows your updated copy."];
    } catch (Throwable $e) {
        if (isset($pdo) && $pdo->inTransaction()) { $pdo->rollBack(); }
        error_log('website-content.php: ' . $e->getMessage());
        $flash = ['type' => 'error', 'message' => 'Could not save the website content.'];
    }
}

$values = [];
foreach (array_keys($fields) as $key) {
    $values[$key] = site_content($key, '');
}

$page = [
    'title'       => 'Website Content | USMCI-TMS',
    'description' => 'Editable public website copy',
    'bodyClass'   => 'admissions-page',
];
?>
<!DOCTYPE html>
<html lang="en">

<?php include INCLUDES_PATH . '/head.php'; ?>

<link rel="stylesheet" href="<?= e(base_url('assets/css/portal.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/workspace.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/inquiry-queue/assets/css/page.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/email-center/style.css?v=9')); ?>">

<body class="<?= e($page['bodyClass']); ?>">

    <?php include NAVBAR_PATH . '/index.php'; ?>

    <section class="portal-shell portal-shell--2col">

        <?php require ADMISSIONS_PATH . '/inquiry-queue/partials/sidebar.php'; ?>

        <main class="portal-content email-center">

            <header class="workspace-header">
                <div class="workspace-header__left">
                    <span class="section-badge">Administration</span>
                    <h1>Website Content</h1>
                    <p>Edit the public website copy here — the site reads these values live. No code changes needed.</p>
                </div>
            </header>

            <div id="wcFlash" data-type="<?= $flash['type']; ?>" style="display:none;"><?= htmlspecialchars($flash['message'] ?? '', ENT_QUOTES, 'UTF-8'); ?></div>

            <form method="post" action="<?= e(base_url('sections/admissions/settings/website-content.php')); ?>" id="wcForm">
                <?= csrf_field(); ?>

                <?php $renderField = function (string $key, array $f, array $values): void { ?>
                    <div class="t-field <?= $f['kind'] === 'textarea' || $f['kind'] === 'list' ? 't-field--full' : ''; ?>">
                        <label><?= e($f['label']); ?></label>
                        <?php if ($f['kind'] === 'textarea'): ?>
                            <textarea name="<?= e($key); ?>" rows="4" style="width:100%;padding:10px 12px;border:1px solid #CBD5E1;border-radius:8px;font-family:inherit;"><?= e($values[$key]); ?></textarea>
                        <?php elseif ($f['kind'] === 'list'): ?>
                            <textarea name="<?= e($key); ?>" rows="4" style="width:100%;padding:10px 12px;border:1px solid #CBD5E1;border-radius:8px;font-family:inherit;" placeholder="One item per line…"><?= e($values[$key]); ?></textarea>
                        <?php else: ?>
                            <input name="<?= e($key); ?>" value="<?= e($values[$key]); ?>" style="width:100%;height:40px;padding:0 12px;border:1px solid #CBD5E1;border-radius:8px;font-family:inherit;">
                        <?php endif; ?>
                        <?php if (!empty($f['hint'])): ?>
                            <small class="field-hint"><?= e($f['hint']); ?></small>
                        <?php endif; ?>
                    </div>
                <?php }; ?>

                <?php $aboutKeys = array_filter(array_keys($fields), fn($k) => str_starts_with($k, 'site_about_') || str_starts_with($k, 'site_courses_') || str_starts_with($k, 'site_facilities_')); ?>
                <?php $contactKeys = array_filter(array_keys($fields), fn($k) => str_starts_with($k, 'site_contact_')); ?>
                <?php $newsKeys = array_filter(array_keys($fields), fn($k) => str_starts_with($k, 'site_news_')); ?>

                <section class="email-card email-card--wide" style="margin-top:16px;">
                    <h2>📖 About / Courses / Facilities</h2>
                    <p class="email-card__hint">These fields power the <code>#about</code>, <code>#courses</code> and <code>#facilities</code> blocks on the homepage. Empty fields fall back to the official company profile text.</p>

                    <div class="cert-form__grid" style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-top:14px;">
                        <?php foreach ($aboutKeys as $key): ?>
                            <?php $renderField($key, $fields[$key], $values); ?>
                        <?php endforeach; ?>
                    </div>
                </section>

                <section class="email-card email-card--wide" style="margin-top:16px;">
                    <h2>☎️ Contact Section</h2>
                    <p class="email-card__hint">These fields power the <code>#contact</code> block. The address, telephone, mobile and email come from the official letterhead settings — edit those there so documents and the site always match.</p>

                    <div class="cert-form__grid" style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-top:14px;">
                        <?php foreach ($contactKeys as $key): ?>
                            <?php $renderField($key, $fields[$key], $values); ?>
                        <?php endforeach; ?>
                    </div>
                </section>

                <section class="email-card email-card--wide" style="margin-top:16px;">
                    <h2>📢 News — Announcements row</h2>
                    <p class="email-card__hint">These fields power the <code>Training Center Announcements</code> row under the enrollment batches. The announcements themselves are maintained at <a href="<?= e(base_url('sections/admissions/settings/announcements.php')); ?>">Settings → Training Center Announcements</a>.</p>

                    <div class="cert-form__grid" style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-top:14px;">
                        <?php foreach ($newsKeys as $key): ?>
                            <?php $renderField($key, $fields[$key], $values); ?>
                        <?php endforeach; ?>
                    </div>
                </section>

                <div style="margin-top:18px;text-align:right;">
                    <a class="btn-secondary btn-sm" style="text-decoration:none;" href="<?= e(base_url('index.php#about')); ?>" target="_blank">👁 Preview About</a>
                    <a class="btn-secondary btn-sm" style="text-decoration:none;margin-left:6px;" href="<?= e(base_url('index.php#contact')); ?>" target="_blank">👁 Preview Contact</a>
                    <button type="submit" class="btn-primary" style="height:42px;padding:0 22px;border-radius:10px;font-weight:700;background:#0D8A72;color:#fff;border:none;cursor:pointer;margin-left:8px;">💾 Save Website Content</button>
                </div>
            </form>

        </main>
    </section>

    <?php include INCLUDES_PATH . '/footer.php'; ?>
    <?php include INCLUDES_PATH . '/scripts.php'; ?>

    <script>
        (function () {
            function showToast(msg, type) { window.usmciToast(msg, type); }
            var fl = document.getElementById("wcFlash");
            if (fl && fl.textContent.trim() !== "") showToast(fl.textContent.trim(), fl.dataset.type);
        })();
    </script>

</body>
</html>
