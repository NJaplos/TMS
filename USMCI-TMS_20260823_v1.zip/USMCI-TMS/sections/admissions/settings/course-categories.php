<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Admissions Settings: Course Categories
 * File : sections/admissions/settings/course-categories.php
 * ---------------------------------------------------------
 * The client finalizes the course categories used to group the
 * public website COURSES section (e.g. INHOUSE, STCW, TESDA,
 * MARINA). Add / rename / reorder / activate. Selected in
 * Course Management.
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/config/bootstrap.php';

require_access('settings');
if ($_SERVER['REQUEST_METHOD'] === 'POST') { require_edit('settings'); }

$pdo = db();

$flash = ['type' => null, 'message' => null];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = (string) ($_POST['action'] ?? '');
    try {
        if ($action === 'save') {
            $id    = (int) ($_POST['cat_id'] ?? 0);
            $code  = strtoupper(trim((string) ($_POST['code'] ?? '')));
            $name  = trim((string) ($_POST['name'] ?? ''));
            $desc  = trim((string) ($_POST['description'] ?? ''));
            $sort  = (int) ($_POST['sort_order'] ?? 0);

            if ($code === '' || $name === '') {
                $flash = ['type' => 'error', 'message' => 'Code and name are required.'];
            } else {
                $dup = $pdo->prepare("SELECT id FROM mnt_course_category WHERE code = :c AND id <> :id");
                $dup->execute(['c' => $code, 'id' => $id ?: 0]);
                if ($dup->fetch()) {
                    $flash = ['type' => 'error', 'message' => "A category with code '{$code}' already exists."];
                } elseif ($id > 0) {
                    $pdo->prepare("UPDATE mnt_course_category SET code = :c, name = :n, description = :d, sort_order = :s, updated_at = NOW() WHERE id = :id")
                        ->execute(['c' => $code, 'n' => $name, 'd' => $desc !== '' ? $desc : null, 's' => $sort, 'id' => $id]);
                    audit_log('settings', 'course_category_update', $id, "Category '{$name}' ({$code}) updated");
                    $flash = ['type' => 'success', 'message' => "Category '{$name}' updated."];
                } else {
                    $pdo->prepare("INSERT INTO mnt_course_category (code, name, description, sort_order, is_active, created_at) VALUES (:c, :n, :d, :s, 1, NOW())")
                        ->execute(['c' => $code, 'n' => $name, 'd' => $desc !== '' ? $desc : null, 's' => $sort]);
                    audit_log('settings', 'course_category_create', (int) $pdo->lastInsertId(), "Category '{$name}' ({$code}) created");
                    $flash = ['type' => 'success', 'message' => "Category '{$name}' added."];
                }
            }
        } elseif ($action === 'toggle') {
            $id = (int) ($_POST['cat_id'] ?? 0);
            $st = $pdo->prepare('SELECT code, name, is_active FROM mnt_course_category WHERE id = :id');
            $st->execute(['id' => $id]);
            $row = $st->fetch();
            if ($row) {
                $new = (int) $row['is_active'] ? 0 : 1;
                $pdo->prepare('UPDATE mnt_course_category SET is_active = :a, updated_at = NOW() WHERE id = :id')
                    ->execute(['a' => $new, 'id' => $id]);
                audit_log('settings', 'course_category_' . ($new ? 'activate' : 'deactivate'), $id, "Category '{$row['name']}' ({$row['code']}) " . ($new ? 'activated' : 'deactivated'));
                $flash = ['type' => 'success', 'message' => "Category '{$row['name']}' " . ($new ? 'activated.' : 'deactivated.')];
            } else {
                $flash = ['type' => 'error', 'message' => 'Category not found.'];
            }
        }
    } catch (Throwable $e) {
        error_log('course-categories.php: ' . $e->getMessage());
        $flash = ['type' => 'error', 'message' => 'Could not save the category.'];
    }
}

$cats = $pdo->query("SELECT * FROM mnt_course_category ORDER BY is_active DESC, sort_order, name")->fetchAll() ?: [];

$page = [
    'title'       => 'Course Categories | USMCI-TMS',
    'description' => 'Manage course categories',
    'bodyClass'   => 'admissions-page',
];
?>
<!DOCTYPE html>
<html lang="en">

<?php include INCLUDES_PATH . '/head.php'; ?>

<link rel="stylesheet" href="<?= e(base_url('assets/css/portal.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/workspace.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/inquiry-queue/assets/css/page.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/email-center/style.css?v=9')); ?>">

<body class="<?= e($page['bodyClass']); ?>">

    <?php include NAVBAR_PATH . '/index.php'; ?>

    <section class="portal-shell portal-shell--2col">

        <?php require ADMISSIONS_PATH . '/inquiry-queue/partials/sidebar.php'; ?>

        <main class="portal-content email-center">

            <header class="workspace-header">
                <div class="workspace-header__left">
                    <span class="section-badge">Administration</span>
                    <h1>Course Categories</h1>
                    <p>Finalize the categories used to group the public website Courses section (e.g. INHOUSE, STCW, TESDA, MARINA). Selected per course in Course Management.</p>
                </div>
            </header>

            <div id="ccFlash" data-type="<?= $flash['type']; ?>" style="display:none;"><?= htmlspecialchars($flash['message'] ?? '', ENT_QUOTES, 'UTF-8'); ?></div>

            <!-- add form -->
            <section class="email-card email-card--wide" style="margin-top:16px;">
                <h2>＋ Add Category</h2>
                <form method="post" action="<?= e(base_url('sections/admissions/settings/course-categories.php')); ?>" class="cert-form" style="display:flex;gap:10px;flex-wrap:wrap;margin-top:12px;">
                    <?= csrf_field(); ?>
                    <input type="hidden" name="action" value="save">
                    <input type="hidden" name="cat_id" value="0">
                    <input name="code" placeholder="CODE (e.g. TESDA)" style="width:120px;height:38px;padding:0 10px;border:1px solid #CBD5E1;border-radius:8px;font-family:inherit;" maxlength="50" required>
                    <input name="name" placeholder="Name (e.g. TESDA Courses)" style="flex:1;min-width:180px;height:38px;padding:0 10px;border:1px solid #CBD5E1;border-radius:8px;font-family:inherit;" maxlength="150" required>
                    <input name="sort_order" type="number" placeholder="Sort" style="width:80px;height:38px;padding:0 10px;border:1px solid #CBD5E1;border-radius:8px;font-family:inherit;" value="0">
                    <button type="submit" class="btn-primary" style="height:38px;padding:0 16px;border:none;border-radius:8px;font-weight:700;background:#0D8A72;color:#fff;cursor:pointer;">＋ Add</button>
                </form>
            </section>

            <!-- hidden edit forms -->
            <?php foreach ($cats as $c): ?>
                <form id="cf-<?= (int) $c['id']; ?>" method="post" action="<?= e(base_url('sections/admissions/settings/course-categories.php')); ?>">
                    <?= csrf_field(); ?>
                    <input type="hidden" name="action" value="save">
                    <input type="hidden" name="cat_id" value="<?= (int) $c['id']; ?>">
                </form>
            <?php endforeach; ?>

            <section class="email-card email-card--wide" style="margin-top:16px;">
                <h2>🗂 Categories</h2>
                <div class="table-responsive" style="margin-top:12px;">
                    <table class="inquiry-table">
                        <thead><tr><th style="width:100px;">Code</th><th>Name</th><th>Description</th><th style="width:70px;">Sort</th><th>Status</th><th style="width:210px;">Actions</th></tr></thead>
                        <tbody>
                            <?php if (!$cats): ?>
                                <tr><td colspan="6" style="text-align:center;color:#94A3B8;padding:22px;">No categories yet — add one above.</td></tr>
                            <?php endif; ?>
                            <?php foreach ($cats as $c): ?>
                                <tr style="<?= $c['is_active'] ? '' : 'opacity:.55;'; ?>">
                                    <td><input name="code" form="cf-<?= (int) $c['id']; ?>" value="<?= e($c['code']); ?>" style="width:90px;height:32px;padding:0 6px;border:1px solid #E2E8F0;border-radius:6px;font-family:inherit;font-size:.8rem;" maxlength="50"></td>
                                    <td><input name="name" form="cf-<?= (int) $c['id']; ?>" value="<?= e($c['name']); ?>" style="width:100%;min-width:140px;height:32px;padding:0 6px;border:1px solid #E2E8F0;border-radius:6px;font-family:inherit;font-size:.8rem;" maxlength="150"></td>
                                    <td><input name="description" form="cf-<?= (int) $c['id']; ?>" value="<?= e($c['description'] ?? ''); ?>" style="width:100%;min-width:160px;height:32px;padding:0 6px;border:1px solid #E2E8F0;border-radius:6px;font-family:inherit;font-size:.8rem;" maxlength="255"></td>
                                    <td><input name="sort_order" form="cf-<?= (int) $c['id']; ?>" type="number" value="<?= (int) $c['sort_order']; ?>" style="width:60px;height:32px;padding:0 6px;border:1px solid #E2E8F0;border-radius:6px;font-family:inherit;font-size:.8rem;"></td>
                                    <td><span class="status-badge <?= $c['is_active'] ? 'status-converted' : 'status-closed'; ?>"><?= $c['is_active'] ? 'Active' : 'Inactive'; ?></span></td>
                                    <td>
                                        <button type="submit" form="cf-<?= (int) $c['id']; ?>" class="btn-secondary btn-sm">💾 Save</button>
                                        <form method="post" action="<?= e(base_url('sections/admissions/settings/course-categories.php')); ?>" style="display:inline;">
                                            <?= csrf_field(); ?>
                                            <input type="hidden" name="action" value="toggle">
                                            <input type="hidden" name="cat_id" value="<?= (int) $c['id']; ?>">
                                            <button type="submit" class="btn-secondary btn-sm"><?= $c['is_active'] ? '🚫 Deactivate' : '✅ Activate'; ?></button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </section>

        </main>
    </section>

    <?php include INCLUDES_PATH . '/footer.php'; ?>
    <?php include INCLUDES_PATH . '/scripts.php'; ?>

    <script>
        (function () {
            function showToast(msg, type) { window.usmciToast(msg, type); }
            var fl = document.getElementById("ccFlash");
            if (fl && fl.textContent.trim() !== "") showToast(fl.textContent.trim(), fl.dataset.type);
        })();
    </script>

</body>
</html>
