<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Admissions Settings: Process Rules
 * File : sections/admissions/settings/process-rules.php
 * ---------------------------------------------------------
 * The property can change enrollment & certificate workflow
 * rules WITHOUT code changes. Every toggle is read at runtime
 * via process_rule() in config/helpers.php by:
 *   - enrollment.php      (status gate + forced-pending)
 *   - payments.php        (auto-enroll on payment)
 *   - payment_void/delete (auto-revert to pending)
 *   - certificates.php    (issuable list + issue gate + auto-complete)
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/config/bootstrap.php';

require_access('settings');
if ($_SERVER['REQUEST_METHOD'] === 'POST') { require_edit('settings'); }

$pdo = db();

$flash = ['type' => null, 'message' => null];

/* The canonical rule catalog. Defaults match the property's current policy. */
$rules = [
    [
        'key'   => 'rule_enroll_marketing_require_paid',
        'label' => 'Marketing / Endorser: payment required before Enrolled',
        'desc'  => 'Pending marketing-endorsed enrollments cannot be marked Enrolled until at least one payment is recorded. When OFF, they can be Enrolled with ₱0.',
        'group' => 'Enrollment',
        'default' => true,
    ],
    [
        'key'   => 'rule_enroll_company_require_paid',
        'label' => 'Company-Endorsed: payment required before Enrolled',
        'desc'  => 'Company-endorsed enrollments can normally be marked Enrolled without payment. Turn ON if the property wants to force payment first.',
        'group' => 'Enrollment',
        'default' => false,
    ],
    [
        'key'   => 'rule_auto_enroll_on_payment',
        'label' => 'Auto-update to Enrolled when a payment is recorded',
        'desc'  => 'A Pending enrollment becomes Enrolled automatically the moment any payment is recorded (no manual Status step).',
        'group' => 'Enrollment',
        'default' => true,
    ],
    [
        'key'   => 'rule_enroll_require_docs',
        'label' => 'Require documents before Enrolled',
        'desc'  => 'When ON, an enrollment cannot be marked Enrolled until the applicant has submitted ALL required documents (the "Docs: X/Y" indicator in the list turns amber/red).',
        'group' => 'Enrollment',
        'default' => false,
    ],
    [
        'key'   => 'rule_cert_marketing_require_paid',
        'label' => 'Marketing / Endorser: payment required before certificate',
        'desc'  => 'A certificate cannot be issued for a marketing-endorsed enrollment that has not been paid.',
        'group' => 'Certificates',
        'default' => true,
    ],
    [
        'key'   => 'rule_cert_company_allow_unpaid',
        'label' => 'Company-Endorsed: certificate allowed without payment',
        'desc'  => 'Company-endorsed enrollments may receive a certificate even when no payment was received. Turn OFF to require payment for company certificates too.',
        'group' => 'Certificates',
        'default' => true,
    ],
    [
        'key'   => 'rule_cert_require_enrolled_status',
        'label' => 'Certificate requires Enrolled / Completed status',
        'desc'  => 'When OFF, Pending enrollments may be issued certificates (subject to the payment rules above). When ON, only Enrolled or Completed enrollments qualify.',
        'group' => 'Certificates',
        'default' => false,
    ],
    [
        'key'   => 'rule_auto_complete_on_cert',
        'label' => 'Auto-update enrollment to Completed when a certificate is issued',
        'desc'  => 'Issuing a certificate marks the enrollment Completed automatically. Turn OFF to keep the status unchanged on issue.',
        'group' => 'Certificates',
        'default' => true,
    ],
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    try {
        $saved = 0;
        $upd = $pdo->prepare(
            'INSERT INTO mnt_system_setting (setting_key, setting_value, data_type, description, updated_at)
             VALUES (:k, :v, \'boolean\', :d, NOW())
             ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = NOW()'
        );
        foreach ($rules as $r) {
            $on = isset($_POST[$r['key']]) ? '1' : '0';
            $upd->execute(['k' => $r['key'], 'v' => $on, 'd' => $r['desc']]);
            $saved++;
        }
        audit_log('settings', 'process_rules_update', null, "$saved process rules saved");
        $flash = ['type' => 'success', 'message' => 'Process rules saved — the new rules are now active. Changes apply immediately.'];
    } catch (Throwable $e) {
        error_log('process-rules.php: ' . $e->getMessage());
        $flash = ['type' => 'error', 'message' => 'Could not save the process rules.'];
    }
}

/* Load current values */
$values = [];
$stmt = $pdo->query("SELECT setting_key, setting_value FROM mnt_system_setting WHERE setting_key LIKE 'rule\_%'");
foreach ($stmt->fetchAll() ?: [] as $row) {
    $values[$row['setting_key']] = in_array(strtolower(trim((string) $row['setting_value'])), ['1', 'true', 'on', 'yes'], true);
}

$page = [
    'title'       => 'Process Rules | USMCI-TMS',
    'description' => 'Enrollment & certificate workflow policy',
    'bodyClass'   => 'admissions-page',
];
?>
<!DOCTYPE html>
<html lang="en">

<?php include INCLUDES_PATH . '/head.php'; ?>

<link rel="stylesheet" href="<?= e(base_url('assets/css/portal.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/workspace.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/inquiry-queue/assets/css/page.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/email-center/style.css?v=9')); ?>">

<body class="<?= e($page['bodyClass']); ?>">

    <?php include NAVBAR_PATH . '/index.php'; ?>

    <section class="portal-shell portal-shell--2col">

        <?php require ADMISSIONS_PATH . '/inquiry-queue/partials/sidebar.php'; ?>

        <main class="portal-content email-center">

            <header class="workspace-header">
                <div class="workspace-header__left">
                    <span class="section-badge">Administration</span>
                    <h1>Process Rules</h1>
                    <p>Enrollment &amp; certificate workflow policy — changeable anytime without code changes.</p>
                </div>
            </header>

            <div id="prFlash" data-type="<?= $flash['type']; ?>" style="display:none;"><?= htmlspecialchars($flash['message'] ?? '', ENT_QUOTES, 'UTF-8'); ?></div>

            <form method="post" action="<?= e(base_url('sections/admissions/settings/process-rules.php')); ?>" id="rulesForm">
                <?= csrf_field(); ?>
                <input type="hidden" name="action" value="save_rules">

                <?php foreach (['Enrollment' => '🎓', 'Certificates' => '📜'] as $group => $icon): ?>
                <section class="email-card email-card--wide" style="margin-top:16px;">
                    <h2><?= $icon; ?> <?= $group; ?> Rules</h2>
                    <div style="display:flex;flex-direction:column;gap:14px;margin-top:12px;">
                        <?php foreach ($rules as $r):
                            if ($r['group'] !== $group) { continue; }
                            $on = array_key_exists($r['key'], $values) ? $values[$r['key']] : $r['default'];
                        ?>
                        <label class="pr-row" style="display:flex;gap:14px;align-items:flex-start;background:#F8FAFC;border:1px solid #E2E8F0;border-radius:12px;padding:14px 16px;cursor:pointer;">
                            <input type="checkbox" name="<?= e($r['key']); ?>" value="1" <?= $on ? 'checked' : ''; ?>
                                   style="width:20px;height:20px;margin-top:2px;accent-color:#0D8A72;flex-shrink:0;">
                            <span>
                                <strong style="display:block;font-size:.92rem;color:#0B3C5D;"><?= e($r['label']); ?></strong>
                                <span style="display:block;font-size:.8rem;color:#5B6472;margin-top:4px;line-height:1.45;"><?= e($r['desc']); ?></span>
                                <span style="display:inline-block;margin-top:8px;font-size:.72rem;font-weight:700;padding:3px 10px;border-radius:999px;<?= $on ? 'background:#D9F2EC;color:#0D8A72;' : 'background:#EDEFF2;color:#5B6472;'; ?>"
                                      class="pr-state"><?= $on ? 'ON — active' : 'OFF — inactive'; ?></span>
                            </span>
                        </label>
                        <?php endforeach; ?>
                    </div>
                </section>
                <?php endforeach; ?>

                <div style="margin-top:18px;text-align:right;">
                    <button type="submit" class="btn-primary" style="height:42px;padding:0 22px;border-radius:10px;font-weight:700;background:#0D8A72;color:#fff;border:none;cursor:pointer;">💾 Save Process Rules</button>
                </div>
            </form>

        </main>
    </section>

    <?php include INCLUDES_PATH . '/footer.php'; ?>
    <?php include INCLUDES_PATH . '/scripts.php'; ?>

    <script>
        (function () {
            function showToast(msg, type) { window.usmciToast(msg, type); }
            var fl = document.getElementById("prFlash");
            if (fl && fl.textContent.trim() !== "") showToast(fl.textContent.trim(), fl.dataset.type);
            /* live ON/OFF pill update when a switch is toggled */
            document.querySelectorAll(".pr-row input[type=checkbox]").forEach(function (cb) {
                cb.addEventListener("change", function () {
                    var pill = this.closest(".pr-row").querySelector(".pr-state");
                    if (this.checked) {
                        pill.textContent = "ON — active";
                        pill.style.background = "#D9F2EC"; pill.style.color = "#0D8A72";
                    } else {
                        pill.textContent = "OFF — inactive";
                        pill.style.background = "#EDEFF2"; pill.style.color = "#5B6472";
                    }
                });
            });
        })();
    </script>

</body>
</html>
