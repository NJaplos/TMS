<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Inquiry Queue
 * POST /actions/send_email.php
 * ---------------------------------------------------------
 * Fire-and-forget email delivery endpoint. The UI calls this
 * in the background AFTER showing the registration code, so
 * the admin never waits on SMTP. Requires the email_queue id
 * returned by convert.php.
 *
 * Expected POST: email_queue_id (int), csrf_token
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once dirname(__DIR__, 4) . '/config/bootstrap.php';

/* Staff only */
require_staff();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'POST required.']);
    exit;
}

csrf_check();

$queueId = filter_input(INPUT_POST, 'email_queue_id', FILTER_VALIDATE_INT);

if (!$queueId) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Missing email_queue_id.']);
    exit;
}

/* Send (fast timeout; returns quickly either way) */
$result = mailer_send_now($queueId);

echo json_encode([
    'success' => $result['success'],
    'message' => $result['message'],
]);
