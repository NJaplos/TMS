<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Inquiry Queue
 * POST /actions/convert.php
 * ---------------------------------------------------------
 * "Create Applicant Account" — creates the applicant stub,
 * generates the secure invitation token, and queues the
 * invitation email (which links to register.php).
 *
 * Expected POST fields:
 *   inquiry_id   — required
 *   csrf_token   — required
 *
 * Staff identity comes from the SESSION (never from the client).
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once dirname(__DIR__, 4) . '/config/bootstrap.php';
require_once ADMISSIONS_PATH . '/inquiry_invite.php';

/* Staff only */
require_staff();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'POST required.']);
    exit;
}

/* CSRF guard */
csrf_check();

$user = current_user();
$staffId = (int) ($user['id'] ?? 0);

$inquiryId = filter_input(INPUT_POST, 'inquiry_id', FILTER_VALIDATE_INT);

if (!$inquiryId) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Missing or invalid inquiry_id.']);
    exit;
}

$result = invite_applicant_to_enroll($inquiryId, $staffId);

if (!$result['success']) {
    http_response_code(422);
}

echo json_encode($result);
