<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Inquiry Queue
 * POST /actions/reply.php
 * ---------------------------------------------------------
 * Logs the staff reply in inquiry_reply, queues a real email
 * to the applicant via email_queue (sent next time
 * mailer/send_queued_emails.php runs), and advances the
 * inquiry to REPLIED.
 *
 * Expected POST fields:
 *   inquiry_id   — required
 *   message      — required, the reply text
 *   csrf_token   — required (sent automatically by script.js)
 *
 * Staff identity comes from the SESSION (never from the client).
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once dirname(__DIR__, 4) . '/config/bootstrap.php';

/* Staff only */
require_staff();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'POST required.']);
    exit;
}

/* CSRF guard */
csrf_check();

$user = current_user();
$staffId = (int) ($user['id'] ?? 0);

$inquiryId = filter_input(INPUT_POST, 'inquiry_id', FILTER_VALIDATE_INT);
$message = trim((string) ($_POST['message'] ?? ''));

if (!$inquiryId) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Missing or invalid inquiry_id.']);
    exit;
}

if ($message === '') {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Reply message cannot be empty.']);
    exit;
}

$messageLength = function_exists('mb_strlen') ? mb_strlen($message) : strlen($message);

if ($messageLength > 2000) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Reply is too long (max 2000 characters).']);
    exit;
}

/* Strip CR/LF from anything that will end up in an email header. */
$sanitizeHeader = static fn(string $value): string => str_replace(["\r", "\n"], ' ', trim($value));

try {
    $pdo = db();
    $pdo->beginTransaction();

    $inquiryStmt = $pdo->prepare(
        "SELECT id, inquiry_no, full_name, email, subject FROM inquiry WHERE id = :id FOR UPDATE"
    );
    $inquiryStmt->execute(['id' => $inquiryId]);
    $inquiry = $inquiryStmt->fetch();

    // Look up an active (unused, unexpired) registration code for this inquiry
    $regCode = null;
    $regStmt = $pdo->prepare(
        "SELECT registration_code
         FROM applicant_invitation
         WHERE inquiry_id = :iid
           AND registration_code IS NOT NULL
           AND used_at IS NULL
           AND expires_at > NOW()
         ORDER BY id DESC LIMIT 1"
    );
    $regStmt->execute(['iid' => $inquiryId]);
    $regRow = $regStmt->fetch();
    if ($regRow && $regRow['registration_code'] !== '') {
        $regCode = $regRow['registration_code'];
    }

    if (!$inquiry) {
        throw new RuntimeException('Inquiry not found.');
    }

    if ($inquiry['email'] === null || trim($inquiry['email']) === '') {
        throw new RuntimeException('This inquiry has no email address on file — cannot send a reply.');
    }

    $pdo->prepare(
        "INSERT INTO inquiry_reply (inquiry_id, sender_type, sender_id, message, created_at)
         VALUES (:inquiry_id, 'staff', :sender_id, :message, NOW())"
    )->execute([
        'inquiry_id' => $inquiryId,
        'sender_id' => $staffId,
        'message' => $message,
    ]);

    $repliedStatusId = $pdo->query(
        "SELECT id FROM mnt_inquiry_status WHERE code = 'REPLIED'"
    )->fetchColumn();

    $pdo->prepare(
        "UPDATE inquiry SET status_id = :status_id, assigned_to = :staff_id WHERE id = :id"
    )->execute([
        'status_id' => $repliedStatusId,
        'staff_id' => $staffId,
        'id' => $inquiryId,
    ]);

    $safeName = htmlspecialchars($inquiry['full_name'], ENT_QUOTES, 'UTF-8');
    $safeMessage = nl2br(htmlspecialchars($message, ENT_QUOTES, 'UTF-8'));
    $safeSubject = htmlspecialchars((string) $inquiry['subject'], ENT_QUOTES, 'UTF-8');
    $safeReplySubject = $sanitizeHeader((string) $inquiry['subject']);

    // "include code" checkbox: default ON when a code exists
    $includeCode = ($_POST['include_code'] ?? '1') !== '0' && $regCode !== null;

    $codeBlock = '';
    if ($includeCode && $regCode !== null) {
        $codeBlock = <<<HTML
        <div style="margin:18px 0;padding:16px 18px;background:#EAF6F2;border:2px dashed #0D8A72;border-radius:10px;">
            <p style="margin:0 0 6px;font-size:.78rem;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:#0B7A64;">Your one-time registration code</p>
            <p style="margin:0;font-size:1.3rem;font-weight:800;letter-spacing:.08em;color:#0B3C5D;">{$regCode}</p>
            <p style="margin:8px 0 0;font-size:.8rem;color:#64748B;">Enter this code on our login page under <strong>Create Account</strong> to set your password and access your dashboard. Single-use · valid 7 days.</p>
        </div>
    HTML;
    }

    $bodyHtml = <<<HTML
        <h2>Re: {$safeSubject}</h2>
        <p>Hi {$safeName},</p>
        <p>{$safeMessage}</p>
        {$codeBlock}
        <p style="color:#6B7280;font-size:.85rem;">
            Reference: {$inquiry['inquiry_no']}<br>
            — USMCI Admissions Office
        </p>
    HTML;

    $pdo->prepare(
        "INSERT INTO email_queue (recipient_email, subject, body_html, status, scheduled_at, created_at)
         VALUES (:email, :subject, :body, 'pending', NOW(), NOW())"
    )->execute([
        'email' => $inquiry['email'],
        'subject' => 'Re: ' . ($safeReplySubject !== '' ? $safeReplySubject : 'Your Admissions Inquiry'),
        'body' => $bodyHtml,
    ]);

    $emailQueueId = (int) $pdo->lastInsertId();

    $pdo->commit();

    /* Return instantly; the browser delivers the email in the
       background via send_email.php so the UI never waits. */
    echo json_encode([
        'success'        => true,
        'delivered'      => false,
        'email_queue_id' => $emailQueueId,
        'message'        => 'Reply saved and queued for delivery.',
    ]);
} catch (Throwable $exception) {
    if (isset($pdo)) {
        $pdo->rollBack();
    }
    error_log('reply.php failed: ' . $exception->getMessage());

    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Could not send the reply right now. Please try again.',
    ]);
}
