<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Inquiry Queue
 * GET /actions/detail.php?id=123
 * ---------------------------------------------------------
 * Returns one inquiry's full detail plus its reply thread,
 * for populating the modal when a staff member opens a row.
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once dirname(__DIR__, 4) . '/config/bootstrap.php';

/* Staff only */
require_staff();

header('Content-Type: application/json');

try {
    $inquiryId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

    if (!$inquiryId) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Missing or invalid inquiry id.']);
        exit;
    }

    $pdo = db();

    $stmt = $pdo->prepare(
        "SELECT
            i.id, i.inquiry_no, i.full_name, i.email, i.mobile_no,
            i.preferred_contact, i.course_interest, i.preferred_schedule,
            i.preferred_date, i.subject, i.message, i.created_at,
            s.code AS status_code, s.label AS status_label
         FROM inquiry i
         LEFT JOIN mnt_inquiry_status s ON s.id = i.status_id
         WHERE i.id = :id"
    );
    $stmt->execute(['id' => $inquiryId]);
    $inquiry = $stmt->fetch();

    if (!$inquiry) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'Inquiry not found.']);
        exit;
    }

    $repliesStmt = $pdo->prepare(
        "SELECT sender_type, sender_id, message, created_at
         FROM inquiry_reply
         WHERE inquiry_id = :id
         ORDER BY created_at ASC"
    );
    $repliesStmt->execute(['id' => $inquiryId]);

    /* Latest outbound email for this inquiry's recipient —
       shows whether the reply actually delivered. */
    $lastEmail = null;
    if ($inquiry['email'] !== null) {
        $emailStmt = $pdo->prepare(
            "SELECT recipient_email, subject, status, attempts, error_message, sent_at, created_at
             FROM email_queue
             WHERE recipient_email = :em
             ORDER BY id DESC LIMIT 1"
        );
        $emailStmt->execute(['em' => $inquiry['email']]);
        $lastEmail = $emailStmt->fetch() ?: null;
    }

    /* Active registration code (unused, unexpired) for this inquiry */
    $regCode = null;
    $regStmt = $pdo->prepare(
        "SELECT registration_code
         FROM applicant_invitation
         WHERE inquiry_id = :iid
           AND registration_code IS NOT NULL
           AND used_at IS NULL
           AND expires_at > NOW()
         ORDER BY id DESC LIMIT 1"
    );
    $regStmt->execute(['iid' => $inquiryId]);
    $regRow = $regStmt->fetch();
    if ($regRow && $regRow['registration_code'] !== '') {
        $regCode = $regRow['registration_code'];
    }

    echo json_encode([
        'success' => true,
        'inquiry' => $inquiry,
        'replies' => $repliesStmt->fetchAll(),
        'last_email' => $lastEmail,
        'registration_code' => $regCode,
    ]);
} catch (Throwable $exception) {
    error_log('detail.php failed: ' . $exception->getMessage());

    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Could not load inquiry detail.']);
}
