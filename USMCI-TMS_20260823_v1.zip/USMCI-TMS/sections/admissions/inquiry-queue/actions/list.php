<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Inquiry Queue
 * GET /actions/list.php
 * ---------------------------------------------------------
 * Returns inquiries as JSON for the queue table, with REAL
 * server-side pagination.
 *
 * Supports filters (all optional):
 *   ?status=NEW|REPLIED|INVITED|CONVERTED|CLOSED
 *   ?search=keyword          (inquiry no, name, email, mobile, course)
 *   ?date=YYYY-MM-DD         (inquiries created that day)
 *   ?aging=3                 (open inquiries older than N days — "Pending > 3 days")
 *   ?page=1                  (1-based page number, default 1)
 *   ?page_size=10            (10/25/50/100, default 10)
 *
 * Response:
 *   { success, inquiries[], total, page, page_size, total_pages }
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once dirname(__DIR__, 4) . '/config/bootstrap.php';

/* Staff only */
require_staff();

header('Content-Type: application/json');

try {
    $pdo = db();

    $status = trim((string) ($_GET['status'] ?? ''));
    $search = trim((string) ($_GET['search'] ?? ''));
    $date   = trim((string) ($_GET['date'] ?? ''));
    $aging  = max(0, (int) ($_GET['aging'] ?? 0));

    $page     = max(1, (int) ($_GET['page'] ?? 1));
    $pageSize = (int) ($_GET['page_size'] ?? 10);
    $pageSize = in_array($pageSize, [10, 25, 50, 100], true) ? $pageSize : 10;
    $offset   = ($page - 1) * $pageSize;

    /* ---- base WHERE clause ---- */
    $where  = ' WHERE 1 = 1';
    $params = [];

    if ($status !== '') {
        $where .= ' AND s.code = :status';
        $params['status'] = $status;
    }

    if ($search !== '') {
        // Distinct named params — native prepares (emulated
        // prepares OFF) reject a reused name like :kw.
        $where .= " AND (
                    i.inquiry_no LIKE :kw1
                 OR i.full_name LIKE :kw2
                 OR i.email LIKE :kw3
                 OR i.mobile_no LIKE :kw4
                 OR i.course_interest LIKE :kw5
                 OR i.subject LIKE :kw6
                 )";
        $kw = '%' . $search . '%';
        $params['kw1'] = $kw;
        $params['kw2'] = $kw;
        $params['kw3'] = $kw;
        $params['kw4'] = $kw;
        $params['kw5'] = $kw;
        $params['kw6'] = $kw;
    }

    if ($date !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
        $where .= ' AND DATE(i.created_at) = :date';
        $params['date'] = $date;
    }

    if ($aging > 0) {
        /* "Pending > N days" — open inquiries (NEW/REPLIED/INVITED or none)
           strictly older than N days. */
        $where .= " AND (s.code IS NULL OR s.code NOT IN ('CONVERTED','CLOSED'))
                    AND DATEDIFF(CURDATE(), DATE(i.created_at)) > :aging";
        $params['aging'] = $aging;
    }

    /* ---- total count (respects the same filters) ---- */
    $countSql = "SELECT COUNT(*)
                 FROM inquiry i
                 LEFT JOIN mnt_inquiry_status s ON s.id = i.status_id"
        . $where;

    $countStmt = $pdo->prepare($countSql);
    $countStmt->execute($params);
    $total = (int) $countStmt->fetchColumn();

    $totalPages = max(1, (int) ceil($total / $pageSize));

    if ($page > $totalPages) {
        $page = $totalPages;
        $offset = ($page - 1) * $pageSize;
    }

    /* ---- page rows ---- */
    $sql = "SELECT
                i.id,
                i.inquiry_no,
                i.full_name,
                i.email,
                i.mobile_no,
                i.course_interest,
                i.subject,
                i.message,
                i.created_at,
                DATEDIFF(CURDATE(), DATE(i.created_at)) AS age_days,
                s.code AS status_code,
                s.label AS status_label
            FROM inquiry i
            LEFT JOIN mnt_inquiry_status s ON s.id = i.status_id"
        . $where
        . ' ORDER BY i.created_at DESC'
        . ' LIMIT :limit OFFSET :offset';

    $stmt = $pdo->prepare($sql);

    foreach ($params as $key => $value) {
        $stmt->bindValue(':' . $key, $value);
    }

    $stmt->bindValue(':limit', $pageSize, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();

    echo json_encode([
        'success'     => true,
        'inquiries'   => $stmt->fetchAll(),
        'total'       => $total,
        'page'        => $page,
        'page_size'   => $pageSize,
        'total_pages' => $totalPages,
    ]);
} catch (Throwable $exception) {
    error_log('list.php failed: ' . $exception->getMessage());

    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Could not load inquiries. Make sure the mnt_inquiry_status migration has been applied (see database/migration_applicant_invitation.sql).',
    ]);
}
