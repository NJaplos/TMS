<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Module      : Admissions
 * Partial     : Inquiry Queue Summary
 * File        : summary.php
 * Version     : 2.0
 *
 * Description:
 * Live counts from the database (replaces the hardcoded
 * placeholder numbers). Falls back to zeros gracefully if
 * the mnt_inquiry_status migration has not been run yet.
 * ---------------------------------------------------------
 */

declare(strict_types=1);

$counts = ['total' => 0, 'today' => 0, 'awaiting' => 0, 'replied' => 0];

try {
    $pdo = db();

    $counts['total']   = (int) $pdo->query('SELECT COUNT(*) FROM inquiry')->fetchColumn();
    $counts['today']   = (int) $pdo->query('SELECT COUNT(*) FROM inquiry WHERE DATE(created_at) = CURDATE()')->fetchColumn();

    $awaitingStmt = $pdo->prepare(
        "SELECT COUNT(*)
         FROM inquiry i
         LEFT JOIN mnt_inquiry_status s ON s.id = i.status_id
         WHERE i.status_id IS NULL OR s.code = 'NEW'"
    );
    $awaitingStmt->execute();
    $counts['awaiting'] = (int) $awaitingStmt->fetchColumn();

    $repliedStmt = $pdo->prepare(
        "SELECT COUNT(*)
         FROM inquiry i
         LEFT JOIN mnt_inquiry_status s ON s.id = i.status_id
         WHERE s.code IN ('REPLIED', 'INVITED', 'CONVERTED')"
    );
    $repliedStmt->execute();
    $counts['replied'] = (int) $repliedStmt->fetchColumn();
} catch (Throwable $exception) {
    // Migration not run yet — keep zeros, do not break the page.
    error_log('summary.php counts failed: ' . $exception->getMessage());
}
?>

<section class="summary-cards">

    <article class="summary-card">

        <div class="summary-card__icon">
            📨
        </div>

        <div class="summary-card__content">

            <span class="summary-card__value">
                <?= number_format($counts['total']); ?>
            </span>

            <span class="summary-card__label">
                Total Inquiries
            </span>

        </div>

    </article>

    <article class="summary-card summary-card--today">

        <div class="summary-card__icon">
            📅
        </div>

        <div class="summary-card__content">

            <span class="summary-card__value">
                <?= number_format($counts['today']); ?>
            </span>

            <span class="summary-card__label">
                Today's Inquiries
            </span>

        </div>

    </article>

    <article class="summary-card summary-card--awaiting">

        <div class="summary-card__icon">
            ⏳
        </div>

        <div class="summary-card__content">

            <span class="summary-card__value">
                <?= number_format($counts['awaiting']); ?>
            </span>

            <span class="summary-card__label">
                Awaiting Reply
            </span>

        </div>

    </article>

    <article class="summary-card summary-card--replied">

        <div class="summary-card__icon">
            ✅
        </div>

        <div class="summary-card__content">

            <span class="summary-card__value">
                <?= number_format($counts['replied']); ?>
            </span>

            <span class="summary-card__label">
                Replied / Progressed
            </span>

        </div>

    </article>

</section>
