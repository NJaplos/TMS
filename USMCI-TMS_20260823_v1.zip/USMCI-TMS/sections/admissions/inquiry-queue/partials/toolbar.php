<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Module      : Admissions
 * Partial     : Inquiry Queue Toolbar
 * File        : toolbar.php
 * Version     : 2.0
 *
 * Description :
 * Search + status + date filtering, wired to actions/list.php
 * by script.js (2.0). The status dropdown is populated with
 * the inquiry status codes the system knows about.
 * ---------------------------------------------------------
 */

$queueStatusFilters = [
    ''          => 'All Statuses',
    'NEW'       => 'New',
    'REPLIED'   => 'Replied',
    'INVITED'   => 'Invited',
    'CONVERTED' => 'Converted',
    'CLOSED'    => 'Closed',
];
?>

<section class="workspace-toolbar">

    <div class="toolbar-left">

        <!-- Search -->

        <div class="toolbar-search">

            <input
                type="text"
                id="searchKeyword"
                placeholder="Search applicant, inquiry no., email or contact number...">

        </div>

    </div>

    <div class="toolbar-right">

        <!-- Status filter -->

        <select id="filterStatus" class="toolbar-select">

            <?php foreach ($queueStatusFilters as $code => $label): ?>

                <option value="<?= e($code); ?>">
                    <?= e($label); ?>
                </option>

            <?php endforeach; ?>

        </select>

        <!-- Date -->

        <input
            type="date"
            id="filterDate"
            class="toolbar-date">

        <!-- Pending > 3 days chip -->

        <button
            type="button"
            id="filterAging"
            class="chip-filter"
            title="Show only open inquiries older than 3 days">

            ⏱ Pending &gt; 3 days

        </button>

        <!-- Refresh -->

        <button
            type="button"
            class="btn-secondary"
            id="btnRefresh">

            Refresh

        </button>

    </div>

</section>
