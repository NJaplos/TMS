<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Module      : Admissions
 * Partial     : Inquiry Workspace Modal
 * File        : modal.php
 * Version     : 2.0
 *
 * Description :
 * Main operational workspace used by the Admissions Office
 * to process inquiries. Now wired to real data via
 * actions/detail.php, actions/reply.php, actions/convert.php
 * (see script.js) instead of static mock content.
 * ---------------------------------------------------------
 */
?>

<div
    id="inquiryModal"
    class="workspace-modal"
    style="display:none;">

    <div class="workspace-modal-container">

        <input type="hidden" id="modalInquiryId" value="">

        <!-- ==========================================
             Header
        =========================================== -->

        <div class="workspace-modal-header">

            <div>

                <h2>

                    Inquiry Details

                </h2>

                <span id="modalInquiryNo">

                    —

                </span>

            </div>

            <button
                type="button"
                id="closeInquiryModal"
                class="modal-close">

                &times;

            </button>

        </div>

        <!-- ==========================================
             Applicant Summary
        =========================================== -->

        <div class="workspace-modal-summary">

            <div>

                <label>Applicant</label>

                <strong id="modalApplicant">

                    —

                </strong>

            </div>

            <div>

                <label>Email</label>

                <strong id="modalEmail">

                    —

                </strong>

            </div>

            <div>

                <label>Mobile</label>

                <strong id="modalMobile">

                    —

                </strong>

            </div>

            <div>

                <label>Course</label>

                <strong id="modalCourse">

                    —

                </strong>

            </div>

        </div>

        <!-- ==========================================
             Navigation Tabs
        =========================================== -->

        <nav class="workspace-tabs">

            <button type="button" class="tab-button active" data-tab="inquiry">

                Inquiry

            </button>

            <button type="button" class="tab-button" data-tab="conversation">

                Conversation

            </button>

            <button type="button" class="tab-button" data-tab="reply">

                Reply

            </button>

            <button type="button" class="tab-button" data-tab="applicant">

                Applicant

            </button>

        </nav>

        <!-- ==========================================
             Workspace Body
        =========================================== -->

        <div class="workspace-modal-body">

            <!-- Tab: Inquiry -->
            <div class="workspace-tab-content" data-tab-content="inquiry">

                <h3>

                    Inquiry Information

                </h3>

                <table class="details-table">

                    <tr>
                        <th>Date Submitted</th>
                        <td id="modalDate">—</td>
                    </tr>

                    <tr>
                        <th>Preferred Schedule</th>
                        <td id="modalSchedule">—</td>
                    </tr>

                    <tr>
                        <th>Preferred Date</th>
                        <td id="modalPreferredDate">—</td>
                    </tr>

                    <tr>
                        <th>Subject</th>
                        <td id="modalSubject">—</td>
                    </tr>

                    <tr>
                        <th>Message</th>
                        <td id="modalMessage">—</td>
                    </tr>

                    <tr>
                        <th>Status</th>
                        <td id="modalStatus">—</td>
                    </tr>

                    <tr>
                        <th>Last Email</th>
                        <td id="modalEmailStatus">—</td>
                    </tr>

                </table>

            </div>

            <!-- Tab: Conversation (reply thread, oldest first) -->
            <div class="workspace-tab-content" data-tab-content="conversation" style="display:none;">

                <h3>Conversation</h3>

                <div id="modalConversationList" class="conversation-list">

                    <p class="conversation-empty">No replies yet.</p>

                </div>

            </div>

            <!-- Tab: Reply — the actual "Send Reply" form -->
            <div class="workspace-tab-content" data-tab-content="reply" style="display:none;">

                <h3>Send a Reply</h3>

                <p class="tab-hint">
                    This will be emailed to the applicant and logged in the
                    conversation thread above.
                </p>

                <div class="reply-code-option" id="replyCodeOption" style="display:none;">
                    <label class="reply-code-toggle">
                        <input type="checkbox" id="replyIncludeCode" checked>
                        <span>
                            <strong>Include the registration code in this reply</strong>
                            <small>The code appears as a highlighted block so the applicant can
                                  create their account.</small>
                        </span>
                    </label>
                    <div class="reply-code-preview">
                        <span class="reply-code-preview__label">Code that will be included:</span>
                        <code id="replyCodePreview">—</code>
                    </div>
                </div>

                <textarea
                    id="replyMessage"
                    rows="6"
                    maxlength="2000"
                    placeholder="Type your reply to the applicant here..."></textarea>

                <div id="replyFeedback" class="reply-feedback" style="display:none;"></div>

            </div>

            <!-- Tab: Applicant / Registration Code -->
            <div class="workspace-tab-content" data-tab-content="applicant" style="display:none;">

                <h3>Registration Code</h3>

                <p class="tab-hint">
                    Generate a single-use registration code for this applicant.
                    The code is emailed automatically (when SMTP is set) and
                    can also be copied and pasted into a reply below.
                </p>

                <div id="regCodeBox" class="reg-code-box" style="display:none;">
                    <div class="reg-code-box__label">Registration Code</div>
                    <div class="reg-code-box__value" id="regCodeValue">—</div>
                    <div class="reg-code-box__actions">
                        <button type="button" class="btn-secondary btn-sm" id="regCodeCopy">📋 Copy</button>
                        <button type="button" class="btn-secondary btn-sm" id="regCodeUseReply">✉️ Use in Reply</button>
                    </div>
                    <p class="reg-code-box__note" id="regCodeNote">Single-use · valid 7 days</p>
                </div>

                <div class="reg-code-box reg-code-box--empty" id="regCodeEmpty">
                    <p>No registration code generated for this inquiry yet.</p>
                </div>

            </div>

        </div>

        <!-- ==========================================
             Footer
        =========================================== -->

        <div class="workspace-modal-footer">

            <button
                type="button"
                id="closeInquiryModalBtn"
                class="btn-secondary">

                Close

            </button>

            <button
                type="button"
                id="btnSendReply"
                class="btn-primary">

                Send Reply

            </button>

            <button
                type="button"
                id="btnConvert"
                class="btn-primary">

                Create Registration Code

            </button>

        </div>

    </div>

</div>
