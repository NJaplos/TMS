<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Module      : Admissions
 * Partial     : Inquiry Queue Table
 * File        : table.php
 * Version     : 2.0
 *
 * Description :
 * Main operational table. Rows are rendered by script.js from
 * actions/list.php. Toolbar buttons now have unique ids so
 * they don't collide with the modal's buttons.
 * ---------------------------------------------------------
 */

$queueStatusOptions = [
    'NEW'       => 'New',
    'REPLIED'   => 'Replied',
    'INVITED'   => 'Invited',
    'CONVERTED' => 'Converted',
    'CLOSED'    => 'Closed',
];
?>

<section class="workspace-table">

    <!-- ==========================================
         Toolbar Actions
    =========================================== -->

    <div class="table-toolbar">

        <div class="table-toolbar__left">

            <button
                type="button"
                class="btn-primary"
                id="btnReplySelected">

                Reply

            </button>

            <button
                type="button"
                class="btn-secondary"
                id="btnAssign">

                Assign Staff

            </button>

            <button
                type="button"
                class="btn-secondary"
                id="btnConvertSelected">

                Create Registration Code

            </button>

        </div>

        <div class="table-toolbar__right">

            <button
                type="button"
                class="btn-secondary"
                id="btnExport">

                Export CSV

            </button>

            <button
                type="button"
                class="btn-secondary"
                id="btnPrint">

                Print

            </button>

            <button
                type="button"
                class="btn-secondary"
                id="btnRefreshTable">

                Refresh

            </button>

        </div>

    </div>

    <!-- ==========================================
         Inquiry Table
    =========================================== -->

    <div class="table-responsive">

        <table class="inquiry-table">

            <thead>

                <tr>

                    <th width="40">
                        <input type="checkbox" id="checkAllRows">
                    </th>

                    <th>Inquiry No.</th>

                    <th>Date</th>

                    <th>Age</th>

                    <th>Applicant</th>

                    <th>Email</th>

                    <th>Mobile</th>

                    <th>Course</th>

                    <th>Status</th>

                    <th width="110">Actions</th>

                </tr>

            </thead>

            <tbody id="inquiryTableBody">

                <!-- Rows are rendered by script.js from actions/list.php.
                     See partials/empty-state.php for the "no results" state. -->

            </tbody>

        </table>

        <!-- Spacer so the last row is fully visible above the
             bottom edge / scrollbar of the scroll region. -->
        <div class="table-scroll-pad" aria-hidden="true"></div>

    </div>

    <?php require INQUIRY_QUEUE_PARTIALS . '/empty-state.php'; ?>

</section>
