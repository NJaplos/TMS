<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Module      : Admissions
 * Partial     : Inquiry Queue Header
 * File        : header.php
 * Version     : 2.0
 *
 * Description :
 * Workspace header with title, subtitle and the signed-in
 * user's name — matches the admissions content typography.
 * ---------------------------------------------------------
 */

$hdrUser = current_user();
?>

<section class="workspace-header">

    <div class="workspace-header__left">

        <span class="section-badge">
            Admissions
        </span>

        <h1>
            Inquiry Queue
        </h1>

        <p>
            Manage incoming admissions inquiries, review
            applicant concerns, respond to inquiries and
            prepare applicants for enrollment.
        </p>

    </div>

    <div class="workspace-header__right">

        <div class="user-chip">

            <span class="user-chip__avatar">
                👤
            </span>

            <span class="user-chip__text">
                <strong>
                    <?= e($hdrUser['full_name'] ?? 'Staff'); ?>
                </strong>
                <small>
                    <?= e($hdrUser['role_code'] ?? 'User'); ?>
                </small>
            </span>

        </div>

        <button
            type="button"
            class="btn-refresh">

            ⟳ Refresh

        </button>

    </div>

</section>
