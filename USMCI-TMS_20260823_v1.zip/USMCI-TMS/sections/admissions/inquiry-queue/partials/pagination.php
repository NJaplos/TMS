<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Module      : Admissions
 * Partial     : Inquiry Queue Pagination
 * File        : pagination.php
 * Version     : 3.0
 *
 * Description :
 * Server-side pagination footer. The initial values are
 * rendered here; script.js then drives the buttons from the
 * list.php JSON response (total / page / page_size).
 * ---------------------------------------------------------
 */

declare(strict_types=1);

$totalInquiries = 0;

try {
    $totalInquiries = (int) db()->query('SELECT COUNT(*) FROM inquiry')->fetchColumn();
} catch (Throwable $exception) {
    // Ignore — keep 0 if the DB isn't ready yet.
}

$currentPage = max(1, (int) ($_GET['page'] ?? 1));
$pageSize    = (int) ($_GET['page_size'] ?? 10);
$pageSize    = in_array($pageSize, [10, 25, 50, 100], true) ? $pageSize : 10;

$pageCount = max(1, (int) ceil($totalInquiries / $pageSize));
$fromRow   = $totalInquiries === 0 ? 0 : (($currentPage - 1) * $pageSize) + 1;
$toRow     = min($currentPage * $pageSize, $totalInquiries);
?>

<section class="workspace-pagination" id="queuePagination">

    <div class="pagination-left">

        <span id="paginationSummary">

            Showing

            <strong id="paginationFrom"><?= number_format($fromRow); ?></strong>

            -

            <strong id="paginationTo"><?= number_format($toRow); ?></strong>

            of

            <strong id="paginationTotal"><?= number_format($totalInquiries); ?></strong>

            inquiries

        </span>

    </div>

    <div class="pagination-center">

        <label for="pageSize">

            Rows per page

        </label>

        <select id="pageSize">

            <?php foreach ([10, 25, 50, 100] as $size): ?>
                <option value="<?= $size; ?>" <?= $size === $pageSize ? 'selected' : ''; ?>><?= $size; ?></option>
            <?php endforeach; ?>

        </select>

    </div>

    <div class="pagination-right">

        <button
            type="button"
            class="btn-page"
            id="pageFirst"
            title="First page"
            <?= $currentPage <= 1 ? 'disabled' : ''; ?>>

            ⏮

        </button>

        <button
            type="button"
            class="btn-page"
            id="pagePrev"
            title="Previous page"
            <?= $currentPage <= 1 ? 'disabled' : ''; ?>>

            ◀

        </button>

        <span class="page-number">

            Page

            <strong id="paginationCurrent"><?= number_format($currentPage); ?></strong>

            of

            <strong id="paginationPages"><?= number_format($pageCount); ?></strong>

        </span>

        <button
            type="button"
            class="btn-page"
            id="pageNext"
            title="Next page"
            <?= $currentPage >= $pageCount ? 'disabled' : ''; ?>>

            ▶

        </button>

        <button
            type="button"
            class="btn-page"
            id="pageLast"
            title="Last page"
            <?= $currentPage >= $pageCount ? 'disabled' : ''; ?>>

            ⏭

        </button>

    </div>

</section>
