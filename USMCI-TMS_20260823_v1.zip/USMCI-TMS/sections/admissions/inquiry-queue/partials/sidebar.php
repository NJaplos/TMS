<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Staff sidebar (unified portal sidebar)
 * ---------------------------------------------------------
 * Delegates to includes/portal-sidebar.php so staff and
 * trainee dashboards share the EXACT same sidebar look.
 * ---------------------------------------------------------
 */

$currentUri = $_SERVER['REQUEST_URI'] ?? '';
$queueUser = current_user();

$portalNav = [
    ['href' => base_url('sections/admissions/admin/index.php'), 'icon' => '🏠', 'label' => 'Dashboard', 'desc' => 'KPIs & recent inquiries', 'active' => strpos($currentUri, '/admin/index.php') !== false, 'key' => 'dashboard'],
    ['href' => base_url('sections/admissions/inquiry-queue/index.php'), 'icon' => '📨', 'label' => 'Inquiry Queue', 'desc' => 'Review & reply to inquiries', 'active' => strpos($currentUri, '/inquiry-queue/') !== false, 'key' => 'inquiry_queue'],
    ['href' => base_url('sections/admissions/admin/applicants.php'), 'icon' => '👥', 'label' => 'Applicants', 'desc' => 'Applicant records', 'active' => strpos($currentUri, '/admin/applicants.php') !== false, 'key' => 'applicants'],
    ['href' => base_url('sections/admissions/admin/courses.php'), 'icon' => '📅', 'label' => 'Course Management', 'desc' => 'Add & manage courses', 'active' => strpos($currentUri, '/admin/courses.php') !== false, 'key' => 'courses'],
    ['href' => base_url('sections/admissions/admin/batches.php'), 'icon' => '🗓️', 'label' => 'Training Batches', 'desc' => 'Schedule batches & dates', 'active' => strpos($currentUri, '/admin/batches.php') !== false, 'key' => 'batches'],
    ['href' => base_url('sections/admissions/admin/maintenance.php'), 'icon' => '🏢', 'label' => 'Instructors & Venues', 'desc' => 'Setup venues & instructors', 'active' => strpos($currentUri, '/admin/maintenance.php') !== false, 'key' => 'instructors'],
    ['href' => base_url('sections/admissions/admin/companies.php'), 'icon' => '🏭', 'label' => 'Affiliated Companies', 'desc' => 'Endorsing companies & agencies', 'active' => strpos($currentUri, '/admin/companies.php') !== false, 'key' => 'companies'],
    ['href' => base_url('sections/admissions/admin/enrollment.php'), 'icon' => '📝', 'label' => 'Enrollment', 'desc' => 'Track enrollments', 'active' => strpos($currentUri, '/admin/enrollment.php') !== false, 'key' => 'enrollment'],
    ['href' => base_url('sections/admissions/admin/payments.php'), 'icon' => '💰', 'label' => 'Payments', 'desc' => 'Record & track payments', 'active' => strpos($currentUri, '/admin/payments.php') !== false, 'key' => 'payments'],
    ['href' => base_url('sections/admissions/admin/certificates.php'), 'icon' => '📜', 'label' => 'Certificates', 'desc' => 'Issue & verify certificates', 'active' => strpos($currentUri, '/admin/certificates.php') !== false, 'key' => 'certificates'],
    ['href' => base_url('sections/admissions/admin/reports.php'), 'icon' => '📊', 'label' => 'Reports', 'desc' => 'Operational analytics', 'active' => strpos($currentUri, '/admin/reports.php') !== false, 'key' => 'reports'],
    ['href' => base_url('sections/admissions/settings/index.php'), 'icon' => '⚙', 'label' => 'Admissions Settings', 'desc' => 'Config & email center', 'active' => strpos($currentUri, '/settings/') !== false || strpos($currentUri, '/email-center/') !== false, 'key' => 'settings'],
    ['href' => base_url('sections/admissions/admin/staff-accounts.php'), 'icon' => '👤', 'label' => 'Staff Accounts', 'desc' => 'Manage staff & admins', 'active' => strpos($currentUri, '/admin/staff-accounts.php') !== false, 'key' => 'staff_accounts'],
];

/* RBAC: filter the sidebar by the user's role permissions */
$portalNav = array_values(array_filter($portalNav, function ($item) {
    return user_can($item['key']);
}));

$portalUser = [
    'name'  => $queueUser['full_name'] ?? 'Staff Member',
    'role_label' => $queueUser['role_code'] ?? 'User',
];

include INCLUDES_PATH . '/portal-sidebar.php';
