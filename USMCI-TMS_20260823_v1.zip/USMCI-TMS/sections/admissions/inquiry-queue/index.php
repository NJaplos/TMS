<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Module      : Admissions
 * Page        : Inquiry Queue
 * File        : index.php
 * Version     : 3.1
 *
 * Description :
 * Admissions Inquiry Queue Workspace (staff only).
 *
 * Changes in 3.1:
 *   - require_login() — the queue is now behind authentication.
 *   - Loads the dedicated queue sidebar partial
 *     (partials/sidebar.php) styled to match the Admissions
 *     sidebar, instead of the public "portal" sidebar.
 *   - Exposes the CSRF token to script.js for POST endpoints.
 * ---------------------------------------------------------
 */

declare(strict_types=1);

/* ==========================================================
   Load Global Framework
========================================================== */

require_once dirname(__DIR__, 3) . '/config/bootstrap.php';

/* ==========================================================
   STAFF ONLY — no session, no queue.
========================================================== */

require_access('inquiry_queue');
if ($_SERVER['REQUEST_METHOD'] === 'POST') { require_edit('inquiry_queue'); }

/* ==========================================================
   Page Configuration
========================================================== */

$page = [
    'title'       => 'Admissions Inquiry Queue | USMCI-TMS',
    'description' => 'Admissions Inquiry Queue Workspace',
    'bodyClass'   => 'admissions-page',
    'currentUser' => current_user(),
];

?>

<!DOCTYPE html>

<html lang="en">

<?php include INCLUDES_PATH . '/head.php'; ?>

<!-- ==========================================================
     Stylesheets
========================================================== -->

<link
    rel="stylesheet"
    href="<?= base_url('assets/css/portal.css?v=' . ASSET_VERSION); ?>">

<link
    rel="stylesheet"
    href="<?= ADMISSIONS_URL; ?>/workspace.css?v=<?= ASSET_VERSION; ?>">

<link
    rel="stylesheet"
    href="<?= INQUIRY_QUEUE_URL; ?>/style.css?v=9">

<body class="<?= e($page['bodyClass']); ?>">

    <!-- =====================================================
         Main Navigation
    ====================================================== -->

    <?php include NAVBAR_PATH . '/index.php'; ?>

    <!-- =====================================================
         Admissions Workspace
    ====================================================== -->

    <section class="portal-shell portal-shell--2col">

        <!-- ==========================================
             Queue Sidebar (same design language as the
             Admissions sidebar — see partials/sidebar.php)
        =========================================== -->

        <?php require INQUIRY_QUEUE_PARTIALS . '/sidebar.php'; ?>

        <!-- ==========================================
             Workspace Content
        =========================================== -->

        <main class="portal-content">

            <?php require INQUIRY_QUEUE_PARTIALS . '/header.php'; ?>

            <?php if (!smtp_is_configured()): ?>
                <div class="smtp-warning">
                    <strong>⚠️ Email delivery is not configured.</strong>
                    Replies &amp; invitations will be <em>saved</em> in the queue, but NOT delivered
                    until you set up SMTP in the
                    <a href="<?= e(base_url('sections/admissions/email-center/index.php')); ?>">Email Center</a>.
                </div>
            <?php endif; ?>

            <?php require INQUIRY_QUEUE_PARTIALS . '/summary.php'; ?>

            <?php require INQUIRY_QUEUE_PARTIALS . '/toolbar.php'; ?>

            <?php require INQUIRY_QUEUE_PARTIALS . '/table.php'; ?>

            <?php require INQUIRY_QUEUE_PARTIALS . '/pagination.php'; ?>

        </main>

    </section>

    <!-- =====================================================
         Toast notifications
    ====================================================== -->

    <div id="toastContainer" class="toast-container" aria-live="polite"></div>

    <!-- =====================================================
         Inquiry Queue Modal
    ====================================================== -->

    <?php require INQUIRY_QUEUE_PARTIALS . '/loading.php'; ?>

    <?php require INQUIRY_QUEUE_PARTIALS . '/modal.php'; ?>

    <!-- =====================================================
         Footer
    ====================================================== -->

    <?php include INCLUDES_PATH . '/footer.php'; ?>

    <?php include INCLUDES_PATH . '/scripts.php'; ?>

    <!-- =====================================================
         JavaScript
    ====================================================== -->

    <script>
        // CSRF token shared with the queue's fetch() endpoints.
        window.USMCI_CSRF = <?= json_encode(csrf_token()); ?>;
        window.USMCI_USER = <?= json_encode([
            'id' => (int) ($page['currentUser']['id'] ?? 0),
            'name' => $page['currentUser']['full_name'] ?? '',
        ]); ?>;
    </script>

    <script src="<?= ADMISSIONS_URL; ?>/script.js"></script>

    <script src="<?= INQUIRY_QUEUE_URL; ?>/script.js"></script>

</body>

</html>
