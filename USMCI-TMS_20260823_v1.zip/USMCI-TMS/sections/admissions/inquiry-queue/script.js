/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Module      : Admissions Inquiry Queue
 * File        : script.js
 * Version     : 2.0
 *
 * Wires the workspace to real data:
 *   - loads inquiries from actions/list.php (with search /
 *     status / date filters)
 *   - opens the modal with real detail from actions/detail.php
 *   - Send Reply posts to actions/reply.php (queues a real email)
 *   - Create Applicant Account posts to actions/convert.php
 *   - every POST carries the CSRF token (window.USMCI_CSRF,
 *     injected by index.php)
 * ---------------------------------------------------------
 */

(() => {
    "use strict";

    const ACTIONS_BASE = window.location.pathname.replace(/\/[^/]*$/, "") + "/actions";
    const CSRF = window.USMCI_CSRF || "";

    const tableBody = document.getElementById("inquiryTableBody");
    const emptyState = document.getElementById("emptyState");
    const modal = document.getElementById("inquiryModal");
    const closeButtons = [
        document.getElementById("closeInquiryModal"),
        document.getElementById("closeInquiryModalBtn"),
    ];

    let currentInquiryId = null;
    let currentRows = [];
    const selectedIds = new Set();

    // Pagination state (kept in sync with list.php response)
    let currentPage = 1;
    let currentPageSize = 10;
    let totalInquiries = 0;
    let totalPages = 1;

    // ------------------------------------------------------
    // Helpers
    // ------------------------------------------------------
    function statusBadgeClass(code) {
        const map = {
            NEW: "status-new",
            REPLIED: "status-replied",
            INVITED: "status-invited",
            CONVERTED: "status-converted",
            CLOSED: "status-closed",
        };
        return map[code] || "status-new";
    }

    function escapeHtml(value) {
        const div = document.createElement("div");
        div.textContent = value ?? "";
        return div.innerHTML;
    }

    function formatDate(value) {
        if (!value) return "—";
        const date = new Date(value.replace(" ", "T"));
        if (Number.isNaN(date.getTime())) return value;
        return date.toLocaleDateString("en-US", { year: "numeric", month: "short", day: "numeric" });
    }

    // ------------------------------------------------------
    // Toast notifications — shared UDS component
    // (assets/js/usmci-toast.js → window.usmciToast)
    // ------------------------------------------------------
    function showToast(message, type, title, duration) {
        window.usmciToast(message, type, title);
    }

    function buildQuery() {
        const params = new URLSearchParams();

        const status = document.getElementById("filterStatus")?.value || "";
        const search = document.getElementById("searchKeyword")?.value.trim() || "";
        const date = document.getElementById("filterDate")?.value || "";
        const agingChip = document.getElementById("filterAging");
        const aging = agingChip && agingChip.classList.contains("active") ? 3 : 0;

        if (status) params.set("status", status);
        if (search) params.set("search", search);
        if (date) params.set("date", date);
        if (aging) params.set("aging", String(aging));

        params.set("page", String(currentPage));
        params.set("page_size", String(currentPageSize));

        const qs = params.toString();
        return qs ? `?${qs}` : "";
    }

    // ------------------------------------------------------
    // Load + render the table
    // ------------------------------------------------------
    async function loadInquiries() {
        try {
            const response = await fetch(`${ACTIONS_BASE}/list.php${buildQuery()}`);
            const data = await response.json();

            if (!data.success) {
                console.error("Failed to load inquiries:", data.message);
                return;
            }

            totalInquiries = data.total || 0;
            totalPages = data.total_pages || 1;
            currentPage = data.page || 1;
            currentPageSize = data.page_size || currentPageSize;

            renderTable(data.inquiries);
            renderPagination();
        } catch (error) {
            console.error("loadInquiries error:", error);
        }
    }

    /**
     * Refresh the pagination footer (summary + button states)
     * from the current list.php response.
     */
    function renderPagination() {
        const fromRow = totalInquiries === 0 ? 0 : (currentPage - 1) * currentPageSize + 1;
        const toRow = Math.min(currentPage * currentPageSize, totalInquiries);

        const el = (id) => document.getElementById(id);
        if (el("paginationFrom")) el("paginationFrom").textContent = fromRow.toLocaleString();
        if (el("paginationTo")) el("paginationTo").textContent = toRow.toLocaleString();
        if (el("paginationTotal")) el("paginationTotal").textContent = totalInquiries.toLocaleString();
        if (el("paginationCurrent")) el("paginationCurrent").textContent = currentPage.toLocaleString();
        if (el("paginationPages")) el("paginationPages").textContent = totalPages.toLocaleString();

        const canPrev = currentPage > 1;
        const canNext = currentPage < totalPages;

        const setBtn = (id, enabled) => {
            const btn = el(id);
            if (!btn) return;
            btn.disabled = !enabled;
            btn.classList.toggle("is-disabled", !enabled);
        };

        setBtn("pageFirst", canPrev);
        setBtn("pagePrev", canPrev);
        setBtn("pageNext", canNext);
        setBtn("pageLast", canNext);
    }

    /** Go to a page; resets to page 1 when filters change. */
    function goToPage(page) {
        const target = Math.min(Math.max(1, page), totalPages);
        if (target === currentPage) return;
        currentPage = target;
        loadInquiries();
    }

    function resetToFirstPage() {
        currentPage = 1;
        loadInquiries();
    }

    function renderTable(inquiries) {
        tableBody.innerHTML = "";
        currentRows = inquiries;
        selectedIds.clear();

        const checkAll = document.getElementById("checkAllRows");
        if (checkAll) checkAll.checked = false;

        if (inquiries.length === 0) {
            emptyState.style.display = "flex";
            return;
        }

        emptyState.style.display = "none";

        for (const inquiry of inquiries) {
            const row = document.createElement("tr");

            const ageDays = parseInt(inquiry.age_days, 10) || 0;
            const ageClass = ageDays > 7 ? "age-red" : ageDays >= 3 ? "age-amber" : "age-ok";

            row.innerHTML = `
                <td><input type="checkbox" class="row-check" data-id="${inquiry.id}"></td>
                <td>${escapeHtml(inquiry.inquiry_no)}</td>
                <td>${formatDate(inquiry.created_at)}</td>
                <td><span class="age-badge ${ageClass}">${ageDays}d</span></td>
                <td>${escapeHtml(inquiry.full_name)}</td>
                <td>${escapeHtml(inquiry.email)}</td>
                <td>${escapeHtml(inquiry.mobile_no)}</td>
                <td>${escapeHtml(inquiry.course_interest || "—")}</td>
                <td>
                    <span class="status-badge ${statusBadgeClass(inquiry.status_code)}">
                        ${escapeHtml(inquiry.status_label || "New")}
                    </span>
                </td>
                <td>
                    <button class="btn-table" data-open="${inquiry.id}">View</button>
                </td>
            `;

            tableBody.appendChild(row);
        }
    }

    function selectedInquiryIds() {
        return [...selectedIds];
    }

    function firstSelectedRow() {
        return currentRows.find((r) => selectedIds.has(String(r.id))) || null;
    }

    // ------------------------------------------------------
    // Modal: open + populate with real detail
    // ------------------------------------------------------
    async function openInquiry(inquiryId) {
        try {
            const response = await fetch(`${ACTIONS_BASE}/detail.php?id=${encodeURIComponent(inquiryId)}`);
            const data = await response.json();

            if (!data.success) {
                alert(data.message || "Could not load this inquiry.");
                return;
            }

            populateModal(data.inquiry, data.replies, data.last_email, data.registration_code);
            currentInquiryId = inquiryId;
            document.getElementById("modalInquiryId").value = inquiryId;
            modal.style.display = "flex";
            switchTab("inquiry");
        } catch (error) {
            console.error("openInquiry error:", error);
            alert("Something went wrong loading this inquiry. Please try again.");
        }
    }

    let currentRegCode = null;

    function populateModal(inquiry, replies, lastEmail, regCode) {
        currentRegCode = regCode || null;

        // Show/hide the "include code" option in the Reply tab
        const opt = document.getElementById("replyCodeOption");
        const preview = document.getElementById("replyCodePreview");
        const chk = document.getElementById("replyIncludeCode");
        if (opt) opt.style.display = currentRegCode ? "block" : "none";
        if (preview) preview.textContent = currentRegCode || "—";
        if (chk) chk.checked = !!currentRegCode;
        document.getElementById("modalInquiryNo").textContent = inquiry.inquiry_no;
        document.getElementById("modalApplicant").textContent = inquiry.full_name;
        document.getElementById("modalEmail").textContent = inquiry.email;
        document.getElementById("modalMobile").textContent = inquiry.mobile_no || "—";
        document.getElementById("modalCourse").textContent = inquiry.course_interest || "—";
        document.getElementById("modalDate").textContent = formatDate(inquiry.created_at);
        document.getElementById("modalSchedule").textContent = inquiry.preferred_schedule || "—";
        document.getElementById("modalPreferredDate").textContent = inquiry.preferred_date || "—";
        document.getElementById("modalSubject").textContent = inquiry.subject || "—";
        document.getElementById("modalMessage").textContent = inquiry.message || "—";
        document.getElementById("modalStatus").textContent = inquiry.status_label || "New";

        // Delivery status of the latest email to this recipient
        const emailStatusEl = document.getElementById("modalEmailStatus");
        if (emailStatusEl) {
            if (lastEmail) {
                const st = (lastEmail.status || "unknown").toUpperCase();
                const sentAt = lastEmail.sent_at ? " at " + (lastEmail.sent_at || "") : "";
                emailStatusEl.textContent = st + sentAt;
                emailStatusEl.className = "email-delivery email-delivery--" + (lastEmail.status || "unknown");
                if (lastEmail.status === "failed" && lastEmail.error_message) {
                    emailStatusEl.title = lastEmail.error_message;
                }
            } else {
                emailStatusEl.textContent = "No email sent yet";
                emailStatusEl.className = "email-delivery email-delivery--none";
            }
        }

        const list = document.getElementById("modalConversationList");

        if (!replies || replies.length === 0) {
            list.innerHTML = '<p class="conversation-empty">No replies yet.</p>';
        } else {
            list.innerHTML = replies.map((reply) => `
                <div class="conversation-item conversation-item--${escapeHtml(reply.sender_type)}">
                    <div class="conversation-item__meta">
                        <strong>${reply.sender_type === "staff" ? "Admissions Office" : escapeHtml(inquiry.full_name)}</strong>
                        <span>${formatDate(reply.created_at)}</span>
                    </div>
                    <p>${escapeHtml(reply.message)}</p>
                </div>
            `).join("");
        }

        document.getElementById("replyMessage").value = "";
        const feedback = document.getElementById("replyFeedback");
        feedback.style.display = "none";
        feedback.textContent = "";
    }

    function closeModal() {
        modal.style.display = "none";
        currentInquiryId = null;
    }

    // ------------------------------------------------------
    // Tabs
    // ------------------------------------------------------
    function switchTab(tabName) {
        document.querySelectorAll(".tab-button").forEach((btn) => {
            btn.classList.toggle("active", btn.dataset.tab === tabName);
        });

        document.querySelectorAll("[data-tab-content]").forEach((panel) => {
            panel.style.display = panel.dataset.tabContent === tabName ? "block" : "none";
        });
    }

    // ------------------------------------------------------
    // POST helper with CSRF
    // ------------------------------------------------------
    async function postForm(url, params) {
        const body = new URLSearchParams(params);
        body.set("csrf_token", CSRF);

        return fetch(url, {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body,
        });
    }

    // ------------------------------------------------------
    // Send Reply — the actual email-sending integration
    // ------------------------------------------------------
    async function sendReply() {
        const message = document.getElementById("replyMessage").value.trim();
        const feedback = document.getElementById("replyFeedback");

        if (!currentInquiryId) {
            showToast("Open an inquiry first before replying.", "warning");
            return;
        }

        if (message === "") {
            showToast("Please type a reply before sending — the message field is required.", "warning", "Missing reply");
            showReplyFeedback("Please type a reply before sending.", true);
            return;
        }

        const sendButton = document.getElementById("btnSendReply");
        sendButton.disabled = true;
        sendButton.textContent = "Sending...";

        // Show a "sending" toast first so the user sees the state change
        showToast("Saving your reply…", "sending", "Please wait");

        try {
            const includeCode = document.getElementById("replyIncludeCode") && document.getElementById("replyIncludeCode").checked ? "1" : "0";
            const response = await postForm(`${ACTIONS_BASE}/reply.php`, {
                inquiry_id: currentInquiryId,
                message: message,
                include_code: includeCode,
            });

            const data = await response.json();
            showReplyFeedback(data.message, !data.success);

            if (data.success) {
                showToast(data.message, "success", "Reply saved", 6000);

                // Background delivery so the UI stays instant
                if (data.email_queue_id) {
                    postForm(`${ACTIONS_BASE}/send_email.php`, { email_queue_id: data.email_queue_id })
                        .then(r => r.json())
                        .then(res => {
                            if (res && res.success) {
                                showToast("Reply delivered to the applicant.", "success", "Email sent", 8000);
                            } else if (res && res.message) {
                                showToast(res.message, "warning", "Email queued", 8000);
                            }
                        })
                        .catch(() => {});
                }

                await openInquiry(currentInquiryId); // refresh conversation + status
                switchTab("conversation");
                await loadInquiries(); // refresh table's status badge
            } else {
                showToast(data.message || "Reply could not be sent.", "error", "Send failed", 10000);
            }
        } catch (error) {
            console.error("sendReply error:", error);
            showToast("Something went wrong sending this reply. Please try again.", "error", "Send failed", 10000);
            showReplyFeedback("Something went wrong sending this reply. Please try again.", true);
        } finally {
            sendButton.disabled = false;
            sendButton.textContent = "Send Reply";
        }
    }

    function showReplyFeedback(message, isError) {
        const feedback = document.getElementById("replyFeedback");
        feedback.textContent = message;
        feedback.style.display = "block";
        feedback.className = "reply-feedback " + (isError ? "reply-feedback--error" : "reply-feedback--success");
    }

    // ------------------------------------------------------
    // Create Applicant Account (from the modal)
    // ------------------------------------------------------
    async function convertToApplicant() {
        if (!currentInquiryId) return;

        const convertButton = document.getElementById("btnConvert");
        convertButton.disabled = true;
        convertButton.textContent = "Generating...";
        showToast("Generating a registration code for this applicant…", "sending", "Please wait");

        try {
            const response = await postForm(`${ACTIONS_BASE}/convert.php`, {
                inquiry_id: currentInquiryId,
            });

            const data = await response.json();

            if (data.success) {
                // Fill the inline registration code box inside the modal (INSTANT)
                if (data.registration_code) {
                    showRegistrationCodeInModal(data.registration_code, data.delivered, data.inquiry_no);
                    switchTab("applicant");
                    showToast("Registration code created — email will be sent in the background.", "success", "Code created");
                } else {
                    showToast(data.message || "Registration code created.", "success", "Code created");
                }

                // Fire-and-forget: deliver the queued invitation email in the
                // background so the admin never waits on SMTP.
                if (data.email_queue_id) {
                    postForm(`${ACTIONS_BASE}/send_email.php`, { email_queue_id: data.email_queue_id })
                        .then(r => r.json())
                        .then(res => {
                            if (res && res.success) {
                                showToast("Invitation email delivered to the applicant.", "success", "Email sent");
                            } else if (res && res.message) {
                                showToast(res.message, "warning", "Email queued");
                            }
                        })
                        .catch(() => { /* ignore — email stays queued, Email Center can send later */ });
                }

                await loadInquiries();
            } else {
                showToast(data.message || "Something went wrong creating the code.", "error", "Failed");
            }
        } catch (error) {
            console.error("convertToApplicant error:", error);
            showToast("Something went wrong creating the code. Please try again.", "error", "Failed");
        } finally {
            convertButton.disabled = false;
            convertButton.textContent = "Create Registration Code";
        }
    }

    /**
     * Show the generated registration code INSIDE the inquiry modal's
     * Applicant tab (content area) with Copy + Use-in-Reply actions.
     */
    function showRegistrationCodeInModal(code, delivered, inquiryNo) {
        const box = document.getElementById("regCodeBox");
        const empty = document.getElementById("regCodeEmpty");
        const valueEl = document.getElementById("regCodeValue");
        const noteEl = document.getElementById("regCodeNote");
        if (!box || !valueEl) return;

        if (empty) empty.style.display = "none";
        box.style.display = "block";
        valueEl.textContent = code;

        if (noteEl) {
            noteEl.textContent = delivered
                ? "Emailed to the applicant · single-use · valid 7 days"
                : "Email delivery pending (SMTP not configured) · single-use · valid 7 days";
        }
    }

    function copyCodeToClipboard(text, btn) {
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(text).then(() => {
                if (btn) { btn.textContent = "✅ Copied!"; setTimeout(() => { btn.textContent = "📋 Copy"; }, 2000); }
            });
        } else {
            const ta = document.createElement("textarea");
            ta.value = text;
            document.body.appendChild(ta);
            ta.select();
            document.execCommand("copy");
            document.body.removeChild(ta);
            if (btn) { btn.textContent = "✅ Copied!"; setTimeout(() => { btn.textContent = "📋 Copy"; }, 2000); }
        }
    }

    /** Use the code in a ready-to-send reply template. */
    function useCodeInReply(code) {
        const replyEl = document.getElementById("replyMessage");
        if (!replyEl) return;
        const applicant = document.getElementById("modalApplicant").textContent || "";
        replyEl.value = "Hi " + applicant + ",\n\nThank you for your inquiry. Please create your USMCI Admissions account using this one-time registration code:\n\n" + code + "\n\nEnter it on our login page under \"Create Account\". This code is valid for 7 days.\n\n— USMCI Admissions Office";
        switchTab("reply");
        replyEl.focus();
        // Keep the include-code option visible & checked so the code
        // ALSO renders as the highlighted block in the email.
        const chk = document.getElementById("replyIncludeCode");
        if (chk) chk.checked = true;
        showToast("Reply template with the code is ready — review and send.", "info", "Template ready");
    }

    // ------------------------------------------------------
    // Row-selection actions (toolbar)
    // ------------------------------------------------------
    function requireSelection(action) {
        const ids = selectedInquiryIds();
        if (ids.length === 0) {
            alert("Select at least one inquiry first (tick the checkbox).");
            return null;
        }
        if (ids.length > 1) {
            alert(`Please select only one inquiry for "${action}".`);
            return null;
        }
        return ids[0];
    }

    function openSelectedReply() {
        const id = requireSelection("Reply");
        if (id !== null) openInquiry(id);
    }

    function convertSelected() {
        const id = requireSelection("Create Applicant");
        if (id !== null) {
            currentInquiryId = id;
            convertToApplicant();
        }
    }

    function exportCsv() {
        if (currentRows.length === 0) {
            alert("No inquiries to export.");
            return;
        }

        const header = ["Inquiry No.", "Date", "Applicant", "Email", "Mobile", "Course", "Subject", "Status"];
        const lines = currentRows.map((r) => [
            r.inquiry_no,
            r.created_at,
            r.full_name,
            r.email,
            r.mobile_no,
            r.course_interest || "",
            r.subject || "",
            r.status_label || "New",
        ].map((cell) => `"${String(cell ?? "").replace(/"/g, '""')}"`).join(","));

        const csv = [header.join(","), ...lines].join("\n");
        const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `inquiries-${new Date().toISOString().slice(0, 10)}.csv`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }

    // ------------------------------------------------------
    // Event wiring
    // ------------------------------------------------------
    document.addEventListener("DOMContentLoaded", () => {
        loadInquiries();

        // Row "View" button opens the modal
        tableBody.addEventListener("click", (event) => {
            const openBtn = event.target.closest("[data-open]");
            if (openBtn) {
                openInquiry(openBtn.dataset.open);
            }
        });

        // Row checkboxes
        tableBody.addEventListener("change", (event) => {
            const box = event.target.closest(".row-check");
            if (!box) return;
            if (box.checked) {
                selectedIds.add(box.dataset.id);
            } else {
                selectedIds.delete(box.dataset.id);
            }
        });

        const checkAll = document.getElementById("checkAllRows");
        if (checkAll) {
            checkAll.addEventListener("change", () => {
                tableBody.querySelectorAll(".row-check").forEach((box) => {
                    box.checked = checkAll.checked;
                    if (checkAll.checked) {
                        selectedIds.add(box.dataset.id);
                    } else {
                        selectedIds.delete(box.dataset.id);
                    }
                });
            });
        }

        closeButtons.forEach((btn) => btn && btn.addEventListener("click", closeModal));

        modal.addEventListener("click", (event) => {
            if (event.target === modal) closeModal();
        });

        document.querySelectorAll(".tab-button").forEach((btn) => {
            btn.addEventListener("click", () => switchTab(btn.dataset.tab));
        });

        document.getElementById("btnSendReply").addEventListener("click", sendReply);
        document.getElementById("btnConvert").addEventListener("click", convertToApplicant);

        // Registration code inline actions
        const regCopy = document.getElementById("regCodeCopy");
        if (regCopy) {
            regCopy.addEventListener("click", () => {
                const val = document.getElementById("regCodeValue");
                if (val && val.textContent && val.textContent !== "—") {
                    copyCodeToClipboard(val.textContent, regCopy);
                }
            });
        }
        const regUse = document.getElementById("regCodeUseReply");
        if (regUse) {
            regUse.addEventListener("click", () => {
                const val = document.getElementById("regCodeValue");
                if (val && val.textContent && val.textContent !== "—") {
                    useCodeInReply(val.textContent);
                }
            });
        }

        // Toolbar: filters (any change resets to page 1)
        const searchInput = document.getElementById("searchKeyword");
        if (searchInput) {
            let debounceTimer;
            searchInput.addEventListener("input", () => {
                clearTimeout(debounceTimer);
                debounceTimer = setTimeout(resetToFirstPage, 350);
            });
        }

        const statusSelect = document.getElementById("filterStatus");
        if (statusSelect) statusSelect.addEventListener("change", resetToFirstPage);

        const dateInput = document.getElementById("filterDate");
        if (dateInput) dateInput.addEventListener("change", resetToFirstPage);

        const agingChip = document.getElementById("filterAging");
        if (agingChip) agingChip.addEventListener("click", () => {
            agingChip.classList.toggle("active");
            resetToFirstPage();
        });

        // Pagination: rows per page
        const pageSizeSelect = document.getElementById("pageSize");
        if (pageSizeSelect) {
            pageSizeSelect.addEventListener("change", () => {
                currentPageSize = parseInt(pageSizeSelect.value, 10) || 10;
                currentPage = 1;
                loadInquiries();
            });
        }

        // Pagination: page navigation
        const pageFirst = document.getElementById("pageFirst");
        if (pageFirst) pageFirst.addEventListener("click", () => goToPage(1));

        const pagePrev = document.getElementById("pagePrev");
        if (pagePrev) pagePrev.addEventListener("click", () => goToPage(currentPage - 1));

        const pageNext = document.getElementById("pageNext");
        if (pageNext) pageNext.addEventListener("click", () => goToPage(currentPage + 1));

        const pageLast = document.getElementById("pageLast");
        if (pageLast) pageLast.addEventListener("click", () => goToPage(totalPages));

        // Toolbar: actions
        const btnRefresh = document.getElementById("btnRefresh");
        if (btnRefresh) btnRefresh.addEventListener("click", loadInquiries);

        const btnRefreshTable = document.getElementById("btnRefreshTable");
        if (btnRefreshTable) btnRefreshTable.addEventListener("click", loadInquiries);

        const btnReplySelected = document.getElementById("btnReplySelected");
        if (btnReplySelected) btnReplySelected.addEventListener("click", openSelectedReply);

        const btnConvertSelected = document.getElementById("btnConvertSelected");
        if (btnConvertSelected) btnConvertSelected.addEventListener("click", convertSelected);

        const btnAssign = document.getElementById("btnAssign");
        if (btnAssign) {
            btnAssign.addEventListener("click", () => {
                alert("Assign Staff is not implemented yet — it will attach a staff member to the selected inquiry.");
            });
        }

        const btnExport = document.getElementById("btnExport");
        if (btnExport) btnExport.addEventListener("click", exportCsv);

        const btnPrint = document.getElementById("btnPrint");
        if (btnPrint) btnPrint.addEventListener("click", () => window.print());
    });
})();
