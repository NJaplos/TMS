<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Applicant Registration (via Invitation Link)
 * File : sections/admissions/register.php
 * Version : 1.0
 *
 * Description:
 * This is the missing page the invitation emails link to:
 *
 *   {WEBSITE_BASE_URL}/sections/admissions/register.php?token=...
 *
 * Flow:
 *   1. GET ?token=...  -> validate_invitation_token()
 *   2. Shows account-creation form (email is locked to the
 *      invited address).
 *   3. POST -> creates applicant_account with password_hash(),
 *      marks the invitation used, advances inquiry to CONVERTED.
 *
 * This file is what validate_invitation.php was written for —
 * loading validate_invitation.php directly shows a blank page
 * because it is a function library, not a page.
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once __DIR__ . '/../../config/bootstrap.php';
require_once __DIR__ . '/validate_invitation.php';

$token = (string) ($_GET['token'] ?? '');
$error = '';
$success = false;

/*----------------------------------------------------------
1. Validate the token (first page load)
----------------------------------------------------------*/
$check = validate_invitation_token($token);
$invitation = $check['valid'] ? $check['invitation'] : null;

/*----------------------------------------------------------
2. Handle form submission
----------------------------------------------------------*/
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $check['valid']) {
    csrf_check();

    $password = (string) ($_POST['password'] ?? '');
    $confirm  = (string) ($_POST['password_confirm'] ?? '');

    if (strlen($password) < (int) (defined('PASSWORD_MIN_LENGTH') ? PASSWORD_MIN_LENGTH : 8)) {
        $error = 'Password must be at least 8 characters long.';
    } elseif ($password !== $confirm) {
        $error = 'Passwords do not match.';
    } else {
        try {
            $pdo = db();

            // One account per email — stop duplicates.
            $dup = $pdo->prepare('SELECT id FROM applicant_account WHERE email = :email LIMIT 1');
            $dup->execute(['email' => $invitation['email']]);

            if ($dup->fetch()) {
                $error = 'An account already exists for this email address. Please log in instead.';
            } else {
                $statusActive = (int) $pdo->query(
                    "SELECT id FROM mnt_account_status WHERE code = 'ACTIVE' LIMIT 1"
                )->fetchColumn() ?: 1;

                $pdo->beginTransaction();

                $stmt = $pdo->prepare(
                    "INSERT INTO applicant_account
                        (applicant_id, username, email, password_hash, email_verified_at, status_id, created_at)
                     VALUES
                        (:applicant_id, :username, :email, :password_hash, NOW(), :status_id, NOW())"
                );
                $stmt->execute([
                    'applicant_id'   => (int) $invitation['applicant_id'],
                    'username'       => $invitation['email'],
                    'email'          => $invitation['email'],
                    'password_hash'  => password_hash($password, PASSWORD_DEFAULT),
                    'status_id'      => $statusActive,
                ]);

                mark_invitation_used((int) $invitation['id'], (int) $invitation['inquiry_id']);

                $pdo->commit();

                $success = true;
            }
        } catch (Throwable $exception) {
            if (isset($pdo)) {
                $pdo->rollBack();
            }
            error_log('register.php failed: ' . $exception->getMessage());
            $error = 'Your account could not be created right now. Please try again or contact the Admissions Office.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Your Account | USMCI Admissions</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #0B3C5D 0%, #0D8A72 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 24px;
        }
        .card {
            background: #fff;
            border-radius: 16px;
            width: 100%;
            max-width: 460px;
            padding: 40px 36px;
            box-shadow: 0 24px 60px rgba(0,0,0,.25);
        }
        .card__badge {
            display: inline-flex;
            align-items: center;
            padding: 5px 14px;
            border-radius: 999px;
            background: #EAF6F2;
            color: #0D8A72;
            font-size: .72rem;
            font-weight: 700;
            letter-spacing: .03em;
            text-transform: uppercase;
            margin-bottom: 14px;
        }
        .card h1 {
            font-size: 1.35rem;
            font-weight: 700;
            color: #0B3C5D;
            margin-bottom: 8px;
        }
        .card p { font-size: .88rem; color: #5B6472; line-height: 1.55; margin-bottom: 22px; }
        .field { margin-bottom: 16px; }
        .field label { display: block; font-size: .8rem; font-weight: 600; color: #334155; margin-bottom: 6px; }
        .field input {
            width: 100%; padding: 11px 14px;
            border: 1px solid #CBD5E1; border-radius: 8px;
            font-size: .95rem; font-family: inherit;
        }
        .field input:focus { outline: none; border-color: #0D8A72; box-shadow: 0 0 0 3px rgba(13,138,114,.15); }
        .field input:disabled { background: #F1F5F9; color: #475569; }
        .btn {
            width: 100%; padding: 12px; background: #0D8A72; color: #fff;
            border: none; border-radius: 8px; font-size: .95rem; font-weight: 700;
            font-family: inherit; cursor: pointer; margin-top: 8px;
        }
        .btn:hover { background: #0B7A64; }
        .alert { background: #FEF2F2; border: 1px solid #FECACA; color: #B91C1C; padding: 10px 14px; border-radius: 8px; font-size: .85rem; margin-bottom: 18px; }
        .notice { background: #F8FAFC; border: 1px solid #E2E8F0; border-radius: 10px; padding: 14px 16px; font-size: .85rem; color: #334155; margin-bottom: 20px; }
        .notice strong { color: #0B3C5D; }
        .success { text-align: center; padding: 10px 0 4px; }
        .success .icon { font-size: 3rem; margin-bottom: 10px; }
        .success h1 { margin-bottom: 8px; }
        .success a { color: #0D8A72; font-weight: 600; text-decoration: none; }
        .muted { font-size: .78rem; color: #94A3B8; text-align: center; margin-top: 18px; }
    </style>
</head>
<body>

<?php if ($success): ?>
    <!-- ================= ACCOUNT CREATED ================= -->
    <div class="card success">
        <div class="icon">🎉</div>
        <h1>Account Created!</h1>
        <p>Your USMCI Admissions Portal account is ready.
           You can now sign in with your email and the password you just set.</p>
        <a class="btn" href="<?= htmlspecialchars(base_url('login.php'), ENT_QUOTES, 'UTF-8'); ?>"
           style="display:inline-block;text-decoration:none;">Go to Login</a>
        <p class="muted">The Admissions Office has been notified of your registration.</p>
    </div>

<?php elseif (!$check['valid']): ?>
    <!-- ================= INVALID / EXPIRED TOKEN ================= -->
    <div class="card">
        <span class="card__badge">Admissions Portal</span>
        <h1>Link Not Valid</h1>
        <div class="alert"><?= htmlspecialchars($check['reason'] ?? 'This invitation link is invalid.', ENT_QUOTES, 'UTF-8'); ?></div>
        <p>If you believe this is a mistake, please contact the USMCI Admissions Office and ask for a new invitation link.</p>
        <a class="btn" href="<?= htmlspecialchars(base_url('index.php'), ENT_QUOTES, 'UTF-8'); ?>"
           style="display:inline-block;text-decoration:none;text-align:center;">Back to Website</a>
    </div>

<?php else: ?>
    <!-- ================= REGISTRATION FORM ================= -->
    <div class="card">
        <span class="card__badge">Admissions Portal</span>
        <h1>Create Your Account</h1>
        <p>You've been invited to continue your application with USMCI. Set a password below to activate your account.</p>

        <div class="notice">
            <strong>Invited for:</strong>
            <?= htmlspecialchars($invitation['full_name'] ?? '', ENT_QUOTES, 'UTF-8'); ?>
            &nbsp;·&nbsp; Reference:
            <?= htmlspecialchars($invitation['inquiry_no'] ?? '', ENT_QUOTES, 'UTF-8'); ?>
        </div>

        <?php if ($error !== ''): ?>
            <div class="alert"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></div>
        <?php endif; ?>

        <form method="post"
              action="<?= htmlspecialchars(base_url('sections/admissions/register.php') . '?token=' . urlencode($token), ENT_QUOTES, 'UTF-8'); ?>">
            <?= csrf_field(); ?>

            <div class="field">
                <label>Email Address (locked to your invitation)</label>
                <input type="email" value="<?= htmlspecialchars($invitation['email'], ENT_QUOTES, 'UTF-8'); ?>" disabled>
            </div>

            <div class="field">
                <label for="password">Password</label>
                <input type="password" id="password" name="password"
                       minlength="<?= (int) (defined('PASSWORD_MIN_LENGTH') ? PASSWORD_MIN_LENGTH : 8); ?>"
                       placeholder="At least <?= (int) (defined('PASSWORD_MIN_LENGTH') ? PASSWORD_MIN_LENGTH : 8); ?> characters"
                       required autocomplete="new-password">
            </div>

            <div class="field">
                <label for="password_confirm">Confirm Password</label>
                <input type="password" id="password_confirm" name="password_confirm"
                       required autocomplete="new-password">
            </div>

            <button type="submit" class="btn">Create Account</button>
        </form>

        <p class="muted">This link is single-use and expires after 7 days.</p>
    </div>
<?php endif; ?>

</body>
</html>
