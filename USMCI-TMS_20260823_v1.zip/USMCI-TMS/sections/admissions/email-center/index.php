<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Module      : Admissions
 * Page        : Email Center
 * File        : index.php
 * Version     : 1.0
 *
 * Description :
 * Staff tool to manage outgoing email:
 *   1. SMTP Settings   — switch between Mailtrap / Gmail /
 *                        company SMTP without editing files.
 *   2. Test Email      — send a test message right now.
 *   3. Email Queue     — view pending/sent/failed, send pending
 *                        now, retry failed.
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/config/bootstrap.php';
require_once __DIR__ . '/../mailer/SimpleSmtpMailer.php';
require_once __DIR__ . '/../mailer/send_queued_emails.php';

/* Staff only */
require_access('settings');
if ($_SERVER['REQUEST_METHOD'] === 'POST') { require_edit('settings'); }

/* ==========================================================
   Handle POST actions (all CSRF-guarded)
========================================================== */

$flash = ['type' => null, 'message' => null];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();

    $action = $_POST['action'] ?? '';

    try {
        switch ($action) {
            /* ---- Save SMTP settings ---- */
            case 'save_settings':
                $fields = [
                    'smtp_host'          => trim((string) ($_POST['smtp_host'] ?? '')),
                    'smtp_port'          => trim((string) ($_POST['smtp_port'] ?? '587')),
                    'smtp_encryption'    => in_array($_POST['smtp_encryption'] ?? '', ['none', 'ssl', 'tls'], true)
                        ? $_POST['smtp_encryption'] : 'tls',
                    'smtp_username'      => trim((string) ($_POST['smtp_username'] ?? '')),
                    'smtp_password'      => (string) ($_POST['smtp_password'] ?? ''),
                    'mail_from_email'    => trim((string) ($_POST['mail_from_email'] ?? '')),
                    'mail_from_name'     => trim((string) ($_POST['mail_from_name'] ?? '')),
                    'admin_notify_email' => trim((string) ($_POST['admin_notify_email'] ?? '')),
                ];

                foreach ($fields as $key => $value) {
                    mail_setting_save($key, $value);
                }

                $flash = [
                    'type' => 'success',
                    'message' => 'SMTP settings saved. ' . (smtp_is_configured()
                        ? 'SMTP is configured (' . smtp_config()['host'] . ':' . smtp_config()['port'] . ').'
                        : 'SMTP host is empty — emails will use PHP mail() until you enter one.'),
                ];
                break;

            /* ---- Send a test email immediately ---- */
            case 'send_test':
                $to      = trim((string) ($_POST['test_to'] ?? ''));
                $subject = trim((string) ($_POST['test_subject'] ?? 'USMCI-TMS Test Email'));
                $body    = (string) ($_POST['test_body'] ?? 'This is a test email from USMCI-TMS. If you can read this, email delivery is working.');

                if ($to === '' || !filter_var($to, FILTER_VALIDATE_EMAIL)) {
                    $flash = ['type' => 'error', 'message' => 'Enter a valid recipient email for the test.'];
                    break;
                }

                $bodyHtml = '<h2>' . htmlspecialchars($subject, ENT_QUOTES, 'UTF-8') . '</h2>'
                    . '<p>' . nl2br(htmlspecialchars($body, ENT_QUOTES, 'UTF-8')) . '</p>'
                    . '<p style="color:#6B7280;font-size:.85rem;">Sent from USMCI-TMS Email Center.</p>';

                $result = SimpleSmtpMailer::send($to, $subject, $bodyHtml, null, smtp_config());

                $flash = [
                    'type' => $result['success'] ? 'success' : 'error',
                    'message' => $result['success']
                        ? 'Test email sent to ' . $to . ' successfully.'
                        : 'Test email FAILED: ' . $result['error'],
                ];
                break;

            /* ---- Send all pending emails now ---- */
            case 'process_queue':
                $summary = process_email_queue();
                $flash = [
                    'type' => 'success',
                    'message' => 'Queue processed: ' . $summary['sent'] . ' sent, ' . $summary['failed'] . ' failed (of ' . $summary['total'] . ' attempted).',
                ];
                break;

            /* ---- Retry failed emails ---- */
            case 'retry_failed':
                $pdo = db();
                $pdo->prepare(
                    "UPDATE email_queue SET status = 'pending', attempts = 0, error_message = NULL WHERE status = 'failed'"
                )->execute();

                $summary = process_email_queue();
                $flash = [
                    'type' => 'success',
                    'message' => 'Failed emails reset and reprocessed: ' . $summary['sent'] . ' sent, ' . $summary['failed'] . ' failed.',
                ];
                break;

            default:
                $flash = ['type' => 'error', 'message' => 'Unknown action.'];
        }
    } catch (Throwable $exception) {
        error_log('email-center: ' . $exception->getMessage());
        $flash = ['type' => 'error', 'message' => 'Something went wrong: ' . $exception->getMessage()];
    }
}

/* ==========================================================
   Load data for the page
========================================================== */

$pdo = db();

$cfg = smtp_config();

$queueFilter = $_GET['status'] ?? '';

$counts = [
    'pending' => (int) $pdo->query("SELECT COUNT(*) FROM email_queue WHERE status = 'pending'")->fetchColumn(),
    'sent'    => (int) $pdo->query("SELECT COUNT(*) FROM email_queue WHERE status = 'sent'")->fetchColumn(),
    'failed'  => (int) $pdo->query("SELECT COUNT(*) FROM email_queue WHERE status = 'failed'")->fetchColumn(),
];

$queueSql = "SELECT id, recipient_email, subject, status, attempts, created_at, sent_at, error_message
             FROM email_queue";
$params = [];

if (in_array($queueFilter, ['pending', 'sent', 'failed'], true)) {
    $queueSql .= ' WHERE status = :status';
    $params['status'] = $queueFilter;
}

$queueSql .= ' ORDER BY created_at DESC LIMIT 100';

$queueStmt = $pdo->prepare($queueSql);
$queueStmt->execute($params);
$queueRows = $queueStmt->fetchAll();

$page = [
    'title'       => 'Email Center | USMCI-TMS',
    'description' => 'Email Center — settings, test, and queue.',
    'bodyClass'   => 'admissions-page',
];
?>
<!DOCTYPE html>
<html lang="en">

<?php include INCLUDES_PATH . '/head.php'; ?>

<link rel="stylesheet" href="<?= e(base_url('assets/css/portal.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/workspace.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/inquiry-queue/assets/css/page.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/email-center/style.css?v=9')); ?>">

<body class="<?= e($page['bodyClass']); ?>">

    <?php include NAVBAR_PATH . '/index.php'; ?>

    <section class="portal-shell portal-shell--2col">

        <?php require ADMISSIONS_PATH . '/inquiry-queue/partials/sidebar.php'; ?>

        <main class="portal-content email-center">

            <header class="workspace-header">
                <div class="workspace-header__left">
                    <span class="section-badge">Communications</span>
                    <h1>Email Center</h1>
                    <p>Configure the SMTP account, send test emails, and manage the outgoing email queue.</p>
                </div>
                <div class="workspace-header__right">
                    <span class="smtp-status smtp-status--<?= smtp_is_configured() ? 'on' : 'off'; ?>">
                        <?= smtp_is_configured() ? '● SMTP ' . $cfg['host'] . ':' . $cfg['port'] : '● SMTP not configured — using PHP mail()'; ?>
                    </span>
                </div>
            </header>

            <?php if ($flash['message']): ?>
                <div class="email-alert email-alert--<?= $flash['type']; ?>">
                    <?= htmlspecialchars($flash['message'], ENT_QUOTES, 'UTF-8'); ?>
                </div>
            <?php endif; ?>

            <div class="email-grid">

                <!-- ==================== SMTP SETTINGS ==================== -->
                <section class="email-card">
                    <h2>1 · SMTP Settings</h2>
                    <p class="email-card__hint">
                        Test with <strong>Mailtrap</strong> or your own account; switch to the company email
                        before going live — no code changes needed.
                    </p>

                    <form method="post" action="<?= e(base_url('sections/admissions/email-center/index.php')); ?>" class="email-form" id="smtpForm">
                        <?= csrf_field(); ?>
                        <input type="hidden" name="action" value="save_settings">

                        <div class="field-row">
                            <div class="field">
                                <label>SMTP Host</label>
                                <input type="text" name="smtp_host" value="<?= e($cfg['host']); ?>" placeholder="smtp.gmail.com / sandbox.smtp.mailtrap.io">
                            </div>
                            <div class="field field--sm">
                                <label>Port</label>
                                <input type="number" name="smtp_port" value="<?= e((string) $cfg['port']); ?>" placeholder="587">
                            </div>
                            <div class="field field--sm">
                                <label>Encryption</label>
                                <select name="smtp_encryption">
                                    <option value="tls"  <?= $cfg['encryption'] === 'tls' ? 'selected' : ''; ?>>TLS (587)</option>
                                    <option value="ssl"  <?= $cfg['encryption'] === 'ssl' ? 'selected' : ''; ?>>SSL (465)</option>
                                    <option value="none" <?= $cfg['encryption'] === 'none' ? 'selected' : ''; ?>>None</option>
                                </select>
                            </div>
                        </div>

                        <div class="field-row">
                            <div class="field">
                                <label>Username</label>
                                <input type="text" name="smtp_username" value="<?= e($cfg['username']); ?>" placeholder="your@email.com" autocomplete="off">
                            </div>
                            <div class="field">
                                <label>Password / App Password</label>
                                <input type="password" name="smtp_password" value="<?= e($cfg['password']); ?>" autocomplete="new-password">
                            </div>
                        </div>

                        <div class="field-row">
                            <div class="field">
                                <label>From Email</label>
                                <input type="email" name="mail_from_email" value="<?= e($cfg['from_email']); ?>" placeholder="no-reply@usmci.edu.ph">
                            </div>
                            <div class="field">
                                <label>From Name</label>
                                <input type="text" name="mail_from_name" value="<?= e($cfg['from_name']); ?>" placeholder="USMCI Admissions">
                            </div>
                        </div>

                        <div class="field">
                            <label>Admin Notification Email (receives new-inquiry alerts)</label>
                            <input type="email" name="admin_notify_email" value="<?= e($cfg['admin_notify_email']); ?>" placeholder="admissions@usmci.edu.ph">
                        </div>

                        <div class="form-actions">
                            <button type="submit" class="btn-primary">Save Settings</button>
                        </div>
                    </form>

                    <div class="presets">
                        <span class="presets__label">Quick presets:</span>
                        <button type="button" class="btn-secondary btn-sm" data-preset="mailtrap">Mailtrap</button>
                        <button type="button" class="btn-secondary btn-sm" data-preset="gmail">Gmail</button>
                        <button type="button" class="btn-secondary btn-sm" data-preset="company">Company SMTP</button>
                    </div>
                </section>

                <!-- ==================== TEST EMAIL ==================== -->
                <section class="email-card">
                    <h2>2 · Send a Test Email</h2>
                    <p class="email-card__hint">Verifies the current SMTP account works end-to-end.</p>

                    <form method="post" action="<?= e(base_url('sections/admissions/email-center/index.php')); ?>" class="email-form">
                        <?= csrf_field(); ?>
                        <input type="hidden" name="action" value="send_test">

                        <div class="field">
                            <label>Recipient</label>
                            <input type="email" name="test_to" value="<?= e($cfg['admin_notify_email']); ?>" required>
                        </div>

                        <div class="field">
                            <label>Subject</label>
                            <input type="text" name="test_subject" value="USMCI-TMS Test Email">
                        </div>

                        <div class="field">
                            <label>Message</label>
                            <textarea name="test_body" rows="4">This is a test email from USMCI-TMS. If you can read this, email delivery is working.</textarea>
                        </div>

                        <div class="form-actions">
                            <button type="submit" class="btn-primary">Send Test Email</button>
                        </div>
                    </form>
                </section>
            </div>

            <!-- ==================== EMAIL QUEUE ==================== -->
            <section class="email-card email-card--wide">
                <div class="queue-head">
                    <h2>3 · Email Queue</h2>
                    <div class="queue-actions">
                        <form method="post" action="<?= e(base_url('sections/admissions/email-center/index.php')); ?>">
                            <?= csrf_field(); ?>
                            <input type="hidden" name="action" value="process_queue">
                            <button type="submit" class="btn-primary">▶ Send Pending Now</button>
                        </form>
                        <form method="post" action="<?= e(base_url('sections/admissions/email-center/index.php')); ?>">
                            <?= csrf_field(); ?>
                            <input type="hidden" name="action" value="retry_failed">
                            <button type="submit" class="btn-secondary">↻ Retry Failed</button>
                        </form>
                    </div>
                </div>

                <div class="queue-counts">
                    <span class="qc qc--pending">⏳ Pending: <strong><?= number_format($counts['pending']); ?></strong></span>
                    <span class="qc qc--sent">✅ Sent: <strong><?= number_format($counts['sent']); ?></strong></span>
                    <span class="qc qc--failed">❌ Failed: <strong><?= number_format($counts['failed']); ?></strong></span>
                </div>

                <div class="queue-filter">
                    <?php foreach (['' => 'All', 'pending' => 'Pending', 'sent' => 'Sent', 'failed' => 'Failed'] as $val => $label): ?>
                        <a class="<?= $queueFilter === $val ? 'active' : ''; ?>" href="<?= e(base_url('sections/admissions/email-center/index.php?status=' . $val)); ?>"><?= e($label); ?></a>
                    <?php endforeach; ?>
                </div>

                <div class="table-responsive">
                    <table class="inquiry-table email-table">
                        <thead>
                            <tr>
                                <th>Recipient</th>
                                <th>Subject</th>
                                <th>Status</th>
                                <th>Attempts</th>
                                <th>Created</th>
                                <th>Sent At</th>
                                <th>Error</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!$queueRows): ?>
                                <tr><td colspan="7" class="email-empty">No emails in the queue<?= $queueFilter !== '' ? ' with status "' . e($queueFilter) . '"' : ''; ?>.</td></tr>
                            <?php endif; ?>
                            <?php foreach ($queueRows as $row): ?>
                                <tr>
                                    <td><?= e($row['recipient_email']); ?></td>
                                    <td class="email-subject"><?= e($row['subject']); ?></td>
                                    <td>
                                        <span class="status-badge status-<?= e($row['status']); ?>">
                                            <?= e($row['status']); ?>
                                        </span>
                                    </td>
                                    <td><?= (int) $row['attempts']; ?></td>
                                    <td><?= e((string) $row['created_at']); ?></td>
                                    <td><?= e($row['sent_at'] ?? '—'); ?></td>
                                    <td class="email-error" title="<?= e($row['error_message'] ?? ''); ?>">
                                        <?= $row['error_message'] ? mb_substr($row['error_message'], 0, 40) . '…' : '—'; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </section>

        </main>
    </section>

    <?php include INCLUDES_PATH . '/footer.php'; ?>
    <?php include INCLUDES_PATH . '/scripts.php'; ?>

    <script>
        (function () {
            var presetBtns = document.querySelectorAll("[data-preset]");
            var presets = {
                mailtrap: { host: "sandbox.smtp.mailtrap.io", port: "2525", enc: "tls" },
                gmail:    { host: "smtp.gmail.com", port: "587", enc: "tls" },
                company:  { host: "smtp.company.com", port: "587", enc: "tls" }
            };
            presetBtns.forEach(function (btn) {
                btn.addEventListener("click", function () {
                    var p = presets[btn.dataset.preset];
                    if (!p) return;
                    var form = document.getElementById("smtpForm");
                    if (!form) return;
                    form.querySelector("[name=smtp_host]").value = p.host;
                    form.querySelector("[name=smtp_port]").value = p.port;
                    form.querySelector("[name=smtp_encryption]").value = p.enc;
                    alert("Preset applied: " + p.host + ":" + p.port + " (" + p.enc + "). Enter your username/password, then Save.");
                });
            });
        })();
    </script>

</body>
</html>
