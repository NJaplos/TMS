<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Invite Applicant to Enroll
 * ---------------------------------------------------------
 * Called when staff clicks "Create Applicant Account" in the
 * Inquiry Queue. Creates a stub `applicant` row (if one
 * doesn't already exist for this inquiry), generates a
 * single-use registration token, stores only its HASH, and
 * queues the invitation email.
 *
 * SECURITY NOTE: the raw token only ever exists in memory and
 * in the emailed URL — it is never written to the database or
 * logged. Only sha256(token) is stored, in applicant_invitation
 * .token_hash. Even a full database leak can't be used to
 * register as someone else.
 *
 * v2 changes:
 *   - Applicant numbers now come from sequence_generator
 *     (locked with FOR UPDATE) instead of COUNT(*)+1, which
 *     had a race condition and reused numbers after deletes.
 *   - Registration URL falls back to the current host when
 *     WEBSITE_BASE_URL is not configured.
 * ---------------------------------------------------------
 */

declare(strict_types=1);

if (!defined('USMCI_BOOTSTRAP')) {
    require_once dirname(__DIR__, 2) . '/config/bootstrap.php';
}

const INVITATION_VALID_DAYS = 7;

/**
 * @return array{success: bool, message: string, inquiry_no?: string}
 */
function invite_applicant_to_enroll(int $inquiryId, int $staffId): array
{
    $pdo = db();

    $pdo->beginTransaction();

    try {
        $inquiryStmt = $pdo->prepare(
            "SELECT id, inquiry_no, applicant_id, full_name, email, status_id
             FROM inquiry WHERE id = :id FOR UPDATE"
        );
        $inquiryStmt->execute(['id' => $inquiryId]);
        $inquiry = $inquiryStmt->fetch();

        if (!$inquiry) {
            throw new RuntimeException('Inquiry not found.');
        }

        if ($inquiry['email'] === null || trim($inquiry['email']) === '') {
            throw new RuntimeException('This inquiry has no email address on file — cannot send an invitation.');
        }

        $applicantId = $inquiry['applicant_id'];

        if ($applicantId === null) {
            [$firstName, $lastName] = split_full_name($inquiry['full_name']);
            $applicantNo = generate_applicant_no($pdo);

            $insertApplicant = $pdo->prepare(
                "INSERT INTO applicant (applicant_no, first_name, last_name, email, created_at)
                 VALUES (:applicant_no, :first_name, :last_name, :email, NOW())"
            );
            $insertApplicant->execute([
                'applicant_no' => $applicantNo,
                'first_name' => $firstName,
                'last_name' => $lastName,
                'email' => $inquiry['email'],
            ]);

            $applicantId = (int) $pdo->lastInsertId();

            $pdo->prepare("UPDATE inquiry SET applicant_id = :applicant_id WHERE id = :id")
                ->execute(['applicant_id' => $applicantId, 'id' => $inquiryId]);
        }

        $pdo->prepare(
            "UPDATE applicant_invitation
             SET used_at = NOW()
             WHERE inquiry_id = :inquiry_id AND used_at IS NULL"
        )->execute(['inquiry_id' => $inquiryId]);

        $rawToken = bin2hex(random_bytes(32));
        $tokenHash = hash('sha256', $rawToken);
        $expiresAt = (new DateTimeImmutable("+" . INVITATION_VALID_DAYS . " days"))->format('Y-m-d H:i:s');

        // Auto-generate a human-usable, single-use REGISTRATION CODE
        // related to the inquiry number (e.g. USMCI-INQ2026-000013-K7X2).
        $registrationCode = generate_registration_code($pdo, $inquiry['inquiry_no']);

        $insertInvitation = $pdo->prepare(
            "INSERT INTO applicant_invitation
                (inquiry_id, applicant_id, token_hash, registration_code, email, expires_at, created_by, created_at)
             VALUES
                (:inquiry_id, :applicant_id, :token_hash, :registration_code, :email, :expires_at, :created_by, NOW())"
        );
        $insertInvitation->execute([
            'inquiry_id' => $inquiryId,
            'applicant_id' => $applicantId,
            'token_hash' => $tokenHash,
            'registration_code' => $registrationCode,
            'email' => $inquiry['email'],
            'expires_at' => $expiresAt,
            'created_by' => $staffId,
        ]);

        $invitedStatusId = $pdo->query(
            "SELECT id FROM mnt_inquiry_status WHERE code = 'INVITED'"
        )->fetchColumn();

        $pdo->prepare("UPDATE inquiry SET status_id = :status_id, assigned_to = :staff_id WHERE id = :id")
            ->execute(['status_id' => $invitedStatusId, 'staff_id' => $staffId, 'id' => $inquiryId]);

        $registrationUrl = build_registration_url($rawToken);
        $bodyHtml = render_invitation_email($inquiry['full_name'], $registrationUrl, $registrationCode, INVITATION_VALID_DAYS);

        $pdo->prepare(
            "INSERT INTO email_queue (recipient_email, subject, body_html, status, scheduled_at, created_at)
             VALUES (:email, :subject, :body, 'pending', NOW(), NOW())"
        )->execute([
            'email' => $inquiry['email'],
            'subject' => "You're invited to create your USMCI Admissions account",
            'body' => $bodyHtml,
        ]);

        $emailQueueId = (int) $pdo->lastInsertId();

        $pdo->commit();

        /* IMPORTANT: do NOT send synchronously here — that blocks the
           UI while SMTP connects. The code is returned instantly and
           the invitation email is delivered in the background via
           actions/send_email.php (fire-and-forget from the browser). */
        $inviteDelivery = ['success' => true];

        return [
            'success' => true,
            'delivered' => false,
            'email_queue_id' => $emailQueueId,
            'message' => 'Registration code created and invitation queued.',
            'inquiry_no' => $inquiry['inquiry_no'],
            'registration_code' => $registrationCode,
        ];
    } catch (Throwable $exception) {
        if (isset($pdo)) {
            $pdo->rollBack();
        }
        error_log('invite_applicant_to_enroll failed: ' . $exception->getMessage());

        return ['success' => false, 'message' => $exception->getMessage()];
    }
}

/** @return array{0: string, 1: string} */
function split_full_name(string $fullName): array
{
    $parts = preg_split('/\s+/', trim($fullName), 2);

    return [$parts[0] ?? $fullName, $parts[1] ?? ''];
}

/**
 * Applicant number via the shared sequence_generator table.
 * MUST be called inside an active transaction (it is — see
 * invite_applicant_to_enroll) so the FOR UPDATE lock holds.
 */
function generate_applicant_no(PDO $pdo): string
{
    $year = (int) date('Y');

    $select = $pdo->prepare(
        "SELECT id, current_value, prefix, padding_length
         FROM sequence_generator
         WHERE sequence_code = 'APP' AND sequence_year = :year
         FOR UPDATE"
    );
    $select->execute(['year' => $year]);
    $sequence = $select->fetch();

    if (!$sequence) {
        $insert = $pdo->prepare(
            "INSERT INTO sequence_generator (sequence_code, sequence_year, current_value, prefix, padding_length)
             VALUES ('APP', :year, 0, 'APP', 6)"
        );
        $insert->execute(['year' => $year]);

        $select->execute(['year' => $year]);
        $sequence = $select->fetch();
    }

    $nextValue = ((int) $sequence['current_value']) + 1;

    $update = $pdo->prepare('UPDATE sequence_generator SET current_value = :value WHERE id = :id');
    $update->execute(['value' => $nextValue, 'id' => $sequence['id']]);

    return sprintf(
        '%s-%d-%s',
        $sequence['prefix'],
        $year,
        str_pad((string) $nextValue, (int) $sequence['padding_length'], '0', STR_PAD_LEFT)
    );
}

/**
 * Generate a unique, human-usable registration code related to
 * the inquiry number, e.g.  USMCI-INQ2026-000013-K7X2
 */
function generate_registration_code(PDO $pdo, string $inquiryNo): string
{
    $cleanNo = preg_replace('/[^A-Z0-9]/', '', strtoupper($inquiryNo)) ?: 'INQ';
    $suffix  = strtoupper(bin2hex(random_bytes(2)));   // 4 hex chars

    $code = 'USMCI-' . $cleanNo . '-' . $suffix;

    // Ensure uniqueness (tiny chance of collision — retry once)
    $check = $pdo->prepare('SELECT id FROM applicant_invitation WHERE registration_code = :c LIMIT 1');
    $check->execute(['c' => $code]);
    if ($check->fetch()) {
        $suffix = strtoupper(bin2hex(random_bytes(2)));
        $code = 'USMCI-' . $cleanNo . '-' . $suffix;
    }

    return $code;
}

function build_registration_url(string $rawToken): string
{
    if (defined('WEBSITE_BASE_URL') && WEBSITE_BASE_URL !== '') {
        $base = rtrim(WEBSITE_BASE_URL, '/');
    } else {
        $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
        $base = $scheme . '://' . $host . rtrim(BASE_URL, '/');
    }

    return $base . '/sections/admissions/register.php?token=' . urlencode($rawToken);
}

function render_invitation_email(string $fullName, string $registrationUrl, string $registrationCode, int $validDays): string
{
    $safeName = htmlspecialchars($fullName, ENT_QUOTES, 'UTF-8');
    $safeUrl = htmlspecialchars($registrationUrl, ENT_QUOTES, 'UTF-8');
    $safeCode = htmlspecialchars($registrationCode, ENT_QUOTES, 'UTF-8');

    return <<<HTML
        <h2>You're invited to continue your application</h2>
        <p>Hi {$safeName},</p>
        <p>Thank you for your interest in USMCI's maritime training programs. You're invited to
        create your Admissions Portal account to continue your application online.</p>

        <p><strong>Your registration code:</strong></p>
        <p style="font-size:1.25rem;font-weight:800;letter-spacing:.08em;color:#0B3C5D;background:#EAF6F2;
        display:inline-block;padding:10px 20px;border-radius:10px;">{$safeCode}</p>

        <p>Enter this code on the login page under <strong>Create Account</strong>, or use this direct link:</p>
        <p><a href="{$safeUrl}" style="display:inline-block;padding:12px 24px;background:#0D8A72;color:#fff;
        text-decoration:none;border-radius:8px;">Create My Account</a></p>

        <p style="color:#6B7280;font-size:.85rem;">The code and link are valid for {$validDays} days and can
        only be used once. If you didn't request this, you can safely ignore this email.</p>
    HTML;
}
