<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Admissions Portal
 * Campus Slideshow Image Loader
 * ---------------------------------------------------------
 * Portable: builds image URLs from base_url() so the project
 * can be renamed without breaking the slideshow.
 * ---------------------------------------------------------
 */

$imageDirectory = __DIR__ . '/../assets/images/campus/';

$imageList = [];

if (is_dir($imageDirectory)) {

    $allowed = ['jpg', 'jpeg', 'png', 'webp'];

    foreach (scandir($imageDirectory) as $file) {

        if ($file === '.' || $file === '..') {
            continue;
        }

        $extension = strtolower(pathinfo($file, PATHINFO_EXTENSION));

        if (in_array($extension, $allowed)) {

            $imageList[] =
                base_url('sections/admissions/assets/images/campus/') . $file;

        }

    }

}

sort($imageList);
