<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Admissions Portal (content section, public)
 * ---------------------------------------------------------
 */

$pageTitle = "Admissions Portal";
?>


<link rel="stylesheet" href="<?= e(base_url('sections/admissions/style.css')); ?>">

<section id="admissions-portal" class="admissions-portal">

    <?php require 'partials/sidebar.php'; ?>

    <main class="portal-content">

        <?php require 'partials/status.php'; ?>

        <?php require 'partials/process.php'; ?>

        <?php require 'partials/requirements.php'; ?>

        <?php require 'partials/programs.php'; ?>

        <?php require 'partials/faq.php'; ?>

        <?php require 'partials/cta.php'; ?>

    </main>

    <?php require 'partials/right-panel.php'; ?>

</section>

<script src="<?= e(base_url('sections/admissions/assets/js/portal.js')); ?>"></script>

<script src="<?= e(base_url('sections/admissions/assets/js/slideshow.js')); ?>"></script>
