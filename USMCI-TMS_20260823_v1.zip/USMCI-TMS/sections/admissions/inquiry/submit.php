<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Inquiry Form Handler
 * File : sections/admissions/inquiry/submit.php
 * Version : 2.1
 *
 * v2.1: boots through config/bootstrap.php so base_url() is
 * available (no more hardcoded /USMCI-TMS/ paths) and adds
 * a CSRF check on the POST.
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once __DIR__ . '/../../../config/bootstrap.php';
require_once __DIR__ . '/inquiry_service.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ' . base_url('sections/admissions/inquiry/index.php'));
    exit;
}

/* CSRF guard — token comes from csrf_field() in form.php */
csrf_check();

/* V5.58: allow the public site to send submissions back to its own
   page (e.g. index.php#contact) instead of the inquiry page. Only
   accepts URLs that start with the app's own base URL. */
$returnTo = trim((string) ($_POST['return_to'] ?? ''));
if ($returnTo !== '' && strpos($returnTo, rtrim(base_url('/'), '/')) !== 0) {
    $returnTo = ''; /* not ours — ignore */
}
$fallback = $returnTo !== '' ? $returnTo : base_url('sections/admissions/inquiry/index.php');

/* Put the status query string BEFORE any #fragment so
   index.php?status=success&inquiry_no=X#contact resolves correctly. */
$appendQuery = function (string $url, string $qs): string {
    if (strpos($url, '#') !== false) {
        [$base, $frag] = explode('#', $url, 2);
        return $base . (strpos($base, '?') !== false ? '&' : '?') . $qs . '#' . $frag;
    }
    return $url . (strpos($url, '?') !== false ? '&' : '?') . $qs;
};

[$data, $errors] = validate_inquiry($_POST);

if ($errors) {
    $message = urlencode(implode(' ', $errors));
    header('Location: ' . $appendQuery($fallback, 'status=error&message=' . $message));
    exit;
}

try {
    $result = save_inquiry($data);
    $status = $result['type'] === 'existing' ? 'existing' : 'success';
    header('Location: ' . $appendQuery($fallback, 'status=' . $status . '&inquiry_no=' . urlencode($result['inquiry_no'])));
    exit;
} catch (Throwable $exception) {
    error_log($exception->getMessage());
    header('Location: ' . $appendQuery($fallback, 'status=error&message=' . urlencode('Inquiry could not be sent right now. Please try again.')));
    exit;
}
