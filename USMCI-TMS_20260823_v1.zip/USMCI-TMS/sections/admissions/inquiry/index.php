<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Module      : Admissions
 * Page        : Inquiry (PUBLIC form)
 * File        : index.php
 * Version     : 2.1
 * Description : Public inquiry form — boots bootstrap so
 *               base_url() is available (portable paths,
 *               no hardcoded /USMCI-TMS/).
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once __DIR__ . '/../../../config/bootstrap.php';

$page = [
    'title'       => 'Admissions Inquiry — USMCI Training Management System',
    'description' => 'Send an admissions inquiry to United Seafarers Maritime Center, Inc.',
    'bodyClass'   => 'admissions-inquiry-page'
];
?>

<!DOCTYPE html>
<html lang="en">

<?php include INCLUDES_PATH . '/head.php'; ?>

<link rel="stylesheet" href="<?= e(base_url('sections/admissions/inquiry/style.css')); ?>">

<body class="<?= $page['bodyClass']; ?>">

    <!-- Navigation -->
    <?php include NAVBAR_PATH . '/index.php'; ?>

    <main id="main-content">

        <section id="admissions-inquiry" class="admissions-inquiry">

            <?php require __DIR__ . '/partials/hero.php'; ?>

            <?php require __DIR__ . '/partials/form.php'; ?>

        </section>

    </main>

    <?php include INCLUDES_PATH . '/footer.php'; ?>

    <?php include INCLUDES_PATH . '/scripts.php'; ?>

    <script src="<?= e(base_url('sections/admissions/inquiry/script.js')); ?>"></script>

</body>

</html>
