<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Inquiry Service Layer
 * File : sections/admissions/inquiry/inquiry_service.php
 * Version : 2.1
 *
 * v2.1: sanitizes CR/LF out of anything that will end up in an
 * email header (subject / Reply-To name) to prevent header
 * injection.
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once __DIR__ . '/../../../config/database.php';
require_once __DIR__ . '/../../../config/mail.php';

function clean_text(?string $value, int $maxLength): string
{
    $value = trim((string) $value);
    $value = preg_replace('/\s+/', ' ', $value) ?? '';
    return mb_substr($value, 0, $maxLength);
}

/** Strip CR/LF — safe to place into an email Subject/header. */
function header_safe(?string $value): string
{
    return str_replace(["\r", "\n"], ' ', trim((string) $value));
}

function generate_reference(PDO $pdo, string $sequenceCode): string
{
    $year = (int) date('Y');

    $pdo->beginTransaction();

    $select = $pdo->prepare(
        'SELECT id, current_value, prefix, padding_length
         FROM sequence_generator
         WHERE sequence_code = :code AND sequence_year = :year
         FOR UPDATE'
    );
    $select->execute([
        ':code' => $sequenceCode,
        ':year' => $year,
    ]);

    $sequence = $select->fetch();

    if (!$sequence) {
        $insert = $pdo->prepare(
            'INSERT INTO sequence_generator (sequence_code, sequence_year, current_value, prefix, padding_length)
             VALUES (:code, :year, 0, :prefix, 6)'
        );
        $insert->execute([
            ':code' => $sequenceCode,
            ':year' => $year,
            ':prefix' => $sequenceCode,
        ]);

        $select->execute([
            ':code' => $sequenceCode,
            ':year' => $year,
        ]);
        $sequence = $select->fetch();
    }

    $nextValue = ((int) $sequence['current_value']) + 1;

    $update = $pdo->prepare(
        'UPDATE sequence_generator SET current_value = :value WHERE id = :id'
    );
    $update->execute([
        ':value' => $nextValue,
        ':id' => $sequence['id'],
    ]);

    $reference = sprintf(
        '%s-%d-%s',
        $sequence['prefix'],
        $year,
        str_pad((string) $nextValue, (int) $sequence['padding_length'], '0', STR_PAD_LEFT)
    );

    $pdo->commit();

    return $reference;
}

function get_lookup_id(PDO $pdo, string $table, string $code): ?int
{
    $allowedTables = [
        'mnt_inquiry_type',
    ];

    if (!in_array($table, $allowedTables, true)) {
        return null;
    }

    $stmt = $pdo->prepare("SELECT id FROM {$table} WHERE code = :code LIMIT 1");
    $stmt->execute([':code' => $code]);
    $row = $stmt->fetch();

    return $row ? (int) $row['id'] : null;
}

function validate_inquiry(array $post): array
{
    $data = [
        'fullname' => clean_text($post['fullname'] ?? '', 200),
        'email' => clean_text($post['email'] ?? '', 150),
        'mobile' => clean_text($post['mobile'] ?? '', 50),
        'preferred_contact' => clean_text($post['preferred_contact'] ?? 'Email', 50),
        'course' => clean_text($post['course'] ?? '', 150),
        'schedule' => clean_text($post['schedule'] ?? 'No Preference', 50),
        'preferred_date' => clean_text($post['preferred_date'] ?? '', 20),
        'subject' => clean_text($post['subject'] ?? '', 255),
        'message' => trim((string) ($post['message'] ?? '')),
        'privacy_agree' => isset($post['privacy_agree']),
    ];

    $errors = [];

    if ($data['fullname'] === '') {
        $errors[] = 'Full name is required.';
    }

    if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'A valid email address is required.';
    }

    if ($data['mobile'] === '') {
        $errors[] = 'Mobile number is required.';
    }

    if ($data['course'] === '') {
        $errors[] = 'Preferred course is required.';
    }

    if ($data['subject'] === '') {
        $errors[] = 'Subject is required.';
    }

    if ($data['message'] === '') {
        $errors[] = 'Message is required.';
    }

    if (mb_strlen($data['message']) > 1000) {
        $errors[] = 'Message must not exceed 1000 characters.';
    }

    if (!$data['privacy_agree']) {
        $errors[] = 'Data privacy agreement is required.';
    }

    if ($data['preferred_date'] !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $data['preferred_date'])) {
        $errors[] = 'Preferred date is invalid.';
    }

    return [$data, $errors];
}

function save_inquiry(array $data): array
{
    $pdo = db();

    /* A1 — duplicate-inquiry detection: if this email already has an
       OPEN inquiry (NEW / REPLIED / INVITED), don't create another.
       Return the existing reference so the applicant is pointed to it. */
    $existing = $pdo->prepare(
        "SELECT i.inquiry_no
         FROM inquiry i
         LEFT JOIN mnt_inquiry_status s ON s.id = i.status_id
         WHERE LOWER(TRIM(i.email)) = :em
           AND (s.code IN ('NEW','REPLIED','INVITED') OR s.code IS NULL)
         ORDER BY i.id DESC LIMIT 1"
    );
    $existing->execute(['em' => strtolower(trim((string) $data['email']))]);
    if ($existingNo = $existing->fetchColumn()) {
        return ['type' => 'existing', 'inquiry_no' => (string) $existingNo];
    }

    $inquiryNo = generate_reference($pdo, 'INQ');
    $inquiryTypeId = get_lookup_id($pdo, 'mnt_inquiry_type', 'ADMISSION');

    $message = "Preferred Contact: {$data['preferred_contact']}\n"
        . "Preferred Course: {$data['course']}\n"
        . "Preferred Schedule: {$data['schedule']}\n"
        . "Preferred Date: " . ($data['preferred_date'] !== '' ? $data['preferred_date'] : 'No preference') . "\n\n"
        . $data['message'];

    $pdo->beginTransaction();

    // New inquiries start with status NEW (migration must be applied).
    $newStatusId = $pdo->query("SELECT id FROM mnt_inquiry_status WHERE code = 'NEW'")->fetchColumn();
    $newStatusId = $newStatusId ? (int) $newStatusId : null;

    $stmt = $pdo->prepare(
        'INSERT INTO inquiry (
            inquiry_no, inquiry_type_id, full_name, email, mobile_no,
            preferred_contact, course_interest, preferred_schedule, preferred_date,
            subject, message, source, status_id, created_at, updated_at
        ) VALUES (
            :inquiry_no, :inquiry_type_id, :full_name, :email, :mobile_no,
            :preferred_contact, :course_interest, :preferred_schedule, :preferred_date,
            :subject, :message, :source, :status_id, NOW(), NOW()
        )'
    );
    $stmt->execute([
        ':inquiry_no' => $inquiryNo,
        ':inquiry_type_id' => $inquiryTypeId,
        ':full_name' => $data['fullname'],
        ':email' => $data['email'],
        ':mobile_no' => $data['mobile'],
        ':preferred_contact' => $data['preferred_contact'],
        ':course_interest' => $data['course'],
        ':preferred_schedule' => $data['schedule'],
        ':preferred_date' => $data['preferred_date'] !== '' ? $data['preferred_date'] : null,
        ':subject' => $data['subject'],
        ':message' => $message,
        ':source' => 'website',
        ':status_id' => $newStatusId,
    ]);

    $inquiryId = (int) $pdo->lastInsertId();

    $comm = $pdo->prepare(
        'INSERT INTO communication_log (
            inquiry_id, channel, direction, subject, message, created_at
        ) VALUES (
            :inquiry_id, :channel, :direction, :subject, :message, NOW()
        )'
    );
    $comm->execute([
        ':inquiry_id' => $inquiryId,
        ':channel' => 'email',
        ':direction' => 'inbound',
        ':subject' => $data['subject'],
        ':message' => $message,
    ]);

    $emailQueueId = queue_admin_email($pdo, $inquiryNo, $data, $message);
    $ackQueueId   = queue_applicant_acknowledgement($pdo, $inquiryNo, $data);

    $pdo->commit();

    /* The PUBLIC form must not block on SMTP. Emails are queued and
       delivered by the Email Center worker / "Send Pending Now". */
    return ['type' => 'new', 'inquiry_no' => $inquiryNo];
}

/**
 * Send the applicant a confirmation email with their reference
 * number. Returns the email_queue id (or 0 on failure).
 */
function queue_applicant_acknowledgement(PDO $pdo, string $inquiryNo, array $data): int
{
    $safeName = htmlspecialchars($data['fullname'], ENT_QUOTES, 'UTF-8');
    $safeCourse = htmlspecialchars($data['course'], ENT_QUOTES, 'UTF-8');
    $safeSubject = htmlspecialchars($data['subject'], ENT_QUOTES, 'UTF-8');

    $subject = "We received your inquiry ({$inquiryNo})";
    $body = <<<HTML
        <h2>Thank you, {$safeName}!</h2>
        <p>We have received your admissions inquiry and our team will get back to you
        within one (1) business day.</p>
        <p><strong>Your reference number:</strong> {$inquiryNo}</p>
        <p><strong>Course of interest:</strong> {$safeCourse}<br>
           <strong>Subject:</strong> {$safeSubject}</p>
        <p>Please keep your reference number — you may be asked for it when you
        follow up with the Admissions Office.</p>
        <p style="color:#6B7280;font-size:.85rem;">— USMCI Admissions Office</p>
    HTML;

    $stmt = $pdo->prepare(
        'INSERT INTO email_queue (recipient_email, subject, body_html, status, scheduled_at, created_at)
         VALUES (:email, :subject, :body, :status, NOW(), NOW())'
    );
    $stmt->execute([
        ':email' => $data['email'],
        ':subject' => $subject,
        ':body' => $body,
        ':status' => 'pending',
    ]);

    return (int) $pdo->lastInsertId();
}

function queue_admin_email(PDO $pdo, string $inquiryNo, array $data, string $message): int
{
    // Sanitize anything that will appear in email headers.
    $safeSubjectHeader = header_safe($data['subject']);
    $safeReplyToName = header_safe($data['fullname']);

    $subject = "[{$inquiryNo}] New Admissions Inquiry: {$safeSubjectHeader}";
    $body = '<h2>New Admissions Inquiry</h2>'
        . '<p><strong>Inquiry No:</strong> ' . htmlspecialchars($inquiryNo, ENT_QUOTES, 'UTF-8') . '</p>'
        . '<p><strong>Name:</strong> ' . htmlspecialchars($data['fullname'], ENT_QUOTES, 'UTF-8') . '</p>'
        . '<p><strong>Email:</strong> ' . htmlspecialchars($data['email'], ENT_QUOTES, 'UTF-8') . '</p>'
        . '<p><strong>Mobile:</strong> ' . htmlspecialchars($data['mobile'], ENT_QUOTES, 'UTF-8') . '</p>'
        . '<p><strong>Reply-To:</strong> ' . htmlspecialchars($data['email'], ENT_QUOTES, 'UTF-8') . '</p>'
        . '<hr><pre style="font-family:Arial,sans-serif;white-space:pre-wrap;">'
        . htmlspecialchars($message, ENT_QUOTES, 'UTF-8')
        . '</pre>';

    $stmt = $pdo->prepare(
        'INSERT INTO email_queue (
            recipient_email, subject, body_html, status, scheduled_at, created_at
        ) VALUES (
            :recipient_email, :subject, :body_html, :status, NOW(), NOW()
        )'
    );
    $notifyEmail = function_exists('mail_setting')
        ? (mail_setting('admin_notify_email', ADMIN_INQUIRY_EMAIL) ?: ADMIN_INQUIRY_EMAIL)
        : ADMIN_INQUIRY_EMAIL;

    $stmt->execute([
        ':recipient_email' => $notifyEmail,
        ':subject' => $subject,
        ':body_html' => $body,
        ':status' => 'pending',
    ]);

    if (MAIL_SEND_IMMEDIATELY) {
        $headers = [
            'MIME-Version: 1.0',
            'Content-type: text/html; charset=UTF-8',
            'From: ' . WEBSITE_FROM_NAME . ' <' . WEBSITE_FROM_EMAIL . '>',
            'Reply-To: ' . $safeReplyToName . ' <' . $data['email'] . '>',
        ];

        @mail($notifyEmail, $subject, $body, implode("\r\n", $headers));
    }

    return (int) $pdo->lastInsertId();
}
