<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Module      : Admissions Inquiry
 * File        : form.php
 * Version     : 2.1
 * Description : Inquiry Form — now includes the CSRF token
 *               field (validated by submit.php).
 * ---------------------------------------------------------
 */
$status = $_GET['status'] ?? '';
$inquiryNo = $_GET['inquiry_no'] ?? '';
$feedbackMessage = $_GET['message'] ?? '';

/* V5.51: course list is LIVE from Course Management (active courses);
   ?course=NAME pre-selects the course (from the website course modal). */
$preselectedCourse = trim((string) ($_GET['course'] ?? ''));
$inquiryCourses = [];
try {
    $pdo = function_exists('db') ? db() : null;
    if ($pdo) {
        $inquiryCourses = $pdo->query("SELECT course_name FROM mnt_course WHERE is_active = 1 ORDER BY course_name")->fetchAll(PDO::FETCH_COLUMN) ?: [];
    }
} catch (Throwable $e) {
    $inquiryCourses = [];
}
?>

<section class="inquiry-form-section">

    <div class="inquiry-card">

        <div class="card-header">

            <h2>Send us your Inquiry</h2>

            <p>
                Complete the form below and our Admissions Team
                will contact you as soon as possible.
            </p>

        </div>

        <?php if ($status === 'success'): ?>
            <div id="inquiry-toast" class="inquiry-toast inquiry-toast--success" role="status" aria-live="polite">
                <span class="inquiry-toast__icon">✓</span>
                <div class="inquiry-toast__text">
                    <strong>Inquiry sent successfully.</strong>
                    <?php if ($inquiryNo !== ''): ?>
                        <span>Your reference number is <?= htmlspecialchars($inquiryNo, ENT_QUOTES, 'UTF-8'); ?>.</span>
                    <?php endif; ?>
                </div>
            </div>
        <?php elseif ($status === 'existing'): ?>
            <div id="inquiry-toast" class="inquiry-toast inquiry-toast--info" role="status" aria-live="polite">
                <span class="inquiry-toast__icon">ℹ️</span>
                <div class="inquiry-toast__text">
                    <strong>We already have your inquiry.</strong>
                    <?php if ($inquiryNo !== ''): ?>
                        <span>Your reference number is <?= htmlspecialchars($inquiryNo, ENT_QUOTES, 'UTF-8'); ?> — our admissions team will get back to you.</span>
                    <?php endif; ?>
                </div>
            </div>
        <?php elseif ($status === 'error'): ?>
            <div id="inquiry-toast" class="inquiry-toast inquiry-toast--error" role="alert">
                <span class="inquiry-toast__icon">!</span>
                <div class="inquiry-toast__text">
                    <strong>Inquiry was not sent.</strong>
                    <span><?= htmlspecialchars($feedbackMessage !== '' ? $feedbackMessage : 'Please check the form and try again.', ENT_QUOTES, 'UTF-8'); ?></span>
                </div>
            </div>
        <?php endif; ?>

        <form id="inquiryForm" method="post" action="<?= htmlspecialchars(base_url('sections/admissions/inquiry/submit.php'), ENT_QUOTES, 'UTF-8'); ?>">

            <?= csrf_field(); ?>

            <?php if (!empty($inquiryReturnUrl)): ?>
                <input type="hidden" name="return_to" value="<?= htmlspecialchars($inquiryReturnUrl, ENT_QUOTES, 'UTF-8'); ?>">
            <?php endif; ?>

            <!-- PERSONAL -->

            <div class="form-section">

                <h3>

                    <span>👤</span>

                    Personal Information

                </h3>

                <div class="form-grid grid-2">

                    <div class="form-group">

                        <label>

                            Full Name
                            <span class="required">*</span>

                        </label>

                        <input
                            class="form-control"
                            type="text"
                            name="fullname"
                            placeholder="Juan Dela Cruz"
                            required>

                    </div>

                    <div class="form-group">

                        <label>Email Address <span class="required">*</span></label>

                        <input
                            class="form-control"
                            type="email"
                            name="email"
                            placeholder="juan@email.com"
                            required>

                    </div>

                    <div class="form-group">

                        <label>Mobile Number <span class="required">*</span></label>

                        <input
                            class="form-control"
                            type="text"
                            name="mobile"
                            placeholder="09XXXXXXXXX"
                            required>

                    </div>

                    <div class="form-group">

                        <label>Preferred Contact</label>

                        <select class="form-control" name="preferred_contact">

                            <option>Email</option>
                            <option>Phone Call</option>
                            <option>SMS</option>

                        </select>

                    </div>

                </div>

            </div>

            <!-- TRAINING -->

            <div class="form-section">

                <h3>

                    <span>🎓</span>

                    Training Interest

                </h3>

                <div class="form-grid grid-3">

                    <div class="form-group">

                        <label>Preferred Course <span class="required">*</span></label>

                        <select class="form-control" name="course" required>

                            <option value="">Select Course</option>
                            <?php if ($inquiryCourses): ?>
                                <?php foreach ($inquiryCourses as $ic):
                                    $sel = ($preselectedCourse !== '' && strcasecmp($ic, $preselectedCourse) === 0) ? 'selected' : '';
                                ?>
                                    <option value="<?= e($ic); ?>" <?= $sel; ?>><?= e($ic); ?></option>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <option value="Other / Not Sure">Other / Not Sure</option>
                            <?php endif; ?>
                            <option value="Other / Not Sure">Other / Not Sure</option>

                        </select>

                    </div>

                    <div class="form-group">

                        <label>Preferred Schedule</label>

                        <select class="form-control" name="schedule">

                            <option>No Preference</option>
                            <option>Morning</option>
                            <option>Afternoon</option>
                            <option>Weekend</option>

                        </select>

                    </div>

                    <div class="form-group">

                        <label>Preferred Date</label>

                        <input
                            class="form-control"
                            type="date"
                            name="preferred_date">

                    </div>

                </div>

            </div>

            <!-- MESSAGE -->

            <div class="form-section">

                <h3>

                    <span>💬</span>

                    Inquiry Details

                </h3>

                <div class="form-grid grid-2">

                    <div class="form-group">

                        <label>Subject <span class="required">*</span></label>

                        <input
                            class="form-control"
                            type="text"
                            name="subject"
                            placeholder="Course Fees"
                            required>

                    </div>

                    <div class="form-group">

                        <label>&nbsp;</label>

                        <div class="privacy-inline">

                            <input type="checkbox" id="privacyAgree" name="privacy_agree" value="1" required>

                            <label for="privacyAgree">
                                🛡️ I agree to the
                                <a href="#" tabindex="-1">Data Privacy Act of 2012</a>
                                terms.
                            </label>

                        </div>

                    </div>

                    <div class="form-group full">

                        <label>Message <span class="required">*</span></label>

                        <textarea
                                class="form-control"
                                id="message"
                                name="message"
                                rows="3"
                                maxlength="1000"
                                required
                                placeholder="Please type your inquiry here..."
                            ></textarea>

                        <div class="character-counter">
                            <span id="messageCount">0</span>/1000
                        </div>

                    </div>

                </div>

            </div>

            <!-- BUTTONS -->

            <div class="form-actions">

                <button
                    type="reset"
                    class="btn btn-secondary">

                    ← Cancel

                </button>

                <button
                    type="submit"
                    class="btn btn-primary">

                    Send Inquiry →

                </button>

            </div>

        </form>

    </div>

</section>
