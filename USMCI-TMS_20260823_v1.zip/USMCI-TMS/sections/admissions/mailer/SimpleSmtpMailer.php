<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Simple SMTP Mailer
 * ---------------------------------------------------------
 * A minimal, dependency-free SMTP client — no Composer/
 * PHPMailer required. Supports STARTTLS + AUTH LOGIN, which
 * is exactly what Gmail SMTP needs (smtp.gmail.com:587).
 *
 * v2.0: settings are resolved from mnt_system_setting via
 * smtp_config() (config/mail.php) when the $config parameter
 * is not supplied — the Email Center can change the account
 * without touching code. Falls back to PHP mail() when no
 * SMTP host is configured.
 * ---------------------------------------------------------
 */

declare(strict_types=1);

final class SimpleSmtpMailer
{
    /**
     * @param array{host?: string, port?: int, encryption?: string,
     *               username?: string, password?: string,
     *               from_email?: string, from_name?: string}|null $config
     * @return array{success: bool, error: ?string}
     */
    public static function send(string $toEmail, string $subject, string $bodyHtml, ?string $replyTo = null, ?array $config = null): array
    {
        if ($config === null && function_exists('smtp_config')) {
            $config = smtp_config();
        }

        $config = $config ?? [];

        $host = (string) ($config['host'] ?? (defined('SMTP_HOST') ? SMTP_HOST : ''));

        if ($host !== '') {
            return self::sendViaSmtp($toEmail, $subject, $bodyHtml, $replyTo, $config);
        }

        return self::sendViaPhpMail($toEmail, $subject, $bodyHtml, $replyTo, $config);
    }

    /**
     * @param array{from_email?: string, from_name?: string} $config
     */
    private static function sendViaPhpMail(string $toEmail, string $subject, string $bodyHtml, ?string $replyTo, array $config): array
    {
        $fromEmail = (string) ($config['from_email'] ?? (defined('WEBSITE_FROM_EMAIL') ? WEBSITE_FROM_EMAIL : 'no-reply@localhost'));
        $fromName  = (string) ($config['from_name'] ?? (defined('WEBSITE_FROM_NAME') ? WEBSITE_FROM_NAME : 'USMCI-TMS'));

        $headers = "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
        $headers .= "From: {$fromName} <{$fromEmail}>\r\n";

        if ($replyTo !== null && $replyTo !== '') {
            $headers .= "Reply-To: {$replyTo}\r\n";
        }

        $sent = @mail($toEmail, $subject, $bodyHtml, $headers);

        return $sent
            ? ['success' => true, 'error' => null]
            : ['success' => false, 'error' => 'PHP mail() returned false — check your php.ini sendmail/SMTP settings.'];
    }

    /**
     * @param array{port?: int, encryption?: string, username?: string,
     *               password?: string, from_email?: string, from_name?: string} $config
     */
    private static function sendViaSmtp(string $toEmail, string $subject, string $bodyHtml, ?string $replyTo, array $config): array
    {
        $host = (string) ($config['host'] ?? '');
        $port = (int) ($config['port'] ?? 587);
        $encryption = (string) ($config['encryption'] ?? 'tls');
        $username = (string) ($config['username'] ?? '');
        $password = (string) ($config['password'] ?? '');
        $fromEmail = (string) ($config['from_email'] ?? $username);
        $fromName = (string) ($config['from_name'] ?? 'USMCI-TMS');

        $socket = @stream_socket_client(
            "tcp://{$host}:{$port}",
            $errno,
            $errstr,
            5,               // short connect timeout so the UI never hangs
            STREAM_CLIENT_CONNECT
        );

        if ($socket === false) {
            return ['success' => false, 'error' => "Could not connect to {$host}:{$port} — {$errstr}"];
        }

        try {
            self::expect($socket, 220);
            self::command($socket, "EHLO " . gethostname(), 250);

            if ($encryption === 'tls') {
                self::command($socket, "STARTTLS", 220);

                if (!stream_socket_enable_crypto($socket, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) {
                    return ['success' => false, 'error' => 'STARTTLS negotiation failed.'];
                }

                self::command($socket, "EHLO " . gethostname(), 250);
            }

            if ($username !== '') {
                self::command($socket, "AUTH LOGIN", 334);
                self::command($socket, base64_encode($username), 334);
                self::command($socket, base64_encode($password), 235);
            }

            self::command($socket, "MAIL FROM:<{$fromEmail}>", 250);
            self::command($socket, "RCPT TO:<{$toEmail}>", 250);
            self::command($socket, "DATA", 354);

            $headers = "From: {$fromName} <{$fromEmail}>\r\n";
            $headers .= "To: <{$toEmail}>\r\n";
            $headers .= "Subject: {$subject}\r\n";
            $headers .= "MIME-Version: 1.0\r\n";
            $headers .= "Content-Type: text/html; charset=UTF-8\r\n";

            if ($replyTo !== null && $replyTo !== '') {
                $headers .= "Reply-To: {$replyTo}\r\n";
            }

            // Dot-stuff any line that starts with a lone "." per RFC 5321.
            $escapedBody = preg_replace('/^\./m', '..', $bodyHtml);

            self::command($socket, $headers . "\r\n" . $escapedBody . "\r\n.", 250);
            self::command($socket, "QUIT", 221);

            return ['success' => true, 'error' => null];
        } catch (RuntimeException $exception) {
            return ['success' => false, 'error' => $exception->getMessage()];
        } finally {
            fclose($socket);
        }
    }

    /** @param resource $socket */
    private static function command($socket, string $line, int $expectedCode): string
    {
        fwrite($socket, $line . "\r\n");

        return self::expect($socket, $expectedCode);
    }

    /** @param resource $socket */
    private static function expect($socket, int $expectedCode): string
    {
        $response = '';

        while ($line = fgets($socket, 515)) {
            $response .= $line;

            // Multi-line SMTP responses use "code-" until the final "code ".
            if (isset($line[3]) && $line[3] === ' ') {
                break;
            }
        }

        $actualCode = (int) substr($response, 0, 3);

        if ($actualCode !== $expectedCode) {
            throw new RuntimeException("Expected SMTP {$expectedCode}, got: " . trim($response));
        }

        return $response;
    }
}
