<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Admin: Void certificate (AJAX)
 * File : sections/admissions/admin/certificate_void.php
 * ---------------------------------------------------------
 * JSON endpoint used by the Certificate Issuing page to VOID
 * a certificate. The verification link then shows VOID.
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/config/bootstrap.php';

require_edit('certificates');

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'POST required.']);
    exit;
}

csrf_check();

$certId = (int) ($_POST['certificate_id'] ?? 0);
$remarks = trim((string) ($_POST['remarks'] ?? ''));

if (!$certId) {
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => 'Certificate id is required.']);
    exit;
}

try {
    $pdo = db();

    $stmt = $pdo->prepare('SELECT id, certificate_no, status FROM certificate WHERE id = :id');
    $stmt->execute(['id' => $certId]);
    $cert = $stmt->fetch();

    if (!$cert) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'Certificate not found.']);
        exit;
    }

    if ($cert['status'] === 'void') {
        http_response_code(422);
        echo json_encode(['success' => false, 'message' => 'This certificate is already void.']);
        exit;
    }

    $pdo->prepare("UPDATE certificate SET status = 'void', void_remarks = :rm, updated_at = NOW() WHERE id = :id")
        ->execute(['rm' => $remarks !== '' ? $remarks : null, 'id' => $certId]);

    audit_log('certificates', 'void', $certId, "Certificate {$cert['certificate_no']} voided" . ($remarks !== '' ? " — " . $remarks : ''));

    echo json_encode(['success' => true, 'message' => "Certificate {$cert['certificate_no']} voided."]);
} catch (Throwable $e) {
    error_log('certificate_void: ' . $e->getMessage());
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => 'Could not void the certificate.']);
}
exit;
