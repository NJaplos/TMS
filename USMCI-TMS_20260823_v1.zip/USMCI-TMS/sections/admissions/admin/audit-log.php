<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Admin: Audit Log
 * File : sections/admissions/admin/audit-log.php
 * ---------------------------------------------------------
 * Read-only trail of money/legal-sensitive actions:
 * payment records/voids, certificate voids, applicant deletes,
 * staff account changes. Filterable by module.
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/config/bootstrap.php';

require_access('reports');
if ($_SERVER['REQUEST_METHOD'] === 'POST') { require_edit('reports'); }

$pdo = db();

$module = trim((string) ($_GET['module'] ?? ''));
$kw     = trim((string) ($_GET['q'] ?? ''));
$page = max(1, (int) ($_GET['page'] ?? 1));
$perPage = 50;

$modules = [
    'payments'     => 'Payments',
    'certificates' => 'Certificates',
    'applicants'   => 'Applicants',
    'enrollments'  => 'Enrollments',
    'requirements' => 'Requirements',
    'staff'        => 'Staff Accounts',
];

$where = ' WHERE 1 = 1';
$params = [];
if ($module !== '' && array_key_exists($module, $modules)) {
    $where .= ' AND table_name = :m';
    $params['m'] = $module;
}
if ($kw !== '') {
    /* Distinct named params — native prepares reject reused names */
    $where .= ' AND (a.action LIKE :kw1 OR CAST(a.record_id AS CHAR) LIKE :kw2 OR a.new_values LIKE :kw3 OR u.full_name LIKE :kw4 OR u.username LIKE :kw5)';
    $like = '%' . $kw . '%';
    $params = array_merge($params, ['kw1' => $like, 'kw2' => $like, 'kw3' => $like, 'kw4' => $like, 'kw5' => $like]);
}

$cntStmt = $pdo->prepare(
    'SELECT COUNT(*) FROM audit_log a LEFT JOIN sys_user u ON u.id = a.actor_id' . $where
);
$cntStmt->execute($params);
$total = (int) $cntStmt->fetchColumn();
$totalPages = max(1, (int) ceil($total / $perPage));
if ($page > $totalPages) { $page = $totalPages; }
$offset = ($page - 1) * $perPage;

$stmt = $pdo->prepare(
    "SELECT a.actor_id, a.action, a.table_name, a.record_id, a.new_values AS detail, a.ip_address, a.created_at,
            COALESCE(NULLIF(TRIM(u.full_name), ''), u.username, 'System') AS actor_name
     FROM audit_log a
     LEFT JOIN sys_user u ON u.id = a.actor_id" . $where . '
     ORDER BY a.id DESC LIMIT ' . $perPage . ' OFFSET ' . $offset
);
$stmt->execute($params);
$rows = $stmt->fetchAll() ?: [];

$page = [
    'title'       => 'Audit Log | USMCI-TMS',
    'description' => 'Audit Log',
    'bodyClass'   => 'admissions-page',
];
?>
<!DOCTYPE html>
<html lang="en">

<?php include INCLUDES_PATH . '/head.php'; ?>

<link rel="stylesheet" href="<?= e(base_url('assets/css/portal.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/workspace.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/inquiry-queue/assets/css/page.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/admin/dashboard.css?v=' . ASSET_VERSION)); ?>">

<body class="<?= e($page['bodyClass']); ?>">

    <?php include NAVBAR_PATH . '/index.php'; ?>

    <section class="portal-shell portal-shell--2col">

        <?php require ADMISSIONS_PATH . '/inquiry-queue/partials/sidebar.php'; ?>

        <main class="portal-content">

            <header class="workspace-header">
                <div class="workspace-header__left">
                    <span class="section-badge">Trail</span>
                    <h1>Audit Log</h1>
                    <p>Who did what — payments, certificates, applicants, staff accounts. Read-only.</p>
                </div>
            </header>

            <!-- Module filter + search (auto-submit) -->
            <section class="workspace-toolbar">
                <form method="get" action="<?= e(base_url('sections/admissions/admin/audit-log.php')); ?>" id="auditFilter" style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
                    <select name="module" id="auditModule" style="height:38px;padding:0 10px;border:1px solid #CBD5E1;border-radius:10px;font-family:inherit;">
                        <option value="">All Modules</option>
                        <?php foreach ($modules as $val => $label): ?>
                            <option value="<?= e($val); ?>" <?= $module === $val ? 'selected' : ''; ?>><?= e($label); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <input type="text" name="q" value="<?= e($kw); ?>" placeholder="Search action, record, user..." style="height:38px;padding:0 12px;border:1px solid #CBD5E1;border-radius:10px;font-family:inherit;width:240px;">
                    <button type="submit" class="btn-secondary btn-sm">Filter</button>
                    <?php if ($module !== '' || $kw !== ''): ?>
                        <a href="<?= e(base_url('sections/admissions/admin/audit-log.php')); ?>" class="btn-secondary btn-sm" style="text-decoration:none;">✕ Clear</a>
                    <?php endif; ?>
                </form>
            </section>

            <section class="workspace-table">
                <div class="dash-panel__head"><h2>Entries (<?= number_format($total); ?>)</h2></div>
                <div class="table-responsive">
                    <table class="inquiry-table">
                        <thead>
                            <tr><th>When</th><th>User</th><th>Module</th><th>Action</th><th>Record</th><th>Detail</th><th>IP</th></tr>
                        </thead>
                        <tbody>
                            <?php if (!$rows): ?>
                                <tr><td colspan="7" style="text-align:center;color:#94A3B8;padding:30px;">No audit entries yet.</td></tr>
                            <?php endif; ?>
                            <?php foreach ($rows as $r): ?>
                                <tr>
                                    <td><?= e(date('M d, Y H:i', strtotime($r['created_at']))); ?></td>
                                    <td><?= e($r['actor_name']); ?></td>
                                    <td><span class="status-badge"><?= e($modules[$r['table_name']] ?? $r['table_name']); ?></span></td>
                                    <td><?= e(str_replace($r['table_name'] . '.', '', $r['action'])); ?></td>
                                    <td><?= $r['record_id'] ? (int) $r['record_id'] : '—'; ?></td>
                                    <td style="max-width:360px;"><?= e((json_decode((string)($r['detail'] ?? ''), true)['detail'] ?? ($r['detail'] ?? '—'))); ?></td>
                                    <td><?= e($r['ip_address'] ?? '—'); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php if ($totalPages > 1): ?>
                    <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;padding:12px 20px;border-top:1px solid #E2E8F0;">
                        <span style="font-size:.82rem;color:#64748B;">Page <?= $page; ?> of <?= $totalPages; ?></span>
                        <div style="display:flex;gap:6px;">
                            <?php if ($page > 1): ?>
                                <a class="btn-secondary btn-sm" style="text-decoration:none;" href="<?= e(base_url('sections/admissions/admin/audit-log.php?module=' . urlencode($module) . '&page=' . ($page - 1))); ?>">← Prev</a>
                            <?php endif; ?>
                            <?php if ($page < $totalPages): ?>
                                <a class="btn-secondary btn-sm" style="text-decoration:none;" href="<?= e(base_url('sections/admissions/admin/audit-log.php?module=' . urlencode($module) . '&page=' . ($page + 1))); ?>">Next →</a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?>
            </section>

        </main>
    </section>

    <?php include INCLUDES_PATH . '/footer.php'; ?>
    <?php include INCLUDES_PATH . '/scripts.php'; ?>

    <script>
        (function () {
            var sel = document.getElementById("auditModule");
            if (sel) sel.addEventListener("change", function () { document.getElementById("auditFilter").submit(); });
        })();
    </script>

</body>
</html>
