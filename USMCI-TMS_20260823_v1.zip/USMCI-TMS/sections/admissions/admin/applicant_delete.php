<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Admin: Delete applicant (AJAX)
 * File : sections/admissions/admin/applicant_delete.php
 * ---------------------------------------------------------
 * Removes an applicant record and its dependent rows (enrollments,
 * application, profile, invitation, account, inquiries) so the
 * Applicants grid stays clean once someone is fully handled.
 *
 * Guards (accounting / legal trail):
 *   - BLOCKED if the applicant has official receipts
 *   - BLOCKED if the applicant has issued certificates
 * All other dependent rows are deleted in FK-safe order inside
 * one transaction.
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/config/bootstrap.php';

require_edit('applicants');

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'POST required.']);
    exit;
}

csrf_check();

$applicantId = (int) ($_POST['applicant_id'] ?? 0);

if (!$applicantId) {
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => 'Applicant id is required.']);
    exit;
}

try {
    $pdo = db();
    $pdo->beginTransaction();

    $stmt = $pdo->prepare('SELECT id, applicant_no, first_name, last_name FROM applicant WHERE id = :id');
    $stmt->execute(['id' => $applicantId]);
    $app = $stmt->fetch();

    if (!$app) {
        $pdo->rollBack();
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'Applicant not found.']);
        exit;
    }

    /* ---- Guards: receipts + certificates are official records ---- */
    $stmt = $pdo->prepare(
        "SELECT COUNT(*) FROM official_receipt r
         JOIN payment_transaction pt ON pt.id = r.payment_transaction_id
         JOIN payment p ON p.id = pt.payment_id
         WHERE p.applicant_id = :id"
    );
    $stmt->execute(['id' => $applicantId]);
    if ((int) $stmt->fetchColumn() > 0) {
        $pdo->rollBack();
        http_response_code(422);
        echo json_encode(['success' => false, 'message' => 'Cannot delete — this applicant has official receipt(s). Keep for accounting.']);
        exit;
    }

    $stmt = $pdo->prepare('SELECT COUNT(*) FROM certificate WHERE applicant_id = :id');
    $stmt->execute(['id' => $applicantId]);
    if ((int) $stmt->fetchColumn() > 0) {
        $pdo->rollBack();
        http_response_code(422);
        echo json_encode(['success' => false, 'message' => 'Cannot delete — this applicant has issued certificate(s). Void them first or keep the record.']);
        exit;
    }

    /* ---- Dependent rows, FK-safe order ---- */
    $enrollmentIds = $pdo->prepare('SELECT id FROM enrollment WHERE applicant_id = :id');
    $enrollmentIds->execute(['id' => $applicantId]);
    $eids = array_map('intval', $enrollmentIds->fetchAll(PDO::FETCH_COLUMN));

    $applicationIds = $pdo->prepare('SELECT id FROM application WHERE applicant_id = :id');
    $applicationIds->execute(['id' => $applicantId]);
    $aids = array_map('intval', $applicationIds->fetchAll(PDO::FETCH_COLUMN));

    $paymentIds = $pdo->prepare('SELECT id FROM payment WHERE applicant_id = :id');
    $paymentIds->execute(['id' => $applicantId]);
    $pids = array_map('intval', $paymentIds->fetchAll(PDO::FETCH_COLUMN));

    $inquiryIds = $pdo->prepare('SELECT id FROM inquiry WHERE applicant_id = :id');
    $inquiryIds->execute(['id' => $applicantId]);
    $iids = array_map('intval', $inquiryIds->fetchAll(PDO::FETCH_COLUMN));

    $del = function (string $sql, array $ids) use ($pdo) {
        if (!$ids) return;
        $in = implode(',', array_fill(0, count($ids), '?'));
        $pdo->prepare(str_replace(':IN', $in, $sql))->execute($ids);
    };

    /* enrollment children */
    $del('DELETE FROM enrollment_history WHERE enrollment_id IN (:IN)', $eids);
    $del('DELETE FROM enrollment_schedule WHERE enrollment_id IN (:IN)', $eids);
    $del('DELETE FROM enrollment_subject WHERE enrollment_id IN (:IN)', $eids);
    $del('DELETE FROM training_attendance WHERE enrollment_id IN (:IN)', $eids);
    $del('DELETE FROM training_completion WHERE enrollment_id IN (:IN)', $eids);

    /* payment chain (no receipts — guarded above) */
    $del('DELETE FROM payment_item WHERE payment_id IN (:IN)', $pids);
    $del('DELETE FROM refund WHERE payment_id IN (:IN)', $pids);
    $del('DELETE FROM payment_transaction WHERE payment_id IN (:IN)', $pids);
    $del('DELETE FROM payment WHERE id IN (:IN)', $pids);

    /* application children */
    $del('DELETE FROM application_course WHERE application_id IN (:IN)', $aids);
    $del('DELETE FROM application_requirement WHERE application_id IN (:IN)', $aids);
    $del('DELETE FROM application_review WHERE application_id IN (:IN)', $aids);
    $del('DELETE FROM application_status_history WHERE application_id IN (:IN)', $aids);

    /* inquiry children */
    $del('DELETE FROM inquiry_reply WHERE inquiry_id IN (:IN)', $iids);
    $del('DELETE FROM inquiry_attachment WHERE inquiry_id IN (:IN)', $iids);
    $del('DELETE FROM applicant_invitation WHERE inquiry_id IN (:IN)', $iids);

    /* direct applicant children */
    $del('DELETE FROM applicant_invitation WHERE applicant_id IN (:IN)', [$applicantId]);
    $del('DELETE FROM applicant_profile WHERE applicant_id IN (:IN)', [$applicantId]);
    $del('DELETE FROM applicant_activity_log WHERE applicant_id IN (:IN)', [$applicantId]);
    $del('DELETE FROM applicant_notification WHERE applicant_id IN (:IN)', [$applicantId]);
    $del('DELETE FROM applicant_account WHERE applicant_id IN (:IN)', [$applicantId]);
    $del('DELETE FROM medical_record WHERE applicant_id IN (:IN)', [$applicantId]);
    $del('DELETE FROM seafarer_credential WHERE applicant_id IN (:IN)', [$applicantId]);
    $del('DELETE FROM sea_service_record WHERE applicant_id IN (:IN)', [$applicantId]);
    $del('DELETE FROM ship_assignment WHERE applicant_id IN (:IN)', [$applicantId]);
    $del('DELETE FROM communication_log WHERE applicant_id IN (:IN)', [$applicantId]);

    /* parents */
    $del('DELETE FROM enrollment WHERE applicant_id IN (:IN)', [$applicantId]);
    $del('DELETE FROM application WHERE applicant_id IN (:IN)', [$applicantId]);
    $del('DELETE FROM inquiry WHERE applicant_id IN (:IN)', [$applicantId]);
    $del('DELETE FROM applicant WHERE id IN (:IN)', [$applicantId]);

    $pdo->commit();

    audit_log('applicants', 'delete', $applicantId, "Applicant {$app['applicant_no']} ({$app['first_name']} {$app['last_name']}) removed with dependent records");

    echo json_encode(['success' => true, 'message' => "Applicant {$app['applicant_no']} removed from the list."]);
} catch (Throwable $e) {
    if (isset($pdo) && $pdo->inTransaction()) { $pdo->rollBack(); }
    error_log('applicant_delete: ' . $e->getMessage());
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => 'Could not delete the applicant.']);
}
exit;
