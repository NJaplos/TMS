<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Admin: Applicant form data (AJAX)
 * File : sections/admissions/admin/applicant_form_data.php
 * ---------------------------------------------------------
 * Returns the applicant's basic + profile fields so the Create
 * Enrollment modal auto-fills them when an existing applicant
 * is selected ("data must be automatically filled up if the
 * trainee has an account").
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/config/bootstrap.php';

require_access('enrollment');

header('Content-Type: application/json');

$applicantId = (int) ($_GET['applicant_id'] ?? 0);
if (!$applicantId) {
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => 'Applicant id is required.']);
    exit;
}

try {
    $pdo = db();
    $stmt = $pdo->prepare(
        "SELECT a.id, a.applicant_no, a.first_name, a.middle_name, a.last_name, a.suffix,
                a.birth_date, a.gender_id, a.civil_status_id, a.nationality_id, a.mobile_no, a.email,
                ap.place_of_birth, ap.address_line1, ap.address_line2, ap.postal_code, ap.country_id,
                ap.emergency_contact_name, ap.emergency_contact_no, ap.relationship_id,
                ap.seafarer_id_no, ap.rank_position, ap.sirb_no, ap.cdc_no,
                ap.passport_no, ap.passport_expiry, ap.medical_certificate_no, ap.medical_expiry,
                ap.photo_path
         FROM applicant a
         LEFT JOIN applicant_profile ap ON ap.applicant_id = a.id
         WHERE a.id = :id LIMIT 1"
    );
    $stmt->execute(['id' => $applicantId]);
    $r = $stmt->fetch();

    if (!$r) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'Applicant not found.']);
        exit;
    }

    echo json_encode(['success' => true, 'data' => $r]);
} catch (Throwable $e) {
    error_log('applicant_form_data: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Could not load the applicant.']);
}
exit;
