<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Module      : Admissions
 * Page        : Admin Dashboard (staff home)
 * File        : index.php
 * Version     : 1.0
 *
 * Description :
 * Staff landing page after login. KPI cards, recent
 * inquiries, quick actions — one glance at the operation.
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/config/bootstrap.php';

/* Staff only */
require_access('dashboard');
if ($_SERVER['REQUEST_METHOD'] === 'POST') { require_edit('dashboard'); }

$pdo = db();

/* ---- KPI counts ---- */
$kpi = [
    'total_inquiries'  => (int) $pdo->query('SELECT COUNT(*) FROM inquiry')->fetchColumn(),
    'today_inquiries'  => (int) $pdo->query('SELECT COUNT(*) FROM inquiry WHERE DATE(created_at) = CURDATE()')->fetchColumn(),
    'new_inquiries'    => (int) $pdo->query(
        "SELECT COUNT(*) FROM inquiry i LEFT JOIN mnt_inquiry_status s ON s.id = i.status_id
         WHERE i.status_id IS NULL OR s.code = 'NEW'"
    )->fetchColumn(),
    'replied'          => (int) $pdo->query(
        "SELECT COUNT(DISTINCT i.id)
         FROM inquiry i
         JOIN inquiry_reply r ON r.inquiry_id = i.id
         WHERE i.email IS NOT NULL AND TRIM(i.email) <> ''
         AND i.email <> '0'"
    )->fetchColumn(),
    'applicants'       => (int) $pdo->query(
        "SELECT COUNT(DISTINCT LOWER(TRIM(email)))
         FROM applicant
         WHERE email IS NOT NULL AND TRIM(email) <> '' AND email <> '0'"
    )->fetchColumn(),
    'pending_emails'   => (int) $pdo->query("SELECT COUNT(*) FROM email_queue WHERE status = 'pending'")->fetchColumn(),
];

/* ---- Recent inquiries ---- */
$recent = $pdo->query(
    "SELECT i.id, i.inquiry_no, i.full_name, i.email, i.course_interest, i.created_at,
            s.code AS status_code, s.label AS status_label
     FROM inquiry i
     LEFT JOIN mnt_inquiry_status s ON s.id = i.status_id
     ORDER BY i.created_at DESC
     LIMIT 8"
)->fetchAll();

/* ---- Latest applicants ---- */
$recentApplicants = $pdo->query(
    'SELECT id, applicant_no, first_name, last_name, email, created_at
     FROM applicant ORDER BY id DESC LIMIT 5'
)->fetchAll();

$user = current_user();

$page = [
    'title'       => 'Dashboard | USMCI-TMS',
    'description' => 'Admissions Dashboard',
    'bodyClass'   => 'admissions-page',
];
?>
<!DOCTYPE html>
<html lang="en">

<?php include INCLUDES_PATH . '/head.php'; ?>

<link rel="stylesheet" href="<?= e(base_url('assets/css/portal.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/workspace.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/inquiry-queue/assets/css/page.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/admin/dashboard.css?v=' . ASSET_VERSION)); ?>">

<body class="<?= e($page['bodyClass']); ?>">

    <?php include NAVBAR_PATH . '/index.php'; ?>

    <section class="portal-shell portal-shell--2col">

        <?php require ADMISSIONS_PATH . '/inquiry-queue/partials/sidebar.php'; ?>

        <main class="portal-content admin-dashboard">

            <header class="workspace-header">
                <div class="workspace-header__left">
                    <span class="section-badge">Overview</span>
                    <h1>Welcome back, <?= e($user['full_name'] ?? 'Staff'); ?> 👋</h1>
                    <p>Here's what's happening in the admissions pipeline today.</p>
                </div>
                <div class="workspace-header__right">
                    <a class="btn-primary dash-btn" href="<?= e(base_url('sections/admissions/inquiry-queue/index.php')); ?>">Open Inquiry Queue →</a>
                </div>
            </header>

            <!-- ================= KPI CARDS ================= -->
            <div class="kpi-grid">
                <div class="kpi-card">
                    <div class="kpi-card__icon" style="background:#EAF6F2;">📨</div>
                    <div>
                        <div class="kpi-card__value"><?= number_format($kpi['total_inquiries']); ?></div>
                        <div class="kpi-card__label">Total Inquiries</div>
                    </div>
                </div>
                <div class="kpi-card">
                    <div class="kpi-card__icon" style="background:#EFF6FF;">📅</div>
                    <div>
                        <div class="kpi-card__value"><?= number_format($kpi['today_inquiries']); ?></div>
                        <div class="kpi-card__label">Today's Inquiries</div>
                    </div>
                </div>
                <div class="kpi-card">
                    <div class="kpi-card__icon" style="background:#FEF3C7;">⏳</div>
                    <div>
                        <div class="kpi-card__value"><?= number_format($kpi['new_inquiries']); ?></div>
                        <div class="kpi-card__label">Awaiting Reply</div>
                    </div>
                </div>
                <div class="kpi-card">
                    <div class="kpi-card__icon" style="background:#DCFCE7;">✅</div>
                    <div>
                        <div class="kpi-card__value"><?= number_format($kpi['replied']); ?></div>
                        <div class="kpi-card__label">Replied / Progressed</div>
                    </div>
                </div>
                <div class="kpi-card">
                    <div class="kpi-card__icon" style="background:#F3E8FF;">👥</div>
                    <div>
                        <div class="kpi-card__value"><?= number_format($kpi['applicants']); ?></div>
                        <div class="kpi-card__label">Applicants</div>
                    </div>
                </div>
                <div class="kpi-card">
                    <div class="kpi-card__icon" style="background:#FFE4E6;">📧</div>
                    <div>
                        <div class="kpi-card__value"><?= number_format($kpi['pending_emails']); ?></div>
                        <div class="kpi-card__label">Pending Emails</div>
                    </div>
                </div>
            </div>

            <!-- ================= RECENT INQUIRIES ================= -->
            <section class="dash-panel">
                <div class="dash-panel__head">
                    <h2>Recent Inquiries</h2>
                    <a href="<?= e(base_url('sections/admissions/inquiry-queue/index.php')); ?>">View all →</a>
                </div>
                <div class="table-responsive">
                    <table class="inquiry-table">
                        <thead>
                            <tr>
                                <th>Inquiry No.</th>
                                <th>Date</th>
                                <th>Applicant</th>
                                <th>Email</th>
                                <th>Course</th>
                                <th>Status</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!$recent): ?>
                                <tr><td colspan="7" style="text-align:center;color:#94A3B8;padding:28px;">No inquiries yet.</td></tr>
                            <?php endif; ?>
                            <?php foreach ($recent as $r): ?>
                                <tr>
                                    <td><?= e($r['inquiry_no']); ?></td>
                                    <td><?= e(date('M d, Y', strtotime($r['created_at']))); ?></td>
                                    <td><?= e($r['full_name']); ?></td>
                                    <td><?= e($r['email']); ?></td>
                                    <td><?= e($r['course_interest'] ?? '—'); ?></td>
                                    <td>
                                        <span class="status-badge status-<?= e(strtolower($r['status_code'] ?? 'new')); ?>">
                                            <?= e($r['status_label'] ?? 'New'); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <a class="btn-table" href="<?= e(base_url('sections/admissions/inquiry-queue/index.php')); ?>">Open</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </section>

        </main>
    </section>

    <?php include INCLUDES_PATH . '/footer.php'; ?>
    <?php include INCLUDES_PATH . '/scripts.php'; ?>

</body>
</html>
