<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Admin: Certificate Issuing
 * File : sections/admissions/admin/certificates.php
 * ---------------------------------------------------------
 * Issue official certificates to enrolled applicants:
 *   - Course + Batch filters narrow the eligible-enrollment
 *     dropdown (no giant list).
 *   - Certificate no CRT-YYYY-###### generated; secure QR token
 *     + public verification URL stored.
 *   - Optionally upload the actual certificate document (PDF/JPEG/
 *     PNG) — the trainee downloads it from their account.
 *   - Validation: an enrollment can only have ONE live cert, and
 *     an applicant can't get a second live cert for the SAME
 *     course (re-issue after expiry is allowed).
 *   - Verify opens an in-app system modal (no new tab).
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/config/bootstrap.php';

require_access('certificates');
if ($_SERVER['REQUEST_METHOD'] === 'POST') { require_edit('certificates'); }

$pdo = db();

$flash = ['type' => null, 'message' => null];

/* ==========================================================
   Sequence helper (CRT)
========================================================== */
function next_certificate_no(PDO $pdo): string
{
    $year = (int) date('Y');
    $sel = $pdo->prepare(
        "SELECT id, current_value, prefix, padding_length
         FROM sequence_generator WHERE sequence_code = 'CRT' AND sequence_year = :y FOR UPDATE"
    );
    $sel->execute(['y' => $year]);
    $seq = $sel->fetch();
    if (!$seq) {
        $pdo->prepare(
            "INSERT INTO sequence_generator (sequence_code, sequence_year, current_value, prefix, padding_length)
             VALUES ('CRT', :y, 0, 'CRT', 6)"
        )->execute(['y' => $year]);
        $sel->execute(['y' => $year]);
        $seq = $sel->fetch();
    }
    $next = ((int) $seq['current_value']) + 1;
    $pdo->prepare("UPDATE sequence_generator SET current_value = :v WHERE id = :id")
        ->execute(['v' => $next, 'id' => $seq['id']]);
    return sprintf('%s-%d-%s', $seq['prefix'], $year, str_pad((string) $next, (int) $seq['padding_length'], '0', STR_PAD_LEFT));
}

/* ==========================================================
   Handle POST (issue)
========================================================== */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = $_POST['action'] ?? '';

    try {
        if ($action === 'issue') {
            $enrollmentId   = (int) ($_POST['enrollment_id'] ?? 0);
            $issuedDate     = trim((string) ($_POST['issued_date'] ?? date('Y-m-d')));
            $expiryDate     = trim((string) ($_POST['expiry_date'] ?? ''));
            $courseOverride = trim((string) ($_POST['course_name_override'] ?? ''));

            if (!$enrollmentId) {
                $flash = ['type' => 'error', 'message' => 'Select an enrollment.'];
            } elseif (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $issuedDate)) {
                $flash = ['type' => 'error', 'message' => 'Issued date is not valid.'];
            } elseif ($expiryDate !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $expiryDate)) {
                $flash = ['type' => 'error', 'message' => 'Expiry date is not valid.'];
            } else {
                $stmt = $pdo->prepare(
                    "SELECT e.id, e.applicant_id, e.course_id, e.enrollment_no, e.status, e.endorser_type,
                            a.first_name, a.last_name,
                            c.course_name, c.code, c.validity_months
                     FROM enrollment e
                     JOIN applicant a ON a.id = e.applicant_id
                     JOIN mnt_course c ON c.id = e.course_id
                     WHERE e.id = :id"
                );
                $stmt->execute(['id' => $enrollmentId]);
                $enr = $stmt->fetch();

                if (!$enr) {
                    $flash = ['type' => 'error', 'message' => 'Enrollment not found.'];
                } else {
                    /* ---- V5.33 process rules (Settings → Process Rules) ---- */
                    $eStatus = (string) ($enr['status'] ?? '');
                    $eType   = ((string) ($enr['endorser_type'] ?? 'marketing')) === 'company' ? 'company' : 'marketing';

                    /* 0a) status eligibility */
                    $statusOk = process_rule('rule_cert_require_enrolled_status', false)
                        ? in_array($eStatus, ['enrolled', 'completed'], true)
                        : !in_array($eStatus, ['cancelled', 'no_show'], true);
                    if (!$statusOk) {
                        $flash = ['type' => 'error', 'message' => 'Cannot issue — enrollment is ' . $eStatus . '. Company-endorsed Pending enrollments are allowed; Marketing requires Enrolled/Completed (or the "status required" rule is ON).'];
                    } else {
                        /* 0b) payment eligibility */
                        $paidQ = $pdo->prepare("SELECT COALESCE(SUM(paid_amount),0) FROM payment WHERE enrollment_id = :id AND payment_status_id NOT IN (4,5)");
                        $paidQ->execute(['id' => $enrollmentId]);
                        $paidAmt = (float) $paidQ->fetchColumn();

                        $paidOk = true;
                        $paidReason = '';
                        if ($eType === 'company') {
                            if (!process_rule('rule_cert_company_allow_unpaid', true) && $paidAmt <= 0) {
                                $paidOk = false;
                                $paidReason = 'Company-endorsed certificates require payment while the rule is set.';
                            }
                        } else {
                            if (process_rule('rule_cert_marketing_require_paid', true) && $paidAmt <= 0) {
                                $paidOk = false;
                                $paidReason = 'Marketing-endorsed certificates require payment — record the payment first.';
                            }
                        }
                        if (!$paidOk) {
                            $flash = ['type' => 'error', 'message' => $paidReason];
                        } else {
                    /* 1) one live certificate per enrollment */
                    $dup = $pdo->prepare("SELECT certificate_no FROM certificate WHERE enrollment_id = :id AND status != 'void' LIMIT 1");
                    $dup->execute(['id' => $enrollmentId]);
                    if ($dupRow = $dup->fetch()) {
                        $flash = ['type' => 'error', 'message' => "A certificate ({$dupRow['certificate_no']}) is already issued for this enrollment."];
                    } else {
                        /* 2) applicant cannot get a second LIVE cert for the same course */
                        $dup2 = $pdo->prepare(
                            "SELECT certificate_no FROM certificate
                             WHERE applicant_id = :ap AND course_id = :cid
                               AND status = 'issued'
                               AND (expiry_date IS NULL OR expiry_date >= CURDATE())
                             LIMIT 1"
                        );
                        $dup2->execute(['ap' => $enr['applicant_id'], 'cid' => $enr['course_id']]);
                        if ($dupRow2 = $dup2->fetch()) {
                            $flash = ['type' => 'error', 'message' => "{$enr['first_name']} {$enr['last_name']} already has a valid certificate for this course ({$dupRow2['certificate_no']})."];
                        } else {
                            /* file upload (optional) */
                            $filePath = null;
                            $fileName = null;
                            if (!empty($_FILES['cert_file']) && $_FILES['cert_file']['error'] === UPLOAD_ERR_OK) {
                                $f = $_FILES['cert_file'];
                                if ($f['size'] > 8 * 1024 * 1024) {
                                    $flash = ['type' => 'error', 'message' => 'Certificate file must be under 8 MB.'];
                                    $f_ok = false;
                                } else {
                                    $ext = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
                                    if (!in_array($ext, ['pdf', 'jpg', 'jpeg', 'png'], true)) {
                                        $flash = ['type' => 'error', 'message' => 'Only PDF, JPG, or PNG allowed for the certificate file.'];
                                        $f_ok = false;
                                    } else {
                                        $dir = BASE_PATH . '/uploads/certificates';
                                        if (!is_dir($dir)) { @mkdir($dir, 0775, true); }
                                        $name = 'cert-' . time() . '-' . preg_replace('/[^A-Za-z0-9._-]/', '_', basename($f['name']));
                                        if (move_uploaded_file($f['tmp_name'], $dir . '/' . $name)) {
                                            $filePath = 'uploads/certificates/' . $name;
                                            $fileName = basename($f['name']);
                                            $f_ok = true;
                                        } else {
                                            $flash = ['type' => 'error', 'message' => 'Could not save the certificate file.'];
                                            $f_ok = false;
                                        }
                                    }
                                }
                                if (!$f_ok) { /* handled above */ }
                            }

                            if (isset($f_ok) && !$f_ok) {
                                /* flash already set */
                            } else {
                                $pdo->beginTransaction();
                                $qr = bin2hex(random_bytes(16));
                                $verifyUrl = base_url('verify.php') . '?ref=' . 'REPLACE_CERT' . '&t=' . $qr;

                                /* Insert with collision-safe cert no retry */
                                $certNo = null;
                                $inserted = false;
                                for ($attempt = 0; $attempt < 5 && !$inserted; $attempt++) {
                                    $candidate = next_certificate_no($pdo);
                                    try {
                                        $pdo->prepare(
                                            "INSERT INTO certificate
                                                (certificate_no, enrollment_id, course_id, course_name_override, applicant_id,
                                                 issued_date, expiry_date, qr_code_value, verification_url, file_path, file_name,
                                                 issued_by, status, is_self_recorded, created_at)
                                             VALUES
                                                (:no, :en, :cid, :ovr, :ap,
                                                 :idate, :edate, :qr, :vurl, :fp, :fn,
                                                 :by, 'issued', 0, NOW())"
                                        )->execute([
                                            'no' => $candidate, 'en' => $enrollmentId, 'cid' => $enr['course_id'],
                                            'ovr' => $courseOverride !== '' && $courseOverride !== $enr['course_name'] ? $courseOverride : null,
                                            'ap' => $enr['applicant_id'], 'idate' => $issuedDate,
                                            'edate' => $expiryDate !== '' ? $expiryDate : null,
                                            'qr' => $qr, 'vurl' => str_replace('REPLACE_CERT', rawurlencode($candidate), $verifyUrl), 'fp' => $filePath, 'fn' => $fileName,
                                            'by' => (int) (current_user()['id'] ?? 0),
                                        ]);
                                        $certNo = $candidate;
                                        $inserted = true;
                                    } catch (Throwable $ex) {
                                        if (strpos($ex->getMessage(), 'Duplicate entry') === false) { throw $ex; }
                                        /* collision → next sequence value */
                                    }
                                }

                                if (!$certNo) {
                                    $pdo->rollBack();
                                    $flash = ['type' => 'error', 'message' => 'Could not allocate a certificate number. Please try again.'];
                                } else {
                                    /* V5.33: issuing a certificate completes the
                                       enrollment only while the rule is ON */
                                    $autoComplete = process_rule('rule_auto_complete_on_cert', true);
                                    $completedNow = false;
                                    if ($autoComplete) {
                                        $oldSt = $pdo->prepare('SELECT status FROM enrollment WHERE id = :id');
                                        $oldSt->execute(['id' => $enrollmentId]);
                                        $oldStatus = $oldSt->fetchColumn();
                                        if ($oldStatus !== 'completed') {
                                            $pdo->prepare("UPDATE enrollment SET status = 'completed', updated_at = NOW() WHERE id = :id")
                                                ->execute(['id' => $enrollmentId]);
                                            $pdo->prepare(
                                                "INSERT INTO enrollment_history (enrollment_id, changed_by, old_status, new_status, created_at)
                                                 VALUES (:eid, :uid, :from, 'completed', NOW())"
                                            )->execute(['eid' => $enrollmentId, 'uid' => (int) (current_user()['id'] ?? 0), 'from' => $oldStatus]);
                                            $completedNow = true;
                                        }
                                    }

                                    $pdo->commit();
                                    audit_log('certificates', 'issue', $enrollmentId, "Certificate {$certNo} issued to {$enr['first_name']} {$enr['last_name']} (enrollment {$enr['enrollment_no']})");
                                    /* V5.41: notify the trainee their certificate is ready */
                                    $notifType = $pdo->query("SELECT id FROM mnt_notification_type WHERE code = 'TRAINING' LIMIT 1")->fetchColumn();
                                    notify_applicant($pdo, (int) $enr['applicant_id'],
                                        'Certificate Issued — ' . $certNo,
                                        'Your certificate for ' . htmlspecialchars_decode((string) $enr['course_name']) . ' has been issued. You can view and download it from the Certificates tab.',
                                        $notifType ? (int) $notifType : null);
                                    $flash = ['type' => 'success', 'message' => "Certificate {$certNo} issued to {$enr['first_name']} {$enr['last_name']}."
                                        . ($completedNow ? ' Enrollment auto-updated to Completed.' : ($autoComplete ? ' (already completed).' : ' Enrollment status unchanged (rule OFF).'))
                                        . ($filePath ? ' File attached.' : '')];
                                }
                            }
                        }
                    }
                }
                }
                }
            }
        }
    } catch (Throwable $e) {
        if (isset($pdo) && $pdo->inTransaction()) { $pdo->rollBack(); }
        error_log('certificates.php: ' . $e->getMessage());
        $flash = ['type' => 'error', 'message' => 'Could not issue the certificate.'];
    }
}

/* ==========================================================
   Load data
========================================================== */
$courses = $pdo->query("SELECT id, code, course_name FROM mnt_course WHERE is_active = 1 ORDER BY course_name")->fetchAll() ?: [];

/* Batches that have eligible enrollments (for the filter + modal) */
$batches = $pdo->query(
    "SELECT DISTINCT t.id, t.training_no, t.batch_name, t.course_id, c.course_name
     FROM training t
     JOIN mnt_course c ON c.id = t.course_id
     WHERE t.id IN (
         SELECT DISTINCT e.training_id FROM enrollment e
         WHERE e.training_id IS NOT NULL AND e.status NOT IN ('cancelled','no_show')
     )
     ORDER BY t.start_date DESC"
)->fetchAll() ?: [];

/* All candidate enrollments (no live cert yet) — embedded as JSON for
   client-side course/batch filtering inside the Issue modal.
   V5.33: eligibility is rule-driven (Settings → Process Rules):
   company-endorsed Pending enrollments are issuable while the
   "status required" rule is OFF; marketing must be paid. */
$issuableRaw = $pdo->query(
    "SELECT e.id, e.enrollment_no, e.course_id, e.training_id, e.status, e.endorser_type,
            a.first_name, a.last_name, a.applicant_no,
            c.code, c.course_name, c.validity_months,
            t.training_no, t.batch_name,
            (SELECT COALESCE(SUM(p.paid_amount),0)
             FROM payment p
             WHERE p.enrollment_id = e.id AND p.payment_status_id NOT IN (4,5)) AS paid_amount
     FROM enrollment e
     JOIN applicant a ON a.id = e.applicant_id
     JOIN mnt_course c ON c.id = e.course_id
     LEFT JOIN training t ON t.id = e.training_id
     WHERE e.status NOT IN ('cancelled','no_show')
       AND NOT EXISTS (
           SELECT 1 FROM certificate x
           WHERE x.enrollment_id = e.id AND x.status != 'void'
       )
       AND NOT EXISTS (
           SELECT 1 FROM certificate y
           WHERE y.applicant_id = e.applicant_id AND y.course_id = e.course_id
             AND y.status = 'issued'
             AND (y.expiry_date IS NULL OR y.expiry_date >= CURDATE())
       )
     ORDER BY e.id DESC LIMIT 500"
)->fetchAll() ?: [];

/* Apply the process rules to the candidate list */
$issuableRaw = array_values(array_filter($issuableRaw, function ($e) {
    $s = (string) ($e['status'] ?? '');
    $t = ((string) ($e['endorser_type'] ?? 'marketing')) === 'company' ? 'company' : 'marketing';
    $paid = (float) ($e['paid_amount'] ?? 0);

    $statusOk = process_rule('rule_cert_require_enrolled_status', false)
        ? in_array($s, ['enrolled', 'completed'], true)
        : !in_array($s, ['cancelled', 'no_show'], true);
    if (!$statusOk) {
        return false;
    }
    if ($t === 'company') {
        if (!process_rule('rule_cert_company_allow_unpaid', true) && $paid <= 0) {
            return false;
        }
    } elseif (process_rule('rule_cert_marketing_require_paid', true) && $paid <= 0) {
        return false;
    }
    return true;
}));

$issuableJson = array_map(function ($e) {
    return [
        'id'      => (int) $e['id'],
        'label'   => $e['enrollment_no'] . ' · ' . trim($e['first_name'] . ' ' . $e['last_name']) . ' — ' . $e['code'] . ' ' . $e['course_name'],
        'course_id' => (int) $e['course_id'],
        'batch_id'  => (int) $e['training_id'],
        'course'  => $e['course_name'],
        'validity'=> (int) $e['validity_months'],
        'batch'   => $e['training_no'] ? $e['training_no'] . ' · ' . $e['batch_name'] : '—',
    ];
}, $issuableRaw);

/* ---- List filters: status + course + batch ---- */
$filterStatus = trim((string) ($_GET['status'] ?? ''));
$filterCourse = (int) ($_GET['course'] ?? 0);
$filterBatch  = (int) ($_GET['batch'] ?? 0);
$filterKw     = trim((string) ($_GET['q'] ?? ''));

$where = ' WHERE 1 = 1';
$params = [];
if ($filterStatus !== '') { $where .= ' AND c.status = :st'; $params['st'] = $filterStatus; }
if ($filterCourse)        { $where .= ' AND c.course_id = :co'; $params['co'] = $filterCourse; }
if ($filterBatch)         { $where .= ' AND e.training_id = :ba'; $params['ba'] = $filterBatch; }
if ($filterKw !== '') {
    $where .= ' AND (c.certificate_no LIKE :kw1 OR a.first_name LIKE :kw2 OR a.last_name LIKE :kw3 OR c.course_name_override LIKE :kw4 OR m.course_name LIKE :kw5 OR e.enrollment_no LIKE :kw6)';
    $like = '%' . $filterKw . '%';
    $params = array_merge($params, ['kw1' => $like, 'kw2' => $like, 'kw3' => $like, 'kw4' => $like, 'kw5' => $like, 'kw6' => $like]);
}

$certsStmt = $pdo->prepare(
    "SELECT c.*, a.first_name, a.last_name, a.applicant_no, e.enrollment_no,
            m.course_name, COALESCE(m.course_name, c.course_name_override) AS display_course,
            u.full_name AS issued_by_name, t.training_no, t.batch_name
     FROM certificate c
     LEFT JOIN mnt_course m ON m.id = c.course_id
     LEFT JOIN applicant a ON a.id = c.applicant_id
     LEFT JOIN enrollment e ON e.id = c.enrollment_id
     LEFT JOIN training t ON t.id = e.training_id
     LEFT JOIN sys_user u ON u.id = c.issued_by"
    . $where . " ORDER BY c.issued_date DESC, c.id DESC LIMIT 300"
);
$certsStmt->execute($params);
$certs = $certsStmt->fetchAll() ?: [];

/* KPIs */
$kpi = $pdo->query(
    "SELECT
        COUNT(*) AS total,
        COALESCE(SUM(CASE WHEN c.status = 'issued' AND (c.expiry_date IS NULL OR c.expiry_date >= CURDATE()) THEN 1 ELSE 0 END), 0) AS active,
        COALESCE(SUM(CASE WHEN c.status = 'issued' AND c.expiry_date IS NOT NULL AND c.expiry_date >= CURDATE() AND c.expiry_date <= DATE_ADD(CURDATE(), INTERVAL 90 DAY) THEN 1 ELSE 0 END), 0) AS expiring,
        COALESCE(SUM(CASE WHEN c.status = 'void' THEN 1 ELSE 0 END), 0) AS voided
     FROM certificate c"
)->fetch();

$page = [
    'title'       => 'Certificates | USMCI-TMS',
    'description' => 'Certificate Issuing',
    'bodyClass'   => 'admissions-page',
];
?>
<!DOCTYPE html>
<html lang="en">

<?php include INCLUDES_PATH . '/head.php'; ?>

<link rel="stylesheet" href="<?= e(base_url('assets/css/portal.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/workspace.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/inquiry-queue/assets/css/page.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/admin/dashboard.css?v=' . ASSET_VERSION)); ?>">

<body class="<?= e($page['bodyClass']); ?>">

    <?php include NAVBAR_PATH . '/index.php'; ?>

    <section class="portal-shell portal-shell--2col">

        <?php require ADMISSIONS_PATH . '/inquiry-queue/partials/sidebar.php'; ?>

        <main class="portal-content">

            <header class="workspace-header">
                <div class="workspace-header__left">
                    <span class="section-badge">Certification</span>
                    <h1>Certificate Issuing</h1>
                    <p>Issue official training certificates — filtered by course &amp; batch, with optional file attachment and in-app verification.</p>
                </div>
                <div class="workspace-header__right">
                    <?php if (user_can('certificates', 'edit')): ?><button type="button" class="btn-primary" id="btnIssueCert">＋ Issue Certificate</button><?php endif; ?>
                </div>
            </header>

            <?php if ($flash['message']): ?>
                <div id="certFlash" data-type="<?= $flash['type']; ?>" style="display:none;"><?= htmlspecialchars($flash['message'], ENT_QUOTES, 'UTF-8'); ?></div>
            <?php endif; ?>

            <!-- KPIs -->
            <section class="kpi-grid kpi-grid--4">
                <div class="kpi-card">
                    <div class="kpi-card__icon" style="background:#E0F2FE;">📜</div>
                    <div>
                        <div class="kpi-card__value"><?= (int) $kpi['total']; ?></div>
                        <div class="kpi-card__label">Total Issued</div>
                    </div>
                </div>
                <div class="kpi-card">
                    <div class="kpi-card__icon" style="background:#DCFCE7;">✅</div>
                    <div>
                        <div class="kpi-card__value" style="color:#15803D;"><?= (int) $kpi['active']; ?></div>
                        <div class="kpi-card__label">Currently Valid</div>
                    </div>
                </div>
                <div class="kpi-card">
                    <div class="kpi-card__icon" style="background:#FEF3C7;">⏳</div>
                    <div>
                        <div class="kpi-card__value" style="color:#B45309;"><?= (int) $kpi['expiring']; ?></div>
                        <div class="kpi-card__label">Expiring ≤ 90 days</div>
                    </div>
                </div>
                <div class="kpi-card">
                    <div class="kpi-card__icon" style="background:#F1F5F9;">🚫</div>
                    <div>
                        <div class="kpi-card__value" style="color:#64748B;"><?= (int) $kpi['voided']; ?></div>
                        <div class="kpi-card__label">Voided</div>
                    </div>
                </div>
            </section>

            <!-- Filters (auto-filter — no button, single row) -->
            <section class="workspace-toolbar">
                <form method="get" action="<?= e(base_url('sections/admissions/admin/certificates.php')); ?>" id="certFilterForm" class="cert-filter-form">
                    <input type="text" name="q" value="<?= e($filterKw); ?>" placeholder="Search cert / applicant…" class="toolbar-search" id="cfSearch">
                    <select name="course" id="cfCourse">
                        <option value="">All Courses</option>
                        <?php foreach ($courses as $co): ?>
                            <option value="<?= (int) $co['id']; ?>" <?= $filterCourse === (int) $co['id'] ? 'selected' : ''; ?>><?= e($co['code'] . ' · ' . $co['course_name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <select name="batch" id="cfBatch">
                        <option value="">All Batches</option>
                        <?php foreach ($batches as $ba): ?>
                            <option value="<?= (int) $ba['id']; ?>" <?= $filterBatch === (int) $ba['id'] ? 'selected' : ''; ?>><?= e($ba['training_no'] . ' · ' . $ba['batch_name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <select name="status" id="cfStatus">
                        <option value="">All Statuses</option>
                        <?php foreach (['issued' => 'Issued', 'expired' => 'Expired', 'void' => 'Void', 'draft' => 'Draft', 'reissued' => 'Reissued'] as $val => $label): ?>
                            <option value="<?= e($val); ?>" <?= $filterStatus === $val ? 'selected' : ''; ?>><?= e($label); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <?php if ($filterStatus || $filterCourse || $filterBatch || $filterKw !== ''): ?>
                        <a href="<?= e(base_url('sections/admissions/admin/certificates.php')); ?>" class="btn-secondary btn-sm" style="text-decoration:none;">✕ Clear</a>
                    <?php endif; ?>
                </form>
            </section>

            <!-- Certificates table -->
            <section class="workspace-table">
                <div class="dash-panel__head"><h2>Certificates (<?= count($certs); ?>)</h2></div>
                <div class="table-responsive">
                    <table class="inquiry-table">
                        <thead>
                            <tr>
                                <th>Cert. No.</th><th>Applicant</th><th>Course</th><th>Batch</th><th>Issued</th><th>Expiry</th><th>Status</th><th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!$certs): ?>
                                <tr><td colspan="8" style="text-align:center;color:#94A3B8;padding:30px;">No certificates match — click <strong>＋ Issue Certificate</strong> to issue the first one.</td></tr>
                            <?php endif; ?>
                            <?php foreach ($certs as $c): ?>
                                <?php
                                    $expired = $c['expiry_date'] && strtotime($c['expiry_date']) < time();
                                    $near = !$expired && $c['expiry_date'] && (strtotime($c['expiry_date']) - time()) < 90 * 86400;
                                    $status = $c['status'] === 'issued' && $expired ? 'expired' : $c['status'];
                                ?>
                                <tr id="cert-<?= e($c['certificate_no']); ?>">
                                    <td class="cert-table__no"><?= e($c['certificate_no']); ?></td>
                                    <td><?= e(trim(($c['first_name'] ?? '') . ' ' . ($c['last_name'] ?? ''))); ?><br><span class="course-desc"><?= e($c['enrollment_no'] ?? ''); ?></span></td>
                                    <td><?= e($c['display_course'] ?? '—'); ?></td>
                                    <td><span class="course-desc"><?= e(($c['training_no'] ?? '—') . ($c['batch_name'] ? ' · ' . $c['batch_name'] : '')); ?></span></td>
                                    <td><?= e($c['issued_date']); ?></td>
                                    <td>
                                        <span class="cert-expiry <?= $expired ? 'cert-expired' : ($near ? 'cert-near' : ''); ?>">
                                            <?= e($c['expiry_date'] ?? '—'); ?>
                                            <?php if ($expired): ?> · EXPIRED<?php elseif ($near): ?> · soon<?php endif; ?>
                                        </span>
                                    </td>
                                    <td><span class="status-badge status-<?= e($status); ?>"><?= e(ucfirst($status)); ?></span></td>
                                    <td class="cert-table__actions">
                                        <?php
                                            $hasFile = !empty($c['file_path']) && is_file(BASE_PATH . '/' . ltrim((string) $c['file_path'], '/'));
                                            $fileMissing = !empty($c['file_path']) && !$hasFile;
                                        ?>
                                        <?php if ($fileMissing): ?>
                                            <span class="status-badge status-closed" title="The uploaded file was lost (uploads/ folder was replaced). Re-upload or use the system certificate.">⚠ File Missing</span>
                                        <?php endif; ?>
                                        <div class="cert-actions-2x2">
                                            <a class="btn-secondary btn-sm" href="<?= e(base_url('download_certificate.php?ref=' . urlencode($c['certificate_no']) . '&view=1')); ?>" target="_blank" title="<?= $hasFile ? 'Open the uploaded certificate file for printing' : ($fileMissing ? 'Uploaded file is missing — showing the system certificate fallback' : 'Printable system certificate with QR code — print or save as PDF'); ?>"><?= $hasFile ? '📄 View File' : '📱 View / Print (QR)'; ?></a>
                                            <a class="btn-secondary btn-sm" href="<?= e(base_url('download_certificate.php?ref=' . urlencode($c['certificate_no']))); ?>" download="<?= e($c['file_name'] ?? ($c['certificate_no'] . '.pdf')); ?>">⬇ Download</a>
                                            <button type="button" class="btn-secondary btn-sm" data-cert-verify='<?= json_encode(['no'=>$c['certificate_no'],'name'=>trim(($c['first_name']??'').' '.($c['last_name']??'')),'course'=>$c['display_course']??'','batch'=>(($c['training_no']??'').($c['batch_name']?' · '.$c['batch_name']:'')),'issued'=>$c['issued_date'],'expiry'=>$c['expiry_date']??'','status'=>$status,'by'=>$c['issued_by_name']??'USMCI','url'=>$c['verification_url']??'','remarks'=>$c['void_remarks']??''], JSON_HEX_APOS|JSON_HEX_QUOT); ?>'>🔎 Verify</button>
                                            <?php if ($status !== 'void'): ?>
                                                <button type="button" class="btn-secondary btn-sm" data-cert-void='<?= json_encode(['id'=>(int)$c['id'],'no'=>$c['certificate_no']], JSON_HEX_APOS|JSON_HEX_QUOT); ?>'>🚫 Void</button>
                                            <?php else: ?>
                                                <span class="status-badge status-closed">VOID</span>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </section>

        </main>
    </section>

    <?php include INCLUDES_PATH . '/footer.php'; ?>
    <?php include INCLUDES_PATH . '/scripts.php'; ?>

    <!-- Issue certificate modal -->
    <div id="issueModal" class="portal-modal" style="display:none;">
        <div class="portal-modal__box">
            <div class="portal-modal__head">
                <h3>Issue Certificate</h3>
                <p>Pick a course &amp; batch to narrow the list, then select the trainee</p>
                <button class="portal-modal__close" id="issueClose">&times;</button>
            </div>
            <form method="post" action="<?= e(base_url('sections/admissions/admin/certificates.php')); ?>" enctype="multipart/form-data">
                <?= csrf_field(); ?>
                <input type="hidden" name="action" value="issue">
                <div class="portal-modal__body">
                    <div class="cert-form__grid">
                        <div class="t-field"><label>Filter: Course</label>
                            <select id="issFilterCourse">
                                <option value="">All Courses</option>
                                <?php foreach ($courses as $co): ?>
                                    <option value="<?= (int) $co['id']; ?>"><?= e($co['code'] . ' · ' . $co['course_name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="t-field"><label>Filter: Batch</label>
                            <select id="issFilterBatch">
                                <option value="">All Batches</option>
                                <?php foreach ($batches as $ba): ?>
                                    <option value="<?= (int) $ba['id']; ?>"><?= e($ba['training_no'] . ' · ' . $ba['batch_name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="t-field t-field--full">
                            <label>Enrollment (Trainee) * <span id="issCount" class="field-hint"></span></label>
                            <select name="enrollment_id" id="issEnrollment" required>
                                <option value="">— select trainee —</option>
                            </select>
                        </div>
                        <div class="t-field"><label>Date Issued *</label><input type="date" name="issued_date" id="issIssued" required></div>
                        <div class="t-field"><label>Date Expiry</label><input type="date" name="expiry_date" id="issExpiry"></div>
                        <div class="t-field t-field--full"><label>Course Name (on certificate)</label><input name="course_name_override" id="issCourseTxt" placeholder="Auto-filled from the course — edit if needed"></div>
                        <div class="t-field t-field--full">
                            <label>Attach Certificate File <span class="field-hint">(optional — PDF/JPG/PNG, max 8MB)</span></label>
                            <input type="file" name="cert_file" id="issFile" accept=".pdf,.jpg,.jpeg,.png">
                        </div>
                    </div>
                    <p style="margin-top:14px;font-size:.8rem;color:#64748B;">A certificate number (CRT-YYYY-######), QR token, and public verification link are generated automatically. The attached file becomes downloadable by the trainee.</p>
                </div>
                <div class="portal-modal__foot">
                    <button type="button" class="btn-secondary" id="issueCancel">Cancel</button>
                    <button type="submit" class="btn-primary">Issue Certificate</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Verify modal -->
    <div id="verifyModal" class="portal-modal" style="display:none;">
        <div class="portal-modal__box">
            <div class="portal-modal__head">
                <h3>🔎 Certificate Verification</h3>
                <p id="verifyTarget">—</p>
                <button class="portal-modal__close" id="verifyClose">&times;</button>
            </div>
            <div class="portal-modal__body">
                <div id="verifyBadge" class="verify-badge">—</div>
                <div class="meta-grid">
                    <div class="meta-cell"><span>Certificate No.</span><b id="vmNo">—</b></div>
                    <div class="meta-cell"><span>Trainee</span><b id="vmName">—</b></div>
                    <div class="meta-cell"><span>Course</span><b id="vmCourse">—</b></div>
                    <div class="meta-cell"><span>Batch</span><b id="vmBatch">—</b></div>
                    <div class="meta-cell"><span>Date Issued</span><b id="vmIssued">—</b></div>
                    <div class="meta-cell"><span>Date Expiry</span><b id="vmExpiry">—</b></div>
                    <div class="meta-cell"><span>Issued By</span><b id="vmBy">—</b></div>
                    <div class="meta-cell"><span>Status</span><b id="vmStatus">—</b></div>
                    <div class="meta-cell meta-cell--full" id="vmRemarksWrap" style="display:none;"><span>Void Remarks</span><b id="vmRemarks" style="color:#B91C1C;">—</b></div>
                </div>
            </div>
            <div class="portal-modal__foot">
                <a href="#" id="vmPublic" target="_blank" class="btn-secondary" style="text-decoration:none;">Open Public Page</a>
                <button type="button" class="btn-primary" id="verifyCloseBtn">Close</button>
            </div>
        </div>
    </div>

    <script>
        (function () {
            function showToast(msg, type) { window.usmciToast(msg, type); }
            var flashEl = document.getElementById("certFlash");
            if (flashEl && flashEl.textContent.trim() !== "") showToast(flashEl.textContent.trim(), flashEl.dataset.type);

            /* ---- Auto-submit list filters (no button) ---- */
            (function () {
                var form = document.getElementById("certFilterForm");
                if (!form) return;
                var q = form.querySelector('input[name="q"]');
                ["cfCourse", "cfBatch", "cfStatus"].forEach(function (id) {
                    var el = document.getElementById(id);
                    if (el) el.addEventListener("change", function () { form.submit(); });
                });
                var debounce = null;
                if (q) q.addEventListener("input", function () {
                    clearTimeout(debounce);
                    debounce = setTimeout(function () { form.submit(); }, 600);
                });
            })();

            /* ---- Eligible enrollments (embedded) ---- */
            var ISSUABLE = <?= json_encode($issuableJson); ?> || [];
            function todayLocal() {
                var d = new Date();
                return d.getFullYear() + "-" + String(d.getMonth()+1).padStart(2,"0") + "-" + String(d.getDate()).padStart(2,"0");
            }

            /* ---- Issue modal + course/batch filters ---- */
            var issueModal = document.getElementById("issueModal");
            var fc = document.getElementById("issFilterCourse");
            var fb = document.getElementById("issFilterBatch");
            var sel = document.getElementById("issEnrollment");

            function renderIssuable() {
                var c = fc.value || "";
                var b = fb.value || "";
                var list = ISSUABLE.filter(function (x) {
                    if (c && String(x.course_id) !== c) return false;
                    if (b && String(x.batch_id) !== String(b)) return false;
                    return true;
                });
                sel.innerHTML = "";
                if (list.length === 0) {
                    sel.appendChild(new Option("— no eligible trainees —", ""));
                } else {
                    sel.appendChild(new Option("— select trainee (" + list.length + ") —", ""));
                    list.forEach(function (x) {
                        var o = new Option(x.label + "  [" + x.batch + "]", x.id);
                        o.dataset.course = x.course;
                        o.dataset.validity = x.validity;
                        o.dataset.batch = x.batch;
                        sel.appendChild(o);
                    });
                }
                document.getElementById("issCount").textContent = list.length + " eligible";
                autofill();
            }

            function autofill() {
                var opt = sel.options[sel.selectedIndex];
                if (!opt || !opt.value) {
                    document.getElementById("issCourseTxt").value = "";
                    document.getElementById("issExpiry").value = "";
                    return;
                }
                document.getElementById("issCourseTxt").value = opt.dataset.course || "";
                var valid = parseInt(opt.dataset.validity || "0", 10);
                if (valid > 0) {
                    var issued = document.getElementById("issIssued").value || todayLocal();
                    var dt = new Date(issued + "T00:00:00");
                    dt.setMonth(dt.getMonth() + valid);
                    document.getElementById("issExpiry").value =
                        dt.getFullYear() + "-" + String(dt.getMonth()+1).padStart(2,"0") + "-" + String(dt.getDate()).padStart(2,"0");
                } else {
                    document.getElementById("issExpiry").value = "";
                }
            }

            fc.addEventListener("change", renderIssuable);
            fb.addEventListener("change", renderIssuable);
            sel.addEventListener("change", autofill);

            function openIssue() {
                fc.value = ""; fb.value = ""; renderIssuable();
                document.getElementById("issIssued").value = todayLocal();
                document.getElementById("issExpiry").value = "";
                document.getElementById("issCourseTxt").value = "";
                document.getElementById("issFile").value = "";
                issueModal.style.display = "flex";
            }
            function closeIssue() { issueModal.style.display = "none"; }
            document.getElementById("btnIssueCert").addEventListener("click", openIssue);
            document.getElementById("issueClose").addEventListener("click", closeIssue);
            document.getElementById("issueCancel").addEventListener("click", closeIssue);
            issueModal.addEventListener("click", function (e) { if (e.target === issueModal) closeIssue(); });

            /* ---- Verify modal ---- */
            var vModal = document.getElementById("verifyModal");
            function openVerify(d) {
                document.getElementById("verifyTarget").textContent = d.no;
                document.getElementById("vmNo").textContent = d.no;
                document.getElementById("vmName").textContent = d.name || "—";
                document.getElementById("vmCourse").textContent = d.course || "—";
                document.getElementById("vmBatch").textContent = d.batch || "—";
                document.getElementById("vmIssued").textContent = d.issued || "—";
                document.getElementById("vmExpiry").textContent = d.expiry || "—";
                document.getElementById("vmBy").textContent = d.by || "USMCI";
                var st = (d.status || "issued").toUpperCase();
                document.getElementById("vmStatus").textContent = st;
                var rmWrap = document.getElementById("vmRemarksWrap");
                var rm = (d.remarks || "").toString().trim();
                if (rmWrap) {
                    if (rm) {
                        document.getElementById("vmRemarks").textContent = rm;
                        rmWrap.style.display = "";
                    } else {
                        rmWrap.style.display = "none";
                    }
                }
                var badge = document.getElementById("verifyBadge");
                var map = {
                    ISSUED:   ["✓ VALID CERTIFICATE", "#15803D", "#DCFCE7"],
                    EXPIRED:  ["⚠ EXPIRED CERTIFICATE", "#B91C1C", "#FEE2E2"],
                    VOID:     ["✗ VOID CERTIFICATE", "#64748B", "#F1F5F9"],
                    DRAFT:    ["DRAFT", "#B45309", "#FEF3C7"],
                    REISSUED: ["REISSUED", "#2563EB", "#E0F2FE"]
                };
                var m = map[st] || map.ISSUED;
                badge.textContent = m[0];
                badge.style.color = m[1];
                badge.style.background = m[2];
                document.getElementById("vmPublic").href = d.url || "#";
                vModal.style.display = "flex";
            }
            function closeVerify() { vModal.style.display = "none"; }
            document.querySelectorAll("[data-cert-verify]").forEach(function (b) {
                b.addEventListener("click", function () { try { openVerify(JSON.parse(b.dataset.certVerify)); } catch (e) {} });
            });
            document.getElementById("verifyClose").addEventListener("click", closeVerify);
            document.getElementById("verifyCloseBtn").addEventListener("click", closeVerify);
            vModal.addEventListener("click", function (e) { if (e.target === vModal) closeVerify(); });

            /* ---- Void (AJAX + system confirm modal) ---- */
            var VOID_URL = <?= json_encode(base_url('sections/admissions/admin/certificate_void.php')); ?>;
            var CSRF = <?= json_encode(csrf_token()); ?>;
            document.querySelectorAll("[data-cert-void]").forEach(function (btn) {
                btn.addEventListener("click", function () {
                    var d = JSON.parse(btn.dataset.certVoid);
                    usmciPrompt({
                        title: "Void certificate?",
                        message: "Void certificate " + d.no + "? It will be marked VOID and its verification will show VOID. This cannot be undone.",
                        label: "Reason / remarks (shown to the trainee in Verify)",
                        placeholder: "e.g. Issued in error — duplicate certificate.",
                        confirmText: "Void",
                        danger: true
                    }).then(function (res) {
                        if (!res.ok) return;
                        var fd = new FormData();
                        fd.append("csrf_token", CSRF);
                        fd.append("certificate_id", d.id);
                        fd.append("remarks", res.value);
                        fetch(VOID_URL, { method: "POST", body: fd })
                            .then(function (r) { return r.json(); })
                            .then(function (resp) {
                                showToast(resp.message, resp.success ? "success" : "error");
                                if (resp.success) {
                                    setTimeout(function () { location.reload(); }, 1200);
                                }
                            })
                            .catch(function () { showToast("Could not void the certificate.", "error"); });
                    });
                });
            });
        })();
    </script>

</body>
</html>
