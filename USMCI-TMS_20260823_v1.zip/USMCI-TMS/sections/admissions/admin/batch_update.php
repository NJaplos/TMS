<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Admin: Update / Delete batch from Course modal
 * File : sections/admissions/admin/batch_update.php
 * ---------------------------------------------------------
 * JSON endpoint used by the Course Management modal to EDIT or
 * DELETE an existing training batch for the course being viewed.
 *
 * Validation (course <-> batch):
 *   - batch_id + course_id are BOTH required
 *   - the batch MUST belong to the posted course_id (a batch can
 *     never be moved to another course from here)
 *   - dates are validated (format + end >= start)
 *   - delete is blocked while the batch has enrollments
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/config/bootstrap.php';

require_edit('courses');

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'POST required.']);
    exit;
}

csrf_check();

$action   = (string) ($_POST['action'] ?? '');
$batchId  = (int) ($_POST['batch_id'] ?? 0);
$courseId = (int) ($_POST['course_id'] ?? 0);

if (!$batchId || !$courseId) {
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => 'Batch and course are required.']);
    exit;
}

try {
    $pdo = db();

    /* ---- The batch must belong to this course (vice-versa lock) ---- */
    $stmt = $pdo->prepare('SELECT id, course_id, training_no FROM training WHERE id = :id');
    $stmt->execute(['id' => $batchId]);
    $batch = $stmt->fetch();

    if (!$batch) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'Batch not found.']);
        exit;
    }
    if ((int) $batch['course_id'] !== $courseId) {
        http_response_code(422);
        echo json_encode(['success' => false, 'message' => 'This batch does not belong to the selected course.']);
        exit;
    }

    /* ---- Validate the course is real + active ---- */
    $courseOk = $pdo->prepare('SELECT id FROM mnt_course WHERE id = :id AND is_active = 1');
    $courseOk->execute(['id' => $courseId]);
    if (!$courseOk->fetch()) {
        http_response_code(422);
        echo json_encode(['success' => false, 'message' => 'The selected course is not valid or inactive.']);
        exit;
    }

    if ($action === 'update') {
        $trainingNo = trim((string) ($_POST['training_no'] ?? ''));
        $name       = trim((string) ($_POST['batch_name'] ?? ''));
        $start      = trim((string) ($_POST['start_date'] ?? ''));
        $end        = trim((string) ($_POST['end_date'] ?? ''));
        $slots      = (int) ($_POST['max_slots'] ?? 0);

        if ($trainingNo === '' || $name === '' || $start === '' || $end === '') {
            http_response_code(422);
            echo json_encode(['success' => false, 'message' => 'Batch no., name, start and end dates are required.']);
            exit;
        }
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $start) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $end)) {
            http_response_code(422);
            echo json_encode(['success' => false, 'message' => 'Dates are not valid.']);
            exit;
        }
        if (strtotime($end) < strtotime($start)) {
            http_response_code(422);
            echo json_encode(['success' => false, 'message' => 'End date cannot be before the start date.']);
            exit;
        }
        if ($slots < 1) {
            http_response_code(422);
            echo json_encode(['success' => false, 'message' => 'Max slots must be at least 1.']);
            exit;
        }

        $pdo->prepare(
            "UPDATE training SET training_no = :no, batch_name = :bn, start_date = :sd,
                    end_date = :ed, max_slots = :mx, updated_at = NOW()
             WHERE id = :id AND course_id = :cid"
        )->execute([
            'no' => $trainingNo, 'bn' => $name, 'sd' => $start, 'ed' => $end,
            'mx' => $slots, 'id' => $batchId, 'cid' => $courseId,
        ]);

        echo json_encode(['success' => true, 'message' => "Batch {$trainingNo} updated."]);
    }

    elseif ($action === 'delete') {
        $stmt = $pdo->prepare('SELECT COUNT(*) FROM enrollment WHERE training_id = :id');
        $stmt->execute(['id' => $batchId]);
        $cnt = (int) $stmt->fetchColumn();

        if ($cnt > 0) {
            http_response_code(422);
            echo json_encode(['success' => false, 'message' => 'Cannot delete — this batch has enrollments. Deactivate it in Training Batches instead.']);
            exit;
        }

        $pdo->prepare('DELETE FROM training_schedule WHERE training_id = :id')->execute(['id' => $batchId]);
        $pdo->prepare('DELETE FROM training WHERE id = :id')->execute(['id' => $batchId]);

        echo json_encode(['success' => true, 'message' => "Batch {$batch['training_no']} deleted."]);
    }

    else {
        http_response_code(422);
        echo json_encode(['success' => false, 'message' => 'Unknown action.']);
    }
} catch (Throwable $e) {
    error_log('batch_update: ' . $e->getMessage());
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => 'Could not update the batch.']);
}
exit;
