<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Admin: Instructors & Venues
 * File : sections/admissions/admin/maintenance.php
 * ---------------------------------------------------------
 * Two maintenance tabs:
 *   - Venues     : add/edit/disable training venues
 *   - Instructors: list of instructor accounts (managed in
 *                  Staff Accounts — link provided)
 * Feeds the Training Batches form dropdowns.
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/config/bootstrap.php';

require_access('instructors');
if ($_SERVER['REQUEST_METHOD'] === 'POST') { require_edit('instructors'); }

$pdo = db();

$flash = ['type' => null, 'message' => null];
$tab = $_GET['tab'] ?? 'instructors';
if (!in_array($tab, ['venues', 'instructors'], true)) { $tab = 'instructors'; }

/* ==========================================================
   Venue POST
========================================================== */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = $_POST['action'] ?? '';

    try {
        if ($action === 'venue_save') {
            $id       = (int) ($_POST['venue_id'] ?? 0);
            $name     = trim((string) ($_POST['name'] ?? ''));
            $location = trim((string) ($_POST['location'] ?? ''));
            $capacity = (int) ($_POST['capacity'] ?? 0);

            if ($name === '') {
                $flash = ['type' => 'error', 'message' => 'Venue name is required.'];
            } elseif ($id > 0) {
                $pdo->prepare("UPDATE mnt_venue SET name = :n, location = :l, capacity = :c, updated_at = NOW() WHERE id = :id")
                    ->execute(['n' => $name, 'l' => $location, 'c' => $capacity, 'id' => $id]);
                $flash = ['type' => 'success', 'message' => "Venue '{$name}' updated."];
            } else {
                $pdo->prepare("INSERT INTO mnt_venue (name, location, capacity, is_active) VALUES (:n, :l, :c, 1)")
                    ->execute(['n' => $name, 'l' => $location, 'c' => $capacity]);
                $flash = ['type' => 'success', 'message' => "Venue '{$name}' added."];
            }
        }

        elseif ($action === 'instructor_save') {
            $id         = (int) ($_POST['instructor_id'] ?? 0);
            $code       = trim((string) ($_POST['instructor_code'] ?? ''));
            $firstName  = trim((string) ($_POST['first_name'] ?? ''));
            $middleName = trim((string) ($_POST['middle_name'] ?? ''));
            $lastName   = trim((string) ($_POST['last_name'] ?? ''));
            $email      = trim((string) ($_POST['email'] ?? ''));
            $mobile     = trim((string) ($_POST['mobile_no'] ?? ''));
            $spec       = trim((string) ($_POST['specialization'] ?? ''));
            $license    = trim((string) ($_POST['license_no'] ?? ''));
            $licenseExp = trim((string) ($_POST['license_expiry'] ?? ''));
            $years      = (int) ($_POST['years_experience'] ?? 0);
            $rate       = trim((string) ($_POST['rate_per_day'] ?? '0'));
            $bio        = trim((string) ($_POST['bio'] ?? ''));

            if ($firstName === '' || $lastName === '') {
                $flash = ['type' => 'error', 'message' => 'Instructor first and last name are required.'];
            } else {
                if ($id > 0) {
                    $pdo->prepare(
                        "UPDATE instructor SET instructor_code = :c, first_name = :fn, middle_name = :mn, last_name = :ln,
                                email = :e, mobile_no = :m, specialization = :sp, license_no = :li, license_expiry = :le,
                                years_experience = :y, rate_per_day = :r, bio = :b, updated_at = NOW()
                         WHERE id = :id"
                    )->execute([
                        'c' => $code, 'fn' => $firstName, 'mn' => $middleName, 'ln' => $lastName, 'e' => $email,
                        'm' => $mobile, 'sp' => $spec, 'li' => $license, 'le' => $licenseExp !== '' ? $licenseExp : null,
                        'y' => $years, 'r' => $rate, 'b' => $bio, 'id' => $id,
                    ]);
                    $flash = ['type' => 'success', 'message' => "Instructor {$firstName} {$lastName} updated."];
                } else {
                    $pdo->prepare(
                        "INSERT INTO instructor (instructor_code, first_name, middle_name, last_name, email, mobile_no,
                                specialization, license_no, license_expiry, years_experience, rate_per_day, bio, is_active)
                         VALUES (:c, :fn, :mn, :ln, :e, :m, :sp, :li, :le, :y, :r, :b, 1)"
                    )->execute([
                        'c' => $code, 'fn' => $firstName, 'mn' => $middleName, 'ln' => $lastName, 'e' => $email,
                        'm' => $mobile, 'sp' => $spec, 'li' => $license, 'le' => $licenseExp !== '' ? $licenseExp : null,
                        'y' => $years, 'r' => $rate, 'b' => $bio,
                    ]);
                    $flash = ['type' => 'success', 'message' => "Instructor {$firstName} {$lastName} added."];
                }
            }
        }

        elseif ($action === 'instructor_toggle') {
            $id = (int) ($_POST['instructor_id'] ?? 0);
            $stmt = $pdo->prepare("SELECT is_active FROM instructor WHERE id = :id");
            $stmt->execute(['id' => $id]);
            $cur = (int) $stmt->fetchColumn();
            $pdo->prepare("UPDATE instructor SET is_active = :a, updated_at = NOW() WHERE id = :id")
                ->execute(['a' => $cur ? 0 : 1, 'id' => $id]);
            $flash = ['type' => 'success', 'message' => 'Instructor ' . ($cur ? 'deactivated.' : 'activated.')];
        }

        elseif ($action === 'venue_toggle') {
            $id = (int) ($_POST['venue_id'] ?? 0);
            $stmt = $pdo->prepare("SELECT is_active FROM mnt_venue WHERE id = :id");
            $stmt->execute(['id' => $id]);
            $cur = (int) $stmt->fetchColumn();
            $pdo->prepare("UPDATE mnt_venue SET is_active = :a, updated_at = NOW() WHERE id = :id")
                ->execute(['a' => $cur ? 0 : 1, 'id' => $id]);
            $flash = ['type' => 'success', 'message' => 'Venue ' . ($cur ? 'disabled.' : 'enabled.')];
        }
    } catch (Throwable $e) {
        error_log('maintenance.php: ' . $e->getMessage());
        $flash = ['type' => 'error', 'message' => 'Could not save the venue.'];
    }
}

/* ==========================================================
   Load data
========================================================== */
$venues = $pdo->query("SELECT * FROM mnt_venue ORDER BY is_active DESC, name")->fetchAll();
$instructors = $pdo->query(
    "SELECT id, instructor_code, first_name, middle_name, last_name, email, mobile_no,
            specialization, license_no, license_expiry, years_experience, rate_per_day, bio, is_active
     FROM instructor ORDER BY last_name, first_name"
)->fetchAll();

$page = [
    'title'       => 'Instructors & Venues | USMCI-TMS',
    'description' => 'Instructors & Venues',
    'bodyClass'   => 'admissions-page',
];
?>
<!DOCTYPE html>
<html lang="en">

<?php include INCLUDES_PATH . '/head.php'; ?>

<link rel="stylesheet" href="<?= e(base_url('assets/css/portal.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/workspace.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/inquiry-queue/assets/css/page.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/admin/dashboard.css?v=' . ASSET_VERSION)); ?>">

<body class="<?= e($page['bodyClass']); ?>">

    <?php include NAVBAR_PATH . '/index.php'; ?>

    <section class="portal-shell portal-shell--2col">

        <?php require ADMISSIONS_PATH . '/inquiry-queue/partials/sidebar.php'; ?>

        <main class="portal-content">

            <header class="workspace-header">
                <div class="workspace-header__left">
                    <span class="section-badge">Setup</span>
                    <h1>Instructors &amp; Venues</h1>
                    <p>Manage the venues and instructors used by training batches.</p>
                </div>
            </header>

            <?php if ($flash['message']): ?>
                <div id="maintFlash" data-type="<?= $flash['type']; ?>" style="display:none;"><?= htmlspecialchars($flash['message'], ENT_QUOTES, 'UTF-8'); ?></div>
            <?php endif; ?>

            <!-- Helper banner -->
            <div class="email-alert email-alert--success" style="margin-bottom:16px;">
                <strong>How it works:</strong> Instructors are <strong>profile records</strong> (no login needed).
                Click <strong>＋ Add Instructor</strong> and fill in the profile (name, specialization, license, rate).
                They then appear in the <strong>Training Batch → Lead Instructor</strong> dropdown.
            </div>

            <!-- Tabs -->
            <div class="queue-filter" style="margin-bottom:18px;">
                <a href="<?= e(base_url('sections/admissions/admin/maintenance.php?tab=venues')); ?>" class="<?= $tab === 'venues' ? 'active' : ''; ?>">🏢 Venues</a>
                <a href="<?= e(base_url('sections/admissions/admin/maintenance.php?tab=instructors')); ?>" class="<?= $tab === 'instructors' ? 'active' : ''; ?>">👨‍🏫 Instructors</a>
            </div>

            <?php if ($tab === 'venues'): ?>

                <!-- Venues -->
                <section class="workspace-table">
                    <div class="dash-panel__head">
                        <h2>Training Venues</h2>
                        <?php if (user_can('instructors', 'edit')): ?><button type="button" class="btn-primary btn-sm" id="btnAddVenue">＋ Add Venue</button><?php endif; ?>
                    </div>
                    <div class="table-responsive">
                        <table class="inquiry-table">
                            <thead><tr><th>Name</th><th>Location</th><th>Capacity</th><th>Status</th><th>Actions</th></tr></thead>
                            <tbody>
                                <?php if (!$venues): ?>
                                    <tr><td colspan="5" style="text-align:center;color:#94A3B8;padding:28px;">No venues yet.</td></tr>
                                <?php endif; ?>
                                <?php foreach ($venues as $v): ?>
                                    <tr>
                                        <td class="cert-table__no"><?= e($v['name']); ?></td>
                                        <td><?= e($v['location'] ?? '—'); ?></td>
                                        <td><?= (int) $v['capacity']; ?></td>
                                        <td><span class="status-badge status-<?= $v['is_active'] ? 'converted' : 'closed'; ?>"><?= $v['is_active'] ? 'Active' : 'Inactive'; ?></span></td>
                                        <td class="cert-table__actions">
                                            <button type="button" class="btn-secondary btn-sm" data-venue-edit='<?= json_encode(['id'=>(int)$v['id'],'name'=>$v['name'],'location'=>$v['location']??'','capacity'=>(int)$v['capacity']], JSON_HEX_APOS|JSON_HEX_QUOT); ?>'>✏️ Edit</button>
                                            <form method="post" action="<?= e(base_url('sections/admissions/admin/maintenance.php?tab=venues')); ?>" style="display:inline;">
                                                <?= csrf_field(); ?>
                                                <input type="hidden" name="action" value="venue_toggle">
                                                <input type="hidden" name="venue_id" value="<?= (int) $v['id']; ?>">
                                                <button type="submit" class="btn-secondary btn-sm"><?= $v['is_active'] ? 'Disable' : 'Enable'; ?></button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </section>

            <?php else: ?>

                <!-- Instructors (standalone profiles, no login) -->
                <section class="workspace-table">
                    <div class="dash-panel__head">
                        <h2>Instructors</h2>
                        <?php if (user_can('instructors', 'edit')): ?><button type="button" class="btn-primary btn-sm" id="btnAddInstructor">＋ Add Instructor</button><?php endif; ?>
                    </div>
                    <div class="table-responsive">
                        <table class="inquiry-table">
                            <thead><tr><th>Code</th><th>Name</th><th>Specialization</th><th>License No.</th><th>Experience</th><th>Rate/Day</th><th>Status</th><th>Actions</th></tr></thead>
                            <tbody>
                                <?php if (!$instructors): ?>
                                    <tr><td colspan="8" style="text-align:center;color:#94A3B8;padding:28px;">No instructors yet — add your first instructor profile.</td></tr>
                                <?php endif; ?>
                                <?php foreach ($instructors as $i): ?>
                                    <tr>
                                        <td class="cert-table__no"><?= e($i['instructor_code'] ?? '—'); ?></td>
                                        <td><?= e(trim($i['first_name'] . ' ' . $i['last_name'])); ?></td>
                                        <td><?= e($i['specialization'] ?? '—'); ?></td>
                                        <td><?= e($i['license_no'] ?? '—'); ?></td>
                                        <td><?= $i['years_experience'] ? $i['years_experience'] . ' yrs' : '—'; ?></td>
                                        <td style="font-weight:700;color:#0B3C5D;">₱ <?= number_format((float) $i['rate_per_day'], 2); ?></td>
                                        <td><span class="status-badge status-<?= $i['is_active'] ? 'converted' : 'closed'; ?>"><?= $i['is_active'] ? 'Active' : 'Inactive'; ?></span></td>
                                        <td class="cert-table__actions">
                                            <button type="button" class="btn-secondary btn-sm" data-instructor-edit='<?= json_encode(['id'=>(int)$i['id'],'code'=>$i['instructor_code']??'','first'=>$i['first_name'],'middle'=>$i['middle_name']??'','last'=>$i['last_name'],'email'=>$i['email']??'','mobile'=>$i['mobile_no']??'','spec'=>$i['specialization']??'','license'=>$i['license_no']??'','licenseExp'=>$i['license_expiry']??'','years'=>(int)$i['years_experience'],'rate'=>$i['rate_per_day']??'0','bio'=>$i['bio']??''], JSON_HEX_APOS|JSON_HEX_QUOT); ?>'>✏️ Edit</button>
                                            <form method="post" action="<?= e(base_url('sections/admissions/admin/maintenance.php?tab=instructors')); ?>" style="display:inline;">
                                                <?= csrf_field(); ?>
                                                <input type="hidden" name="action" value="instructor_toggle">
                                                <input type="hidden" name="instructor_id" value="<?= (int) $i['id']; ?>">
                                                <button type="submit" class="btn-secondary btn-sm"><?= $i['is_active'] ? 'Deactivate' : 'Activate'; ?></button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </section>

            <?php endif; ?>

        </main>
    </section>

    <?php include INCLUDES_PATH . '/footer.php'; ?>
    <?php include INCLUDES_PATH . '/scripts.php'; ?>

    <!-- Venue modal -->
    <div id="venueModal" class="portal-modal" style="display:none;">
        <div class="portal-modal__box">
            <div class="portal-modal__head">
                <h3 id="venueModalTitle">Add Venue</h3>
                <p>Add a training venue</p>
                <button class="portal-modal__close" id="venueClose">&times;</button>
            </div>
            <form method="post" action="<?= e(base_url('sections/admissions/admin/maintenance.php?tab=venues')); ?>">
                <?= csrf_field(); ?>
                <input type="hidden" name="action" value="venue_save">
                <input type="hidden" name="venue_id" id="vfId" value="0">
                <div class="portal-modal__body">
                <div class="cert-form__grid">
                    <div class="t-field t-field--full"><label>Venue Name *</label><input name="name" id="vfName" required placeholder="e.g. USMCI Main Campus — Hall A"></div>
                    <div class="t-field"><label>Location</label><input name="location" id="vfLocation" placeholder="e.g. Main Campus, Zamboanga"></div>
                    <div class="t-field"><label>Capacity</label><input type="number" min="0" name="capacity" id="vfCapacity" value="0" placeholder="e.g. 60"></div>
                </div>
                </div>
                <div class="portal-modal__foot">
                    <button type="button" class="btn-secondary" id="venueCancel">Cancel</button>
                    <button type="submit" class="btn-primary">Save Venue</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Instructor modal -->
    <div id="instructorModal" class="portal-modal" style="display:none;">
        <div class="portal-modal__box">
            <div class="portal-modal__head">
                <h3 id="instructorModalTitle">Add Instructor</h3>
                <p>Instructor profile — no login required</p>
                <button class="portal-modal__close" id="instructorClose">&times;</button>
            </div>
            <form method="post" action="<?= e(base_url('sections/admissions/admin/maintenance.php?tab=instructors')); ?>">
                <?= csrf_field(); ?>
                <input type="hidden" name="action" value="instructor_save">
                <input type="hidden" name="instructor_id" id="ifId" value="0">
                <div class="portal-modal__body">
                <div class="cert-form__grid">
                    <div class="t-field"><label>Instructor Code</label><input name="instructor_code" id="ifCode" placeholder="e.g. INS-001"></div>
                    <div class="t-field"><label>Specialization</label><input name="specialization" id="ifSpec" placeholder="e.g. Fire Fighting"></div>
                    <div class="t-field"><label>First Name *</label><input name="first_name" id="ifFirst" required placeholder="e.g. Juan"></div>
                    <div class="t-field"><label>Last Name *</label><input name="last_name" id="ifLast" required placeholder="e.g. Dela Cruz"></div>
                    <div class="t-field"><label>Middle Name</label><input name="middle_name" id="ifMiddle" placeholder="e.g. Santos"></div>
                    <div class="t-field"><label>Email</label><input type="email" name="email" id="ifEmail" placeholder="e.g. instructor@usmci.edu.ph"></div>
                    <div class="t-field"><label>Mobile</label><input name="mobile_no" id="ifMobile" placeholder="e.g. 09XXXXXXXXX"></div>
                    <div class="t-field"><label>License No.</label><input name="license_no" id="ifLicense" placeholder="e.g. MARINA-12345"></div>
                    <div class="t-field"><label>License Expiry</label><input type="date" name="license_expiry" id="ifLicenseExp"></div>
                    <div class="t-field"><label>Years Experience</label><input type="number" min="0" name="years_experience" id="ifYears" value="0" placeholder="e.g. 10"></div>
                    <div class="t-field"><label>Rate / Day (₱)</label><input type="number" step="0.01" min="0" name="rate_per_day" id="ifRate" value="0" placeholder="e.g. 1500.00"></div>
                    <div class="t-field t-field--full"><label>Bio / Notes</label><textarea name="bio" id="ifBio" rows="2" placeholder="Brief background, certifications, teaching areas..."></textarea></div>
                </div>
                </div>
                <div class="portal-modal__foot">
                    <button type="button" class="btn-secondary" id="instructorCancel">Cancel</button>
                    <button type="submit" class="btn-primary">Save Instructor</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        (function () {
            function showToast(msg, type) { window.usmciToast(msg, type); }
            var flashEl = document.getElementById("maintFlash");
            if (flashEl && flashEl.textContent.trim() !== "") showToast(flashEl.textContent.trim(), flashEl.dataset.type);

            // ---- Venue modal (only present on the Venues tab) ----
            var modal = document.getElementById("venueModal");
            function setVal(id, v) { var el = document.getElementById(id); if (el) el.value = v ?? ""; }
            function openVenue(d) {
                document.getElementById("venueModalTitle").textContent = d ? "Edit Venue" : "Add Venue";
                setVal("vfId", d ? d.id : 0);
                setVal("vfName", d ? d.name : "");
                setVal("vfLocation", d ? d.location : "");
                setVal("vfCapacity", d ? d.capacity : 0);
                modal.style.display = "flex";
            }
            function closeVenue() { modal.style.display = "none"; }
            var btnAddVenue = document.getElementById("btnAddVenue");
            if (btnAddVenue) btnAddVenue.addEventListener("click", function () { openVenue(null); });
            document.querySelectorAll("[data-venue-edit]").forEach(function (b) {
                b.addEventListener("click", function () { try { openVenue(JSON.parse(b.dataset.venueEdit)); } catch (e) {} });
            });
            var venueClose = document.getElementById("venueClose");
            if (venueClose) venueClose.addEventListener("click", closeVenue);
            var venueCancel = document.getElementById("venueCancel");
            if (venueCancel) venueCancel.addEventListener("click", closeVenue);
            if (modal) modal.addEventListener("click", function (e) { if (e.target === modal) closeVenue(); });

            // ---- Instructor modal (only present on the Instructors tab) ----
            var imodal = document.getElementById("instructorModal");
            function iset(id, v) { var el = document.getElementById(id); if (el) el.value = v ?? ""; }
            function openInstructor(d) {
                document.getElementById("instructorModalTitle").textContent = d ? "Edit Instructor" : "Add Instructor";
                iset("ifId", d ? d.id : 0);
                iset("ifCode", d ? d.code : "");
                iset("ifSpec", d ? d.spec : "");
                iset("ifFirst", d ? d.first : "");
                iset("ifLast", d ? d.last : "");
                iset("ifMiddle", d ? d.middle : "");
                iset("ifEmail", d ? d.email : "");
                iset("ifMobile", d ? d.mobile : "");
                iset("ifLicense", d ? d.license : "");
                iset("ifLicenseExp", d ? d.licenseExp : "");
                iset("ifYears", d ? d.years : 0);
                iset("ifRate", d ? d.rate : 0);
                iset("ifBio", d ? d.bio : "");
                imodal.style.display = "flex";
            }
            function closeInstructor() { imodal.style.display = "none"; }
            var btnAddInstructor = document.getElementById("btnAddInstructor");
            if (btnAddInstructor) btnAddInstructor.addEventListener("click", function () { openInstructor(null); });
            document.querySelectorAll("[data-instructor-edit]").forEach(function (b) {
                b.addEventListener("click", function () { try { openInstructor(JSON.parse(b.dataset.instructorEdit)); } catch (e) {} });
            });
            var instructorClose = document.getElementById("instructorClose");
            if (instructorClose) instructorClose.addEventListener("click", closeInstructor);
            var instructorCancel = document.getElementById("instructorCancel");
            if (instructorCancel) instructorCancel.addEventListener("click", closeInstructor);
            if (imodal) imodal.addEventListener("click", function (e) { if (e.target === imodal) closeInstructor(); });
        })();
    </script>

</body>
</html>
