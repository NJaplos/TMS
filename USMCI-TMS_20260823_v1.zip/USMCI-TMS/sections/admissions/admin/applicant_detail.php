<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Admin: Applicant 360° detail (AJAX)
 * File : sections/admissions/admin/applicant_detail.php
 * ---------------------------------------------------------
 * JSON endpoint used by the Applicants page "👁 View" button.
 * Returns one applicant's full timeline: info, inquiries,
 * enrollments, payments, documents, certificates.
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/config/bootstrap.php';

require_access('applicants');

header('Content-Type: application/json');

$applicantId = (int) ($_GET['applicant_id'] ?? 0);
if (!$applicantId) {
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => 'Applicant id is required.']);
    exit;
}

try {
    $pdo = db();

    $stmt = $pdo->prepare(
        "SELECT a.*, g.name AS gender_name, cs.name AS civil_status, n.name AS nationality
         FROM applicant a
         LEFT JOIN mnt_gender g ON g.id = a.gender_id
         LEFT JOIN mnt_civil_status cs ON cs.id = a.civil_status_id
         LEFT JOIN mnt_nationality n ON n.id = a.nationality_id
         WHERE a.id = :id LIMIT 1"
    );
    $stmt->execute(['id' => $applicantId]);
    $info = $stmt->fetch();
    if (!$info) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'Applicant not found.']);
        exit;
    }

    /* Inquiries + reply counts */
    $inq = $pdo->prepare(
        "SELECT i.inquiry_no, i.email, i.course_interest, i.created_at,
                COALESCE(s.label, 'New') AS status_label,
                (SELECT COUNT(*) FROM inquiry_reply r WHERE r.inquiry_id = i.id) AS reply_count
         FROM inquiry i
         LEFT JOIN mnt_inquiry_status s ON s.id = i.status_id
         WHERE i.applicant_id = :id OR LOWER(TRIM(i.email)) = LOWER(TRIM(:em))
         ORDER BY i.id DESC LIMIT 20"
    );
    $inq->execute(['id' => $applicantId, 'em' => $info['email'] ?? '']);

    /* Enrollments */
    $enr = $pdo->prepare(
        "SELECT e.enrollment_no, e.enrollment_date, e.status,
                c.code, c.course_name,
                t.training_no, t.batch_name, t.start_date, t.end_date
         FROM enrollment e
         JOIN mnt_course c ON c.id = e.course_id
         LEFT JOIN training t ON t.id = e.training_id
         WHERE e.applicant_id = :id
         ORDER BY e.id DESC LIMIT 20"
    );
    $enr->execute(['id' => $applicantId]);

    /* Payments */
    $pay = $pdo->prepare(
        "SELECT p.payment_no, p.total_amount, p.paid_amount, p.balance_amount, p.due_date,
                COALESCE(ps.name, 'Unpaid') AS status_name
         FROM payment p
         LEFT JOIN mnt_payment_status ps ON ps.id = p.payment_status_id
         WHERE p.applicant_id = :id
         ORDER BY p.id DESC LIMIT 20"
    );
    $pay->execute(['id' => $applicantId]);

    /* Documents */
    $doc = $pdo->prepare(
        "SELECT dt.name AS type_name, d.status, du.file_name, du.uploaded_at
         FROM document d
         LEFT JOIN mnt_document_type dt ON dt.id = d.document_type_id
         LEFT JOIN document_upload du ON du.document_id = d.id
         WHERE d.owner_type = 'applicant' AND d.owner_id = :id
         ORDER BY d.created_at DESC LIMIT 20"
    );
    $doc->execute(['id' => $applicantId]);

    /* Certificates */
    $cert = $pdo->prepare(
        "SELECT c.certificate_no, c.issued_date, c.expiry_date, c.status,
                COALESCE(m.course_name, c.course_name_override) AS course
         FROM certificate c
         LEFT JOIN mnt_course m ON m.id = c.course_id
         WHERE c.applicant_id = :id
         ORDER BY c.issued_date DESC LIMIT 20"
    );
    $cert->execute(['id' => $applicantId]);

    echo json_encode([
        'success' => true,
        'info' => [
            'applicant_no' => $info['applicant_no'],
            'name'         => trim(($info['first_name'] ?? '') . ' ' . ($info['middle_name'] ?? '') . ' ' . ($info['last_name'] ?? '')),
            'email'        => $info['email'] ?? '—',
            'mobile'       => $info['mobile_no'] ?? '—',
            'gender'       => $info['gender_name'] ?? '—',
            'civil_status' => $info['civil_status'] ?? '—',
            'nationality'  => $info['nationality'] ?? '—',
            'created'      => $info['created_at'],
        ],
        'inquiries'   => $inq->fetchAll() ?: [],
        'enrollments' => $enr->fetchAll() ?: [],
        'payments'    => $pay->fetchAll() ?: [],
        'documents'   => $doc->fetchAll() ?: [],
        'certificates'=> $cert->fetchAll() ?: [],
    ]);
} catch (Throwable $e) {
    error_log('applicant_detail: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Could not load the applicant.']);
}
exit;
