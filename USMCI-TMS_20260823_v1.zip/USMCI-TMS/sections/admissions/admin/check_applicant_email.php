<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Admin: Check applicant email (AJAX)
 * File : sections/admissions/admin/check_applicant_email.php
 * ---------------------------------------------------------
 * Returns whether an email already belongs to an applicant.
 * Used by the Create Enrollment modal BEFORE submitting a
 * walk-in, so a duplicate-email submission keeps the modal
 * open and lets the user correct it.
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/config/bootstrap.php';

require_access('enrollment');

header('Content-Type: application/json');

$email = strtolower(trim((string) ($_GET['email'] ?? '')));

if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['exists' => false]);
    exit;
}

try {
    $pdo = db();
    $stmt = $pdo->prepare("SELECT id, applicant_no FROM applicant WHERE LOWER(TRIM(email)) = :em LIMIT 1");
    $stmt->execute(['em' => $email]);
    $row = $stmt->fetch();
    echo json_encode([
        'exists' => (bool) $row,
        'applicant_no' => $row['applicant_no'] ?? null,
    ]);
} catch (Throwable $e) {
    error_log('check_applicant_email: ' . $e->getMessage());
    echo json_encode(['exists' => false]);
}
exit;
