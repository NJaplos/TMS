<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Admin: Delete payment (AJAX)
 * File : sections/admissions/admin/payment_delete.php
 * ---------------------------------------------------------
 * JSON endpoint used by the Payments page to delete a payment
 * record. Blocked while the payment has recorded transactions
 * (receipts exist) — a payment with receipts must be voided
 * by Accounting instead.
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/config/bootstrap.php';

require_edit('payments');

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'POST required.']);
    exit;
}

csrf_check();

$paymentId = (int) ($_POST['payment_id'] ?? 0);

if (!$paymentId) {
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => 'Payment id is required.']);
    exit;
}

try {
    $pdo = db();

    $stmt = $pdo->prepare('SELECT id, payment_no, enrollment_id FROM payment WHERE id = :id');
    $stmt->execute(['id' => $paymentId]);
    $payment = $stmt->fetch();

    if (!$payment) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'Payment not found.']);
        exit;
    }

    $stmt = $pdo->prepare('SELECT COUNT(*) FROM payment_transaction WHERE payment_id = :id');
    $stmt->execute(['id' => $paymentId]);
    $cnt = (int) $stmt->fetchColumn();

    if ($cnt > 0) {
        http_response_code(422);
        echo json_encode(['success' => false, 'message' => 'Cannot delete — ' . $cnt . ' receipt(s) already issued for this payment.']);
        exit;
    }

    $pdo->beginTransaction();
    $pdo->prepare('DELETE FROM payment_item WHERE payment_id = :id')->execute(['id' => $paymentId]);
    $pdo->prepare('DELETE FROM payment WHERE id = :id')->execute(['id' => $paymentId]);

    /* V5.32: if nothing remains paid on the enrollment, revert it to Pending */
    $autoStatus = auto_sync_enrollment_from_payment($pdo, $paymentId, (int) ($payment['enrollment_id'] ?? 0));

    $pdo->commit();

    echo json_encode(['success' => true, 'message' => "Payment {$payment['payment_no']} deleted."
        . ($autoStatus === 'pending' ? ' The enrollment was reverted to Pending.' : '')]);
} catch (Throwable $e) {
    error_log('payment_delete: ' . $e->getMessage());
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => 'Could not delete the payment.']);
}
exit;
