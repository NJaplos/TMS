<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Admin: Printable Enrollment Reports (V5.38)
 * File : sections/admissions/admin/report_form.php
 * ---------------------------------------------------------
 * Two printable "form" reports (USMCI letterhead, logo, signature
 * blocks) with filters by course / batch / date range:
 *
 *   ?type=enrollment_list   → Reg No · SRN · Name · Contact · Signature
 *   ?type=enrollment_status → Reg No · SRN · Name · Contact · Status
 *
 * Header text comes from Settings → Report Letterhead (report_setting).
 * Lead Instructor comes from the batch (training.lead_instructor_id),
 * "Prepared by" is the logged-in staff.
 *
 * Supports CSV export with the same filters: ?export=1&type=…
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/config/bootstrap.php';

require_access('reports');

$pdo = db();

$type = (string) ($_GET['type'] ?? 'enrollment_list');
$isStatus = $type === 'enrollment_status';
if (!in_array($type, ['enrollment_list', 'enrollment_status'], true)) { $type = 'enrollment_list'; }

$courseId = (int) ($_GET['course_id'] ?? 0);
$batchId  = (int) ($_GET['batch_id'] ?? 0);
$from     = trim((string) ($_GET['from'] ?? ''));
$to       = trim((string) ($_GET['to'] ?? ''));
if ($from !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $from)) { $from = ''; }
if ($to   !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $to))   { $to   = ''; }

$where  = ' WHERE 1 = 1';
$params = [];
if ($courseId) { $where .= ' AND e.course_id = :cid'; $params['cid'] = $courseId; }
if ($batchId)  { $where .= ' AND e.training_id = :tid'; $params['tid'] = $batchId; }
if ($from !== '') { $where .= ' AND e.enrollment_date >= :dfrom'; $params['dfrom'] = $from; }
if ($to   !== '') { $where .= ' AND e.enrollment_date <= :dto';   $params['dto']   = $to;   }

$sql = "SELECT e.enrollment_no, e.enrollment_date, e.status, e.training_id, e.course_id,
               a.first_name, a.middle_name, a.last_name, a.mobile_no,
               ap.seafarer_id_no AS srn,
               c.course_name, c.code AS course_code,
               t.training_no, t.batch_name, t.max_slots, t.start_date, t.end_date, t.lead_instructor_id
        FROM enrollment e
        JOIN applicant a ON a.id = e.applicant_id
        LEFT JOIN applicant_profile ap ON ap.applicant_id = a.id
        JOIN mnt_course c ON c.id = e.course_id
        LEFT JOIN training t ON t.id = e.training_id"
    . $where . ' ORDER BY c.course_name, t.training_no, e.enrollment_no';

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll() ?: [];

/* ---- CSV export (same filters) ---- */
if (($_GET['export'] ?? '') === '1') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $type . '-' . date('Ymd') . '.csv"');
    $out = fopen('php://output', 'w');
    fwrite($out, "\xEF\xBB\xBF");
    fputcsv($out, $isStatus
        ? ['Registration No', 'SRN', 'Name', 'Contact No', 'Enrollment Status']
        : ['Registration No', 'SRN', 'Name', 'Contact No', 'Signature']);
    foreach ($rows as $r) {
        $name = trim($r['first_name'] . ' ' . ($r['middle_name'] ?? '') . ' ' . $r['last_name']);
        fputcsv($out, $isStatus
            ? [$r['enrollment_no'], $r['srn'] ?? '', $name, $r['mobile_no'] ?? '', $r['status']]
            : [$r['enrollment_no'], $r['srn'] ?? '', $name, $r['mobile_no'] ?? '', '']);
    }
    fclose($out);
    exit;
}

/* ---- Filter options ---- */
$courses = $pdo->query("SELECT id, code, course_name FROM mnt_course WHERE is_active = 1 ORDER BY course_name")->fetchAll() ?: [];
$batches = $pdo->query(
    "SELECT t.id, t.training_no, t.batch_name, t.course_id, t.max_slots, t.start_date, t.end_date,
            COALESCE(CONCAT(i.first_name, ' ', i.last_name), '') AS lead_instructor
     FROM training t
     LEFT JOIN instructor i ON i.id = t.lead_instructor_id
     ORDER BY t.start_date DESC LIMIT 300"
)->fetchAll() ?: [];

/* ---- Batch context for the header (first row's batch) ---- */
$ctx = [];
$firstRow = $rows[0] ?? null;
if ($firstRow && $firstRow['training_id']) {
    $ctx = [
        'batch'  => trim(($firstRow['training_no'] ?? '') . ' ' . ($firstRow['batch_name'] ?? '')),
        'slots'  => (int) ($firstRow['max_slots'] ?? 0),
        'dates'  => ($firstRow['start_date'] && $firstRow['end_date'])
                    ? date('M d, Y', strtotime($firstRow['start_date'])) . ' — ' . date('M d, Y', strtotime($firstRow['end_date']))
                    : '',
    ];
} elseif ($batchId) {
    foreach ($batches as $b) {
        if ((int) $b['id'] === $batchId) {
            $ctx = [
                'batch' => trim($b['training_no'] . ' ' . $b['batch_name']),
                'slots' => (int) $b['max_slots'],
                'dates' => ($b['start_date'] && $b['end_date']) ? date('M d, Y', strtotime($b['start_date'])) . ' — ' . date('M d, Y', strtotime($b['end_date'])) : '',
            ];
            break;
        }
    }
}
$courseName = '';
if ($courseId) {
    foreach ($courses as $c) { if ((int) $c['id'] === $courseId) { $courseName = $c['code'] . ' — ' . $c['course_name']; break; } }
}
$dateRange = trim(($from !== '' ? 'From ' . date('M d, Y', strtotime($from)) : '') . ($from !== '' && $to !== '' ? ' to ' : '') . ($to !== '' ? date('M d, Y', strtotime($to)) : ''));

/* ---- Letterhead (Settings → Report Letterhead) ---- */
$orgName    = report_setting('report_org_name', 'UNITED SEAFARERS MARITIME CENTER INC');
$orgAddress = report_setting('report_org_address', 'G/F YMCA OF MANILA BLDG 350 ANTONIO VILLEGAS ST ERMITA MANILA');
$telNo      = report_setting('report_tel_no', 'TEL NO: 8241-0881');
$mobileNo   = report_setting('report_mobile_no', 'MOBILE NO: 09971201553');
$email      = report_setting('report_email', 'usmci2010@gmail.com');
$footerNote = report_setting('report_footer', '');

$logoB64 = '';
$logoPath = BASE_PATH . '/assets/images/branding/logo-light3.png';
if (is_file($logoPath)) {
    $logoB64 = 'data:image/png;base64,' . base64_encode(file_get_contents($logoPath));
}

/* Lead instructor + prepared by */
$leadInstructor = '';
if ($firstRow && $firstRow['lead_instructor_id']) {
    $li = $pdo->prepare("SELECT CONCAT(first_name, ' ', last_name) AS n FROM instructor WHERE id = :id");
    $li->execute(['id' => (int) $firstRow['lead_instructor_id']]);
    $leadInstructor = (string) $li->fetchColumn();
}
$preparedBy = trim((string) (current_user()['full_name'] ?? ''));
if ($preparedBy === '') { $preparedBy = trim((string) (current_user()['username'] ?? '')); }

$page = [
    'title'       => ($isStatus ? 'Enrollment Status' : 'Enrollment List') . ' | USMCI-TMS',
    'description' => 'Printable enrollment report',
    'bodyClass'   => 'admissions-page',
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $isStatus ? 'Enrollment Status' : 'Enrollment List'; ?> — <?= htmlspecialchars($orgName, ENT_QUOTES); ?></title>
<style>
    * { margin:0; padding:0; box-sizing:border-box; }
    body { font-family:Arial, Helvetica, sans-serif; color:#111; font-size:13px; padding:16px; }
    .filters { max-width:900px; margin:0 auto 14px; display:flex; flex-wrap:wrap; gap:8px; align-items:flex-end; }
    .filters label { font-size:.72rem; font-weight:700; color:#5B6472; display:block; margin-bottom:2px; }
    .filters select, .filters input { height:34px; padding:0 8px; border:1px solid #CBD5E1; border-radius:8px; font-family:inherit; font-size:.82rem; }
    .filters .btn { background:#0D8A72; color:#fff; border:none; padding:0 14px; height:34px; border-radius:8px; font-weight:700; cursor:pointer; font-size:.8rem; text-decoration:none; display:inline-flex; align-items:center; }
    .filters .btn.ghost { background:#fff; color:#0B3C5D; border:1px solid #CBD5E1; }
    .sheet { max-width:900px; margin:0 auto; border:1px solid #000; padding:16px 18px 22px; }
    .top { display:grid; grid-template-columns:1fr auto 1fr; gap:12px; align-items:start; border-bottom:2px solid #000; padding-bottom:10px; }
    .logo { width:150px; height:60px; display:flex; align-items:center; justify-content:flex-start; overflow:hidden; }
    .logo img { max-width:150px; max-height:60px; object-fit:contain; }
    .org { text-align:center; }
    .org .name { font-size:15px; font-weight:800; letter-spacing:.4px; }
    .org .addr { font-size:9.5px; margin-top:3px; }
    .org .contacts { font-size:9.5px; margin-top:2px; }
    .title { text-align:center; font-weight:800; font-size:14px; padding:8px 0 2px; letter-spacing:1px; }
    .meta { display:flex; flex-wrap:wrap; gap:6px 24px; font-size:11px; padding:6px 2px 10px; border-bottom:1px solid #999; }
    .meta b { color:#0B3C5D; }
    table { width:100%; border-collapse:collapse; table-layout:fixed; margin-top:10px; }
    th, td { border:1px solid #000; padding:5px 7px; vertical-align:top; font-size:12px; }
    th { background:#F1F5F9; font-size:10.5px; text-transform:uppercase; letter-spacing:.3px; }
    td.sig { height:44px; }
    .sigline { border-top:1px solid #999; margin-top:30px; padding-top:3px; font-size:9.5px; text-align:center; }
    .foot { display:flex; justify-content:space-between; gap:20px; margin-top:26px; }
    .foot .block { width:46%; text-align:center; font-size:11px; }
    .foot .block .line { border-top:1px solid #000; padding-top:4px; font-weight:700; min-height:24px; }
    .foot .block .lbl { font-size:8.5px; color:#555; margin-top:3px; text-transform:uppercase; letter-spacing:.3px; }
    .note { font-size:9px; margin-top:14px; text-align:center; color:#333; }
    @media print {
        body { padding:0; }
        .filters { display:none; }
        .sheet { border:none; max-width:100%; }
        thead { display:table-header-group; }
        tr { page-break-inside:avoid; }
    }
</style>
</head>
<body>

<div class="filters">
    <form method="get" action="<?= e(base_url('sections/admissions/admin/report_form.php')); ?>" style="display:contents;">
        <input type="hidden" name="type" value="<?= e($type); ?>">
        <div><label>Course</label>
            <select name="course_id">
                <option value="">All Courses</option>
                <?php foreach ($courses as $c): ?>
                    <option value="<?= (int) $c['id']; ?>" <?= $courseId === (int) $c['id'] ? 'selected' : ''; ?>><?= e($c['code'] . ' — ' . $c['course_name']); ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div><label>Batch</label>
            <select name="batch_id">
                <option value="">All Batches</option>
                <?php foreach ($batches as $b): ?>
                    <option value="<?= (int) $b['id']; ?>" <?= $batchId === (int) $b['id'] ? 'selected' : ''; ?>><?= e($b['training_no'] . ' · ' . $b['batch_name'] . ' (' . $b['start_date'] . ' → ' . $b['end_date'] . ')'); ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div><label>From</label><input type="date" name="from" value="<?= e($from); ?>"></div>
        <div><label>To</label><input type="date" name="to" value="<?= e($to); ?>"></div>
        <button class="btn" type="submit">Apply</button>
        <a class="btn ghost" href="<?= e(base_url('sections/admissions/admin/report_form.php?export=1&type=' . $type . ($courseId ? '&course_id=' . $courseId : '') . ($batchId ? '&batch_id=' . $batchId : '') . ($from ? '&from=' . $from : '') . ($to ? '&to=' . $to : ''))); ?>">⬇ CSV</a>
        <a class="btn ghost" href="<?= e(base_url('sections/admissions/admin/reports.php')); ?>">← Reports</a>
        <button class="btn" type="button" onclick="window.print()">🖨 Print / Save PDF</button>
    </form>
</div>

<div class="sheet">
    <div class="top">
        <div class="logo"><?php if ($logoB64 !== ''): ?><img src="<?= htmlspecialchars($logoB64, ENT_QUOTES); ?>" alt="logo"><?php endif; ?></div>
        <div class="org">
            <div class="name"><?= htmlspecialchars($orgName, ENT_QUOTES); ?></div>
            <div class="addr"><?= htmlspecialchars($orgAddress, ENT_QUOTES); ?></div>
            <div class="contacts"><?= htmlspecialchars(trim($telNo . '  ' . $mobileNo), ENT_QUOTES); ?> · <?= htmlspecialchars($email, ENT_QUOTES); ?></div>
        </div>
    </div>

    <div class="title"><?= $isStatus ? 'ENROLLMENT STATUS REPORT' : 'ENROLLMENT LIST'; ?></div>

    <div class="meta">
        <?php if ($courseName !== ''): ?><span><b>Course:</b> <?= e($courseName); ?></span><?php endif; ?>
        <?php if (!empty($ctx['batch'])): ?><span><b>Batch:</b> <?= e($ctx['batch']); ?></span><?php endif; ?>
        <?php if (!empty($ctx['slots'])): ?><span><b>Slots:</b> <?= (int) $ctx['slots']; ?></span><?php endif; ?>
        <?php if (!empty($ctx['dates'])): ?><span><b>Schedule:</b> <?= e($ctx['dates']); ?></span><?php endif; ?>
        <?php if ($dateRange !== ''): ?><span><b>Filter:</b> <?= e($dateRange); ?></span><?php endif; ?>
        <span><b>Printed:</b> <?= e(date('M d, Y g:i A')); ?></span>
    </div>

    <table>
        <thead>
            <tr>
                <th style="width:15%;">Registration No.</th>
                <th style="width:15%;">SRN</th>
                <th style="width:28%;">Name</th>
                <th style="width:17%;">Contact No.</th>
                <?php if ($isStatus): ?>
                    <th style="width:25%;">Enrollment Status</th>
                <?php else: ?>
                    <th style="width:25%;">Signature</th>
                <?php endif; ?>
            </tr>
        </thead>
        <tbody>
            <?php if (!$rows): ?>
                <tr><td colspan="5" style="text-align:center;color:#5B6472;padding:20px;">No enrollments match the filters.</td></tr>
            <?php endif; ?>
            <?php foreach ($rows as $r):
                $name = trim($r['first_name'] . ' ' . ($r['middle_name'] ?? '') . ' ' . $r['last_name']);
                $name = trim(preg_replace('/\s+/', ' ', $name));
            ?>
                <tr>
                    <td><?= e($r['enrollment_no']); ?></td>
                    <td><?= e($r['srn'] ?? ''); ?></td>
                    <td><?= e($name); ?></td>
                    <td><?= e($r['mobile_no'] ?? ''); ?></td>
                    <?php if ($isStatus): ?>
                        <td><span style="font-weight:700;text-transform:uppercase;font-size:10.5px;"><?= e($r['status']); ?></span></td>
                    <?php else: ?>
                        <td class="sig"></td>
                    <?php endif; ?>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <?php if (!$isStatus): ?>
        <div class="sigline">Signature</div>
    <?php endif; ?>

    <div class="foot">
        <div class="block">
            <div class="line"><?= htmlspecialchars($leadInstructor, ENT_QUOTES); ?></div>
            <div class="lbl">Lead Instructor</div>
        </div>
        <div class="block">
            <div class="line"><?= htmlspecialchars($preparedBy, ENT_QUOTES); ?></div>
            <div class="lbl">Prepared by</div>
        </div>
    </div>

    <?php if ($footerNote !== ''): ?>
        <p class="note"><?= htmlspecialchars($footerNote, ENT_QUOTES); ?></p>
    <?php endif; ?>
</div>

</body>
</html>
