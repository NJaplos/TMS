<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Admin: Applicants
 * File : sections/admissions/admin/applicants.php
 * ---------------------------------------------------------
 * Applicant registry with:
 *   - server-side pagination (D2)
 *   - auto-hide already-enrolled (toggle to include)
 *   - 👁 View → 360° modal (info + inquiries + enrollments +
 *     payments + documents + certificates) via applicant_detail.php
 *   - 🗑 Delete (system confirm modal)
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/config/bootstrap.php';

require_access('applicants');
if ($_SERVER['REQUEST_METHOD'] === 'POST') { require_edit('applicants'); }

$pdo = db();

$search = trim((string) ($_GET['q'] ?? ''));
$showEnrolled = isset($_GET['enrolled']) && (int) $_GET['enrolled'] === 1;
$pageNum = max(1, (int) ($_GET['page'] ?? 1));
$perPage = 25;

$where = ' WHERE 1 = 1';
$params = [];

if (!$showEnrolled) {
    $where .= " AND NOT EXISTS (SELECT 1 FROM enrollment e WHERE e.applicant_id = a.id)";
}

if ($search !== '') {
    /* PDO native prepares (EMULATE_PREPARES=false) reject reused named
       params — bind one placeholder per LIKE. */
    $where .= " AND (a.applicant_no LIKE :kw1 OR a.first_name LIKE :kw2 OR a.last_name LIKE :kw3 OR a.email LIKE :kw4)";
    $like = '%' . $search . '%';
    $params = array_merge($params, ['kw1' => $like, 'kw2' => $like, 'kw3' => $like, 'kw4' => $like]);
}

/* Total (for pagination) */
$cntStmt = $pdo->prepare("SELECT COUNT(*) FROM applicant a" . $where);
$cntStmt->execute($params);
$total = (int) $cntStmt->fetchColumn();
$totalPages = max(1, (int) ceil($total / $perPage));
if ($pageNum > $totalPages) { $pageNum = $totalPages; }
$offset = ($pageNum - 1) * $perPage;

$sql = "SELECT a.id, a.applicant_no, a.first_name, a.middle_name, a.last_name, a.email,
               a.mobile_no, a.created_at,
               (SELECT COUNT(*) FROM inquiry i WHERE i.applicant_id = a.id) AS inquiry_count,
               (SELECT COUNT(*) FROM enrollment e WHERE e.applicant_id = a.id) AS enrollment_count
        FROM applicant a"
    . $where . " ORDER BY a.id DESC LIMIT $perPage OFFSET $offset";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$applicants = $stmt->fetchAll();

/* Query-string builder for pagination links (preserves filters) */
function app_qs(array $overrides = []): string
{
    $p = [
        'q'        => trim((string) ($_GET['q'] ?? '')),
        'enrolled' => isset($_GET['enrolled']) ? '1' : '',
        'page'     => $overrides['page'] ?? '',
    ];
    $parts = [];
    foreach ($p as $k => $v) {
        if ($v !== '' && $v !== null) { $parts[] = $k . '=' . urlencode((string) $v); }
    }
    return $parts ? '?' . implode('&', $parts) : '';
}

$page = [
    'title'       => 'Applicants | USMCI-TMS',
    'description' => 'Applicants',
    'bodyClass'   => 'admissions-page',
];
?>
<!DOCTYPE html>
<html lang="en">

<?php include INCLUDES_PATH . '/head.php'; ?>

<link rel="stylesheet" href="<?= e(base_url('assets/css/portal.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/workspace.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/inquiry-queue/assets/css/page.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/admin/dashboard.css?v=' . ASSET_VERSION)); ?>">

<body class="<?= e($page['bodyClass']); ?>">

    <?php include NAVBAR_PATH . '/index.php'; ?>

    <section class="portal-shell portal-shell--2col">

        <?php require ADMISSIONS_PATH . '/inquiry-queue/partials/sidebar.php'; ?>

        <main class="portal-content">

            <header class="workspace-header">
                <div class="workspace-header__left">
                    <span class="section-badge">Registry</span>
                    <h1>Applicants</h1>
                    <p>All applicant records — <?= number_format($total); ?> total<?= $showEnrolled ? ' (incl. enrolled)' : ' (already-enrolled hidden)'; ?>.</p>
                </div>
                <div class="workspace-header__right" style="align-items:center;">
                    <form method="get" style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;">
                        <label style="display:flex;align-items:center;gap:6px;font-size:.85rem;color:#334155;font-weight:600;cursor:pointer;">
                            <input type="checkbox" name="enrolled" value="1" onchange="this.form.submit()" <?= $showEnrolled ? 'checked' : ''; ?> style="width:16px;height:16px;accent-color:#0D8A72;cursor:pointer;">
                            Show already-enrolled
                        </label>
                        <input type="text" name="q" value="<?= e($search); ?>" placeholder="Search applicants..." class="toolbar-search">
                    </form>
                </div>
            </header>

            <section class="workspace-table">
                <div class="table-responsive">
                    <table class="inquiry-table">
                        <thead>
                            <tr>
                                <th>Applicant No.</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Mobile</th>
                                <th>Inquiries</th>
                                <th>Enrollments</th>
                                <th>Created</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!$applicants): ?>
                                <tr><td colspan="8" style="text-align:center;color:#94A3B8;padding:30px;">No applicants found.</td></tr>
                            <?php endif; ?>
                            <?php foreach ($applicants as $a): ?>
                                <tr>
                                    <td><?= e($a['applicant_no']); ?></td>
                                    <td><?= e(trim($a['first_name'] . ' ' . $a['last_name'])); ?></td>
                                    <td><?= e($a['email']); ?></td>
                                    <td><?= e($a['mobile_no'] ?? '—'); ?></td>
                                    <td><?= (int) $a['inquiry_count']; ?></td>
                                    <td><?= (int) $a['enrollment_count']; ?></td>
                                    <td><?= e(date('M d, Y', strtotime($a['created_at']))); ?></td>
                                    <td class="cert-table__actions">
                                        <div class="cert-actions-2x2">
                                            <button type="button" class="btn-secondary btn-sm" data-applicant-view="<?= (int) $a['id']; ?>">👁 View</button>
                                            <button type="button" class="btn-secondary btn-sm" data-applicant-delete='<?= json_encode(['id'=>(int)$a['id'],'no'=>$a['applicant_no'],'name'=>trim($a['first_name'].' '.$a['last_name']),'enrolled'=>(int)$a['enrollment_count'] > 0], JSON_HEX_APOS|JSON_HEX_QUOT); ?>'>🗑 Delete</button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <?php if ($totalPages > 1): ?>
                    <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;padding:12px 20px;border-top:1px solid #E2E8F0;">
                        <span style="font-size:.82rem;color:#64748B;">Page <?= $pageNum; ?> of <?= $totalPages; ?> · <?= number_format($total); ?> applicants</span>
                        <div style="display:flex;gap:6px;">
                            <?php if ($pageNum > 1): ?>
                                <a class="btn-secondary btn-sm" style="text-decoration:none;" href="<?= e(base_url('sections/admissions/admin/applicants.php' . app_qs(['page' => $pageNum - 1]))); ?>">← Prev</a>
                            <?php endif; ?>
                            <?php if ($pageNum < $totalPages): ?>
                                <a class="btn-secondary btn-sm" style="text-decoration:none;" href="<?= e(base_url('sections/admissions/admin/applicants.php' . app_qs(['page' => $pageNum + 1]))); ?>">Next →</a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?>
            </section>

        </main>
    </section>

    <?php include INCLUDES_PATH . '/footer.php'; ?>
    <?php include INCLUDES_PATH . '/scripts.php'; ?>

    <!-- Applicant 360° modal -->
    <div id="appModal" class="portal-modal" style="display:none;">
        <div class="portal-modal__box portal-modal__box--wide">
            <div class="portal-modal__head">
                <h3>👁 Applicant Profile</h3>
                <p id="appModalSub">—</p>
                <button class="portal-modal__close" id="appClose">&times;</button>
            </div>
            <div class="portal-modal__body" id="appModalBody">
                <div style="text-align:center;color:#94A3B8;padding:30px;">Loading…</div>
            </div>
            <div class="portal-modal__foot">
                <button type="button" class="btn-primary" id="appCloseBtn">Close</button>
            </div>
        </div>
    </div>

    <script>
        (function () {
            var DETAIL_URL = <?= json_encode(base_url('sections/admissions/admin/applicant_detail.php')); ?>;

            /* ---- 360° view modal ---- */
            var appModal = document.getElementById("appModal");
            function esc(s) {
                return String(s ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;")
                    .replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
            }
            function money(v) { return "₱ " + Number(v || 0).toLocaleString("en-US", { minimumFractionDigits: 2 }); }
            function fmt(d) { return d ? String(d).substring(0, 10) : "—"; }

            function section(title, rows, cols, rowHtml) {
                if (!rows || rows.length === 0) return "";
                var h = '<div class="app-sec"><h4>' + title + ' <span class="app-count">' + rows.length + '</span></h4><table class="app-tbl"><thead><tr>' +
                    cols.map(function (c) { return "<th>" + c + "</th>"; }).join("") + "</tr></thead><tbody>" +
                    rows.map(rowHtml).join("") + "</tbody></table></div>";
                return h;
            }

            function openView(id) {
                appModal.style.display = "flex";
                document.getElementById("appModalBody").innerHTML = '<div style="text-align:center;color:#94A3B8;padding:30px;">Loading…</div>';
                fetch(DETAIL_URL + "?applicant_id=" + id, { headers: { "X-Requested-With": "fetch" } })
                    .then(function (r) { return r.json(); })
                    .then(function (d) {
                        if (!d.success) { document.getElementById("appModalBody").innerHTML = '<div class="notfound" style="text-align:center;color:#B91C1C;padding:20px;">' + esc(d.message || "Could not load.") + "</div>"; return; }
                        var info = d.info;
                        document.getElementById("appModalSub").textContent = info.applicant_no + " · " + info.email;
                        var html =
                            '<div class="app-info">' +
                                '<div class="app-info__cell"><span>Name</span><b>' + esc(info.name) + '</b></div>' +
                                '<div class="app-info__cell"><span>Email</span><b>' + esc(info.email) + '</b></div>' +
                                '<div class="app-info__cell"><span>Mobile</span><b>' + esc(info.mobile) + '</b></div>' +
                                '<div class="app-info__cell"><span>Gender</span><b>' + esc(info.gender) + '</b></div>' +
                                '<div class="app-info__cell"><span>Civil Status</span><b>' + esc(info.civil_status) + '</b></div>' +
                                '<div class="app-info__cell"><span>Nationality</span><b>' + esc(info.nationality) + '</b></div>' +
                                '<div class="app-info__cell"><span>Registered</span><b>' + fmt(info.created) + '</b></div>' +
                            '</div>';

                        html += section("Inquiries", d.inquiries, ["Inquiry No.", "Course", "Status", "Replies", "Date"],
                            function (r) { return "<tr><td>" + esc(r.inquiry_no) + "</td><td>" + esc(r.course_interest || "—") + "</td><td>" + esc(r.status_label) + "</td><td>" + r.reply_count + "</td><td>" + fmt(r.created_at) + "</td></tr>"; });

                        html += section("Enrollments", d.enrollments, ["Enrollment No.", "Course", "Batch", "Status", "Dates"],
                            function (r) { return "<tr><td>" + esc(r.enrollment_no) + "</td><td>" + esc(r.code + " " + r.course_name) + "</td><td>" + esc(r.batch_name || "—") + "</td><td>" + esc(r.status) + "</td><td>" + fmt(r.start_date) + " → " + fmt(r.end_date) + "</td></tr>"; });

                        html += section("Payments", d.payments, ["Payment No.", "Total", "Paid", "Balance", "Status", "Due"],
                            function (r) { return "<tr><td>" + esc(r.payment_no) + "</td><td>" + money(r.total_amount) + "</td><td style='color:#15803D;'>" + money(r.paid_amount) + "</td><td style='color:#B45309;'>" + money(r.balance_amount) + "</td><td>" + esc(r.status_name) + "</td><td>" + fmt(r.due_date) + "</td></tr>"; });

                        html += section("Documents", d.documents, ["Type", "File", "Status", "Uploaded"],
                            function (r) { return "<tr><td>" + esc(r.type_name || "—") + "</td><td>" + esc(r.file_name || "—") + "</td><td>" + esc(r.status || "—") + "</td><td>" + fmt(r.uploaded_at) + "</td></tr>"; });

                        html += section("Certificates", d.certificates, ["Cert No.", "Course", "Issued", "Expiry", "Status"],
                            function (r) { return "<tr><td>" + esc(r.certificate_no) + "</td><td>" + esc(r.course || "—") + "</td><td>" + fmt(r.issued_date) + "</td><td>" + fmt(r.expiry_date) + "</td><td>" + esc(r.status) + "</td></tr>"; });

                        document.getElementById("appModalBody").innerHTML = html || '<div style="text-align:center;color:#94A3B8;padding:30px;">No records yet.</div>';
                    })
                    .catch(function () { document.getElementById("appModalBody").innerHTML = '<div style="text-align:center;color:#B91C1C;padding:30px;">Could not load the applicant.</div>'; });
            }
            function closeView() { appModal.style.display = "none"; }
            document.querySelectorAll("[data-applicant-view]").forEach(function (b) {
                b.addEventListener("click", function () { openView(b.dataset.applicantView); });
            });
            document.getElementById("appClose").addEventListener("click", closeView);
            document.getElementById("appCloseBtn").addEventListener("click", closeView);
            appModal.addEventListener("click", function (e) { if (e.target === appModal) closeView(); });

            /* ---- Delete (AJAX + system confirm modal) ---- */
            var DELETE_URL = <?= json_encode(base_url('sections/admissions/admin/applicant_delete.php')); ?>;
            var CSRF = <?= json_encode(csrf_token()); ?>;
            document.querySelectorAll("[data-applicant-delete]").forEach(function (btn) {
                btn.addEventListener("click", function () {
                    var d = JSON.parse(btn.dataset.applicantDelete);
                    var msg = "Delete applicant " + d.no + " (" + d.name + ")? This removes the record" +
                        (d.enrolled ? " and its enrollments" : "") + " from the list. Records with official receipts or issued certificates are protected.";
                    usmciConfirm({
                        title: "Delete applicant?",
                        message: msg,
                        confirmText: "Delete",
                        danger: true
                    }).then(function (ok) {
                        if (!ok) return;
                        var fd = new FormData();
                        fd.append("csrf_token", CSRF);
                        fd.append("applicant_id", d.id);
                        fetch(DELETE_URL, { method: "POST", body: fd })
                            .then(function (r) { return r.json(); })
                            .then(function (res) {
                                window.usmciToast(res.message, res.success ? "success" : "error");
                                if (res.success) {
                                    var tr = btn.closest("tr");
                                    if (tr) tr.remove();
                                }
                            })
                            .catch(function () { window.usmciToast("Could not delete the applicant.", "error"); });
                    });
                });
            });
        })();
    </script>

</body>
</html>
