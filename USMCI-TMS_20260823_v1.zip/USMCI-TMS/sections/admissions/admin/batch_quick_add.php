<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Admin: Quick-add batch (from course modal)
 * POST /sections/admissions/admin/batch_quick_add.php
 * ---------------------------------------------------------
 * JSON endpoint used by the Course Management modal to add a
 * training batch for a course without leaving the page.
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/config/bootstrap.php';

require_edit('courses');

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'POST required.']);
    exit;
}

csrf_check();

$courseId = (int) ($_POST['course_id'] ?? 0);
$batchNo  = trim((string) ($_POST['batch_no'] ?? ''));
$name     = trim((string) ($_POST['batch_name'] ?? ''));
$start    = trim((string) ($_POST['start_date'] ?? ''));
$end      = trim((string) ($_POST['end_date'] ?? ''));
$slots    = (int) ($_POST['max_slots'] ?? 24);
$timeStart = trim((string) ($_POST['time_start'] ?? ''));
$timeEnd   = trim((string) ($_POST['time_end'] ?? ''));

if (!$courseId || $batchNo === '' || $name === '' || $start === '' || $end === '') {
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => 'Batch no., name, start and end dates are required.']);
    exit;
}
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $start) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $end)) {
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => 'Dates are not valid.']);
    exit;
}
if (strtotime($end) < strtotime($start)) {
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => 'End date cannot be before the start date.']);
    exit;
}

try {
    $pdo = db();
    $pdo->prepare(
        "INSERT INTO training (training_no, course_id, batch_name, batch_status_id, max_slots, start_date, end_date, created_at)
         VALUES (:no, :cid, :bn, 2, :mx, :sd, :ed, NOW())"
    )->execute([
        'no' => $batchNo, 'cid' => $courseId, 'bn' => $name,
        'mx' => $slots, 'sd' => $start, 'ed' => $end,
    ]);
    $trainingId = (int) $pdo->lastInsertId();

    /* Session times (one row per day) */
    if ($timeStart !== '' && $timeEnd !== '') {
        $ins = $pdo->prepare(
            "INSERT INTO training_schedule (training_id, session_date, start_time, end_time, topic, created_at)
             VALUES (:tid, :sd, :st, :en, :tp, NOW())"
        );
        for ($d = strtotime($start); $d <= strtotime($end); $d = strtotime('+1 day', $d)) {
            $ins->execute(['tid' => $trainingId, 'sd' => date('Y-m-d', $d), 'st' => $timeStart, 'en' => $timeEnd, 'tp' => $name]);
        }
    }

    echo json_encode([
        'success' => true,
        'message' => "Batch {$batchNo} added.",
        'batch' => [
            'no' => $batchNo, 'name' => $name, 'from' => $start, 'to' => $end,
        ],
    ]);
} catch (Throwable $e) {
    error_log('batch_quick_add: ' . $e->getMessage());
    $dup = strpos($e->getMessage(), 'Duplicate entry') !== false;
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => $dup ? 'That batch number already exists.' : 'Could not add the batch.']);
}
exit;
