<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Admin: Payments
 * File : sections/admissions/admin/payments.php
 * ---------------------------------------------------------
 * Payment recording for enrolled applicants:
 *   - Create a payment against an enrollment (total auto-filled
 *     from the course price, editable) → PAY-YYYY-###### number
 *     and one payment_item row (course name + price).
 *   - Record a payment transaction (amount, method, ref, date,
 *     remarks) → inserts payment_transaction + official_receipt
 *     (OR-YYYY-######) and recomputes paid/balance/status
 *     (UNPAID → PARTIAL → PAID).
 *   - Delete a payment (AJAX) — only while it has no receipts.
 * The trainee portal's Payments ledger reads the same `payment`
 * rows, so recorded payments appear to the trainee instantly.
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/config/bootstrap.php';

require_access('payments');
if ($_SERVER['REQUEST_METHOD'] === 'POST') { require_edit('payments'); }

$pdo = db();

$flash = ['type' => null, 'message' => null];

/* ==========================================================
   Sequence helper (PAY / OR) — mirrors the ENR generator.
   Must be called inside an active transaction (FOR UPDATE).
========================================================== */
function next_sequence_no(PDO $pdo, string $code): string
{
    $year = (int) date('Y');

    $sel = $pdo->prepare(
        "SELECT id, current_value, prefix, padding_length
         FROM sequence_generator WHERE sequence_code = :c AND sequence_year = :y FOR UPDATE"
    );
    $sel->execute(['c' => $code, 'y' => $year]);
    $seq = $sel->fetch();

    if (!$seq) {
        $pdo->prepare(
            "INSERT INTO sequence_generator (sequence_code, sequence_year, current_value, prefix, padding_length)
             VALUES (:c1, :y1, 0, :c2, 6)"
        )->execute(['c1' => $code, 'y1' => $year, 'c2' => $code]);
        $sel->execute(['c' => $code, 'y' => $year]);
        $seq = $sel->fetch();
    }

    $next = ((int) $seq['current_value']) + 1;
    $pdo->prepare("UPDATE sequence_generator SET current_value = :v WHERE id = :id")
        ->execute(['v' => $next, 'id' => $seq['id']]);

    return sprintf('%s-%d-%s', $seq['prefix'], $year, str_pad((string) $next, (int) $seq['padding_length'], '0', STR_PAD_LEFT));
}

/* ==========================================================
   Handle POST
========================================================== */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = $_POST['action'] ?? '';

    try {
        /* ---- Create payment (against an enrollment) ---- */
        if ($action === 'payment_save') {
            $enrollmentId = (int) ($_POST['enrollment_id'] ?? 0);
            $total        = (float) ($_POST['total_amount'] ?? 0);
            $dueDate      = trim((string) ($_POST['due_date'] ?? ''));

            if (!$enrollmentId) {
                $flash = ['type' => 'error', 'message' => 'Select an enrollment.'];
            } elseif ($total <= 0) {
                $flash = ['type' => 'error', 'message' => 'Total amount must be greater than zero.'];
            } else {
                $stmt = $pdo->prepare(
                    "SELECT e.id, e.applicant_id, e.course_id, e.enrollment_no,
                            a.first_name, a.last_name,
                            c.course_name, c.price_amount
                     FROM enrollment e
                     JOIN applicant a ON a.id = e.applicant_id
                     JOIN mnt_course c ON c.id = e.course_id
                     WHERE e.id = :id AND e.status IN ('pending','enrolled')"
                );
                $stmt->execute(['id' => $enrollmentId]);
                $enr = $stmt->fetch();

                if (!$enr) {
                    $flash = ['type' => 'error', 'message' => 'Enrollment not found or is not active.'];
                } else {
                    $pdo->beginTransaction();
                    $paymentNo = next_sequence_no($pdo, 'PAY');
                    $paid = 0.00;
                    $balance = round($total, 2);

                    $pdo->prepare(
                        "INSERT INTO payment (payment_no, applicant_id, enrollment_id, payment_status_id,
                                total_amount, paid_amount, balance_amount, due_date, created_at)
                         VALUES (:no, :ap, :en, 1, :tt, :pd, :bl, :dd, NOW())"
                    )->execute([
                        'no' => $paymentNo, 'ap' => $enr['applicant_id'], 'en' => $enrollmentId,
                        'tt' => $total, 'pd' => $paid, 'bl' => $balance,
                        'dd' => $dueDate !== '' ? $dueDate : null,
                    ]);

                    $paymentId = (int) $pdo->lastInsertId();

                    $pdo->prepare(
                        "INSERT INTO payment_item (payment_id, item_name, quantity, unit_price, total_price)
                         VALUES (:pid, :item, 1, :up, :tp)"
                    )->execute([
                        'pid' => $paymentId, 'item' => $enr['course_name'],
                        'up' => $total, 'tp' => $total,
                    ]);

                    $pdo->commit();
                    audit_log('payments', 'create_obligation', $paymentId, "Payment {$paymentNo} created for {$enr['first_name']} {$enr['last_name']} (₱ " . number_format($total, 2) . ")");
                    $flash = ['type' => 'success', 'message' => "Payment {$paymentNo} created for {$enr['first_name']} {$enr['last_name']} (₱ " . number_format($total, 2) . ")."];
                }
            }
        }

        /* ---- Record a payment transaction (issues an OR) ---- */
        elseif ($action === 'payment_record') {
            $paymentId = (int) ($_POST['payment_id'] ?? 0);
            $amount    = (float) ($_POST['amount'] ?? 0);
            $methodId  = (int) ($_POST['payment_method_id'] ?? 0);
            $ref       = trim((string) ($_POST['transaction_ref'] ?? ''));
            $remarks   = trim((string) ($_POST['remarks'] ?? ''));
            $txDate    = trim((string) ($_POST['transaction_date'] ?? ''));
            $txDate    = ($txDate === '') ? date('Y-m-d') : $txDate;

            if (!$paymentId) {
                $flash = ['type' => 'error', 'message' => 'Payment is required.'];
            } elseif ($amount <= 0) {
                $flash = ['type' => 'error', 'message' => 'Amount must be greater than zero.'];
            } elseif (!$methodId) {
                $flash = ['type' => 'error', 'message' => 'Select a payment method.'];
            } else {
                $pdo->beginTransaction();

                $stmt = $pdo->prepare("SELECT * FROM payment WHERE id = :id FOR UPDATE");
                $stmt->execute(['id' => $paymentId]);
                $pay = $stmt->fetch();

                if (!$pay) {
                    $pdo->rollBack();
                    $flash = ['type' => 'error', 'message' => 'Payment not found.'];
                } elseif ((int) $pay['payment_status_id'] === 4 || (int) $pay['payment_status_id'] === 5) {
                    $pdo->rollBack();
                    $label = (int) $pay['payment_status_id'] === 4 ? 'refunded' : 'void';
                    $flash = ['type' => 'error', 'message' => 'This payment is ' . $label . ' — recording is not allowed.'];
                } elseif ($amount > (float) $pay['balance_amount'] + 0.004) {
                    $pdo->rollBack();
                    $flash = ['type' => 'error', 'message' => 'Amount exceeds the remaining balance (₱ ' . number_format((float) $pay['balance_amount'], 2) . ').'];
                } else {
                    $staffId = (int) (current_user()['id'] ?? 0);
                    $txDateDt = date('Y-m-d H:i:s', strtotime($txDate . ' ' . date('H:i:s')));

                    $pdo->prepare(
                        "INSERT INTO payment_transaction (payment_id, payment_method_id, transaction_ref,
                                amount, transaction_date, received_by, remarks, created_at)
                         VALUES (:pid, :mth, :ref, :amt, :dt, :by, :rm, NOW())"
                    )->execute([
                        'pid' => $paymentId, 'mth' => $methodId, 'ref' => $ref !== '' ? $ref : null,
                        'amt' => $amount, 'dt' => $txDateDt, 'by' => $staffId, 'rm' => $remarks !== '' ? $remarks : null,
                    ]);

                    $txId = (int) $pdo->lastInsertId();
                    $receiptNo = next_sequence_no($pdo, 'OR');

                    $pdo->prepare(
                        "INSERT INTO official_receipt (receipt_no, payment_transaction_id, issued_date, issued_by, status, created_at)
                         VALUES (:no, :tx, :dt, :by, 'issued', NOW())"
                    )->execute(['no' => $receiptNo, 'tx' => $txId, 'dt' => $txDate, 'by' => $staffId]);

                    $newPaid = round((float) $pay['paid_amount'] + $amount, 2);
                    $newBalance = round((float) $pay['total_amount'] - $newPaid, 2);
                    $newStatus = $newBalance <= 0.004 ? 3 : 2; // 3=PAID, 2=PARTIAL

                    $pdo->prepare(
                        "UPDATE payment SET paid_amount = :pd, balance_amount = :bl,
                                payment_status_id = :st, updated_at = NOW()
                         WHERE id = :id"
                    )->execute(['pd' => $newPaid, 'bl' => $newBalance, 'st' => $newStatus, 'id' => $paymentId]);

                    /* V5.32: auto-update enrollment status when a payment is recorded
                       (pending + any payment → Enrolled; confirmation email queued). */
                    $autoStatus = auto_sync_enrollment_from_payment($pdo, $paymentId);

                    $pdo->commit();
                    audit_log('payments', 'record_payment', $paymentId, "₱ " . number_format($amount, 2) . " recorded on {$pay['payment_no']} — receipt {$receiptNo} issued"
                        . ($autoStatus === 'enrolled' ? ' — enrollment auto-updated to Enrolled' : ''));
                    $flash = ['type' => 'success', 'message' => "₱ " . number_format($amount, 2) . " recorded — receipt {$receiptNo} issued."
                        . ($autoStatus === 'enrolled' ? " The enrollment was auto-updated to Enrolled." : '')];
                }
            }
        }
    } catch (Throwable $e) {
        if (isset($pdo) && $pdo->inTransaction()) { $pdo->rollBack(); }
        error_log('payments.php: ' . $e->getMessage());
        $flash = ['type' => 'error', 'message' => 'Could not save the payment. Please try again.'];
    }
}

/* ==========================================================
   Load data
========================================================== */
$statuses  = $pdo->query("SELECT id, code, name FROM mnt_payment_status ORDER BY sort_order")->fetchAll() ?: [];
$methods   = $pdo->query("SELECT id, code, name FROM mnt_payment_method WHERE is_active = 1 ORDER BY sort_order")->fetchAll() ?: [];

/* Filters */
$filterStatus = (int) ($_GET['status'] ?? 0);
$filterKw     = trim((string) ($_GET['q'] ?? ''));

$where = ' WHERE 1 = 1';
$params = [];
if ($filterStatus) { $where .= ' AND p.payment_status_id = :st'; $params['st'] = $filterStatus; }
if ($filterKw !== '') {
    $where .= ' AND (p.payment_no LIKE :kw1 OR a.first_name LIKE :kw2 OR a.last_name LIKE :kw3 OR a.applicant_no LIKE :kw4 OR e.enrollment_no LIKE :kw5)';
    $like = '%' . $filterKw . '%';
    $params = array_merge($params, ['kw1' => $like, 'kw2' => $like, 'kw3' => $like, 'kw4' => $like, 'kw5' => $like]);
}

$paymentsStmt = $pdo->prepare(
    "SELECT p.*, ps.name AS status_name,
            a.first_name, a.last_name, a.applicant_no,
            e.enrollment_no, c.course_name, c.code AS course_code,
            (SELECT COUNT(*) FROM payment_transaction pt WHERE pt.payment_id = p.id) AS tx_count
     FROM payment p
     LEFT JOIN mnt_payment_status ps ON ps.id = p.payment_status_id
     LEFT JOIN applicant a ON a.id = p.applicant_id
     LEFT JOIN enrollment e ON e.id = p.enrollment_id
     LEFT JOIN mnt_course c ON c.id = e.course_id"
    . $where . " ORDER BY p.id DESC LIMIT 300"
);
$paymentsStmt->execute($params);
$payments = $paymentsStmt->fetchAll() ?: [];

/* KPIs */
$kpi = $pdo->query(
    "SELECT
        COALESCE(SUM(CASE WHEN p.payment_status_id IN (1,2,3) THEN p.paid_amount ELSE 0 END), 0) AS collected,
        COALESCE(SUM(CASE WHEN p.payment_status_id IN (1,2) THEN p.balance_amount ELSE 0 END), 0) AS outstanding,
        COALESCE(SUM(CASE WHEN p.payment_status_id = 3 THEN 1 ELSE 0 END), 0) AS paid_count,
        COALESCE(SUM(CASE WHEN p.payment_status_id = 2 THEN 1 ELSE 0 END), 0) AS partial_count,
        COALESCE(SUM(CASE WHEN p.payment_status_id IN (1,2) THEN 1 ELSE 0 END), 0) AS open_count,
        COALESCE(SUM(CASE WHEN p.payment_status_id = 5 THEN 1 ELSE 0 END), 0) AS voided_count,
        COALESCE(SUM(CASE WHEN p.payment_status_id = 5 THEN p.paid_amount ELSE 0 END), 0) AS voided_amount
     FROM payment p"
)->fetch();

$page = [
    'title'       => 'Payments | USMCI-TMS',
    'description' => 'Payment Recording',
    'bodyClass'   => 'admissions-page',
];
?>
<!DOCTYPE html>
<html lang="en">

<?php include INCLUDES_PATH . '/head.php'; ?>

<link rel="stylesheet" href="<?= e(base_url('assets/css/portal.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/workspace.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/inquiry-queue/assets/css/page.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/admin/dashboard.css?v=' . ASSET_VERSION)); ?>">

<body class="<?= e($page['bodyClass']); ?>">

    <?php include NAVBAR_PATH . '/index.php'; ?>

    <section class="portal-shell portal-shell--2col">

        <?php require ADMISSIONS_PATH . '/inquiry-queue/partials/sidebar.php'; ?>

        <main class="portal-content">

            <header class="workspace-header">
                <div class="workspace-header__left">
                    <span class="section-badge">Accounting</span>
                    <h1>Payments</h1>
                    <p>Record collections and issue official receipts. Payment obligations are <strong>auto-created</strong> when an enrollment is marked <em>Enrolled</em> — no manual step needed.</p>
                </div>
            </header>

            <?php if ($flash['message']): ?>
                <div id="payFlash" data-type="<?= $flash['type']; ?>" style="display:none;"><?= htmlspecialchars($flash['message'], ENT_QUOTES, 'UTF-8'); ?></div>
            <?php endif; ?>

            <!-- KPIs -->
            <section class="kpi-grid kpi-grid--4">
                <div class="kpi-card">
                    <div class="kpi-card__icon" style="background:#EAF6F2;">💰</div>
                    <div>
                        <div class="kpi-card__value" style="color:#15803D;">₱ <?= number_format((float) $kpi['collected'], 2); ?></div>
                        <div class="kpi-card__label">Total Collected</div>
                    </div>
                </div>
                <div class="kpi-card">
                    <div class="kpi-card__icon" style="background:#FEF3C7;">⏳</div>
                    <div>
                        <div class="kpi-card__value" style="color:#B45309;">₱ <?= number_format((float) $kpi['outstanding'], 2); ?></div>
                        <div class="kpi-card__label">Outstanding Balance</div>
                    </div>
                </div>
                <div class="kpi-card">
                    <div class="kpi-card__icon" style="background:#E0F2FE;">✅</div>
                    <div>
                        <div class="kpi-card__value"><?= (int) $kpi['paid_count']; ?></div>
                        <div class="kpi-card__label">Fully Paid (<?= (int) $kpi['partial_count']; ?> partial)</div>
                    </div>
                </div>
                <div class="kpi-card">
                    <div class="kpi-card__icon" style="background:#FDE8E8;">🚫</div>
                    <div>
                        <div class="kpi-card__value" style="color:#B91C1C;"><?= (int) $kpi['voided_count']; ?></div>
                        <div class="kpi-card__label">Voided (₱ <?= number_format((float) $kpi['voided_amount'], 2); ?>)</div>
                    </div>
                </div>
            </section>

            <!-- Filters -->
            <section class="workspace-toolbar">
                <div class="toolbar-left"></div>
                <div class="toolbar-right">
                    <form method="get" action="<?= e(base_url('sections/admissions/admin/payments.php')); ?>" style="display:flex;gap:8px;align-items:center;">
                        <input type="text" name="q" value="<?= e($filterKw); ?>" placeholder="Search payment / applicant…" class="toolbar-search" style="width:220px;">
                        <select name="status">
                            <option value="">All Statuses</option>
                            <?php foreach ($statuses as $st): ?>
                                <option value="<?= (int) $st['id']; ?>" <?= $filterStatus === (int) $st['id'] ? 'selected' : ''; ?>><?= e($st['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                        <button type="submit" class="btn-secondary btn-sm">Filter</button>
                        <?php if ($filterStatus || $filterKw !== ''): ?>
                            <a href="<?= e(base_url('sections/admissions/admin/payments.php')); ?>" class="btn-secondary btn-sm" style="text-decoration:none;">Reset</a>
                        <?php endif; ?>
                    </form>
                </div>
            </section>

            <!-- Payments table -->
            <section class="workspace-table">
                <div class="dash-panel__head"><h2>Payments (<?= count($payments); ?>)</h2></div>
                <div class="table-responsive">
                    <table class="inquiry-table">
                        <thead>
                            <tr>
                                <th>Payment No.</th><th>Applicant</th><th>Course / Enrollment</th><th>Total</th><th>Paid</th><th>Balance</th><th>Due</th><th>Status</th><th>Receipts</th><th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!$payments): ?>
                                <tr><td colspan="10" style="text-align:center;color:#94A3B8;padding:30px;">No payments yet — click <strong>＋ Record Payment Obligation</strong> to create the first one.</td></tr>
                            <?php endif; ?>
                            <?php foreach ($payments as $p): ?>
                                <?php
                                    $balance = (float) $p['balance_amount'];
                                    $statusId = (int) $p['payment_status_id'];
                                    $voided   = $statusId === 4 || $statusId === 5; // REFUNDED / VOID
                                    $hasTx    = (int) $p['tx_count'] > 0;
                                    $canRecord = !$voided && $balance > 0.004;
                                ?>
                                <tr>
                                    <td class="cert-table__no"><?= e($p['payment_no']); ?></td>
                                    <td><?= e(trim(($p['first_name'] ?? '') . ' ' . ($p['last_name'] ?? ''))); ?><br><span class="course-desc"><?= e($p['applicant_no'] ?? ''); ?></span></td>
                                    <td><?= e($p['course_name'] ?? '—'); ?><br><span class="course-desc"><?= e($p['enrollment_no'] ?? ''); ?></span></td>
                                    <td style="font-weight:700;color:#0B3C5D;">₱ <?= number_format((float) $p['total_amount'], 2); ?></td>
                                    <td style="color:#15803D;">₱ <?= number_format((float) $p['paid_amount'], 2); ?></td>
                                    <td style="color:#B45309;font-weight:600;">₱ <?= number_format($balance, 2); ?></td>
                                    <td><?= e($p['due_date'] ?? '—'); ?></td>
                                    <td><span class="status-badge status-<?= $statusId === 3 ? 'converted' : ($statusId === 2 ? 'pending' : 'closed'); ?>"><?= e($p['status_name'] ?? '—'); ?></span></td>
                                    <td><?= (int) $p['tx_count']; ?></td>
                                    <td class="cert-table__actions">
                                        <div class="cert-actions-2x2">
                                            <?php if ($canRecord): ?>
                                                <button type="button" class="btn-secondary btn-sm" data-record='<?= json_encode(['id'=>(int)$p['id'],'no'=>$p['payment_no'],'balance'=>$balance], JSON_HEX_APOS|JSON_HEX_QUOT); ?>'>💳 Record</button>
                                            <?php endif; ?>
                                            <?php if (!$voided && $hasTx): ?>
                                                <button type="button" class="btn-secondary btn-sm" data-payment-void='<?= json_encode(['id'=>(int)$p['id'],'no'=>$p['payment_no'],'receipts'=>(int)$p['tx_count']], JSON_HEX_APOS|JSON_HEX_QUOT); ?>'>🚫 Void</button>
                                            <?php endif; ?>
                                            <?php if (!$voided && !$hasTx): ?>
                                                <button type="button" class="btn-secondary btn-sm" data-payment-delete='<?= json_encode(['id'=>(int)$p['id'],'no'=>$p['payment_no']], JSON_HEX_APOS|JSON_HEX_QUOT); ?>'>🗑 Delete</button>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </section>

        </main>
    </section>

    <?php include INCLUDES_PATH . '/footer.php'; ?>
    <?php include INCLUDES_PATH . '/scripts.php'; ?>

    <!-- Record payment modal -->
    <div id="recordModal" class="portal-modal" style="display:none;">
        <div class="portal-modal__box">
            <div class="portal-modal__head">
                <h3>Record Payment</h3>
                <p id="recordTarget">—</p>
                <button class="portal-modal__close" id="recordClose">&times;</button>
            </div>
            <form method="post" action="<?= e(base_url('sections/admissions/admin/payments.php')); ?>">
                <?= csrf_field(); ?>
                <input type="hidden" name="action" value="payment_record">
                <input type="hidden" name="payment_id" id="rmId" value="0">
                <div class="portal-modal__body">
                    <div class="cert-form__grid">
                        <div class="t-field"><label>Amount (₱) *</label><input type="number" step="0.01" min="0.01" name="amount" id="rmAmount" required></div>
                        <div class="t-field">
                            <label>Payment Method *</label>
                            <select name="payment_method_id" id="rmMethod" required>
                                <option value="">— select method —</option>
                                <?php foreach ($methods as $m): ?>
                                    <option value="<?= (int) $m['id']; ?>"><?= e($m['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="t-field"><label>Transaction Ref</label><input name="transaction_ref" id="rmRef" placeholder="e.g. GCash ref no."></div>
                        <div class="t-field"><label>Date</label><input type="date" name="transaction_date" id="rmDate" value="<?= e(date('Y-m-d')); ?>"></div>
                        <div class="t-field t-field--full"><label>Remarks</label><textarea name="remarks" id="rmRemarks" rows="2" placeholder="Optional note"></textarea></div>
                    </div>
                </div>
                <div class="portal-modal__foot">
                    <button type="button" class="btn-secondary" id="recordCancel">Cancel</button>
                    <button type="submit" class="btn-primary">Record &amp; Issue Receipt</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        (function () {
            function showToast(msg, type) { window.usmciToast(msg, type); }
            var flashEl = document.getElementById("payFlash");
            if (flashEl && flashEl.textContent.trim() !== "") showToast(flashEl.textContent.trim(), flashEl.dataset.type);

            /* ---- Record payment modal ---- */
            var recordModal = document.getElementById("recordModal");
            function todayLocal() {
                var d = new Date();
                return d.getFullYear() + "-" + String(d.getMonth()+1).padStart(2,"0") + "-" + String(d.getDate()).padStart(2,"0");
            }
            function openRecord(d) {
                document.getElementById("rmId").value = d.id;
                var bal = Number(d.balance);
                document.getElementById("recordTarget").textContent = d.no + " — remaining balance: ₱ " + bal.toFixed(2);
                document.getElementById("rmAmount").value = bal > 0 ? bal.toFixed(2) : "";
                document.getElementById("rmRef").value = "";
                document.getElementById("rmRemarks").value = "";
                document.getElementById("rmDate").value = todayLocal();
                recordModal.style.display = "flex";
            }
            function closeRecord() { recordModal.style.display = "none"; }
            document.querySelectorAll("[data-record]").forEach(function (b) {
                b.addEventListener("click", function () { try { openRecord(JSON.parse(b.dataset.record)); } catch (e) {} });
            });
            document.getElementById("recordClose").addEventListener("click", closeRecord);
            document.getElementById("recordCancel").addEventListener("click", closeRecord);
            recordModal.addEventListener("click", function (e) { if (e.target === recordModal) closeRecord(); });

            var CSRF = <?= json_encode(csrf_token()); ?>;

            /* ---- Delete payment (AJAX) — only while no receipts ---- */
            var DELETE_URL = <?= json_encode(base_url('sections/admissions/admin/payment_delete.php')); ?>;
            document.querySelectorAll("[data-payment-delete]").forEach(function (btn) {
                btn.addEventListener("click", function () {
                    var d = JSON.parse(btn.dataset.paymentDelete);
                    usmciConfirm({
                        title: "Delete payment?",
                        message: "Delete payment " + d.no + "? Only allowed while no receipts were issued.",
                        confirmText: "Delete",
                        danger: true
                    }).then(function (ok) {
                        if (!ok) return;
                        var fd = new FormData();
                        fd.append("csrf_token", CSRF);
                        fd.append("payment_id", d.id);
                        fetch(DELETE_URL, { method: "POST", body: fd })
                            .then(function (r) { return r.json(); })
                            .then(function (res) {
                                showToast(res.message, res.success ? "success" : "error");
                                if (res.success) {
                                    setTimeout(function () { location.reload(); }, 1200);
                                }
                            })
                            .catch(function () { showToast("Could not delete the payment.", "error"); });
                    });
                });
            });

            /* ---- Void payment (AJAX) — payments that have receipts ---- */
            var VOID_URL = <?= json_encode(base_url('sections/admissions/admin/payment_void.php')); ?>;
            document.querySelectorAll("[data-payment-void]").forEach(function (btn) {
                btn.addEventListener("click", function () {
                    var d = JSON.parse(btn.dataset.paymentVoid);
                    usmciConfirm({
                        title: "Void payment?",
                        message: "Void payment " + d.no + "? This voids " + d.receipts + " official receipt(s) and marks the payment VOID. This cannot be undone.",
                        confirmText: "Void",
                        danger: true
                    }).then(function (ok) {
                        if (!ok) return;
                        var fd = new FormData();
                        fd.append("csrf_token", CSRF);
                        fd.append("payment_id", d.id);
                        fetch(VOID_URL, { method: "POST", body: fd })
                            .then(function (r) { return r.json(); })
                            .then(function (res) {
                                showToast(res.message, res.success ? "success" : "error");
                                if (res.success) {
                                    setTimeout(function () { location.reload(); }, 1200);
                                }
                            })
                            .catch(function () { showToast("Could not void the payment.", "error"); });
                    });
                });
            });
        })();
    </script>

</body>
</html>
