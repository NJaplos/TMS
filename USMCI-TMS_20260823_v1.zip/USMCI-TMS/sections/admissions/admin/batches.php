<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Admin: Training Batches & Schedules
 * File : sections/admissions/admin/batches.php
 * ---------------------------------------------------------
 * CRUD for training batches (training table) + their session
 * schedules (training_schedule). Feeds:
 *   - Course Management "Upcoming Batches" dates
 *   - Enrollment "Training Batch" dropdown
 *   - Trainee Registration (enrollment slip)
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/config/bootstrap.php';

require_access('batches');
if ($_SERVER['REQUEST_METHOD'] === 'POST') { require_edit('batches'); }

$pdo = db();

$flash = ['type' => null, 'message' => null];

/* ==========================================================
   Handle POST
========================================================== */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = $_POST['action'] ?? '';

    try {
        /* ---- Create / Update batch ---- */
        if ($action === 'save') {
            $id         = (int) ($_POST['batch_id'] ?? 0);
            $trainingNo = trim((string) ($_POST['training_no'] ?? ''));
            $courseId   = (int) ($_POST['course_id'] ?? 0);
            $batchName  = trim((string) ($_POST['batch_name'] ?? ''));
            $statusId   = (int) ($_POST['batch_status_id'] ?? 0) ?: null;
            $maxSlots   = (int) ($_POST['max_slots'] ?? 0);
            $startDate  = trim((string) ($_POST['start_date'] ?? ''));
            $endDate    = trim((string) ($_POST['end_date'] ?? ''));
            $venue      = trim((string) ($_POST['venue'] ?? ''));
            $instructor = (int) ($_POST['lead_instructor_id'] ?? 0) ?: null;
            $timeStart  = trim((string) ($_POST['time_start'] ?? ''));
            $timeEnd    = trim((string) ($_POST['time_end'] ?? ''));

            if ($trainingNo === '' || !$courseId || $batchName === '' || $startDate === '' || $endDate === '') {
                $flash = ['type' => 'error', 'message' => 'Batch no., course, batch name, and dates are required.'];
            } elseif (strtotime($endDate) < strtotime($startDate)) {
                $flash = ['type' => 'error', 'message' => 'End date cannot be before the start date.'];
            } else {
                /* Course <-> batch validation: the course must exist and be active */
                $courseOk = $pdo->prepare('SELECT id FROM mnt_course WHERE id = :id AND is_active = 1');
                $courseOk->execute(['id' => $courseId]);
                if (!$courseOk->fetch()) {
                    $flash = ['type' => 'error', 'message' => 'The selected course is not valid or is inactive.'];
                } else {
                if ($id > 0) {
                    $pdo->prepare(
                        "UPDATE training SET training_no = :no, course_id = :cid, batch_name = :bn,
                                batch_status_id = :st, max_slots = :mx, start_date = :sd, end_date = :ed,
                                venue = :vn, lead_instructor_id = :li, updated_at = NOW()
                         WHERE id = :id"
                    )->execute([
                        'no' => $trainingNo, 'cid' => $courseId, 'bn' => $batchName, 'st' => $statusId,
                        'mx' => $maxSlots, 'sd' => $startDate, 'ed' => $endDate, 'vn' => $venue,
                        'li' => $instructor, 'id' => $id,
                    ]);
                    $flash = ['type' => 'success', 'message' => "Batch {$trainingNo} updated."];
                } else {
                    $pdo->prepare(
                        "INSERT INTO training (training_no, course_id, batch_name, batch_status_id, max_slots,
                                start_date, end_date, venue, lead_instructor_id, created_at)
                         VALUES (:no, :cid, :bn, :st, :mx, :sd, :ed, :vn, :li, NOW())"
                    )->execute([
                        'no' => $trainingNo, 'cid' => $courseId, 'bn' => $batchName, 'st' => $statusId,
                        'mx' => $maxSlots, 'sd' => $startDate, 'ed' => $endDate, 'vn' => $venue, 'li' => $instructor,
                    ]);
                    $flash = ['type' => 'success', 'message' => "Batch {$trainingNo} created."];
                }

                /* ---- Save training time schedule (one row per day) ---- */
                if (!empty($timeStart) || !empty($timeEnd)) {
                    $trainingId = $id > 0 ? $id : (int) $pdo->lastInsertId();
                    if ($trainingId && $timeStart !== '' && $timeEnd !== '') {
                        $pdo->prepare('DELETE FROM training_schedule WHERE training_id = :id')->execute(['id' => $trainingId]);
                        $d1 = strtotime($startDate);
                        $d2 = strtotime($endDate);
                        $ins = $pdo->prepare(
                            "INSERT INTO training_schedule (training_id, session_date, start_time, end_time, topic, created_at)
                             VALUES (:tid, :sd, :st, :en, :tp, NOW())"
                        );
                        for ($d = $d1; $d <= $d2; $d = strtotime('+1 day', $d)) {
                            $ins->execute(['tid' => $trainingId, 'sd' => date('Y-m-d', $d), 'st' => $timeStart, 'en' => $timeEnd, 'tp' => $batchName]);
                        }
                    }
                }
                }
            }
        }

        /* ---- Delete batch (guarded: no enrollments) ---- */
        elseif ($action === 'delete') {
            $id = (int) ($_POST['batch_id'] ?? 0);
            $cnt = (int) $pdo->prepare("SELECT COUNT(*) FROM enrollment WHERE training_id = :id")->execute(['id' => $id]) ? 0 : 0;
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM enrollment WHERE training_id = :id");
            $stmt->execute(['id' => $id]);
            $cnt = (int) $stmt->fetchColumn();

            if ($cnt > 0) {
                $flash = ['type' => 'error', 'message' => 'Cannot delete — this batch has enrollments. Deactivate it instead.'];
            } else {
                $pdo->prepare("DELETE FROM training_schedule WHERE training_id = :id")->execute(['id' => $id]);
                $pdo->prepare("DELETE FROM training WHERE id = :id")->execute(['id' => $id]);
                $flash = ['type' => 'success', 'message' => 'Batch deleted.'];
            }
        }

        /* ---- Toggle active (via batch_status) ---- */
        elseif ($action === 'toggle') {
            $id = (int) ($_POST['batch_id'] ?? 0);
            $stmt = $pdo->prepare("SELECT batch_status_id FROM training WHERE id = :id");
            $stmt->execute(['id' => $id]);
            $cur = (int) $stmt->fetchColumn();
            // 1=PLANNED, 2=OPEN ... 5=COMPLETED; treat PLANNED as inactive-ish
            $new = $cur === 1 ? 2 : 1;
            $pdo->prepare("UPDATE training SET batch_status_id = :s, updated_at = NOW() WHERE id = :id")
                ->execute(['s' => $new, 'id' => $id]);
            $flash = ['type' => 'success', 'message' => 'Batch status toggled.'];
        }
    } catch (Throwable $e) {
        error_log('batches.php: ' . $e->getMessage());
        $dup = strpos($e->getMessage(), 'Duplicate entry') !== false;
        $flash = ['type' => 'error', 'message' => $dup ? 'That batch number already exists.' : 'Could not save the batch.'];
    }
}

/* ==========================================================
   Load data
========================================================== */
$courses = $pdo->query("SELECT id, code, course_name FROM mnt_course WHERE is_active = 1 ORDER BY course_name")->fetchAll();
$venues = $pdo->query("SELECT id, name FROM mnt_venue WHERE is_active = 1 ORDER BY name")->fetchAll();
$batchStatuses = $pdo->query("SELECT id, name FROM mnt_batch_status ORDER BY sort_order")->fetchAll();
$instructors = $pdo->query(
    "SELECT id, first_name, last_name, specialization FROM instructor WHERE is_active = 1 ORDER BY last_name, first_name"
)->fetchAll();

$filterCourse = (int) ($_GET['course'] ?? 0);
$filterStatus = (int) ($_GET['status'] ?? 0);

$where = ' WHERE 1 = 1';
$params = [];
if ($filterCourse) { $where .= ' AND t.course_id = :c'; $params['c'] = $filterCourse; }
if ($filterStatus) { $where .= ' AND t.batch_status_id = :s'; $params['s'] = $filterStatus; }

$batches = $pdo->prepare(
    "SELECT t.*, c.course_name, c.code AS course_code, bs.name AS status_name,
            sc.time_start, sc.time_end,
            (SELECT COUNT(*) FROM enrollment e WHERE e.training_id = t.id AND e.status NOT IN ('cancelled','no_show')) AS enrolled
     FROM training t
     LEFT JOIN mnt_course c ON c.id = t.course_id
     LEFT JOIN mnt_batch_status bs ON bs.id = t.batch_status_id
     LEFT JOIN (SELECT training_id, MIN(start_time) AS time_start, MAX(end_time) AS time_end FROM training_schedule GROUP BY training_id) sc ON sc.training_id = t.id"
    . $where . " ORDER BY t.start_date DESC LIMIT 200"
);
$batches->execute($params);
$batches = $batches->fetchAll() ?: [];

$page = [
    'title'       => 'Training Batches | USMCI-TMS',
    'description' => 'Training Batches & Schedules',
    'bodyClass'   => 'admissions-page',
];
?>
<!DOCTYPE html>
<html lang="en">

<?php include INCLUDES_PATH . '/head.php'; ?>

<link rel="stylesheet" href="<?= e(base_url('assets/css/portal.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/workspace.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/inquiry-queue/assets/css/page.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/admin/dashboard.css?v=' . ASSET_VERSION)); ?>">

<body class="<?= e($page['bodyClass']); ?>">

    <?php include NAVBAR_PATH . '/index.php'; ?>

    <section class="portal-shell portal-shell--2col">

        <?php require ADMISSIONS_PATH . '/inquiry-queue/partials/sidebar.php'; ?>

        <main class="portal-content">

            <header class="workspace-header">
                <div class="workspace-header__left">
                    <span class="section-badge">Scheduling</span>
                    <h1>Training Batches & Schedules</h1>
                    <p>Manage course batches, dates, slots, and venues — feeds enrollment & the course modal.</p>
                </div>
                <div class="workspace-header__right">
                    <?php if (user_can('batches', 'edit')): ?><button type="button" class="btn-primary" id="btnAddBatch">＋ Add Batch</button><?php endif; ?>
                </div>
            </header>

            <?php if ($flash['message']): ?>
                <div id="batchFlash" data-type="<?= $flash['type']; ?>" style="display:none;"><?= htmlspecialchars($flash['message'], ENT_QUOTES, 'UTF-8'); ?></div>
            <?php endif; ?>

            <!-- Filters -->
            <section class="workspace-toolbar">
                <div class="toolbar-left"></div>
                <div class="toolbar-right">
                    <select id="filterCourse">
                        <option value="">All Courses</option>
                        <?php foreach ($courses as $c): ?>
                            <option value="<?= (int) $c['id']; ?>" <?= $filterCourse === (int) $c['id'] ? 'selected' : ''; ?>><?= e('#' . $c['id'] . ' · ' . $c['code'] . ' — ' . $c['course_name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <select id="filterStatus">
                        <option value="">All Statuses</option>
                        <?php foreach ($batchStatuses as $bs): ?>
                            <option value="<?= (int) $bs['id']; ?>" <?= $filterStatus === (int) $bs['id'] ? 'selected' : ''; ?>><?= e($bs['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </section>

            <!-- Batches table -->
            <section class="workspace-table">
                <div class="table-responsive">
                    <table class="inquiry-table">
                        <thead>
                            <tr>
                                <th>Batch No.</th><th>Batch</th><th>Course</th><th>Dates</th><th>Venue</th><th>Slots</th><th>Status</th><th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!$batches): ?>
                                <tr><td colspan="8" style="text-align:center;color:#94A3B8;padding:30px;">No training batches yet — add your first batch.</td></tr>
                            <?php endif; ?>
                            <?php foreach ($batches as $b): ?>
                                <tr>
                                    <td class="cert-table__no"><?= e($b['training_no']); ?></td>
                                    <td><strong><?= e($b['batch_name']); ?></strong></td>
                                    <td><?= e('#' . $b['course_id'] . ' · ' . $b['course_code'] . ' — ' . $b['course_name']); ?></td>
                                    <td><?= e(date('M d, Y', strtotime($b['start_date']))); ?><br><span class="course-desc">→ <?= e(date('M d, Y', strtotime($b['end_date']))); ?></span></td>
                                    <td><?= e($b['venue'] ?? '—'); ?></td>
                                    <td><span class="<?= (int) $b['enrolled'] >= (int) $b['max_slots'] ? 'cert-expired' : ''; ?>"><?= (int) $b['enrolled']; ?> / <?= (int) $b['max_slots']; ?></span></td>
                                    <td><span class="status-badge"><?= e($b['status_name'] ?? '—'); ?></span></td>
                                    <td class="cert-table__actions">
                                        <button type="button" class="btn-secondary btn-sm" data-edit='<?= json_encode(['id'=>(int)$b['id'],'no'=>$b['training_no'],'course_id'=>(int)$b['course_id'],'name'=>$b['batch_name'],'status_id'=>(int)$b['batch_status_id'],'slots'=>(int)$b['max_slots'],'start'=>$b['start_date'],'end'=>$b['end_date'],'venue'=>$b['venue']??'','instructor'=>(int)$b['lead_instructor_id'],'tstart'=>$b['time_start']??'','tend'=>$b['time_end']??''], JSON_HEX_APOS|JSON_HEX_QUOT); ?>'>✏️ Edit</button>
                                        <button type="button" class="btn-secondary btn-sm" data-batch-delete='<?= json_encode(['id'=>(int)$b['id'],'no'=>$b['training_no']], JSON_HEX_APOS|JSON_HEX_QUOT); ?>'>🗑 Delete</button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </section>

        </main>
    </section>

    <?php include INCLUDES_PATH . '/footer.php'; ?>
    <?php include INCLUDES_PATH . '/scripts.php'; ?>

    <!-- Add/Edit batch modal -->
    <div id="batchModal" class="portal-modal" style="display:none;">
        <div class="portal-modal__box">
            <div class="portal-modal__head">
                <h3 id="batchModalTitle">Add Training Batch</h3>
                <p>Schedule a course batch with dates, slots, venue, and instructor</p>
                <button class="portal-modal__close" id="batchClose">&times;</button>
            </div>
            <form method="post" action="<?= e(base_url('sections/admissions/admin/batches.php')); ?>" class="cert-form" id="batchForm">
                <?= csrf_field(); ?>
                <input type="hidden" name="action" value="save">
                <input type="hidden" name="batch_id" id="bfId" value="0">
                <div class="portal-modal__body">
                <div class="cert-form__grid">
                    <div class="t-field"><label>Batch No. *</label><input name="training_no" id="bfNo" required placeholder="e.g. TRN-2026-002"></div>
                    <div class="t-field"><label>Batch Name *</label><input name="batch_name" id="bfName" required placeholder="e.g. Batch Feb 2026"></div>
                    <div class="t-field t-field--full">
                        <label>Course *</label>
                        <select name="course_id" id="bfCourse" required>
                            <option value="">— select course —</option>
                            <?php foreach ($courses as $c): ?>
                                <option value="<?= (int) $c['id']; ?>"><?= e('#' . $c['id'] . ' · ' . $c['code'] . ' — ' . $c['course_name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="t-field"><label>Start Date *</label><input type="date" name="start_date" id="bfStart" required></div>
                    <div class="t-field"><label>End Date *</label><input type="date" name="end_date" id="bfEnd" required></div>
                    <div class="t-field"><label>Training Time Start</label><input type="time" name="time_start" id="bfTimeStart" placeholder="e.g. 08:00"></div>
                    <div class="t-field"><label>Training Time End</label><input type="time" name="time_end" id="bfTimeEnd" placeholder="e.g. 17:00"></div>
                    <div class="t-field"><label>Max Slots</label><input type="number" min="1" name="max_slots" id="bfSlots" value="24" placeholder="e.g. 24"></div>
                    <div class="t-field">
                        <label>Status</label>
                        <select name="batch_status_id" id="bfStatus">
                            <?php foreach ($batchStatuses as $bs): ?>
                                <option value="<?= (int) $bs['id']; ?>"><?= e($bs['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="t-field t-field--full">
                        <label>Venue</label>
                        <select name="venue" id="bfVenue">
                            <option value="">— select venue —</option>
                            <?php foreach ($venues as $vn): ?>
                                <option value="<?= e($vn['name']); ?>" <?= (($b['venue'] ?? '') === $vn['name']) ? 'selected' : ''; ?>><?= e($vn['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="t-field t-field--full">
                        <label>Lead Instructor</label>
                        <select name="lead_instructor_id" id="bfInstructor">
                            <option value="">— none —</option>
                            <?php foreach ($instructors as $i): ?>
                                <option value="<?= (int) $i['id']; ?>"><?= e(trim($i['first_name'] . ' ' . $i['last_name'])); ?> <?= $i['specialization'] ? '· ' . e($i['specialization']) : ''; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                </div>
                <div class="portal-modal__foot">
                    <button type="button" class="btn-secondary" id="batchCancel">Cancel</button>
                    <button type="submit" class="btn-primary" id="batchSubmitBtn">Save Batch</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        (function () {
            function showToast(msg, type) { window.usmciToast(msg, type); }
            var flashEl = document.getElementById("batchFlash");
            if (flashEl && flashEl.textContent.trim() !== "") showToast(flashEl.textContent.trim(), flashEl.dataset.type);

            var modal = document.getElementById("batchModal");
            function setVal(id, v) { var el = document.getElementById(id); if (el) el.value = v ?? ""; }
            function openBatch(d) {
                document.getElementById("batchModalTitle").textContent = d ? "Edit Batch — " + d.no : "Add Training Batch";
                document.getElementById("batchSubmitBtn").textContent = d ? "Save Changes" : "Save Batch";
                setVal("bfId", d ? d.id : 0);
                setVal("bfNo", d ? d.no : "");
                setVal("bfName", d ? d.name : "");
                setVal("bfCourse", d ? String(d.course_id) : "");
                setVal("bfStart", d ? d.start : "");
                setVal("bfEnd", d ? d.end : "");
                setVal("bfSlots", d && d.slots ? d.slots : 24);
                setVal("bfTimeStart", d ? d.tstart : "");
                setVal("bfTimeEnd", d ? d.tend : "");
                setVal("bfStatus", d && d.status_id ? String(d.status_id) : "1");
                setVal("bfVenue", d ? d.venue : "");
                setVal("bfInstructor", d && d.instructor ? String(d.instructor) : "");
                modal.style.display = "flex";
            }
            /* Batch No. reuse guard — instant, before submit (server also blocks) */
            var EXISTING_NOS = <?= json_encode(array_values(array_unique(array_map(function ($b) { return $b['training_no']; }, $batches)))); ?>;
            function batchNoInUse(no) {
                no = String(no || "").trim().toLowerCase();
                if (!no) return false;
                var currentEdit = document.getElementById("bfId").value;
                return EXISTING_NOS.some(function (n) {
                    if (String(n).toLowerCase() !== no) return false;
                    /* allow keeping the SAME no on the batch being edited */
                    if (currentEdit && currentEdit !== "0") {
                        var row = document.querySelector('[data-edit]');
                        // find the edit row matching this batch id
                        var match = null;
                        document.querySelectorAll("[data-edit]").forEach(function (b) {
                            try { if (String(JSON.parse(b.dataset.edit).id) === currentEdit) match = b; } catch (e) {}
                        });
                        if (match) { try { if (JSON.parse(match.dataset.edit).no.toLowerCase() === no) return false; } catch (e) {} }
                    }
                    return true;
                });
            }
            var bfForm = document.getElementById("batchForm");
            if (bfForm) bfForm.addEventListener("submit", function (e) {
                var no = document.getElementById("bfNo").value.trim();
                if (batchNoInUse(no)) {
                    e.preventDefault();
                    showToast("Batch No. '" + no + "' is already in use — it cannot be reused.", "error");
                }
            });
            document.getElementById("btnAddBatch").addEventListener("click", function () { openBatch(null); });
            document.querySelectorAll("[data-edit]").forEach(function (b) {
                b.addEventListener("click", function () { try { openBatch(JSON.parse(b.dataset.edit)); } catch (e) {} });
            });
            function closeBatch() { modal.style.display = "none"; }
            document.getElementById("batchClose").addEventListener("click", closeBatch);
            document.getElementById("batchCancel").addEventListener("click", closeBatch);
            modal.addEventListener("click", function (e) { if (e.target === modal) closeBatch(); });

            // Filters
            var fc = document.getElementById("filterCourse");
            var fs = document.getElementById("filterStatus");
            function go() {
                var url = window.location.pathname + "?";
                if (fc.value) url += "course=" + fc.value + "&";
                if (fs.value) url += "status=" + fs.value;
                window.location = url;
            }
            if (fc) fc.addEventListener("change", go);
            if (fs) fs.addEventListener("change", go);

            // Delete batch (AJAX — instant toast, no page reload)
            var DELETE_URL = <?= json_encode(base_url('sections/admissions/admin/batch_delete.php')); ?>;
            var CSRF = <?= json_encode(csrf_token()); ?>;
            document.querySelectorAll("[data-batch-delete]").forEach(function (btn) {
                btn.addEventListener("click", function () {
                    var d = JSON.parse(btn.dataset.batchDelete);
                    usmciConfirm({
                        title: "Delete batch?",
                        message: "Delete batch " + d.no + "? Only allowed if it has no enrollments.",
                        confirmText: "Delete",
                        danger: true
                    }).then(function (ok) {
                        if (!ok) return;
                        var fd = new FormData();
                        fd.append("csrf_token", CSRF);
                        fd.append("batch_id", d.id);
                        fetch(DELETE_URL, { method: "POST", body: fd })
                            .then(function (r) { return r.json(); })
                            .then(function (res) {
                                showToast(res.message, res.success ? "success" : "error");
                                if (res.success) {
                                    var tr = btn.closest("tr");
                                    if (tr) tr.remove();
                                    var rows = document.querySelectorAll("tbody tr");
                                    if (rows.length === 1 && rows[0].querySelector("td[colspan]")) {
                                        location.reload(); // show the empty state
                                    }
                                }
                            })
                            .catch(function () { showToast("Could not delete the batch.", "error"); });
                    });
                });
            });
        })();
    </script>

</body>
</html>
