<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Admin: Course Availability
 * File : sections/admissions/admin/course-availability.php
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/config/bootstrap.php';

require_staff();

$pdo = db();

$courses = $pdo->query(
    "SELECT c.id, c.code, c.course_name, c.duration_hours, c.is_active,
            (SELECT COUNT(*) FROM training t WHERE t.course_id = c.id AND t.start_date >= CURDATE()) AS upcoming_batches
     FROM mnt_course c
     ORDER BY c.course_name"
)->fetchAll();

$trainings = $pdo->query(
    "SELECT t.id, t.training_no, t.batch_name, t.start_date, t.end_date, t.max_slots, t.venue,
            c.course_name, bs.name AS batch_status
     FROM training t
     LEFT JOIN mnt_course c ON c.id = t.course_id
     LEFT JOIN mnt_batch_status bs ON bs.id = t.batch_status_id
     ORDER BY t.start_date DESC LIMIT 50"
)->fetchAll();

$page = [
    'title'       => 'Course Availability | USMCI-TMS',
    'description' => 'Course Availability',
    'bodyClass'   => 'admissions-page',
];
?>
<!DOCTYPE html>
<html lang="en">

<?php include INCLUDES_PATH . '/head.php'; ?>

<link rel="stylesheet" href="<?= e(base_url('assets/css/portal.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/workspace.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/inquiry-queue/assets/css/page.css?v=' . ASSET_VERSION)); ?>">

<body class="<?= e($page['bodyClass']); ?>">

    <?php include NAVBAR_PATH . '/index.php'; ?>

    <section class="portal-shell portal-shell--2col">

        <?php require ADMISSIONS_PATH . '/inquiry-queue/partials/sidebar.php'; ?>

        <main class="portal-content">

            <header class="workspace-header">
                <div class="workspace-header__left">
                    <span class="section-badge">Catalog</span>
                    <h1>Course Availability</h1>
                    <p>Courses offered and upcoming training batches.</p>
                </div>
            </header>

            <section class="workspace-table">
                <div class="dash-panel__head"><h2>Courses</h2></div>
                <div class="table-responsive">
                    <table class="inquiry-table">
                        <thead><tr><th>Code</th><th>Course</th><th>Duration</th><th>Price</th><th>Upcoming Batches</th><th>Status</th></tr></thead>
                        <tbody>
                            <?php if (!$courses): ?><tr><td colspan="6" style="text-align:center;color:#94A3B8;padding:28px;">No courses yet.</td></tr><?php endif; ?>
                            <?php foreach ($courses as $c): ?>
                                <tr>
                                    <td><?= e($c['code']); ?></td>
                                    <td><?= e($c['course_name']); ?></td>
                                    <td><?= e($c['duration_hours'] ? $c['duration_hours'] . ' hrs' : '—'); ?></td>
                                    <td style="font-weight:700;color:#0B3C5D;">₱ <?= number_format((float) $c['price_amount'], 2); ?></td>
                                    <td><?= (int) $c['upcoming_batches']; ?></td>
                                    <td><span class="status-badge status-<?= $c['is_active'] ? 'converted' : 'closed'; ?>"><?= $c['is_active'] ? 'Active' : 'Inactive'; ?></span></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </section>

            <section class="workspace-table">
                <div class="dash-panel__head"><h2>Upcoming / Recent Training Batches</h2></div>
                <div class="table-responsive">
                    <table class="inquiry-table">
                        <thead><tr><th>Training No.</th><th>Batch</th><th>Course</th><th>Start</th><th>End</th><th>Slots</th><th>Venue</th><th>Status</th></tr></thead>
                        <tbody>
                            <?php if (!$trainings): ?><tr><td colspan="8" style="text-align:center;color:#94A3B8;padding:28px;">No training batches yet.</td></tr><?php endif; ?>
                            <?php foreach ($trainings as $t): ?>
                                <tr>
                                    <td><?= e($t['training_no']); ?></td>
                                    <td><?= e($t['batch_name']); ?></td>
                                    <td><?= e($t['course_name'] ?? '—'); ?></td>
                                    <td><?= e($t['start_date']); ?></td>
                                    <td><?= e($t['end_date']); ?></td>
                                    <td><?= (int) $t['max_slots']; ?></td>
                                    <td><?= e($t['venue'] ?? '—'); ?></td>
                                    <td><span class="status-badge"><?= e($t['batch_status'] ?? '—'); ?></span></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </section>

        </main>
    </section>

    <?php include INCLUDES_PATH . '/footer.php'; ?>
    <?php include INCLUDES_PATH . '/scripts.php'; ?>

</body>
</html>
