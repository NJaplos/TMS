<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Admin: Course Management
 * File : sections/admissions/admin/courses.php
 * ---------------------------------------------------------
 * Full CRUD for courses (mnt_course) — add, edit, activate/
 * deactivate. The Course Availability page + trainee
 * certificate dropdown both read from here.
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/config/bootstrap.php';

require_access('courses');
if ($_SERVER['REQUEST_METHOD'] === 'POST') { require_edit('courses'); }

$pdo = db();

$flash = ['type' => null, 'message' => null];

/* ==========================================================
   Handle POST (create / update / toggle)
========================================================== */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = $_POST['action'] ?? '';

    try {
        if ($action === 'create' || $action === 'update') {
            $id        = (int) ($_POST['course_id'] ?? 0);
            $code      = trim((string) ($_POST['code'] ?? ''));
            $name      = trim((string) ($_POST['course_name'] ?? ''));
            $catId     = (int) ($_POST['course_category_id'] ?? 0) ?: null;
            $stcw      = trim((string) ($_POST['stcw_reference'] ?? ''));
            $marina    = trim((string) ($_POST['marina_reference'] ?? ''));
            $duration  = trim((string) ($_POST['duration_hours'] ?? ''));
            $validity  = (int) ($_POST['validity_months'] ?? 0) ?: null;
            $price     = trim((string) ($_POST['price_amount'] ?? '0'));
            $upcoming  = (int) ($_POST['upcoming_batches'] ?? 0);
            $med       = isset($_POST['requires_medical']) ? 1 : 0;
            $sea       = 0; // sea-service requirement removed from UI
            $desc      = trim((string) ($_POST['description'] ?? ''));
            $active    = isset($_POST['is_active']) ? 1 : 1;
            $removePhoto = isset($_POST['remove_photo']) ? 1 : 0;

            /* V5.53: optional course photo upload (used on the website Courses page) */
            $photoPath = null;
            if (!empty($_FILES['course_photo']) && $_FILES['course_photo']['error'] === UPLOAD_ERR_OK) {
                $f = $_FILES['course_photo'];
                $ext = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
                if (!in_array($ext, ['jpg', 'jpeg', 'png', 'webp'], true) || $f['size'] > 4 * 1024 * 1024) {
                    $flash = ['type' => 'error', 'message' => 'Course photo must be JPG/PNG/WebP under 4 MB.'];
                    goto photo_skip;
                }
                $dir = BASE_PATH . '/uploads/courses';
                if (!is_dir($dir)) { @mkdir($dir, 0775, true); }
                $pname = 'course-' . time() . '-' . preg_replace('/[^A-Za-z0-9._-]/', '_', basename($f['name']));
                if (move_uploaded_file($f['tmp_name'], $dir . '/' . $pname)) {
                    $photoPath = 'uploads/courses/' . $pname;
                }
            }

            if ($code === '' || $name === '') {
                $flash = ['type' => 'error', 'message' => 'Course code and name are required.'];
            } elseif ($action === 'create') {
                $pdo->prepare(
                    "INSERT INTO mnt_course (course_category_id, code, course_name, stcw_reference, marina_reference,
                            duration_hours, validity_months, price_amount, upcoming_batches, requires_medical, requires_sea_service, description, photo_path, is_active, created_at)
                     VALUES (:cat, :code, :name, :stcw, :marina, :dur, :val, :price, :up, :med, :sea, :desc, :photo, 1, NOW())"
                )->execute([
                    'cat' => $catId, 'code' => $code, 'name' => $name, 'stcw' => $stcw, 'marina' => $marina,
                    'dur' => $duration !== '' ? $duration : null, 'val' => $validity, 'price' => $price, 'up' => $upcoming,
                    'med' => $med, 'sea' => $sea, 'desc' => $desc, 'photo' => $photoPath,
                ]);
                $flash = ['type' => 'success', 'message' => "Course '{$name}' created."];
            } else {
                /* keep existing photo unless replaced or removed */
                if (!$photoPath && !$removePhoto && $id > 0) {
                    $cur = $pdo->prepare('SELECT photo_path FROM mnt_course WHERE id = :id');
                    $cur->execute(['id' => $id]);
                    $photoPath = $cur->fetchColumn() ?: null;
                }
                if ($removePhoto) { $photoPath = null; }
                $pdo->prepare(
                    "UPDATE mnt_course SET course_category_id = :cat, code = :code, course_name = :name,
                            stcw_reference = :stcw, marina_reference = :marina, duration_hours = :dur,
                            validity_months = :val, price_amount = :price, upcoming_batches = :up,
                            requires_medical = :med, requires_sea_service = :sea, description = :desc,
                            photo_path = :photo, is_active = :active, updated_at = NOW()
                     WHERE id = :id"
                )->execute([
                    'cat' => $catId, 'code' => $code, 'name' => $name, 'stcw' => $stcw, 'marina' => $marina,
                    'dur' => $duration !== '' ? $duration : null, 'val' => $validity, 'price' => $price, 'up' => $upcoming,
                    'med' => $med, 'sea' => $sea, 'desc' => $desc, 'photo' => $photoPath, 'active' => $active, 'id' => $id,
                ]);
                $flash = ['type' => 'success', 'message' => "Course '{$name}' updated."];
            }
            photo_skip:
        }

        elseif ($action === 'toggle') {
            $id = (int) ($_POST['course_id'] ?? 0);
            $stmt = $pdo->prepare("SELECT is_active FROM mnt_course WHERE id = :id");
            $stmt->execute(['id' => $id]);
            $cur = (int) $stmt->fetchColumn();
            $pdo->prepare("UPDATE mnt_course SET is_active = :a, updated_at = NOW() WHERE id = :id")
                ->execute(['a' => $cur ? 0 : 1, 'id' => $id]);
            $flash = ['type' => 'success', 'message' => 'Course ' . ($cur ? 'deactivated.' : 'activated.')];
        }
    } catch (Throwable $e) {
        error_log('courses: ' . $e->getMessage());
        $dup = strpos($e->getMessage(), 'Duplicate entry') !== false;
        $flash = ['type' => 'error', 'message' => $dup ? 'That course code already exists.' : 'Could not save the course.'];
    }
}

/* ---- Categories + courses ---- */
$categories = $pdo->query("SELECT id, name FROM mnt_course_category WHERE is_active = 1 ORDER BY sort_order")->fetchAll();
$courses = $pdo->query(
    "SELECT c.*, cc.name AS category_name,
            (SELECT COUNT(*) FROM training t WHERE t.course_id = c.id AND t.start_date >= CURDATE()) AS upcoming_batches
     FROM mnt_course c
     LEFT JOIN mnt_course_category cc ON cc.id = c.course_category_id
     ORDER BY c.course_name"
)->fetchAll();

/* Upcoming training batches grouped by course (for the modal editable list) */
$upcomingByCourse = [];
$upTr = $pdo->query(
    "SELECT id, course_id, training_no, batch_name, start_date, end_date, max_slots
     FROM training WHERE start_date >= CURDATE() ORDER BY start_date"
)->fetchAll();
foreach ($upTr as $u) {
    $upcomingByCourse[(int) $u['course_id']][] = [
        'id' => (int) $u['id'], 'no' => $u['training_no'], 'name' => $u['batch_name'],
        'from' => $u['start_date'], 'to' => $u['end_date'], 'slots' => (int) $u['max_slots'],
    ];
}
$upcomingJson = json_encode($upcomingByCourse);

$page = [
    'title'       => 'Course Management | USMCI-TMS',
    'description' => 'Course Management',
    'bodyClass'   => 'admissions-page',
];
?>
<!DOCTYPE html>
<html lang="en">

<?php include INCLUDES_PATH . '/head.php'; ?>

<link rel="stylesheet" href="<?= e(base_url('assets/css/portal.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/workspace.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/inquiry-queue/assets/css/page.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/admin/dashboard.css?v=' . ASSET_VERSION)); ?>">

<body class="<?= e($page['bodyClass']); ?>">

    <?php include NAVBAR_PATH . '/index.php'; ?>

    <section class="portal-shell portal-shell--2col">

        <?php require ADMISSIONS_PATH . '/inquiry-queue/partials/sidebar.php'; ?>

        <main class="portal-content">

            <header class="workspace-header">
                <div class="workspace-header__left">
                    <span class="section-badge">Catalog</span>
                    <h1>Course Management</h1>
                    <p>Add, edit, and manage maritime training courses.</p>
                </div>
                <div class="workspace-header__right">
                    <?php if (user_can('courses', 'edit')): ?><button type="button" class="btn-primary" id="btnAddCourse">＋ Add Course</button><?php endif; ?>
                </div>
            </header>

            <?php if ($flash['message']): ?>
                <div id="courseFlash" data-type="<?= $flash['type']; ?>" style="display:none;"><?= htmlspecialchars($flash['message'], ENT_QUOTES, 'UTF-8'); ?></div>
            <?php endif; ?>

            <section class="workspace-table">
                <div class="table-responsive">
                    <table class="inquiry-table">
                        <thead>
                            <tr>
                                <th>Code</th><th>Course Name</th><th>Category</th><th>Duration</th><th>Validity</th><th>Price</th><th>Upcoming Batches</th><th>Status</th><th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!$courses): ?>
                                <tr><td colspan="9" style="text-align:center;color:#94A3B8;padding:28px;">No courses yet — add your first course.</td></tr>
                            <?php endif; ?>
                            <?php foreach ($courses as $c): ?>
                                <tr>
                                    <td class="cert-table__no"><?= e($c['code']); ?></td>
                                    <td>
                                        <?= e($c['course_name']); ?>
                                        <?php if (!empty($c['description'])): ?>
                                            <div class="course-desc" title="<?= e($c['description']); ?>"><?= e(mb_strimwidth($c['description'], 0, 60, '…')); ?></div>
                                        <?php endif; ?>
                                    </td>
                                    <td><?= e($c['category_name'] ?? '—'); ?></td>
                                    <td><?= e($c['duration_hours'] ? $c['duration_hours'] . ' hrs' : '—'); ?></td>
                                    <td><?= e($c['validity_months'] ? $c['validity_months'] . ' mo' : '—'); ?></td>
                                    <td style="font-weight:700;color:#0B3C5D;">₱ <?= number_format((float) $c['price_amount'], 2); ?></td>
                                    <td>
                                        <?php if ((int) $c['upcoming_batches'] > 0): ?>
                                            <a href="<?= e(base_url('sections/admissions/admin/batches.php?course=' . (int) $c['id'])); ?>" title="Manage batches for this course" style="color:#0D8A72;font-weight:700;text-decoration:none;"><?= (int) $c['upcoming_batches']; ?> ›</a>
                                        <?php else: ?>—<?php endif; ?>
                                    </td>
                                    <td><span class="status-badge status-<?= $c['is_active'] ? 'converted' : 'closed'; ?>"><?= $c['is_active'] ? 'Active' : 'Inactive'; ?></span></td>
                                    <td class="cert-table__actions">
                                        <div class="cert-actions-2x2">
                                            <button type="button" class="btn-secondary btn-sm" data-edit='<?= json_encode(['id'=>(int)$c['id'],'code'=>$c['code'],'name'=>$c['course_name'],'cat'=>(int)$c['course_category_id'],'stcw'=>$c['stcw_reference']??'','marina'=>$c['marina_reference']??'','dur'=>$c['duration_hours']??'','val'=>(int)$c['validity_months'],'price'=>$c['price_amount']??'0','med'=>(int)$c['requires_medical'],'sea'=>(int)$c['requires_sea_service'],'desc'=>$c['description']??'','upcoming'=>(int)$c['upcoming_batches'],'photo'=>($c['photo_path']??'')], JSON_HEX_APOS|JSON_HEX_QUOT); ?>'>✏️ Edit</button>
                                            <form method="post" action="<?= e(base_url('sections/admissions/admin/courses.php')); ?>" style="display:contents;">
                                                <?= csrf_field(); ?>
                                                <input type="hidden" name="action" value="toggle">
                                                <input type="hidden" name="course_id" value="<?= (int) $c['id']; ?>">
                                                <button type="submit" class="btn-secondary btn-sm"><?= $c['is_active'] ? '🚫 Deactivate' : '✅ Activate'; ?></button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </section>

        </main>
    </section>

    <?php include INCLUDES_PATH . '/footer.php'; ?>
    <?php include INCLUDES_PATH . '/scripts.php'; ?>

    <!-- Add/Edit course modal -->
    <div id="courseModal" class="portal-modal" style="display:none;">
        <div class="portal-modal__box">
            <div class="portal-modal__head">
                <h3 id="courseModalTitle">Add Course</h3>
                <p>Set up a maritime training course</p>
                <button class="portal-modal__close" id="courseClose">&times;</button>
            </div>
            <form method="post" action="<?= e(base_url('sections/admissions/admin/courses.php')); ?>" class="cert-form" enctype="multipart/form-data">
                <?= csrf_field(); ?>
                <input type="hidden" name="action" id="cfAction" value="create">
                <input type="hidden" name="course_id" id="cfId" value="0">
                <div class="portal-modal__body">
                <div class="cert-form__grid">
                    <div class="t-field"><label>Code *</label><input name="code" id="cfCode" required placeholder="e.g. BT-01"></div>
                    <div class="t-field"><label>Course Name *</label><input name="course_name" id="cfName" required placeholder="e.g. Basic Training"></div>
                    <div class="t-field t-field--full"><label>Description</label><textarea name="description" id="cfDesc" rows="2" placeholder="Short description shown under the course name"></textarea></div>
                    <div class="t-field t-field--full">
                        <label>Course Photo <span class="field-hint">(shown on the website Courses page)</span></label>
                        <div style="display:flex;gap:12px;align-items:center;flex-wrap:wrap;">
                            <img id="cfPhotoPreview" alt="Course photo" style="width:86px;height:64px;object-fit:cover;border-radius:8px;border:1px solid #E2E8F0;background:#F8FAFC;display:none;">
                            <input type="file" name="course_photo" id="cfPhoto" accept=".jpg,.jpeg,.png,.webp">
                            <label style="font-size:.78rem;color:#5B6472;display:inline-flex;align-items:center;gap:4px;">
                                <input type="checkbox" name="remove_photo" id="cfRemovePhoto" value="1"> Remove current photo
                            </label>
                        </div>
                    </div>
                    <div class="t-field">
                        <label>Category</label>
                        <select name="course_category_id" id="cfCat">
                            <option value="">— select category —</option>
                            <?php foreach ($categories as $cat): ?>
                                <option value="<?= (int) $cat['id']; ?>"><?= e($cat['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="t-field"><label>STCW Reference</label><input name="stcw_reference" id="cfStcw" placeholder="e.g. A-VI/1"></div>
                    <div class="t-field"><label>MARINA Reference</label><input name="marina_reference" id="cfMarina" placeholder="e.g. MC-2026-01"></div>
                    <div class="t-field"><label>Duration (hours)</label><input type="number" step="0.5" min="0" name="duration_hours" id="cfDur" placeholder="e.g. 40"></div>
                    <div class="t-field"><label>Validity (months)</label><input type="number" min="0" name="validity_months" id="cfVal" placeholder="e.g. 60"></div>
                    <div class="t-field"><label>Price (₱)</label><input type="number" step="0.01" min="0" name="price_amount" id="cfPrice" placeholder="e.g. 2500.00"></div>
                    <div class="t-field t-field--full">
                        <label>Upcoming Batches — editable</label>
                        <div id="cfUpcomingList" class="upcoming-list">
                            <span class="upcoming-list__empty">No upcoming batches for this course.</span>
                        </div>
                        <div class="batch-quick-form" id="cfUbFormWrap" style="display:none;">
                            <label id="cfUbTitle">Edit Batch</label>
                            <input type="hidden" id="cfUbId" value="0">
                            <div class="batch-quick-form__grid">
                                <input type="text" id="cfUbNo" placeholder="Batch No. e.g. TRN-2026-003">
                                <input type="text" id="cfUbName" placeholder="Batch Name e.g. Batch Jun 2026">
                                <input type="date" id="cfUbStart" title="Start date">
                                <input type="date" id="cfUbEnd" title="End date">
                                <input type="number" id="cfUbSlots" placeholder="Max slots" min="1" value="30">
                            </div>
                            <div class="batch-quick-form__actions">
                                <button type="button" class="btn-secondary btn-sm" id="cfUbCancel">Cancel</button>
                                <button type="button" class="btn-primary btn-sm" id="cfUbSave">Update Batch</button>
                            </div>
                        </div>
                        <small class="field-hint">✏️ Edit / 🗑 Delete existing batches right here. To <strong>add</strong> a new batch, use <strong>Training Batches</strong> (sidebar) — new batches appear here automatically.</small>
                    </div>
                    <div class="t-field t-field--req">
                        <label>Requirements</label>
                        <div class="req-toggle">
                            <label><input type="checkbox" name="requires_medical" id="cfMed"> Medical certificate required</label>
                        </div>
                    </div>
                </div>
                </div>
                <div class="portal-modal__foot">
                    <button type="button" class="btn-secondary" id="courseCancel">Cancel</button>
                    <button type="submit" class="btn-primary">Save Course</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        (function () {
            // Toast — shared UDS component (assets/js/usmci-toast.js)
            function showToast(msg, type) { window.usmciToast(msg, type); }

            // Show the flash message as a toast on load
            var flashEl = document.getElementById("courseFlash");
            if (flashEl && flashEl.textContent.trim() !== "") {
                showToast(flashEl.textContent.trim(), flashEl.dataset.type);
            }

            var modal = document.getElementById("courseModal");
            var UPCOMING = <?= $upcomingJson; ?> || {};
            var CSRF = <?= json_encode(csrf_token()); ?>;
            var BATCH_UPDATE_URL = <?= json_encode(base_url('sections/admissions/admin/batch_update.php')); ?>;
            function setVal(id, v) { var el = document.getElementById(id); if (el) el.value = v ?? ""; }
            function esc(s) {
                return String(s ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;")
                    .replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
            }

            function renderUpcoming(courseId) {
                var listEl = document.getElementById("cfUpcomingList");
                if (!listEl) return;
                var batches = UPCOMING[String(courseId)] || [];
                if (batches.length === 0) {
                    listEl.innerHTML = '<span class="upcoming-list__empty">No upcoming batches yet — add one in <strong>Training Batches</strong> (sidebar).</span>';
                    return;
                }
                listEl.innerHTML = batches.map(function (b) {
                    var f = new Date(b.from + "T00:00:00");
                    var t = new Date(b.to + "T00:00:00");
                    var fmt = function (d) { return (d.getMonth()+1) + "/" + d.getDate() + "/" + d.getFullYear(); };
                    var info = '<strong>' + esc(b.no) + '</strong> · ' + esc(b.name) + ' — ' +
                               fmt(f) + ' to ' + fmt(t) + ' · ' + b.slots + ' slots';
                    var btns =
                        '<button type="button" class="ub-btn ub-edit" title="Edit batch"' +
                            ' data-ub-id="' + b.id + '" data-ub-no="' + esc(b.no) + '" data-ub-name="' + esc(b.name) + '"' +
                            ' data-ub-from="' + b.from + '" data-ub-to="' + b.to + '" data-ub-slots="' + b.slots + '">✏️</button>' +
                        '<button type="button" class="ub-btn ub-del" title="Delete batch"' +
                            ' data-ub-id="' + b.id + '" data-ub-no="' + esc(b.no) + '">🗑</button>';
                    return '<div class="upcoming-list__item"><div class="ub-main">' + info + '</div>' +
                           '<div class="ub-actions">' + btns + '</div></div>';
                }).join("");
                bindUb();
            }

            var ubFormWrap = document.getElementById("cfUbFormWrap");

            function bindUb() {
                document.querySelectorAll("#cfUpcomingList .ub-edit").forEach(function (b) {
                    b.addEventListener("click", function () {
                        setVal("cfUbId", b.dataset.ubId);
                        setVal("cfUbNo", b.dataset.ubNo);
                        setVal("cfUbName", b.dataset.ubName);
                        setVal("cfUbStart", b.dataset.ubFrom);
                        setVal("cfUbEnd", b.dataset.ubTo);
                        setVal("cfUbSlots", b.dataset.ubSlots);
                        document.getElementById("cfUbTitle").textContent = "Edit Batch — " + b.dataset.ubNo;
                        ubFormWrap.style.display = "block";
                    });
                });
                document.querySelectorAll("#cfUpcomingList .ub-del").forEach(function (b) {
                    b.addEventListener("click", function () {
                        usmciConfirm({
                            title: "Delete batch?",
                            message: "Delete batch " + b.dataset.ubNo + "? Only allowed if it has no enrollments.",
                            confirmText: "Delete",
                            danger: true
                        }).then(function (ok) {
                            if (!ok) return;
                            var cid = document.getElementById("cfId").value;
                            var fd = new FormData();
                            fd.append("csrf_token", CSRF);
                            fd.append("action", "delete");
                            fd.append("batch_id", b.dataset.ubId);
                            fd.append("course_id", cid);
                            fetch(BATCH_UPDATE_URL, { method: "POST", body: fd })
                                .then(function (r) { return r.json(); })
                                .then(function (res) {
                                    showToast(res.message, res.success ? "success" : "error");
                                    if (res.success) {
                                        UPCOMING[String(cid)] = (UPCOMING[String(cid)] || []).filter(function (x) { return String(x.id) !== b.dataset.ubId; });
                                        renderUpcoming(cid);
                                    }
                                })
                                .catch(function () { showToast("Could not delete the batch.", "error"); });
                        });
                    });
                });
            }

            if (document.getElementById("cfUbSave")) {
                document.getElementById("cfUbSave").addEventListener("click", function () {
                    var cid = document.getElementById("cfId").value;
                    var bid = document.getElementById("cfUbId").value;
                    var no = document.getElementById("cfUbNo").value.trim();
                    var nm = document.getElementById("cfUbName").value.trim();
                    var st = document.getElementById("cfUbStart").value;
                    var en = document.getElementById("cfUbEnd").value;
                    var mx = document.getElementById("cfUbSlots").value || 30;
                    if (!bid || !no || !nm || !st || !en) { showToast("Fill batch no., name, and dates.", "error"); return; }
                    var fd = new FormData();
                    fd.append("csrf_token", CSRF);
                    fd.append("action", "update");
                    fd.append("batch_id", bid);
                    fd.append("course_id", cid);
                    fd.append("training_no", no);
                    fd.append("batch_name", nm);
                    fd.append("start_date", st);
                    fd.append("end_date", en);
                    fd.append("max_slots", mx);
                    fetch(BATCH_UPDATE_URL, { method: "POST", body: fd })
                        .then(function (r) { return r.json(); })
                        .then(function (res) {
                            showToast(res.message, res.success ? "success" : "error");
                            if (res.success) {
                                ubFormWrap.style.display = "none";
                                renderUpcoming(cid);
                            }
                        })
                        .catch(function () { showToast("Could not update the batch.", "error"); });
                });
                document.getElementById("cfUbCancel").addEventListener("click", function () { ubFormWrap.style.display = "none"; });
            }

            function openCourse(d) {
                document.getElementById("courseModalTitle").textContent = d ? "Edit Course" : "Add Course";
                document.getElementById("cfAction").value = d ? "update" : "create";
                if (ubFormWrap) ubFormWrap.style.display = "none";
                setVal("cfId", d ? d.id : 0);
                setVal("cfCode", d ? d.code : "");
                setVal("cfName", d ? d.name : "");
                setVal("cfCat", d && d.cat ? String(d.cat) : "");
                setVal("cfStcw", d ? d.stcw : "");
                setVal("cfMarina", d ? d.marina : "");
                setVal("cfDur", d ? d.dur : "");
                setVal("cfVal", d && d.val ? d.val : "");
                setVal("cfPrice", d && d.price ? d.price : "0");

                setVal("cfDesc", d ? d.desc : "");
                var med = document.getElementById("cfMed"); if (med) med.checked = d ? !!d.med : false;
                /* course photo preview (V5.53) */
                var pv = document.getElementById("cfPhotoPreview");
                var rm = document.getElementById("cfRemovePhoto"); if (rm) rm.checked = false;
                var ph = document.getElementById("cfPhoto"); if (ph) ph.value = "";
                if (pv) {
                    if (d && d.photo) {
                        pv.src = <?= json_encode(base_url('')); ?> + String(d.photo).replace(/^\/+/, "");
                        pv.style.display = "";
                    } else { pv.style.display = "none"; pv.removeAttribute("src"); }
                }
                renderUpcoming(d ? d.id : "");
                modal.style.display = "flex";
            }
            function closeCourse() { modal.style.display = "none"; }
            var cfPhoto = document.getElementById("cfPhoto");
            if (cfPhoto) cfPhoto.addEventListener("change", function () {
                var pv = document.getElementById("cfPhotoPreview");
                var rm = document.getElementById("cfRemovePhoto");
                if (rm) rm.checked = false;
                if (cfPhoto.files && cfPhoto.files[0] && pv) {
                    pv.src = URL.createObjectURL(cfPhoto.files[0]);
                    pv.style.display = "";
                }
            });
            var cfRemove = document.getElementById("cfRemovePhoto");
            if (cfRemove) cfRemove.addEventListener("change", function () {
                var pv = document.getElementById("cfPhotoPreview");
                var ph = document.getElementById("cfPhoto");
                if (ph) ph.value = "";
                if (pv) { pv.style.display = "none"; pv.removeAttribute("src"); }
            });
            document.getElementById("btnAddCourse").addEventListener("click", function () { openCourse(null); });
            document.querySelectorAll("[data-edit]").forEach(function (b) {
                b.addEventListener("click", function () { try { openCourse(JSON.parse(b.dataset.edit)); } catch (e) {} });
            });
            document.getElementById("courseClose").addEventListener("click", closeCourse);
            document.getElementById("courseCancel").addEventListener("click", closeCourse);
            modal.addEventListener("click", function (e) { if (e.target === modal) closeCourse(); });
        })();
    </script>

</body>
</html>
