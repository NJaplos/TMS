<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Admin: Enrollment Requirements (AJAX)
 * File : sections/admissions/admin/enrollment_requirements.php
 * ---------------------------------------------------------
 * GET  ?enrollment_id=N
 *   → { enrollment, applicant, course,
 *       required: [{type_id, code, name, submitted, source, doc_id, doc_title, doc_status}],
 *       counts: {submitted, required} }
 *   "submitted" is true when the applicant has uploaded the doc
 *   (document table) OR staff marked it received (application_requirement
 *   is_submitted=1) — so staff can record that a hardcopy was received.
 *
 * POST action=mark
 *   enrollment_id, document_type_id, value (1|0)
 *   → staff marks/unmarks "received" (application_requirement upsert,
 *     verified_by/verified_at recorded; audit_log entry written).
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/config/bootstrap.php';

require_edit('enrollment');

header('Content-Type: application/json');

try {
    $pdo = db();

    /* ---------- GET: load the checklist ---------- */
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $enrollmentId = (int) ($_GET['enrollment_id'] ?? 0);
        if (!$enrollmentId) {
            http_response_code(422);
            echo json_encode(['success' => false, 'message' => 'Enrollment id required.']);
            exit;
        }

        $stmt = $pdo->prepare(
            "SELECT e.id, e.enrollment_no, e.course_id, e.applicant_id,
                    a.first_name, a.last_name, a.email,
                    c.course_name, c.code AS course_code
             FROM enrollment e
             JOIN applicant a ON a.id = e.applicant_id
             JOIN mnt_course c ON c.id = e.course_id
             WHERE e.id = :id LIMIT 1"
        );
        $stmt->execute(['id' => $enrollmentId]);
        $enr = $stmt->fetch();
        if (!$enr) {
            http_response_code(404);
            echo json_encode(['success' => false, 'message' => 'Enrollment not found.']);
            exit;
        }

        $required = course_required_docs($pdo, (int) $enr['course_id']);

        /* applicant-uploaded docs grouped by type */
        $docs = $pdo->prepare(
            "SELECT d.document_type_id, d.id AS doc_id, d.title, d.status, d.created_at
             FROM document d
             WHERE d.owner_type = 'applicant' AND d.owner_id = :ap
               AND d.status IN ('submitted','verified')
             ORDER BY d.created_at DESC"
        );
        $docs->execute(['ap' => (int) $enr['applicant_id']]);
        $docRows = $docs->fetchAll() ?: [];

        /* staff-marked received (application_requirement) */
        $app = $pdo->prepare("SELECT id FROM application WHERE applicant_id = :ap ORDER BY id DESC LIMIT 1");
        $app->execute(['ap' => (int) $enr['applicant_id']]);
        $applicationId = (int) ($app->fetchColumn() ?: 0);

        $marked = [];
        if ($applicationId) {
            $m = $pdo->prepare(
                "SELECT document_type_id, is_submitted, verified_at, remarks
                 FROM application_requirement WHERE application_id = :aid AND is_submitted = 1"
            );
            $m->execute(['aid' => $applicationId]);
            foreach ($m->fetchAll() ?: [] as $row) {
                $marked[(int) $row['document_type_id']] = $row;
            }
        }

        $submittedCount = 0;
        $items = [];
        foreach ($required as $req) {
            $tid = (int) $req['id'];
            $uploaded = array_values(array_filter($docRows, function ($d) use ($tid) {
                return (int) $d['document_type_id'] === $tid;
            }));
            $isMarked = isset($marked[$tid]) && (int) $marked[$tid]['is_submitted'] === 1;
            $submitted = !empty($uploaded) || $isMarked;
            if ($submitted) { $submittedCount++; }
            $items[] = [
                'type_id'    => $tid,
                'code'       => $req['code'],
                'name'       => $req['name'],
                'submitted'  => $submitted,
                'source'     => !empty($uploaded) ? 'upload' : ($isMarked ? 'staff' : ''),
                'doc_id'     => !empty($uploaded) ? (int) $uploaded[0]['doc_id'] : 0,
                'doc_title'  => !empty($uploaded) ? $uploaded[0]['title'] : '',
                'doc_status' => !empty($uploaded) ? $uploaded[0]['status'] : '',
                'marked_at'  => $isMarked ? ($marked[$tid]['verified_at'] ?? '') : '',
            ];
        }

        echo json_encode([
            'success' => true,
            'enrollment' => [
                'id'   => (int) $enr['id'],
                'no'   => $enr['enrollment_no'],
                'course' => $enr['course_code'] . ' — ' . $enr['course_name'],
                'applicant' => trim($enr['first_name'] . ' ' . $enr['last_name']),
            ],
            'required' => $items,
            'counts'   => ['submitted' => $submittedCount, 'required' => count($required)],
        ]);
        exit;
    }

    /* ---------- POST: staff marks "received" ---------- */
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        csrf_check();
        $action = (string) ($_POST['action'] ?? '');

        if ($action === 'mark') {
            $enrollmentId = (int) ($_POST['enrollment_id'] ?? 0);
            $typeId       = (int) ($_POST['document_type_id'] ?? 0);
            $value        = ((string) ($_POST['value'] ?? '0')) === '1' ? 1 : 0;

            if (!$enrollmentId || !$typeId) {
                http_response_code(422);
                echo json_encode(['success' => false, 'message' => 'Enrollment and document type are required.']);
                exit;
            }

            $stmt = $pdo->prepare("SELECT applicant_id, enrollment_no FROM enrollment WHERE id = :id");
            $stmt->execute(['id' => $enrollmentId]);
            $enr = $stmt->fetch();
            if (!$enr) {
                http_response_code(404);
                echo json_encode(['success' => false, 'message' => 'Enrollment not found.']);
                exit;
            }

            $app = $pdo->prepare("SELECT id FROM application WHERE applicant_id = :ap ORDER BY id DESC LIMIT 1");
            $app->execute(['ap' => (int) $enr['applicant_id']]);
            $applicationId = (int) ($app->fetchColumn() ?: 0);
            if (!$applicationId) {
                $pdo->prepare("INSERT INTO application (application_no, applicant_id, status_id, created_at) VALUES (:no, :ap, 1, NOW())")
                    ->execute(['no' => 'APP-' . $enr['enrollment_no'], 'ap' => (int) $enr['applicant_id']]);
                $applicationId = (int) $pdo->lastInsertId();
            }

            $uid = (int) (current_user()['id'] ?? 0);
            $upd = $pdo->prepare(
                "INSERT INTO application_requirement (application_id, document_type_id, is_submitted, verified_at, verified_by, created_at)
                 VALUES (:aid, :t, :v, NOW(), :by, NOW())
                 ON DUPLICATE KEY UPDATE is_submitted = :v2, verified_at = NOW(), verified_by = :by2"
            );
            $upd->execute([
                'aid' => $applicationId, 't' => $typeId, 'v' => $value,
                'by' => $uid ?: null, 'v2' => $value, 'by2' => $uid ?: null,
            ]);

            audit_log('requirements', $value ? 'mark_received' : 'unmark_received', $enrollmentId,
                "Enrollment {$enr['enrollment_no']} — document type #{$typeId} " . ($value ? 'marked received' : 'unmarked'));

            echo json_encode(['success' => true, 'message' => $value ? 'Marked as received.' : 'Marked as not received.']);
            exit;
        }

        http_response_code(422);
        echo json_encode(['success' => false, 'message' => 'Unknown action.']);
        exit;
    }

    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed.']);
} catch (Throwable $e) {
    error_log('enrollment_requirements: ' . $e->getMessage());
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => 'Could not load/save requirements.']);
}
exit;
