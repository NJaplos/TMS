<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Admin: Delete batch (AJAX)
 * File : sections/admissions/admin/batch_delete.php
 * ---------------------------------------------------------
 * JSON endpoint used by the Training Batches page to delete a
 * batch without a full page reload. Blocked while the batch
 * has enrollments (same rule as the form POST version).
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/config/bootstrap.php';

require_edit('batches');

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'POST required.']);
    exit;
}

csrf_check();

$batchId = (int) ($_POST['batch_id'] ?? 0);

if (!$batchId) {
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => 'Batch id is required.']);
    exit;
}

try {
    $pdo = db();

    $stmt = $pdo->prepare('SELECT id, training_no FROM training WHERE id = :id');
    $stmt->execute(['id' => $batchId]);
    $batch = $stmt->fetch();

    if (!$batch) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'Batch not found.']);
        exit;
    }

    $stmt = $pdo->prepare('SELECT COUNT(*) FROM enrollment WHERE training_id = :id');
    $stmt->execute(['id' => $batchId]);
    $cnt = (int) $stmt->fetchColumn();

    if ($cnt > 0) {
        http_response_code(422);
        echo json_encode(['success' => false, 'message' => 'Cannot delete — this batch has ' . $cnt . ' enrollment(s). Deactivate it instead.']);
        exit;
    }

    $pdo->prepare('DELETE FROM training_schedule WHERE training_id = :id')->execute(['id' => $batchId]);
    $pdo->prepare('DELETE FROM training WHERE id = :id')->execute(['id' => $batchId]);

    echo json_encode(['success' => true, 'message' => "Batch {$batch['training_no']} deleted."]);
} catch (Throwable $e) {
    error_log('batch_delete: ' . $e->getMessage());
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => 'Could not delete the batch.']);
}
exit;
