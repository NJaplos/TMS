<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Admin: Enrollment Management
 * File : sections/admissions/admin/enrollment.php
 * ---------------------------------------------------------
 * Full enrollment workflow:
 *   - KPI summary (total / enrolled / pending / completed)
 *   - Create enrollment (applicant + course + training batch)
 *   - Update enrollment status
 *   - List with search + status filter
 * Uses sequence_generator for ENR numbers.
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/config/bootstrap.php';

require_access('enrollment');
if ($_SERVER['REQUEST_METHOD'] === 'POST') { require_edit('enrollment'); }

$pdo = db();

$flash = ['type' => null, 'message' => null];

/* ==========================================================
   P0 guards (money / record integrity)
========================================================== */

/** Capacity status of a training batch (active enrollments vs max).
 *  $excludeEnrollmentId lets an edit re-save without counting itself. */
function batch_capacity_status(PDO $pdo, int $trainingId, ?int $excludeEnrollmentId = null): array
{
    $stmt = $pdo->prepare('SELECT max_slots FROM training WHERE id = :id');
    $stmt->execute(['id' => $trainingId]);
    $max = (int) $stmt->fetchColumn();

    $sql = "SELECT COUNT(*) FROM enrollment
            WHERE training_id = :tid AND status NOT IN ('cancelled','no_show')";
    $params = ['tid' => $trainingId];
    if ($excludeEnrollmentId) {
        $sql .= ' AND id <> :eid';
        $params['eid'] = $excludeEnrollmentId;
    }
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $filled = (int) $stmt->fetchColumn();

    return ['max' => $max, 'filled' => $filled, 'full' => $filled >= $max];
}

/** True if the applicant already has an ACTIVE enrollment for the
 *  same course (prevents duplicate enrollment → double billing). */
function applicant_has_active_enrollment(PDO $pdo, int $applicantId, int $courseId, ?int $excludeId = null): bool
{
    $sql = "SELECT id FROM enrollment
            WHERE applicant_id = :ap AND course_id = :co
              AND status IN ('pending','enrolled')";
    $params = ['ap' => $applicantId, 'co' => $courseId];
    if ($excludeId) {
        $sql .= ' AND id <> :eid';
        $params['eid'] = $excludeId;
    }
    $sql .= ' LIMIT 1';
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return (bool) $stmt->fetch();
}

/* ==========================================================
   Walk-in support — applicant number + profile upsert
========================================================== */

/** Next APP number (mirrors ENR/PAY generators). Call inside a transaction. */
function generate_applicant_no(PDO $pdo): string
{
    $year = (int) date('Y');
    $sel = $pdo->prepare(
        "SELECT id, current_value, prefix, padding_length
         FROM sequence_generator WHERE sequence_code = 'APP' AND sequence_year = :y FOR UPDATE"
    );
    $sel->execute(['y' => $year]);
    $seq = $sel->fetch();
    if (!$seq) {
        $pdo->prepare(
            "INSERT INTO sequence_generator (sequence_code, sequence_year, current_value, prefix, padding_length)
             VALUES ('APP', :y, 0, 'APP', 6)"
        )->execute(['y' => $year]);
        $sel->execute(['y' => $year]);
        $seq = $sel->fetch();
    }
    $next = ((int) $seq['current_value']) + 1;
    $pdo->prepare("UPDATE sequence_generator SET current_value = :v WHERE id = :id")
        ->execute(['v' => $next, 'id' => $seq['id']]);
    return sprintf('%s-%d-%s', $seq['prefix'], $year, str_pad((string) $next, (int) $seq['padding_length'], '0', STR_PAD_LEFT));
}

/** Insert or update applicant_profile with the enrollment-form values.
 *  $profileFields may be empty — then no-op (or clear nothing). */
function upsert_applicant_profile(PDO $pdo, int $applicantId, array $p): void
{
    /* empty strings → null (date columns reject '') */
    foreach ($p as $k => $v) {
        if ($v === '') { $p[$k] = null; }
    }
    $present = array_filter($p, fn($v) => $v !== '' && $v !== null);
    if (!$present) {
        return;
    }
    $stmt = $pdo->prepare('SELECT applicant_id FROM applicant_profile WHERE applicant_id = :id LIMIT 1');
    $stmt->execute(['id' => $applicantId]);
    $exists = (bool) $stmt->fetch();

    if ($exists) {
        $pdo->prepare(
            "UPDATE applicant_profile SET
                place_of_birth = :pob, address_line1 = :a1, address_line2 = :a2,
                postal_code = :pc, country_id = :co,
                emergency_contact_name = :ecn, emergency_contact_no = :ecm, relationship_id = :rel,
                seafarer_id_no = :sid, rank_position = :rank, sirb_no = :sirb, cdc_no = :cdc,
                passport_no = :pass, passport_expiry = :passexp,
                medical_certificate_no = :med, medical_expiry = :medexp, updated_at = NOW()
             WHERE applicant_id = :id"
        )->execute([
            'pob' => $p['place_of_birth'] ?? null, 'a1' => $p['address_line1'] ?? null, 'a2' => $p['address_line2'] ?? null,
            'pc' => $p['postal_code'] ?? null, 'co' => $p['country_id'] ?: null,
            'ecn' => $p['emergency_contact_name'] ?? null, 'ecm' => $p['emergency_contact_no'] ?? null, 'rel' => $p['relationship_id'] ?: null,
            'sid' => $p['seafarer_id_no'] ?? null, 'rank' => $p['rank_position'] ?? null, 'sirb' => $p['sirb_no'] ?? null, 'cdc' => $p['cdc_no'] ?? null,
            'pass' => $p['passport_no'] ?? null, 'passexp' => $p['passport_expiry'] ?? null,
            'med' => $p['medical_certificate_no'] ?? null, 'medexp' => $p['medical_expiry'] ?? null, 'id' => $applicantId,
        ]);
    } else {
        $pdo->prepare(
            "INSERT INTO applicant_profile
                (applicant_id, place_of_birth, address_line1, address_line2, postal_code, country_id,
                 emergency_contact_name, emergency_contact_no, relationship_id,
                 seafarer_id_no, rank_position, sirb_no, cdc_no,
                 passport_no, passport_expiry, medical_certificate_no, medical_expiry)
             VALUES
                (:id, :pob, :a1, :a2, :pc, :co,
                 :ecn, :ecm, :rel,
                 :sid, :rank, :sirb, :cdc,
                 :pass, :passexp, :med, :medexp)"
        )->execute([
            'id' => $applicantId,
            'pob' => $p['place_of_birth'] ?? null, 'a1' => $p['address_line1'] ?? null, 'a2' => $p['address_line2'] ?? null,
            'pc' => $p['postal_code'] ?? null, 'co' => $p['country_id'] ?: null,
            'ecn' => $p['emergency_contact_name'] ?? null, 'ecm' => $p['emergency_contact_no'] ?? null, 'rel' => $p['relationship_id'] ?: null,
            'sid' => $p['seafarer_id_no'] ?? null, 'rank' => $p['rank_position'] ?? null, 'sirb' => $p['sirb_no'] ?? null, 'cdc' => $p['cdc_no'] ?? null,
            'pass' => $p['passport_no'] ?? null, 'passexp' => $p['passport_expiry'] ?? null,
            'med' => $p['medical_certificate_no'] ?? null, 'medexp' => $p['medical_expiry'] ?? null,
        ]);
    }
}

/* ==========================================================
   Handle POST
========================================================== */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = $_POST['action'] ?? '';

    try {
        /* ---- Create enrollment (existing applicant OR walk-in) ---- */
        if ($action === 'create') {
            $applicantMode = ($_POST['applicant_mode'] ?? 'existing') === 'walkin' ? 'walkin' : 'existing';
            $applicantId   = (int) ($_POST['applicant_id'] ?? 0);
            $courseId      = (int) ($_POST['course_id'] ?? 0);
            $trainingId    = (int) ($_POST['training_id'] ?? 0) ?: null;
            $enrollDate    = trim((string) ($_POST['enrollment_date'] ?? date('Y-m-d')));
            $status        = in_array($_POST['status'] ?? '', ['pending','enrolled','cancelled','completed','no_show'], true) ? $_POST['status'] : 'pending';

            /* Enrollment-form fields (also used to create/update the applicant) */
            $form = [
                'first_name'   => trim((string) ($_POST['wf_first_name'] ?? '')),
                'middle_name'  => trim((string) ($_POST['wf_middle_name'] ?? '')),
                'last_name'    => trim((string) ($_POST['wf_last_name'] ?? '')),
                'suffix'       => trim((string) ($_POST['wf_suffix'] ?? '')),
                'birth_date'   => trim((string) ($_POST['wf_birth_date'] ?? '')),
                'gender_id'    => (int) ($_POST['wf_gender_id'] ?? 0) ?: null,
                'civil_status_id' => (int) ($_POST['wf_civil_status_id'] ?? 0) ?: null,
                'nationality_id'  => (int) ($_POST['wf_nationality_id'] ?? 0) ?: null,
                'mobile_no'    => trim((string) ($_POST['wf_mobile_no'] ?? '')),
                'email'        => strtolower(trim((string) ($_POST['wf_email'] ?? ''))),
            ];
            /* Endorsement & billing */
            $endorsedBy = trim((string) ($_POST['enr_endorsed_by'] ?? ''));
            $chargeTo   = (($_POST['enr_charge_to'] ?? '') === 'company') ? 'company' : 'trainee';
            $remarks    = trim((string) ($_POST['enr_remarks'] ?? ''));
            $endorserType = (($_POST['enr_endorser_type'] ?? '') === 'company') ? 'company' : 'marketing';
            /* company-endorsed ⇒ charge to company */
            if ($endorserType === 'company') { $chargeTo = 'company'; }
            $companyId  = $chargeTo === 'company' ? ((int) ($_POST['enr_company_id'] ?? 0) ?: null) : null;

            $profile = [
                'place_of_birth'   => trim((string) ($_POST['wf_place_of_birth'] ?? '')),
                'address_line1'    => trim((string) ($_POST['wf_address_line1'] ?? '')),
                'address_line2'    => trim((string) ($_POST['wf_address_line2'] ?? '')),
                'postal_code'      => trim((string) ($_POST['wf_postal_code'] ?? '')),
                'country_id'       => (int) ($_POST['wf_country_id'] ?? 0) ?: null,
                'emergency_contact_name' => trim((string) ($_POST['wf_emergency_contact_name'] ?? '')),
                'emergency_contact_no'   => trim((string) ($_POST['wf_emergency_contact_no'] ?? '')),
                'relationship_id'  => (int) ($_POST['wf_relationship_id'] ?? 0) ?: null,
                'seafarer_id_no'   => trim((string) ($_POST['wf_seafarer_id_no'] ?? '')),
                'rank_position'    => (($rk = (int) ($_POST['wf_rank_id'] ?? 0)) > 0)
                        ? ((string) ($pdo->query("SELECT name FROM mnt_rank_position WHERE id = $rk")->fetchColumn() ?: ''))
                        : trim((string) ($_POST['wf_rank_position'] ?? '')),
                'sirb_no'          => trim((string) ($_POST['wf_sirb_no'] ?? '')),
                'cdc_no'           => trim((string) ($_POST['wf_cdc_no'] ?? '')),
                'passport_no'      => trim((string) ($_POST['wf_passport_no'] ?? '')),
                'passport_expiry'  => trim((string) ($_POST['wf_passport_expiry'] ?? '')),
                'medical_certificate_no' => trim((string) ($_POST['wf_medical_certificate_no'] ?? '')),
                'medical_expiry'   => trim((string) ($_POST['wf_medical_expiry'] ?? '')),
            ];

            /* Marketing-endorsed with status=enrolled ⇒ auto-save as Pending so
               staff can record the payment first, then mark Enrolled (the status
               action enforces the payment gate). Honored only while the process
               rule 'marketing requires payment' is ON — the property can switch
               it off in Settings → Process Rules. */
            if ($endorserType === 'marketing' && $status === 'enrolled'
                && process_rule('rule_enroll_marketing_require_paid', true)) {
                $status = 'pending';
                $statusForcedPending = true;
            }

            /* Requirements gate (V5.37): when the optional 'require documents'
               rule is ON and docs are incomplete, a create that asks for
               status=enrolled is saved as Pending (with a hint) instead. */
            if ($status === 'enrolled' && process_rule('rule_enroll_require_docs', false)) {
                $applicantIdForDocs = (int) $applicantId;
                if ($applicantMode === 'walkin' && $applicantIdForDocs <= 0) {
                    /* a brand-new walk-in has no documents yet — keep pending */
                    $status = 'pending';
                    $statusForcedPending = true;
                    $docsForcedHint = true;
                } elseif ($applicantIdForDocs > 0) {
                    $ds = applicant_docs_status($pdo, $applicantIdForDocs);
                    if ($ds['required'] > 0 && $ds['submitted'] < $ds['required']) {
                        $status = 'pending';
                        $statusForcedPending = true;
                        $docsForcedHint = true;
                    }
                }
            }

            /* ---- Basic validations ---- */
            if (!$courseId) {
                $flash = ['type' => 'error', 'message' => 'Select a course.'];
            } elseif (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $enrollDate)) {
                $flash = ['type' => 'error', 'message' => 'Enrollment date is not valid.'];
            } elseif ($applicantMode === 'walkin' && ($form['first_name'] === '' || $form['last_name'] === '')) {
                $flash = ['type' => 'error', 'message' => 'Walk-in applicant needs at least a first and last name.'];
            } elseif ($applicantMode === 'walkin' && $form['email'] === '') {
                /* email is mandatory for walk-ins — needed for the Trainee account */
                $flash = ['type' => 'error', 'message' => 'Email is required for walk-in enrollment (it becomes the Trainee Portal login).'];
            } elseif ($applicantMode === 'walkin' && !filter_var($form['email'], FILTER_VALIDATE_EMAIL)) {
                $flash = ['type' => 'error', 'message' => 'Enter a valid email address for the walk-in applicant.'];
            } elseif ($applicantMode === 'existing' && !$applicantId) {
                $flash = ['type' => 'error', 'message' => 'Select an applicant.'];
            } else {

                /* Defaults so the success flash never touches undefined vars —
                   these are only populated for walk-ins (V5.39). */
                $accountPassword = '';
                $loginUsername   = '';

                /* ---- Resolve applicant (walk-in → create) ---- */
                if ($applicantMode === 'walkin') {
                    /* email duplicate check (if provided) */
                    if ($form['email'] !== '') {
                        $dup = $pdo->prepare("SELECT id FROM applicant WHERE LOWER(TRIM(email)) = :em LIMIT 1");
                        $dup->execute(['em' => $form['email']]);
                        if ($dup->fetch()) {
                            $flash = ['type' => 'error', 'message' => 'An applicant already exists with that email — use Existing Applicant instead.'];
                            goto create_skip;
                        }
                    }
                    $pdo->beginTransaction();
                    $appNo = generate_applicant_no($pdo);
                    $pdo->prepare(
                        "INSERT INTO applicant (applicant_no, first_name, middle_name, last_name, suffix,
                                birth_date, gender_id, civil_status_id, nationality_id, mobile_no, email, status_id, created_at)
                         VALUES (:no, :fn, :mn, :ln, :sx, :bd, :g, :cs, :nat, :mob, :em, 1, NOW())"
                    )->execute([
                        'no' => $appNo, 'fn' => $form['first_name'], 'mn' => $form['middle_name'] !== '' ? $form['middle_name'] : null,
                        'ln' => $form['last_name'], 'sx' => $form['suffix'] !== '' ? $form['suffix'] : null,
                        'bd' => $form['birth_date'] !== '' ? $form['birth_date'] : null,
                        'g' => $form['gender_id'], 'cs' => $form['civil_status_id'], 'nat' => $form['nationality_id'],
                        'mob' => $form['mobile_no'] !== '' ? $form['mobile_no'] : null,
                        'em' => $form['email'] !== '' ? $form['email'] : null,
                    ]);
                    $applicantId = (int) $pdo->lastInsertId();
                    upsert_applicant_profile($pdo, $applicantId, $profile);

                    /* Create a Trainee Portal account for the walk-in so they
                       can log in (username = email, or applicant_no when no
                       email is provided). */
                    $accountPassword = '';
                    $loginUsername = $form['email'] !== '' ? $form['email'] : $appNo;
                    $accountEmail  = $form['email'] !== '' ? $form['email'] : ($appNo . '@usmci.local');
                    $hasAcct = $pdo->prepare('SELECT id FROM applicant_account WHERE applicant_id = :id LIMIT 1');
                    $hasAcct->execute(['id' => $applicantId]);
                    if (!$hasAcct->fetch()) {
                        $statusActive = (int) $pdo->query("SELECT id FROM mnt_account_status WHERE code = 'ACTIVE' LIMIT 1")->fetchColumn() ?: 1;
                        $pw = trim((string) ($_POST['wf_password'] ?? ''));
                        if (strlen($pw) < 8) {
                            $pw = 'Walk-' . strtoupper(bin2hex(random_bytes(4)));
                        }
                        /* ALWAYS remember the actual password so it can be emailed
                           to the walk-in — whether typed or auto-generated. */
                        $accountPassword = $pw;
                        $pdo->prepare(
                            "INSERT INTO applicant_account (applicant_id, username, email, password_hash, email_verified_at, status_id, created_at)
                             VALUES (:ap, :un, :em, :h, NOW(), :st, NOW())"
                        )->execute([
                            'ap' => $applicantId, 'un' => $loginUsername, 'em' => $accountEmail,
                            'h' => password_hash($pw, PASSWORD_DEFAULT), 'st' => $statusActive,
                        ]);
                    }
                } else {
                    $pdo->beginTransaction();
                    /* keep the applicant's basic info in sync with the form */
                    $pdo->prepare(
                        "UPDATE applicant SET
                            first_name = :fn, middle_name = :mn, last_name = :ln, suffix = :sx,
                            birth_date = :bd, gender_id = :g, civil_status_id = :cs, nationality_id = :nat,
                            mobile_no = :mob, email = :em, updated_at = NOW()
                         WHERE id = :id"
                    )->execute([
                        'fn' => $form['first_name'] !== '' ? $form['first_name'] : $pdo->query("SELECT first_name FROM applicant WHERE id = $applicantId")->fetchColumn(),
                        'mn' => $form['middle_name'] !== '' ? $form['middle_name'] : null,
                        'ln' => $form['last_name'] !== '' ? $form['last_name'] : $pdo->query("SELECT last_name FROM applicant WHERE id = $applicantId")->fetchColumn(),
                        'sx' => $form['suffix'] !== '' ? $form['suffix'] : null,
                        'bd' => $form['birth_date'] !== '' ? $form['birth_date'] : null,
                        'g' => $form['gender_id'], 'cs' => $form['civil_status_id'], 'nat' => $form['nationality_id'],
                        'mob' => $form['mobile_no'] !== '' ? $form['mobile_no'] : null,
                        'em' => $form['email'] !== '' ? $form['email'] : null,
                        'id' => $applicantId,
                    ]);
                    upsert_applicant_profile($pdo, $applicantId, $profile);
                }

                /* Resolve the definitive applicant email (for email notifications) */
                $emailStmt = $pdo->prepare('SELECT email FROM applicant WHERE id = :id');
                $emailStmt->execute(['id' => $applicantId]);
                $resolvedEmail = (string) ($emailStmt->fetchColumn() ?: '');

                /* PHOTO required: upload it (if provided) or use the profile photo.
                   Blocks the enrollment when the applicant has no photo at all. */
                $photoSaved = false;
                if (!empty($_FILES['wf_photo']) && $_FILES['wf_photo']['error'] === UPLOAD_ERR_OK) {
                    $f = $_FILES['wf_photo'];
                    $ext = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
                    if (in_array($ext, ['jpg', 'jpeg', 'png'], true) && $f['size'] <= 4 * 1024 * 1024) {
                        $dir = BASE_PATH . '/uploads/trainee-photos';
                        if (!is_dir($dir)) { @mkdir($dir, 0775, true); }
                        $pname = 'trainee-' . $applicantId . '-' . time() . '.' . $ext;
                        if (move_uploaded_file($f['tmp_name'], $dir . '/' . $pname)) {
                            $profChk = $pdo->prepare('SELECT applicant_id FROM applicant_profile WHERE applicant_id = :id LIMIT 1');
                            $profChk->execute(['id' => $applicantId]);
                            if (!$profChk->fetch()) {
                                $pdo->prepare("INSERT INTO applicant_profile (applicant_id, photo_path, created_at) VALUES (:id, :p, NOW())")
                                    ->execute(['id' => $applicantId, 'p' => 'uploads/trainee-photos/' . $pname]);
                            } else {
                                $pdo->prepare("UPDATE applicant_profile SET photo_path = :p, updated_at = NOW() WHERE applicant_id = :id")
                                    ->execute(['p' => 'uploads/trainee-photos/' . $pname, 'id' => $applicantId]);
                            }
                            $photoSaved = true;
                        }
                    }
                }
                if (!$photoSaved) {
                    $profPhoto = $pdo->prepare('SELECT photo_path FROM applicant_profile WHERE applicant_id = :id');
                    $profPhoto->execute(['id' => $applicantId]);
                    $photoSaved = (bool) $profPhoto->fetchColumn();
                }
                if (!$photoSaved) {
                    $pdo->rollBack();
                    $flash = ['type' => 'error', 'message' => 'A photo is required for enrollment — upload one, or pick an existing applicant who has a photo.'];
                    goto create_skip;
                }

                /* P0: capacity + duplicate guards */
                if ($trainingId && ($cap = batch_capacity_status($pdo, $trainingId)) && $cap['full']) {
                    $pdo->rollBack();
                    $flash = ['type' => 'error', 'message' => "Batch is full ({$cap['filled']}/{$cap['max']}) — no slots left."];
                } elseif (applicant_has_active_enrollment($pdo, $applicantId, $courseId)) {
                    $pdo->rollBack();
                    $flash = ['type' => 'error', 'message' => 'This applicant already has an active enrollment for this course. Cancel or complete the existing one first.'];
                } else {

                    /* Ensure the applicant has an application (enrollment.application_id is required) */
                    $appStmt = $pdo->prepare(
                        "SELECT id FROM application WHERE applicant_id = :aid ORDER BY id DESC LIMIT 1"
                    );
                    $appStmt->execute(['aid' => $applicantId]);
                    $applicationId = (int) $appStmt->fetchColumn();

                    if (!$applicationId) {
                        $pdo->prepare(
                            "INSERT INTO application (application_no, applicant_id, status_id, submitted_at, created_at)
                             VALUES (:no, :aid, 2, NOW(), NOW())"
                        )->execute([
                            'no' => 'APP-' . date('Y') . '-' . str_pad((string) random_int(1, 999999), 6, '0', STR_PAD_LEFT),
                            'aid' => $applicantId,
                        ]);
                        $applicationId = (int) $pdo->lastInsertId();
                    }

                    /* Next ENR number from sequence_generator */
                    $enrNo = generate_enrollment_no($pdo);

                    $pdo->prepare(
                        "INSERT INTO enrollment (enrollment_no, application_id, applicant_id, course_id, training_id,
                                endorsed_by, endorser_type, charge_to, company_id, remarks, enrollment_date, status, created_at)
                         VALUES (:no, :app, :aid, :cid, :tid, :eby, :ety, :cto, :co, :rm, :date, :status, NOW())"
                    )->execute([
                        'no' => $enrNo, 'app' => $applicationId, 'aid' => $applicantId,
                        'cid' => $courseId, 'tid' => $trainingId,
                        'eby' => $endorsedBy !== '' ? $endorsedBy : null,
                        'ety' => $endorserType, 'cto' => $chargeTo, 'co' => $companyId,
                        'rm' => $remarks !== '' ? $remarks : null,
                        'date' => $enrollDate, 'status' => $status,
                    ]);

                    $enrollmentId = (int) $pdo->lastInsertId();

                    /* Log history */
                    $pdo->prepare(
                        "INSERT INTO enrollment_history (enrollment_id, changed_by, old_status, new_status, created_at)
                         VALUES (:eid, :uid, NULL, :status, NOW())"
                    )->execute(['eid' => $enrollmentId, 'uid' => (int) current_user()['id'], 'status' => $status]);

                    /* Auto-create the payment obligation when enrolled, or
                       immediately for MARKETING-endorsed (they must pay before
                       being marked Enrolled). V5.34: company-endorsed ALSO get
                       a payment record so they appear in Payments — recording
                       a payment then auto-updates the enrollment status. */
                    $autoPayNo = null;
                    if ($status === 'enrolled' || $endorserType === 'marketing' || $endorserType === 'company') {
                        $autoPayNo = create_payment_for_enrollment($pdo, $enrollmentId);
                    }

                    $pdo->commit();
                    audit_log('enrollments', 'create', $enrollmentId, "Enrollment {$enrNo} created for " . trim($form['first_name'] . ' ' . $form['last_name']) . " (course id {$courseId}, status: {$status}, endorser: {$endorserType})");

                    /* ---- Emails (queued → attempt immediate delivery like the
                       inquiry queue; stays PENDING if SMTP isn't configured yet) ---- */

                    /* 1) Walk-in: temp credentials — ALWAYS email them (typed or
                       auto-generated), so the trainee can log in. */
                    $emailSent = 0;
                    if ($applicantMode === 'walkin' && $resolvedEmail !== '' && $accountPassword !== '') {
                        $qid = queue_email(
                            $resolvedEmail !== '' ? $resolvedEmail : $form['email'],
                            'Your USMCI Trainee Portal Account',
                            email_shell('Trainee Portal Account', '<p>Dear <strong>' . htmlspecialchars(trim($form['first_name'] . ' ' . $form['last_name'])) . '</strong>,</p>'
                                . '<p>Your enrollment as a <strong>walk-in</strong> trainee is complete. Here are your Trainee Portal credentials:</p>'
                                . '<p style="background:#F8FAFC;border:1px dashed #0D8A72;border-radius:8px;padding:12px 16px;">'
                                . '<strong>Username:</strong> ' . htmlspecialchars($loginUsername) . '<br>'
                                . '<strong>Temporary password:</strong> ' . htmlspecialchars($accountPassword) . '</p>'
                                . '<p>Please log in at <a href="' . htmlspecialchars(WEBSITE_BASE_URL . '/login.php') . '">the Trainee Portal</a> and change your password.</p>')
                        );
                        if ($qid) { mailer_send_now($qid); $emailSent = $qid; }
                    }

                    /* 2) Enrolled: confirmation with schedule, location, payments */
                    if ($status === 'enrolled') {
                        /* V5.45: notify the trainee when created directly as Enrolled
                           (the status-action path already notifies) */
                        $notifType = $pdo->query("SELECT id FROM mnt_notification_type WHERE code = 'ENROLLMENT' LIMIT 1")->fetchColumn();
                        notify_applicant($pdo, (int) $applicantId,
                            'Enrollment Confirmed — ' . $enrollmentId,
                            'You are now enrolled in ' . htmlspecialchars_decode((string) ($enr['course_name'] ?? '')) . '. Check your registration page for the schedule.',
                            $notifType ? (int) $notifType : null);

                        $batchInfo = null;
                        if ($trainingId) {
                            $bq = $pdo->prepare("SELECT training_no, batch_name, start_date, end_date, venue FROM training WHERE id = :id");
                            $bq->execute(['id' => $trainingId]);
                            $batchInfo = $bq->fetch();
                        }
                        $payInfo = $pdo->prepare("SELECT payment_no, total_amount, due_date FROM payment WHERE enrollment_id = :id LIMIT 1");
                        $payInfo->execute(['id' => $enrollmentId]);
                        $payRow = $payInfo->fetch();
                        $courseName = $enr['course_name'] ?? '';

                        $enrMailId = queue_email(
                            $resolvedEmail !== '' ? $resolvedEmail : $form['email'],
                            'Enrollment Confirmation — ' . $enrNo,
                            email_shell('Enrollment Confirmed', '<p>Dear <strong>' . htmlspecialchars(trim($form['first_name'] . ' ' . $form['last_name'])) . '</strong>,</p>'
                                . '<p>You are now <strong>enrolled</strong> in <strong>' . htmlspecialchars($courseName) . '</strong>.</p>'
                                . '<table style="border-collapse:collapse;width:100%;font-size:13px;">'
                                . '<tr><td style="padding:6px 10px;border:1px solid #E2E8F0;"><strong>Registration No.</strong></td><td style="padding:6px 10px;border:1px solid #E2E8F0;">' . htmlspecialchars($enrNo) . '</td></tr>'
                                . ($batchInfo ? '<tr><td style="padding:6px 10px;border:1px solid #E2E8F0;"><strong>Batch</strong></td><td style="padding:6px 10px;border:1px solid #E2E8F0;">' . htmlspecialchars($batchInfo['training_no'] . ' · ' . $batchInfo['batch_name']) . '</td></tr>'
                                    . '<tr><td style="padding:6px 10px;border:1px solid #E2E8F0;"><strong>Schedule</strong></td><td style="padding:6px 10px;border:1px solid #E2E8F0;">' . htmlspecialchars(date('M d, Y', strtotime($batchInfo['start_date'])) . ' → ' . date('M d, Y', strtotime($batchInfo['end_date']))) . '</td></tr>'
                                    . '<tr><td style="padding:6px 10px;border:1px solid #E2E8F0;"><strong>Location</strong></td><td style="padding:6px 10px;border:1px solid #E2E8F0;">' . htmlspecialchars($batchInfo['venue'] ?: 'USMCI Training Center') . '</td></tr>' : '')
                                . ($payRow ? '<tr><td style="padding:6px 10px;border:1px solid #E2E8F0;"><strong>Course Fee</strong></td><td style="padding:6px 10px;border:1px solid #E2E8F0;">₱ ' . number_format((float) $payRow['total_amount'], 2) . ' (Payment ' . htmlspecialchars($payRow['payment_no']) . ')</td></tr>'
                                    . ($payRow['due_date'] ? '<tr><td style="padding:6px 10px;border:1px solid #E2E8F0;"><strong>Due Date</strong></td><td style="padding:6px 10px;border:1px solid #E2E8F0;">' . htmlspecialchars($payRow['due_date']) . '</td></tr>' : '') : '')
                                . '</table>'
                                . '<p>Kindly come on time. Training is forfeited if you miss the schedule; a 15-minute grace period is allowed.</p>')
                        );
                        if ($enrMailId) { mailer_send_now($enrMailId); $emailSent = $enrMailId; }
                    }

                    $who = $applicantMode === 'walkin'
                        ? trim($form['first_name'] . ' ' . $form['last_name']) . ' (walk-in)'
                        : 'applicant #' . $applicantId;
                    $flash = ['type' => 'success', 'message' => "Enrollment {$enrNo} created for {$who} (status: {$status})."
                        . (isset($statusForcedPending) && isset($docsForcedHint) ? " Requirements incomplete — saved as Pending until all documents are submitted (rule ON)." : (isset($statusForcedPending) ? " Marketing-endorsed was saved as Pending — record the payment, then mark Enrolled." : ''))
                        . ($autoPayNo ? " Payment {$autoPayNo} auto-created." : '')
                        . ($endorserType === 'company' ? ' Company-endorsed — payment record created (optional, listed in Payments).' : '')
                        . (!empty($accountPassword) ? " Trainee portal: username {$loginUsername} — temporary password: {$accountPassword} (emailed to the trainee)." : '')
                        . ($emailSent ? ' Confirmation email queued.' : '')];
                }
            }
            create_skip:
        }

        /* ---- Update status ---- */
        elseif ($action === 'status') {
            $id     = (int) ($_POST['enrollment_id'] ?? 0);
            $status = in_array($_POST['status'] ?? '', ['pending','enrolled','cancelled','completed','no_show'], true) ? $_POST['status'] : '';

            if ($id && $status !== '') {
                /* Payment gate (V5.33: configurable per endorser type):
                   Marketing  → paid before Enrolled when rule ON (default)
                   Company    → paid before Enrolled when rule ON (default OFF) */
                if ($status === 'enrolled') {
                    $ety = $pdo->prepare('SELECT endorser_type, applicant_id FROM enrollment WHERE id = :id');
                    $ety->execute(['id' => $id]);
                    $eRow = $ety->fetch();
                    $endType = (string) ($eRow['endorser_type'] ?? 'marketing');
                    $applicantId = (int) ($eRow['applicant_id'] ?? 0);

                    $requirePaid = process_rule(
                        $endType === 'company' ? 'rule_enroll_company_require_paid' : 'rule_enroll_marketing_require_paid',
                        $endType !== 'company'
                    );

                    if ($requirePaid) {
                        $paid = $pdo->prepare("SELECT COALESCE(SUM(paid_amount),0) AS paid, COALESCE(SUM(total_amount),0) AS total FROM payment WHERE enrollment_id = :id AND payment_status_id NOT IN (4,5)");
                        $paid->execute(['id' => $id]);
                        $payRow2 = $paid->fetch();
                        if ((float) ($payRow2['paid'] ?? 0) <= 0) {
                            $typeLabel = $endType === 'company' ? 'Company-endorsed' : 'Marketing-endorsed';
                            $flash = ['type' => 'error', 'message' => $typeLabel . ' enrollment requires payment first — record a payment (₱ ' . number_format((float)($payRow2['total'] ?? 0), 2) . '), then mark Enrolled.'];
                            goto status_skip;
                        }
                    }

                    /* Requirements gate (V5.37): when the "require documents"
                       rule is ON, all required docs must be submitted. */
                    if (process_rule('rule_enroll_require_docs', false) && $applicantId > 0) {
                        $ds = applicant_docs_status($pdo, $applicantId);
                        if ($ds['required'] > 0 && $ds['submitted'] < $ds['required']) {
                            $flash = ['type' => 'error', 'message' => "Requirements not complete ({$ds['submitted']}/{$ds['required']} documents submitted) — the 'require documents' rule is ON. Upload the remaining documents first."];
                            goto status_skip;
                        }
                    }
                }

                $pdo->beginTransaction();

                $stmt = $pdo->prepare("SELECT status FROM enrollment WHERE id = :id");
                $stmt->execute(['id' => $id]);
                $old = $stmt->fetchColumn();

                $pdo->prepare("UPDATE enrollment SET status = :status, updated_at = NOW() WHERE id = :id")
                    ->execute(['status' => $status, 'id' => $id]);

                $pdo->prepare(
                    "INSERT INTO enrollment_history (enrollment_id, changed_by, old_status, new_status, created_at)
                     VALUES (:eid, :uid, :from, :to, NOW())"
                )->execute(['eid' => $id, 'uid' => (int) current_user()['id'], 'from' => $old, 'to' => $status]);

                /* Auto-create the payment obligation when it becomes enrolled
                   (V5.34: company-endorsed included — they now appear in
                   Payments too) */
                $autoPayNo = null;
                if ($status === 'enrolled') {
                    $autoPayNo = create_payment_for_enrollment($pdo, $id);
                }

                $pdo->commit();
                audit_log('enrollments', 'status', $id, "Enrollment #{$id} status {$old} → {$status}" . ($autoPayNo ? " (payment {$autoPayNo} auto-created)" : ''));

                /* Enrolled → send the confirmation email (immediate attempt) */
                $enrMailId = 0;
                if ($status === 'enrolled') {
                    $info = $pdo->prepare(
                        "SELECT e.enrollment_no, a.first_name, a.last_name, a.email,
                                c.course_name,
                                t.training_no, t.batch_name, t.start_date, t.end_date, t.venue
                         FROM enrollment e
                         JOIN applicant a ON a.id = e.applicant_id
                         JOIN mnt_course c ON c.id = e.course_id
                         LEFT JOIN training t ON t.id = e.training_id
                         WHERE e.id = :id LIMIT 1"
                    );
                    $info->execute(['id' => $id]);
                    $ei = $info->fetch();
                    $payInfo = $pdo->prepare("SELECT payment_no, total_amount, due_date FROM payment WHERE enrollment_id = :id LIMIT 1");
                    $payInfo->execute(['id' => $id]);
                    $pr = $payInfo->fetch();
                    if ($ei && !empty($ei['email'])) {
                        $enrMailId = queue_email(
                            $ei['email'],
                            'Enrollment Confirmation — ' . $ei['enrollment_no'],
                            email_shell('Enrollment Confirmed', '<p>Dear <strong>' . htmlspecialchars(trim($ei['first_name'] . ' ' . $ei['last_name'])) . '</strong>,</p>'
                                . '<p>You are now <strong>enrolled</strong> in <strong>' . htmlspecialchars($ei['course_name']) . '</strong>.</p>'
                                . '<table style="border-collapse:collapse;width:100%;font-size:13px;">'
                                . '<tr><td style="padding:6px 10px;border:1px solid #E2E8F0;"><strong>Registration No.</strong></td><td style="padding:6px 10px;border:1px solid #E2E8F0;">' . htmlspecialchars($ei['enrollment_no']) . '</td></tr>'
                                . ($ei['training_no'] ? '<tr><td style="padding:6px 10px;border:1px solid #E2E8F0;"><strong>Batch</strong></td><td style="padding:6px 10px;border:1px solid #E2E8F0;">' . htmlspecialchars($ei['training_no'] . ' · ' . $ei['batch_name']) . '</td></tr>'
                                    . '<tr><td style="padding:6px 10px;border:1px solid #E2E8F0;"><strong>Schedule</strong></td><td style="padding:6px 10px;border:1px solid #E2E8F0;">' . htmlspecialchars(date('M d, Y', strtotime($ei['start_date'])) . ' → ' . date('M d, Y', strtotime($ei['end_date']))) . '</td></tr>'
                                    . '<tr><td style="padding:6px 10px;border:1px solid #E2E8F0;"><strong>Location</strong></td><td style="padding:6px 10px;border:1px solid #E2E8F0;">' . htmlspecialchars($ei['venue'] ?: 'USMCI Training Center') . '</td></tr>' : '')
                                . ($pr ? '<tr><td style="padding:6px 10px;border:1px solid #E2E8F0;"><strong>Course Fee</strong></td><td style="padding:6px 10px;border:1px solid #E2E8F0;">₱ ' . number_format((float) $pr['total_amount'], 2) . ' (Payment ' . htmlspecialchars($pr['payment_no']) . ')</td></tr>'
                                    . ($pr['due_date'] ? '<tr><td style="padding:6px 10px;border:1px solid #E2E8F0;"><strong>Due Date</strong></td><td style="padding:6px 10px;border:1px solid #E2E8F0;">' . htmlspecialchars($pr['due_date']) . '</td></tr>' : '') : '')
                                . '</table>'
                                . '<p>Kindly come on time. Training is forfeited if you miss the schedule; a 15-minute grace period is allowed.</p>')
                        );
                        if ($enrMailId) { mailer_send_now($enrMailId); }
                    }
                }

                /* V5.41: notify the trainee on status change (esp. enrolled) */
                if ($status === 'enrolled') {
                    $nInfo = $pdo->prepare("SELECT e.applicant_id, c.course_name FROM enrollment e JOIN mnt_course c ON c.id = e.course_id WHERE e.id = :id");
                    $nInfo->execute(['id' => $id]);
                    $nRow = $nInfo->fetch();
                    if ($nRow && (int) $nRow['applicant_id'] > 0) {
                        $nt = $pdo->query("SELECT id FROM mnt_notification_type WHERE code = 'ENROLLMENT' LIMIT 1")->fetchColumn();
                        notify_applicant($pdo, (int) $nRow['applicant_id'],
                            'Enrollment Confirmed — ' . $id,
                            'You are now enrolled in ' . htmlspecialchars_decode((string) ($nRow['course_name'] ?? '')) . '. Check your registration page for the schedule.',
                            $nt ? (int) $nt : null);
                    }
                }

                $flash = ['type' => 'success', 'message' => "Enrollment #{$id} status updated to {$status}."
                    . ($autoPayNo ? " Payment {$autoPayNo} auto-created." : '')
                    . ($enrMailId ? ' Confirmation email queued.' : '')];
            } else {
                $flash = ['type' => 'error', 'message' => 'Invalid status update.'];
            }
            status_skip:
        }

        /* ---- Update enrollment (incl. training batch) ---- */
        elseif ($action === 'update') {
            $id         = (int) ($_POST['enrollment_id'] ?? 0);
            $courseId   = (int) ($_POST['course_id'] ?? 0);
            $trainingId = (int) ($_POST['training_id'] ?? 0) ?: null;
            $enrollDate = trim((string) ($_POST['enrollment_date'] ?? ''));
            $status     = in_array($_POST['status'] ?? '', ['pending','enrolled','cancelled','completed','no_show'], true) ? $_POST['status'] : 'pending';

            if (!$id || !$courseId) {
                $flash = ['type' => 'error', 'message' => 'Select a course.'];
            } elseif (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $enrollDate)) {
                $flash = ['type' => 'error', 'message' => 'Enrollment date is not valid.'];
            } else {
                /* the applicant never changes on edit — fetch it from the record */
                $stmt = $pdo->prepare('SELECT applicant_id, training_id FROM enrollment WHERE id = :id');
                $stmt->execute(['id' => $id]);
                $cur = $stmt->fetch();
                $applicantId = (int) ($cur['applicant_id'] ?? 0);

                if ($trainingId && ($cap = batch_capacity_status($pdo, $trainingId, $id)) && $cap['full']) {
                    /* P0: never move into a full batch (exclude this enrollment itself) */
                    $flash = ['type' => 'error', 'message' => "Target batch is full ({$cap['filled']}/{$cap['max']}) — no slots left."];
                } elseif ($applicantId && applicant_has_active_enrollment($pdo, $applicantId, $courseId, $id)) {
                    /* P0: one active enrollment per applicant+course */
                    $flash = ['type' => 'error', 'message' => 'This applicant already has an active enrollment for this course. Cancel or complete the existing one first.'];
                } else {
                $pdo->beginTransaction();

                $stmt = $pdo->prepare("SELECT status FROM enrollment WHERE id = :id");
                $stmt->execute(['id' => $id]);
                $oldStatus = $stmt->fetchColumn();

                $endorsedBy = trim((string) ($_POST['enr_endorsed_by'] ?? ''));
                $chargeTo   = (($_POST['enr_charge_to'] ?? '') === 'company') ? 'company' : 'trainee';
                $remarks    = trim((string) ($_POST['enr_remarks'] ?? ''));
                $endorserType = (($_POST['enr_endorser_type'] ?? '') === 'company') ? 'company' : 'marketing';
                if ($endorserType === 'company') { $chargeTo = 'company'; }
                $companyId  = $chargeTo === 'company' ? ((int) ($_POST['enr_company_id'] ?? 0) ?: null) : null;

                if ($status === 'enrolled'
                    && process_rule(
                        $endorserType === 'company' ? 'rule_enroll_company_require_paid' : 'rule_enroll_marketing_require_paid',
                        $endorserType !== 'company'
                    )) {
                    /* per-type rule: payment required — check for a paid payment */
                    $paidQ = $pdo->prepare("SELECT COALESCE(SUM(paid_amount),0) AS paid, COALESCE(SUM(total_amount),0) AS total FROM payment WHERE enrollment_id = :id AND payment_status_id NOT IN (4,5)");
                    $paidQ->execute(['id' => $id]);
                    $payRow3 = $paidQ->fetch();
                    if ((float) ($payRow3['paid'] ?? 0) <= 0) {
                        $typeLabel = $endorserType === 'company' ? 'Company-endorsed' : 'Marketing-endorsed';
                        $flash = ['type' => 'error', 'message' => $typeLabel . ' enrollment requires payment first — record a payment (₱ ' . number_format((float)($payRow3['total'] ?? 0), 2) . '), then mark Enrolled.'];
                        goto update_skip;
                    }
                }

                /* Requirements gate (V5.37): optional rule — docs must be complete */
                if ($status === 'enrolled' && process_rule('rule_enroll_require_docs', false) && $applicantId > 0) {
                    $ds = applicant_docs_status($pdo, $applicantId);
                    if ($ds['required'] > 0 && $ds['submitted'] < $ds['required']) {
                        $flash = ['type' => 'error', 'message' => "Requirements not complete ({$ds['submitted']}/{$ds['required']} documents submitted) — the 'require documents' rule is ON. Upload the remaining documents first."];
                        goto update_skip;
                    }
                }

                $pdo->prepare(
                    "UPDATE enrollment
                     SET course_id = :cid, training_id = :tid, enrollment_date = :date, status = :status,
                         endorsed_by = :eby, endorser_type = :ety, charge_to = :cto, company_id = :co,
                         remarks = :rm, updated_at = NOW()
                     WHERE id = :id"
                )->execute([
                    'cid' => $courseId, 'tid' => $trainingId, 'date' => $enrollDate, 'status' => $status,
                    'eby' => $endorsedBy !== '' ? $endorsedBy : null, 'ety' => $endorserType,
                    'cto' => $chargeTo, 'co' => $companyId, 'rm' => $remarks !== '' ? $remarks : null,
                    'id' => $id,
                ]);

                if ($oldStatus !== $status) {
                    $pdo->prepare(
                        "INSERT INTO enrollment_history (enrollment_id, changed_by, old_status, new_status, created_at)
                         VALUES (:eid, :uid, :from, :to, NOW())"
                    )->execute(['eid' => $id, 'uid' => (int) current_user()['id'], 'from' => $oldStatus, 'to' => $status]);
                }

                /* Auto-create the payment obligation when it becomes enrolled
                   (V5.34: company-endorsed included so they appear in Payments) */
                $autoPayNo = null;
                if ($status === 'enrolled') {
                    $autoPayNo = create_payment_for_enrollment($pdo, $id);
                }

                $pdo->commit();

                $flash = ['type' => 'success', 'message' => "Enrollment #{$id} updated (batch changed, status: {$status})."
                    . ($autoPayNo ? " Payment {$autoPayNo} auto-created." : '')];
            }
            }
            update_skip:
        }
    } catch (Throwable $e) {
        if (isset($pdo) && $pdo->inTransaction()) { $pdo->rollBack(); }
        error_log('enrollment.php: ' . $e->getMessage());
        $flash = ['type' => 'error', 'message' => 'Could not save the enrollment.'];
    }
}

/* ==========================================================
   Auto-create a payment obligation when an enrollment becomes
   ENROLLED (the "Record Payment Obligation" step is removed —
   marking an enrollment enrolled is the single source of truth).
   Returns the PAY number, or null when not eligible.
   Call inside an active transaction.
========================================================== */
function create_payment_for_enrollment(PDO $pdo, int $enrollmentId): ?string
{
    $stmt = $pdo->prepare(
        "SELECT e.applicant_id, e.course_id, e.training_id,
                c.course_name, c.price_amount,
                t.end_date AS batch_end
         FROM enrollment e
         JOIN mnt_course c ON c.id = e.course_id
         LEFT JOIN training t ON t.id = e.training_id
         WHERE e.id = :id"
    );
    $stmt->execute(['id' => $enrollmentId]);
    $enr = $stmt->fetch();

    if (!$enr || (float) $enr['price_amount'] <= 0) {
        return null; // no course price → nothing to bill
    }

    /* Never duplicate a payment for the same enrollment */
    $chk = $pdo->prepare("SELECT id FROM payment WHERE enrollment_id = :id LIMIT 1");
    $chk->execute(['id' => $enrollmentId]);
    if ($chk->fetch()) {
        return null;
    }

    /* P0 defense-in-depth: if this applicant already has an UNPAID or
       PARTIAL payment for the same course (via another enrollment),
       don't create a second obligation — prevents double billing. */
    $dupPay = $pdo->prepare(
        "SELECT p.id
         FROM payment p
         JOIN enrollment e ON e.id = p.enrollment_id
         WHERE p.applicant_id = :ap AND e.course_id = :co
           AND p.payment_status_id IN (1,2)
           AND e.id <> :eid
         LIMIT 1"
    );
    $dupPay->execute(['ap' => $enr['applicant_id'], 'co' => $enr['course_id'], 'eid' => $enrollmentId]);
    if ($dupPay->fetch()) {
        return null;
    }

    /* Next PAY number (mirrors generate_enrollment_no). Retry on the
       rare duplicate (e.g. a manually-inserted payment used the same
       number) so a collision can never roll back the enrollment. */
    $total = (float) $enr['price_amount'];
    $due   = ($enr['batch_end'] ?? null) ?: null;
    $paymentId = 0;
    $paymentNo = '';

    for ($attempt = 0; $attempt < 5 && !$paymentId; $attempt++) {
        $year = (int) date('Y');
        $sel = $pdo->prepare(
            "SELECT id, current_value, prefix, padding_length
             FROM sequence_generator WHERE sequence_code = 'PAY' AND sequence_year = :y FOR UPDATE"
        );
        $sel->execute(['y' => $year]);
        $seq = $sel->fetch();
        if (!$seq) {
            $pdo->prepare(
                "INSERT INTO sequence_generator (sequence_code, sequence_year, current_value, prefix, padding_length)
                 VALUES ('PAY', :y, 0, 'PAY', 6)"
            )->execute(['y' => $year]);
            $sel->execute(['y' => $year]);
            $seq = $sel->fetch();
        }
        $next = ((int) $seq['current_value']) + 1;
        $pdo->prepare("UPDATE sequence_generator SET current_value = :v WHERE id = :id")
            ->execute(['v' => $next, 'id' => $seq['id']]);
        $paymentNo = sprintf('%s-%d-%s', $seq['prefix'], $year, str_pad((string) $next, (int) $seq['padding_length'], '0', STR_PAD_LEFT));

        try {
            $pdo->prepare(
                "INSERT INTO payment (payment_no, applicant_id, enrollment_id, payment_status_id,
                        total_amount, paid_amount, balance_amount, due_date, created_at)
                 VALUES (:no, :ap, :en, 1, :tt, 0, :bl, :dd, NOW())"
            )->execute([
                'no' => $paymentNo, 'ap' => $enr['applicant_id'], 'en' => $enrollmentId,
                'tt' => $total, 'bl' => $total, 'dd' => $due,
            ]);
            $paymentId = (int) $pdo->lastInsertId();
        } catch (Throwable $e) {
            /* duplicate payment_no → try the next sequence value */
            if (strpos($e->getMessage(), 'Duplicate entry') === false) { throw $e; }
        }
    }

    if (!$paymentId) {
        return null; // could not allocate a payment number
    }

    $pdo->prepare(
        "INSERT INTO payment_item (payment_id, item_name, quantity, unit_price, total_price)
         VALUES (:pid, :item, 1, :up, :tp)"
    )->execute(['pid' => $paymentId, 'item' => $enr['course_name'], 'up' => $total, 'tp' => $total]);

    return $paymentNo;
}

/* ==========================================================
   Load data
========================================================== */
$filterStatus = trim((string) ($_GET['status'] ?? ''));
$search       = trim((string) ($_GET['q'] ?? ''));

$where  = ' WHERE 1 = 1';
$params = [];

if ($filterStatus !== '') {
    $where .= ' AND e.status = :status';
    $params['status'] = $filterStatus;
}
if ($search !== '') {
    /* PDO native prepares (EMULATE_PREPARES=false) reject reused named
       params — bind one placeholder per LIKE. :kw6 matches the full
       "First Last" name so typing "Grace Lacsoc" finds the row. */
    $where .= " AND (e.enrollment_no LIKE :kw1 OR a.first_name LIKE :kw2 OR a.last_name LIKE :kw3 OR a.email LIKE :kw4 OR c.course_name LIKE :kw5 OR CONCAT(a.first_name, ' ', a.last_name) LIKE :kw6)";
    $like = '%' . $search . '%';
    $params = array_merge($params, ['kw1' => $like, 'kw2' => $like, 'kw3' => $like, 'kw4' => $like, 'kw5' => $like, 'kw6' => $like]);
}

$enrollments = $pdo->prepare(
    "SELECT e.id, e.enrollment_no, e.applicant_id, e.status, e.enrollment_date, e.created_at, e.training_id, e.course_id,
            e.endorsed_by, e.endorser_type, e.charge_to, e.company_id, e.remarks, comp.company_name,
            a.applicant_no, a.first_name, a.middle_name, a.last_name, a.email,
            c.course_name, c.code AS course_code, c.price_amount,
            t.training_no, t.batch_name, t.start_date, t.end_date, t.max_slots,
            (SELECT COUNT(*) FROM enrollment x WHERE x.training_id = e.training_id AND x.status NOT IN ('cancelled','no_show')) AS enrolled_slots,
            (SELECT COUNT(*) FROM payment p WHERE p.enrollment_id = e.id) AS payment_count,
            (SELECT COALESCE(SUM(p.paid_amount),0) FROM payment p WHERE p.enrollment_id = e.id) AS paid_total,
            (SELECT COUNT(DISTINCT cp.required_document_type_id)
             FROM course_prerequisite cp
             WHERE cp.course_id = e.course_id AND cp.required_document_type_id IS NOT NULL
               AND EXISTS (SELECT 1 FROM mnt_document_type dt
                           WHERE dt.id = cp.required_document_type_id AND dt.is_active = 1)
               AND (
                    EXISTS (SELECT 1 FROM document d
                            WHERE d.owner_type = 'applicant' AND d.owner_id = a.id
                              AND d.document_type_id = cp.required_document_type_id
                              AND d.status IN ('submitted','verified'))
                    OR EXISTS (SELECT 1 FROM application_requirement ar
                               JOIN application ap2 ON ap2.id = ar.application_id
                               WHERE ap2.applicant_id = a.id
                                 AND ar.document_type_id = cp.required_document_type_id
                                 AND ar.is_submitted = 1)
               )) AS docs_submitted,
            (SELECT COUNT(*) FROM course_prerequisite cp
             WHERE cp.course_id = e.course_id AND cp.required_document_type_id IS NOT NULL
               AND EXISTS (SELECT 1 FROM mnt_document_type dt
                           WHERE dt.id = cp.required_document_type_id AND dt.is_active = 1)) AS docs_required
     FROM enrollment e
     LEFT JOIN applicant a ON a.id = e.applicant_id
     LEFT JOIN mnt_course c ON c.id = e.course_id
     LEFT JOIN mnt_company comp ON comp.id = e.company_id
     LEFT JOIN training t ON t.id = e.training_id"
    . $where . " ORDER BY e.id DESC LIMIT 100"
);
$enrollments->execute($params);
$enrollments = $enrollments->fetchAll() ?: [];

/* KPIs */
$kpi = [
    'total'     => (int) $pdo->query('SELECT COUNT(*) FROM enrollment')->fetchColumn(),
    'enrolled'  => (int) $pdo->query("SELECT COUNT(*) FROM enrollment WHERE status = 'enrolled'")->fetchColumn(),
    'pending'   => (int) $pdo->query("SELECT COUNT(*) FROM enrollment WHERE status = 'pending'")->fetchColumn(),
    'completed' => (int) $pdo->query("SELECT COUNT(*) FROM enrollment WHERE status = 'completed'")->fetchColumn(),
];

/* Auto-suggest data — ALL applicants (including already-enrolled ones,
   so a trainee enrolled in one course can be enrolled in another).
   The P0 duplicate guard still blocks the SAME course twice. */
$applicants = $pdo->query(
    "SELECT a.id, a.applicant_no, a.first_name, a.last_name, a.email,
            (SELECT GROUP_CONCAT(c.course_name SEPARATOR ', ')
             FROM enrollment e JOIN mnt_course c ON c.id = e.course_id
             WHERE e.applicant_id = a.id AND e.status IN ('pending','enrolled')) AS enrolled_courses
     FROM applicant a
     WHERE a.email IS NOT NULL AND TRIM(a.email) <> '' AND a.email <> '0'
     ORDER BY a.first_name, a.last_name LIMIT 500"
)->fetchAll();

$courses = $pdo->query(
    "SELECT id, code, course_name, price_amount FROM mnt_course WHERE is_active = 1 ORDER BY course_name"
)->fetchAll();

/* Walk-in enrollment form lookups */
$genders        = $pdo->query("SELECT id, name FROM mnt_gender ORDER BY id")->fetchAll() ?: [];
$civilStatuses  = $pdo->query("SELECT id, name FROM mnt_civil_status ORDER BY id")->fetchAll() ?: [];
$nationalities  = $pdo->query("SELECT id, name FROM mnt_nationality ORDER BY name")->fetchAll() ?: [];
$relationships  = $pdo->query("SELECT id, name FROM mnt_relationship ORDER BY name")->fetchAll() ?: [];
$countries      = $pdo->query("SELECT id, name FROM mnt_country ORDER BY name")->fetchAll() ?: [];
$ranks          = $pdo->query("SELECT id, name FROM mnt_rank_position WHERE is_active = 1 ORDER BY sort_order, name")->fetchAll() ?: [];
$companies      = $pdo->query("SELECT id, company_name, contact_person FROM mnt_company WHERE is_active = 1 ORDER BY company_name")->fetchAll() ?: [];
/* Endorsers = staff accounts whose role code is ENDORSER */
$endorsers = $pdo->query(
    "SELECT u.id, u.full_name
     FROM sys_user u
     JOIN sys_role r ON r.id = u.role_id
     WHERE r.code = 'ENDORSER' AND u.status_id = 1
     ORDER BY u.full_name"
)->fetchAll() ?: [];
/* Company contacts — offered as a droplist in Endorsed By when company-endorsed */
$companyContacts = [];
foreach ($companies as $co) {
    $c = trim((string) ($co['contact_person'] ?? ''));
    if ($c !== '' && !in_array($c, $companyContacts, true)) {
        $companyContacts[] = $c;
    }
}

$trainings = $pdo->query(
    "SELECT t.id, t.training_no, t.batch_name, t.course_id, t.max_slots, t.start_date, t.end_date,
            bs.name AS batch_status,
            (SELECT COUNT(*) FROM enrollment e WHERE e.training_id = t.id AND e.status NOT IN ('cancelled','no_show')) AS filled
     FROM training t
     LEFT JOIN mnt_batch_status bs ON bs.id = t.batch_status_id
     WHERE t.start_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
     ORDER BY t.start_date DESC LIMIT 300"
)->fetchAll();

/**
 * Next ENR number from sequence_generator (locked, transaction-safe).
 */
function generate_enrollment_no(PDO $pdo): string
{
    $year = (int) date('Y');

    $sel = $pdo->prepare(
        "SELECT id, current_value, prefix, padding_length
         FROM sequence_generator WHERE sequence_code = 'ENR' AND sequence_year = :y FOR UPDATE"
    );
    $sel->execute(['y' => $year]);
    $seq = $sel->fetch();

    if (!$seq) {
        $pdo->prepare("INSERT INTO sequence_generator (sequence_code, sequence_year, current_value, prefix, padding_length)
                       VALUES ('ENR', :y, 0, 'ENR', 6)")->execute(['y' => $year]);
        $sel->execute(['y' => $year]);
        $seq = $sel->fetch();
    }

    $next = ((int) $seq['current_value']) + 1;
    $pdo->prepare("UPDATE sequence_generator SET current_value = :v WHERE id = :id")
        ->execute(['v' => $next, 'id' => $seq['id']]);

    return sprintf('%s-%d-%s', $seq['prefix'], $year, str_pad((string) $next, (int) $seq['padding_length'], '0', STR_PAD_LEFT));
}

$page = [
    'title'       => 'Enrollment | USMCI-TMS',
    'description' => 'Enrollment Management',
    'bodyClass'   => 'admissions-page',
];
?>
<!DOCTYPE html>
<html lang="en">

<?php include INCLUDES_PATH . '/head.php'; ?>

<link rel="stylesheet" href="<?= e(base_url('assets/css/portal.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/workspace.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/inquiry-queue/assets/css/page.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/admin/dashboard.css?v=' . ASSET_VERSION)); ?>">

<body class="<?= e($page['bodyClass']); ?>">

    <?php include NAVBAR_PATH . '/index.php'; ?>

    <section class="portal-shell portal-shell--2col">

        <?php require ADMISSIONS_PATH . '/inquiry-queue/partials/sidebar.php'; ?>

        <main class="portal-content">

            <header class="workspace-header">
                <div class="workspace-header__left">
                    <span class="section-badge">Enrollment</span>
                    <h1>Enrollment Management</h1>
                    <p>Create enrollments, assign training batches, and track status.</p>
                </div>
                <div class="workspace-header__right">
                    <?php if (user_can('enrollment', 'edit')): ?><button type="button" class="btn-primary" id="btnAddEnrollment">＋ Create Enrollment</button><?php endif; ?>
                </div>
            </header>

            <?php if ($flash['message']): ?>
                <div id="enrollFlash" data-type="<?= $flash['type']; ?>" style="display:none;"><?= htmlspecialchars($flash['message'], ENT_QUOTES, 'UTF-8'); ?></div>
            <?php endif; ?>

            <!-- KPI (single row — like the Inquiry Queue summary) -->
            <section class="summary-cards">
                <article class="summary-card">
                    <div class="summary-card__icon" style="background:#EAF6F2;">📝</div>
                    <div class="summary-card__content">
                        <span class="summary-card__value"><?= number_format($kpi['total']); ?></span>
                        <span class="summary-card__label">Total Enrollments</span>
                    </div>
                </article>
                <article class="summary-card">
                    <div class="summary-card__icon" style="background:#EFF6FF;">✅</div>
                    <div class="summary-card__content">
                        <span class="summary-card__value"><?= number_format($kpi['enrolled']); ?></span>
                        <span class="summary-card__label">Enrolled</span>
                    </div>
                </article>
                <article class="summary-card">
                    <div class="summary-card__icon" style="background:#FEF3C7;">⏳</div>
                    <div class="summary-card__content">
                        <span class="summary-card__value"><?= number_format($kpi['pending']); ?></span>
                        <span class="summary-card__label">Pending</span>
                    </div>
                </article>
                <article class="summary-card">
                    <div class="summary-card__icon" style="background:#DCFCE7;">🏁</div>
                    <div class="summary-card__content">
                        <span class="summary-card__value"><?= number_format($kpi['completed']); ?></span>
                        <span class="summary-card__label">Completed</span>
                    </div>
                </article>
            </section>

            <!-- Toolbar -->
            <section class="workspace-toolbar">
                <div class="toolbar-left">
                    <div class="toolbar-search">
                        <input type="text" id="enrollSearch" placeholder="Search enrollment no., applicant, course..." value="<?= e($search); ?>">
                    </div>
                </div>
                <div class="toolbar-right">
                    <select id="enrollStatusFilter">
                        <option value="">All Statuses</option>
                        <?php foreach (['pending','enrolled','cancelled','completed','no_show'] as $st): ?>
                            <option value="<?= $st; ?>" <?= $filterStatus === $st ? 'selected' : ''; ?>><?= ucfirst($st); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </section>

            <!-- Table -->
            <section class="workspace-table">
                <div class="table-responsive">
                    <table class="inquiry-table">
                        <thead>
                            <tr>
                                <th>Enrollment No.</th>
                                <th>Applicant</th>
                                <th>Docs</th>
                                <th>Course</th>
                                <th>Batch</th>
                                <th>Dates</th>
                                <th>Slots</th>
                                <th>Paid</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!$enrollments): ?>
                                <tr><td colspan="9" style="text-align:center;color:#94A3B8;padding:30px;">No enrollments found.</td></tr>
                            <?php endif; ?>
                            <?php foreach ($enrollments as $e): ?>
                                <tr>
                                    <td class="cert-table__no"><?= e($e['enrollment_no']); ?></td>
                                    <td>
                                        <?= e(trim($e['first_name'] . ' ' . $e['last_name'])); ?>
                                        <div class="course-desc"><?= e($e['email']); ?> · <?= e($e['applicant_no']); ?></div>
                                    </td>
                                    <td>
                                        <?php
                                            $ds = (int) ($e['docs_submitted'] ?? 0);
                                            $dr = (int) ($e['docs_required'] ?? 0);
                                            $docsCls = $dr > 0 && $ds >= $dr ? 'docs-ok' : ($ds > 0 ? 'docs-part' : 'docs-none');
                                        ?>
                                        <span class="docs-badge <?= $docsCls; ?>" title="Requirement documents submitted / required">
                                            <?= $ds; ?>/<?= $dr; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?= e($e['course_name'] ?? '—'); ?>
                                        <div class="course-desc">₱ <?= number_format((float) $e['price_amount'], 2); ?></div>
                                        <?php if (!empty($e['endorsed_by']) || ($e['charge_to'] ?? '') === 'company'): ?>
                                            <div class="course-desc" style="color:#0D8A72;">
                                                <?= e($e['charge_to'] === 'company' ? '🏢 Company / ' . ($e['company_name'] ?? '') : ''); ?>
                                                <?= e(!empty($e['endorsed_by']) ? '✍️ ' . $e['endorsed_by'] : ''); ?>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?= e($e['batch_name'] ?? '—'); ?>
                                        <div class="course-desc"><?= e($e['training_no'] ?? ''); ?></div>
                                    </td>
                                    <td>
                                        <?= e($e['start_date'] ?? '—'); ?><br><span class="course-desc">→ <?= e($e['end_date'] ?? '—'); ?></span>
                                    </td>
                                    <td>
                                        <?= $e['training_id'] ? ((int) $e['enrolled_slots'] . ' / ' . (int) $e['max_slots']) : '—'; ?>
                                    </td>
                                    <td style="font-weight:700;color:#15803D;">₱ <?= number_format((float) $e['paid_total'], 2); ?></td>
                                    <td>
                                        <span class="status-badge status-<?= e($e['status']); ?>"><?= e(ucfirst($e['status'])); ?></span>
                                    </td>
                                    <td class="cert-table__actions">
                                        <div class="cert-actions-2x2">
                                            <button type="button" class="btn-secondary btn-sm" data-edit='<?= json_encode(['id'=>(int)$e['id'],'no'=>$e['enrollment_no'],'applicant_id'=>(int)$e['applicant_id'],'course_id'=>(int)$e['course_id'],'training_id'=>(int)$e['training_id'],'date'=>$e['enrollment_date'],'status'=>$e['status'],'applicant'=>trim($e['first_name'].' '.$e['last_name']),'endorsed'=>($e['endorsed_by']??''),'etype'=>($e['endorser_type']??'marketing'),'charge'=>($e['charge_to']??'trainee'),'company'=>(int)($e['company_id']??0),'remarks'=>($e['remarks']??'')], JSON_HEX_APOS|JSON_HEX_QUOT); ?>'>✏️ Edit</button>
                                            <a class="btn-secondary btn-sm" style="text-decoration:none;" href="<?= e(base_url('sections/admissions/admin/enrollment_print.php?enrollment_id=' . (int) $e['id'])); ?>" target="_blank" title="Print registration slip">🖨 Slip</a>
                                            <button type="button" class="btn-secondary btn-sm" data-status='<?= json_encode(['id'=>(int)$e['id'],'no'=>$e['enrollment_no'],'status'=>$e['status']], JSON_HEX_APOS|JSON_HEX_QUOT); ?>'>Status</button>
                                            <button type="button" class="btn-secondary btn-sm" data-req='<?= json_encode(['id'=>(int)$e['id'],'no'=>$e['enrollment_no'],'applicant_id'=>(int)$e['applicant_id'],'course_id'=>(int)$e['course_id'],'course'=>$e['course_name']??'', 'app'=>trim($e['first_name'].' '.$e['last_name'])], JSON_HEX_APOS|JSON_HEX_QUOT); ?>' title="Check / update requirement documents">📄 Req</button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </section>

        </main>
    </section>

    <?php include INCLUDES_PATH . '/footer.php'; ?>
    <?php include INCLUDES_PATH . '/scripts.php'; ?>

    <!-- Create Enrollment modal -->
    <div id="enrollModal" class="portal-modal" style="display:none;">
        <div class="portal-modal__box portal-modal__box--wide">
            <div class="portal-modal__head">
                <h3 id="enrollModalTitle">Create Enrollment</h3>
                <p id="enrollModalTarget">Enrollment number is generated automatically (ENR-YYYY-######).</p>
                <button class="portal-modal__close" id="enrollClose">&times;</button>
            </div>
            <form method="post" action="<?= e(base_url('sections/admissions/admin/enrollment.php')); ?>" class="cert-form" id="enrollForm" enctype="multipart/form-data">
                <?= csrf_field(); ?>
                <input type="hidden" name="action" id="enrAction" value="create">
                <input type="hidden" name="enrollment_id" id="enrId" value="0">
                <input type="hidden" name="applicant_mode" id="enrMode" value="existing">
                <div class="portal-modal__body">

                    <!-- Mode toggle -->
                    <div class="enr-mode">
                        <button type="button" class="enr-mode__btn active" data-mode="existing" id="enrModeExisting">👤 Existing Applicant</button>
                        <button type="button" class="enr-mode__btn" data-mode="walkin" id="enrModeWalkin">➕ Walk-in (New Applicant)</button>
                    </div>

                    <!-- Existing applicant picker (hidden in walk-in mode) -->
                    <div id="enrExistingWrap">
                        <div class="t-field t-field--full">
                            <label>Applicant *</label>
                            <span id="enrApplicantLabel" class="enr-applicant-label" style="display:none;"></span>
                            <input type="hidden" name="applicant_id" id="enrApplicant" value="">
                            <div class="enr-combobox">
                                <input type="text" id="enrApplicantSearch" placeholder="Type name, email, or applicant no…" autocomplete="off">
                                <div id="enrApplicantResults" class="enr-combobox__list" style="display:none;"></div>
                            </div>
                            <small class="field-hint">Start typing — matching applicants (by name / email / applicant no.) appear instantly.</small>
                        </div>
                        <p class="enr-hint" id="enrAutofillNote" style="display:none;">✓ Details below were auto-filled from this applicant's account — you can edit or complete any missing fields.</p>
                    </div>

                    <!-- Walk-in notice -->
                    <div id="enrWalkinWrap" style="display:none;">
                        <div class="enr-walkin-banner">🏃 Walk-in enrollment — a new applicant record (APP-…) will be created automatically with the details below.</div>
                        <div class="t-field t-field--full">
                            <label>Temporary Password (for Trainee Portal)</label>
                            <input type="text" name="wf_password" id="wfPassword" minlength="8" placeholder="Min 8 chars — leave blank to auto-generate" autocomplete="off">
                            <small class="field-hint">A trainee account is created for walk-ins so they can log in to the Trainee Portal. If blank, a temporary password is auto-generated and shown after saving.</small>
                        </div>
                    </div>

                    <!-- ============ ENROLLMENT FORM ============ -->
                    <h4 class="enr-sec-title">1 · Personal Information</h4>
                    <div class="cert-form__grid">
                        <div class="t-field"><label>First Name *</label><input name="wf_first_name" id="wfFirstName" required></div>
                        <div class="t-field"><label>Middle Name</label><input name="wf_middle_name" id="wfMiddleName"></div>
                        <div class="t-field"><label>Last Name *</label><input name="wf_last_name" id="wfLastName" required></div>
                        <div class="t-field"><label>Suffix</label><input name="wf_suffix" id="wfSuffix" placeholder="Jr., Sr., III"></div>
                        <div class="t-field"><label>Birth Date</label><input type="date" name="wf_birth_date" id="wfBirthDate"></div>
                        <div class="t-field">
                            <label>Gender</label>
                            <select name="wf_gender_id" id="wfGenderId">
                                <option value="">—</option>
                                <?php foreach ($genders as $g): ?><option value="<?= (int) $g['id']; ?>"><?= e($g['name']); ?></option><?php endforeach; ?>
                            </select>
                        </div>
                        <div class="t-field">
                            <label>Civil Status</label>
                            <select name="wf_civil_status_id" id="wfCivilStatusId">
                                <option value="">—</option>
                                <?php foreach ($civilStatuses as $cs): ?><option value="<?= (int) $cs['id']; ?>"><?= e($cs['name']); ?></option><?php endforeach; ?>
                            </select>
                        </div>
                        <div class="t-field">
                            <label>Nationality</label>
                            <select name="wf_nationality_id" id="wfNationalityId">
                                <option value="">—</option>
                                <?php foreach ($nationalities as $n): ?><option value="<?= (int) $n['id']; ?>"><?= e($n['name']); ?></option><?php endforeach; ?>
                            </select>
                        </div>
                        <div class="t-field"><label>Mobile No.</label><input name="wf_mobile_no" id="wfMobileNo" placeholder="09XXXXXXXXX"></div>
                        <div class="t-field"><label>Email</label><input type="email" name="wf_email" id="wfEmail" placeholder="optional for walk-in"></div>
                    </div>

                    <h4 class="enr-sec-title">2 · Address &amp; Emergency Contact</h4>
                    <div class="cert-form__grid">
                        <div class="t-field"><label>Place of Birth</label><input name="wf_place_of_birth" id="wfPlaceOfBirth"></div>
                        <div class="t-field"><label>Address Line 1</label><input name="wf_address_line1" id="wfAddress1"></div>
                        <div class="t-field"><label>Address Line 2</label><input name="wf_address_line2" id="wfAddress2"></div>
                        <div class="t-field"><label>Postal Code</label><input name="wf_postal_code" id="wfPostalCode"></div>
                        <div class="t-field">
                            <label>Country</label>
                            <select name="wf_country_id" id="wfCountryId">
                                <option value="">—</option>
                                <?php foreach ($countries as $co): ?><option value="<?= (int) $co['id']; ?>"><?= e($co['name']); ?></option><?php endforeach; ?>
                            </select>
                        </div>
                        <div class="t-field t-field--full" style="grid-column:1/-1;"></div>
                        <div class="t-field"><label>Emergency Contact Name</label><input name="wf_emergency_contact_name" id="wfEcn"></div>
                        <div class="t-field"><label>Emergency Contact No.</label><input name="wf_emergency_contact_no" id="wfEcm"></div>
                        <div class="t-field">
                            <label>Relationship</label>
                            <select name="wf_relationship_id" id="wfRelationshipId">
                                <option value="">—</option>
                                <?php foreach ($relationships as $rel): ?><option value="<?= (int) $rel['id']; ?>"><?= e($rel['name']); ?></option><?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <h4 class="enr-sec-title">3 · Seafarer / Credentials</h4>
                    <div class="cert-form__grid">
                        <div class="t-field t-field--full" id="enrPhotoWrap">
                            <label>Photo <span class="field-hint">(auto-fetched from the trainee's profile if available)</span></label>
                            <div style="display:flex;gap:12px;align-items:center;flex-wrap:wrap;">
                                <img id="enrPhotoPreview" alt="Trainee photo" style="width:72px;height:72px;object-fit:cover;border-radius:50%;border:2px solid #E2E8F0;background:#F8FAFC;display:none;">
                                <div style="flex:1;min-width:180px;">
                                    <input type="file" name="wf_photo" id="wfPhoto" accept=".jpg,.jpeg,.png">
                                    <small class="field-hint">JPG/PNG max 4MB — saved to the trainee's profile.</small>
                                </div>
                            </div>
                        </div>
                        <div class="t-field">
                            <label>Rank / Position</label>
                            <select name="wf_rank_id" id="wfRankId">
                                <option value="">— select rank —</option>
                                <?php foreach ($ranks as $rk): ?>
                                    <option value="<?= (int) $rk['id']; ?>"><?= e($rk['name']); ?></option>
                                <?php endforeach; ?>
                                <option value="__custom">Other (type below)</option>
                            </select>
                        </div>
                        <div class="t-field" id="wfRankCustomWrap" style="display:none;"><label>Other Rank</label><input name="wf_rank_position" id="wfRank" placeholder="e.g. Pumpman"></div>
                        <div class="t-field"><label>SRN No. (Seafarer's Registration No.)</label><input name="wf_seafarer_id_no" id="wfSeafarerId"></div>
                        <div class="t-field"><label>SIRB No.</label><input name="wf_sirb_no" id="wfSirb"></div>
                        <div class="t-field"><label>CDC No.</label><input name="wf_cdc_no" id="wfCdc"></div>
                        <div class="t-field"><label>Passport No.</label><input name="wf_passport_no" id="wfPassport"></div>
                        <div class="t-field"><label>Passport Expiry</label><input type="date" name="wf_passport_expiry" id="wfPassportExp"></div>
                        <div class="t-field"><label>Medical Cert No.</label><input name="wf_medical_certificate_no" id="wfMedCert"></div>
                        <div class="t-field"><label>Medical Expiry</label><input type="date" name="wf_medical_expiry" id="wfMedExp"></div>
                    </div>

                    <h4 class="enr-sec-title">4 · Endorsement &amp; Billing</h4>
                    <div class="cert-form__grid">
                        <div class="t-field">
                            <label>Endorser Type *</label>
                            <select name="enr_endorser_type" id="enrEndorserType">
                                <option value="marketing">Marketing / Endorser (payment required)</option>
                                <option value="company">Company-Endorsed (payment not mandatory)</option>
                            </select>
                        </div>
                        <div class="t-field">
                            <label>Endorsed By <span id="enrEndorsedLabel">(Endorser Staff)</span></label>
                            <select name="enr_endorsed_by" id="enrEndorsedBy">
                                <option value="">— select —</option>
                                <optgroup label="Endorser Staff">
                                    <?php foreach ($endorsers as $end): ?>
                                        <option value="<?= e($end['full_name']); ?>"><?= e($end['full_name']); ?></option>
                                    <?php endforeach; ?>
                                </optgroup>
                                <?php if ($companyContacts): ?>
                                <optgroup label="Company Contacts">
                                    <?php foreach ($companyContacts as $cc): ?>
                                        <option value="<?= e($cc); ?>"><?= e($cc); ?></option>
                                    <?php endforeach; ?>
                                </optgroup>
                                <?php endif; ?>
                            </select>
                            <?php if (!$endorsers): ?>
                                <small class="field-hint">No staff have the ENDORSER role yet — add one in Staff Accounts (role = Endorser).</small>
                            <?php endif; ?>
                        </div>
                        <div class="t-field">
                            <label>Charge To</label>
                            <select name="enr_charge_to" id="enrChargeTo">
                                <option value="trainee">Trainee's Account</option>
                                <option value="company">Company / Agency</option>
                            </select>
                        </div>
                        <div class="t-field" id="enrCompanyWrap" style="display:none;">
                            <label>Company *</label>
                            <select name="enr_company_id" id="enrCompanyId">
                                <option value="">— select company —</option>
                                <?php foreach ($companies as $co): ?>
                                    <option value="<?= (int) $co['id']; ?>" data-contact="<?= e($co['contact_person'] ?? ''); ?>"><?= e($co['company_name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="t-field t-field--full"><label>Remarks</label><textarea name="enr_remarks" id="enrRemarks" rows="2" placeholder="Notes shown on the registration slip"></textarea></div>
                    </div>

                    <h4 class="enr-sec-title">5 · Course &amp; Batch</h4>
                    <div class="cert-form__grid">
                        <div class="t-field t-field--full">
                            <label>Course *</label>
                            <select name="course_id" id="enrCourse" required>
                                <option value="">— select course —</option>
                                <?php foreach ($courses as $co): ?>
                                    <option value="<?= (int) $co['id']; ?>" data-price="<?= e($co['price_amount']); ?>"><?= e('#' . $co['id'] . ' · ' . $co['code'] . ' — ' . $co['course_name']); ?> (₱ <?= number_format((float) $co['price_amount'], 2); ?>)</option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="t-field t-field--full">
                            <label>Batch (optional)</label>
                            <select name="training_id" id="enrTraining">
                                <option value="">— no batch —</option>
                                <?php foreach ($trainings as $tr):
                                    $full = (int) $tr['filled'] >= (int) $tr['max_slots'];
                                ?>
                                    <option value="<?= (int) $tr['id']; ?>" data-course="<?= (int) $tr['course_id']; ?>" <?= $full ? 'disabled' : ''; ?>>
                                        <?= e($tr['training_no']); ?> · <?= e($tr['batch_name']); ?> — <?= e(date('M d', strtotime($tr['start_date']))); ?> to <?= e(date('M d, Y', strtotime($tr['end_date']))); ?> (<?= (int) $tr['filled']; ?>/<?= (int) $tr['max_slots']; ?><?= $full ? ' — FULL' : ''; ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="t-field"><label>Enrollment Date</label><input type="date" name="enrollment_date" id="enrollDate" value="<?= date('Y-m-d'); ?>"></div>
                        <div class="t-field">
                            <label>Status</label>
                            <select name="status" id="enrollStatus">
                                <option value="pending">Pending</option>
                                <option value="enrolled">Enrolled</option>
                                <option value="completed">Completed</option>
                                <option value="cancelled">Cancelled</option>
                                <option value="no_show">No Show</option>
                            </select>
                            <small class="field-hint" id="enrStatusHint" style="display:none;color:#B45309;">Marketing-endorsed: created as Pending — record the payment, then mark Enrolled.</small>
                        </div>
                    </div>

                </div>
                <div class="portal-modal__foot">
                    <button type="button" class="btn-secondary" id="enrollCancel">Cancel</button>
                    <button type="submit" class="btn-primary" id="enrollSubmitBtn">Create Enrollment</button>
                </div>
            </form>
        </div>
    </div>


    <!-- Status modal -->
    <div id="statusModal" class="portal-modal" style="display:none;">
        <div class="portal-modal__box">
            <div class="portal-modal__head">
                <h3>Update Enrollment Status</h3>
                <p id="statusTarget">—</p>
                <button class="portal-modal__close" id="statusClose">&times;</button>
            </div>
            <form method="post" action="<?= e(base_url('sections/admissions/admin/enrollment.php')); ?>" id="statusForm">
                <?= csrf_field(); ?>
                <input type="hidden" name="action" value="status">
                <input type="hidden" name="enrollment_id" id="statusId" value="0">
                <div class="portal-modal__body">
                <div class="t-field">
                    <select name="status" id="statusSelect">
                        <option value="pending">Pending</option>
                        <option value="enrolled">Enrolled</option>
                        <option value="completed">Completed</option>
                        <option value="cancelled">Cancelled</option>
                        <option value="no_show">No Show</option>
                    </select>
                </div>
                </div>
                <div class="portal-modal__foot">
                    <button type="button" class="btn-secondary" id="statusCancel">Cancel</button>
                    <button type="submit" class="btn-primary">Save Status</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Requirements modal -->
    <div id="reqModal" class="portal-modal" style="display:none;">
        <div class="portal-modal__box">
            <div class="portal-modal__head">
                <h3>Enrollment Requirements</h3>
                <p id="reqTarget">—</p>
                <button class="portal-modal__close" id="reqClose">&times;</button>
            </div>
            <div class="portal-modal__body">
                <div id="reqBody" style="display:flex;flex-direction:column;gap:10px;max-height:52vh;overflow:auto;">
                    <p class="field-hint">Loading requirements…</p>
                </div>
                <p class="field-hint" style="margin-top:10px;">
                    🟢 = document uploaded by the trainee · ☑ = staff marked "received" (hardcopy).
                    Click a row to toggle "received" for that requirement.
                </p>
            </div>
            <div class="portal-modal__foot">
                <button type="button" class="btn-secondary" id="reqCancel">Close</button>
            </div>
        </div>
    </div>

    <script>
        (function () {
            function showToast(msg, type) { window.usmciToast(msg, type); }
            var flashEl = document.getElementById("enrollFlash");
            if (flashEl && flashEl.textContent.trim() !== "") showToast(flashEl.textContent.trim(), flashEl.dataset.type);

            // Create/Edit modal
            var enrollModal = document.getElementById("enrollModal");
            var FORM_URL = <?= json_encode(base_url('sections/admissions/admin/applicant_form_data.php')); ?>;
            var APPLICANTS = <?= json_encode(array_map(function ($ap) {
                return ['id' => (int) $ap['id'], 'no' => $ap['applicant_no'], 'name' => trim($ap['first_name'] . ' ' . $ap['last_name']), 'email' => (string) ($ap['email'] ?? ''), 'enrolled' => (string) ($ap['enrolled_courses'] ?? '')];
            }, $applicants)); ?> || [];

            function setVal(id, v) { var el = document.getElementById(id); if (el) el.value = v ?? ""; }
            function esc(s) { return String(s ?? "").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;"); }
            function resetForm() {
                ["wfFirstName","wfMiddleName","wfLastName","wfSuffix","wfBirthDate","wfMobileNo","wfEmail",
                 "wfPlaceOfBirth","wfAddress1","wfAddress2","wfPostalCode","wfEcn","wfEcm",
                 "wfRank","wfSeafarerId","wfSirb","wfCdc","wfPassport","wfPassportExp","wfMedCert","wfMedExp"
                ].forEach(function (id) { setVal(id, ""); });
                ["wfGenderId","wfCivilStatusId","wfNationalityId","wfCountryId","wfRelationshipId","wfRankId","enrEndorserType","enrChargeTo","enrRemarks"].forEach(function (id) {
                    var el = document.getElementById(id); if (el) el.value = "";
                });
                document.getElementById("wfRankCustomWrap").style.display = "none";
                var cw = document.getElementById("enrCompanyWrap"); if (cw) cw.style.display = "none";
                var pv = document.getElementById("enrPhotoPreview"); if (pv) { pv.style.display = "none"; pv.removeAttribute("src"); }
                document.getElementById("enrAutofillNote").style.display = "none";
            }

            function fillFormFromApplicant(id) {
                fetch(FORM_URL + "?applicant_id=" + id, { headers: { "X-Requested-With": "fetch" } })
                    .then(function (r) { return r.json(); })
                    .then(function (d) {
                        if (!d.success || !d.data) { resetForm(); return; }
                        var x = d.data;
                        setVal("wfFirstName", x.first_name); setVal("wfMiddleName", x.middle_name);
                        setVal("wfLastName", x.last_name); setVal("wfSuffix", x.suffix);
                        setVal("wfBirthDate", x.birth_date); setVal("wfMobileNo", x.mobile_no); setVal("wfEmail", x.email);
                        setVal("wfGenderId", x.gender_id || ""); setVal("wfCivilStatusId", x.civil_status_id || "");
                        setVal("wfNationalityId", x.nationality_id || ""); setVal("wfCountryId", x.country_id || "");
                        setVal("wfPlaceOfBirth", x.place_of_birth); setVal("wfAddress1", x.address_line1);
                        setVal("wfAddress2", x.address_line2); setVal("wfPostalCode", x.postal_code);
                        setVal("wfEcn", x.emergency_contact_name); setVal("wfEcm", x.emergency_contact_no);
                        setVal("wfRelationshipId", x.relationship_id || "");
                        /* rank: match the name to the dropdown; fall back to custom */
                        var rankSel = document.getElementById("wfRankId");
                        var matched = false;
                        if (rankSel && x.rank_position) {
                            for (var i = 0; i < rankSel.options.length; i++) {
                                if (rankSel.options[i].text === x.rank_position) {
                                    rankSel.selectedIndex = i; matched = true; break;
                                }
                            }
                            if (!matched) {
                                rankSel.value = "__custom";
                                document.getElementById("wfRankCustomWrap").style.display = "";
                                setVal("wfRank", x.rank_position);
                            }
                        } else if (rankSel) { rankSel.value = ""; }
                        setVal("wfSeafarerId", x.seafarer_id_no);
                        setVal("wfSirb", x.sirb_no); setVal("wfCdc", x.cdc_no);
                        setVal("wfPassport", x.passport_no); setVal("wfPassportExp", x.passport_expiry);
                        setVal("wfMedCert", x.medical_certificate_no); setVal("wfMedExp", x.medical_expiry);
                        /* photo auto-fetch */
                        var pv = document.getElementById("enrPhotoPreview");
                        if (pv) {
                            if (x.photo_path) {
                                pv.src = <?= json_encode(base_url('')); ?> + x.photo_path.replace(/^\/+/, "");
                                pv.style.display = "";
                            } else { pv.style.display = "none"; pv.removeAttribute("src"); }
                        }
                        document.getElementById("enrAutofillNote").style.display = "";
                    })
                    .catch(function () { resetForm(); });
            }

            function setMode(mode) {
                document.getElementById("enrMode").value = mode;
                var isWalkin = mode === "walkin";
                document.getElementById("enrModeExisting").classList.toggle("active", !isWalkin);
                document.getElementById("enrModeWalkin").classList.toggle("active", isWalkin);
                document.getElementById("enrExistingWrap").style.display = isWalkin ? "none" : "";
                document.getElementById("enrWalkinWrap").style.display = isWalkin ? "" : "none";
                document.getElementById("enrApplicant").required = !isWalkin;
                /* email mandatory for walk-ins (needed for the Trainee account) */
                var em = document.getElementById("wfEmail");
                if (em) em.required = isWalkin;
            }
            document.getElementById("enrModeExisting").addEventListener("click", function () { setMode("existing"); });
            document.getElementById("enrModeWalkin").addEventListener("click", function () { setMode("walkin"); });

            /* ---- Applicant auto-suggest combobox ---- */
            var appSearch = document.getElementById("enrApplicantSearch");
            var appResults = document.getElementById("enrApplicantResults");
            var appHidden = document.getElementById("enrApplicant");

            function renderApplicantResults(q) {
                q = (q || "").trim().toLowerCase();
                var list = APPLICANTS;
                if (q) {
                    list = APPLICANTS.filter(function (a) {
                        return (a.name || "").toLowerCase().indexOf(q) >= 0
                            || (a.email || "").toLowerCase().indexOf(q) >= 0
                            || (a.no || "").toLowerCase().indexOf(q) >= 0;
                    });
                }
                list = list.slice(0, 12);
                if (!list.length) {
                    appResults.innerHTML = '<div class="enr-combobox__empty">No matching applicant.</div>';
                } else {
                    appResults.innerHTML = list.map(function (a) {
                        var enrolledBadge = a.enrolled ? '<span class="enr-combobox__badge">already enrolled: ' + esc(a.enrolled) + '</span>' : '';
                        return '<div class="enr-combobox__item" data-id="' + a.id + '">' +
                            '<strong>' + esc(a.name) + '</strong> <span class="enr-combobox__meta">' + esc(a.no) + ' · ' + esc(a.email) + '</span>' + enrolledBadge + '</div>';
                    }).join("");
                }
                appResults.style.display = "block";
                appResults.querySelectorAll(".enr-combobox__item").forEach(function (item) {
                    item.addEventListener("click", function () {
                        var id = item.dataset.id;
                        appHidden.value = id;
                        appSearch.value = item.querySelector("strong").textContent;
                        appResults.style.display = "none";
                        fillFormFromApplicant(id);
                    });
                });
            }
            if (appSearch) {
                appSearch.addEventListener("input", function () { renderApplicantResults(this.value); });
                appSearch.addEventListener("focus", function () { if (APPLICANTS.length) renderApplicantResults(this.value); });
                appSearch.addEventListener("blur", function () { setTimeout(function () { appResults.style.display = "none"; }, 150); });
            }

            function openEnroll() {
                document.getElementById("enrAction").value = "create";
                document.getElementById("enrId").value = "0";
                document.getElementById("enrollModalTitle").textContent = "Create Enrollment";
                document.getElementById("enrollSubmitBtn").textContent = "Create Enrollment";
                document.getElementById("enrollModalTarget").textContent = "Enrollment number is generated automatically (ENR-YYYY-######).";
                document.getElementById("enrApplicantLabel").style.display = "none";
                document.getElementById("enrApplicantLabel").textContent = "";
                document.getElementById("enrApplicant").value = "";
                if (appSearch) appSearch.value = "";
                document.getElementById("enrCourse").value = "";
                document.getElementById("enrTraining").value = "";
                document.getElementById("enrollDate").value = "<?= date('Y-m-d'); ?>";
                document.getElementById("enrollStatus").value = "pending";
                document.getElementById("enrollStatus").disabled = false;
                var sh = document.getElementById("enrStatusHint"); if (sh) sh.style.display = "none";
                document.getElementById("enrEndorserType").value = "marketing";
                setMode("existing");
                resetForm();
                syncEndorserType();
                enrollModal.style.display = "flex";
            }
            function openEnrollEdit(d) {
                document.getElementById("enrAction").value = "update";
                document.getElementById("enrId").value = d.id;
                document.getElementById("enrollModalTitle").textContent = "Edit Enrollment — " + d.no;
                document.getElementById("enrollSubmitBtn").textContent = "Save Changes";
                document.getElementById("enrollModalTarget").textContent = "Applicant: " + (d.applicant || "");
                document.getElementById("enrApplicantLabel").style.display = "";
                document.getElementById("enrApplicantLabel").textContent = d.applicant || "";
                if (appSearch) { appSearch.value = d.applicant || ""; appSearch.disabled = true; }
                /* V5.44: set the hidden applicant_id — the submit gate requires
                   it in existing mode, otherwise Save is silently blocked. */
                document.getElementById("enrApplicant").value = String(d.applicant_id || "");
                setMode("existing");
                document.getElementById("enrExistingWrap").style.display = "none";
                resetForm();
                /* V5.42: load the applicant's full record (incl. photo) into the
                   form so edit is never blank — same endpoint as the auto-suggest. */
                if (d.applicant_id) { fillFormFromApplicant(d.applicant_id); }
                document.getElementById("enrCourse").value = String(d.course_id || "");
                // filter trainings by course then set
                var cid = String(d.course_id || "");
                Array.from(document.getElementById("enrTraining").options).forEach(function (o) {
                    o.style.display = (o.value === "" || o.dataset.course === cid) ? "" : "none";
                });
                document.getElementById("enrTraining").value = String(d.training_id || "");
                document.getElementById("enrollDate").value = d.date || "";
                document.getElementById("enrollStatus").value = d.status || "pending";
                /* endorsement & billing (edit) */
                document.getElementById("enrEndorserType").value = d.etype === "company" ? "company" : "marketing";
                var ct = d.charge === "company" ? "company" : "trainee";
                document.getElementById("enrChargeTo").value = ct;
                var cw = document.getElementById("enrCompanyWrap");
                if (cw) cw.style.display = ct === "company" ? "" : "none";
                document.getElementById("enrCompanyId").value = d.company ? String(d.company) : "";
                document.getElementById("enrRemarks").value = d.remarks || "";
                syncEndorserType();
                /* ensure the saved endorser/contact is selectable, then restore it
                   (syncEndorserType auto-fill may have picked the company contact) */
                var savedEnd = (d.endorsed || "").trim();
                if (savedEnd !== "") {
                    var es = document.getElementById("enrEndorsedBy");
                    var exists = Array.from(es.options).some(function (o) { return o.value === savedEnd; });
                    if (!exists) es.appendChild(new Option(savedEnd, savedEnd));
                    es.value = savedEnd;
                }
                enrollModal.style.display = "flex";
            }
            document.getElementById("btnAddEnrollment").addEventListener("click", function () { openEnroll(); });
            document.querySelectorAll("[data-edit]").forEach(function (b) {
                b.addEventListener("click", function () { try { openEnrollEdit(JSON.parse(b.dataset.edit)); } catch (e) {} });
            });
            function closeEnroll() { enrollModal.style.display = "none"; }
            document.getElementById("enrollClose").addEventListener("click", closeEnroll);
            document.getElementById("enrollCancel").addEventListener("click", closeEnroll);
            enrollModal.addEventListener("click", function (e) { if (e.target === enrollModal) closeEnroll(); });

            // Rank dropdown: "Other" → show custom text
            var rankSel = document.getElementById("wfRankId");
            if (rankSel) rankSel.addEventListener("change", function () {
                var custom = document.getElementById("wfRankCustomWrap");
                if (custom) custom.style.display = this.value === "__custom" ? "" : "none";
                if (this.value !== "__custom") { var c = document.getElementById("wfRank"); if (c) c.value = ""; }
            });
            // Endorser Type: company → charge to company; marketing → trainee
            var etypeSel = document.getElementById("enrEndorserType");
            var chargeSel = document.getElementById("enrChargeTo");
            var companyWrap = document.getElementById("enrCompanyWrap");
            var endorsedSel = document.getElementById("enrEndorsedBy");
            var companySel = document.getElementById("enrCompanyId");
            function syncEndorserType() {
                var statusSel = document.getElementById("enrollStatus");
                var statusHint = document.getElementById("enrStatusHint");
                var endorsedLabel = document.getElementById("enrEndorsedLabel");
                if (etypeSel && etypeSel.value === "company") {
                    if (chargeSel) chargeSel.value = "company";
                    if (companyWrap) companyWrap.style.display = "";
                    if (statusSel) statusSel.disabled = false;
                    if (statusHint) statusHint.style.display = "none";
                    if (endorsedLabel) endorsedLabel.textContent = "(Company Contact)";
                    /* company → auto-fill Endorsed By from the company contact person */
                    if (companySel && endorsedSel && companySel.value) {
                        var opt = companySel.options[companySel.selectedIndex];
                        if (opt && opt.dataset.contact) endorsedSel.value = opt.dataset.contact;
                    }
                } else {
                    if (chargeSel) chargeSel.value = "trainee";
                    if (companyWrap) companyWrap.style.display = "none";
                    if (endorsedLabel) endorsedLabel.textContent = "(Endorser Staff)";
                    /* marketing: payment required → force Pending so staff can
                       record payment first, then mark Enrolled. */
                    if (statusSel) { statusSel.value = "pending"; statusSel.disabled = true; }
                    if (statusHint) statusHint.style.display = "";
                }
            }
            if (etypeSel) etypeSel.addEventListener("change", syncEndorserType);
            /* picking a company also fills Endorsed By with its contact person
               (add the contact as an option so it's selectable/saved) */
            if (companySel) companySel.addEventListener("change", function () {
                if (etypeSel && etypeSel.value === "company" && endorsedSel) {
                    var opt = companySel.options[companySel.selectedIndex];
                    if (opt && opt.dataset.contact) {
                        var contact = opt.dataset.contact;
                        var exists = Array.from(endorsedSel.options).some(function (o) { return o.value === contact; });
                        if (!exists) {
                            var o = new Option(contact, contact);
                            endorsedSel.appendChild(o);
                        }
                        endorsedSel.value = contact;
                    }
                }
            });
            if (chargeSel && companyWrap) chargeSel.addEventListener("change", function () {
                companyWrap.style.display = this.value === "company" ? "" : "none";
            });

            // Photo file preview
            var photoInput = document.getElementById("wfPhoto");
            if (photoInput) photoInput.addEventListener("change", function () {
                var pv = document.getElementById("enrPhotoPreview");
                if (!pv) return;
                if (this.files && this.files[0]) {
                    pv.src = URL.createObjectURL(this.files[0]);
                    pv.style.display = "";
                } else { pv.style.display = "none"; pv.removeAttribute("src"); }
            });

            // Walk-in duplicate email: check BEFORE submit so the modal stays open
            var CHECK_URL = <?= json_encode(base_url('sections/admissions/admin/check_applicant_email.php')); ?>;
            var enrollForm = document.getElementById("enrollForm");
            if (enrollForm) enrollForm.addEventListener("submit", function (e) {
                var mode = document.getElementById("enrMode").value;
                var submitBtn = document.getElementById("enrollSubmitBtn");

                /* Existing mode: an applicant must be picked from the combobox */
                if (mode === "existing" && !document.getElementById("enrApplicant").value) {
                    e.preventDefault();
                    showToast("Type and select an applicant from the suggestions.", "error");
                    if (appSearch) appSearch.focus();
                    return;
                }

                /* Photo required ONLY on create (walk-in or new applicant).
                   On EDIT the applicant already has a record — a missing
                   photo preview must not block saving the enrollment
                   (V5.45 fix for "cannot save the changes"). */
                var isEdit = document.getElementById("enrAction").value === "update";
                var photoFile = document.getElementById("wfPhoto");
                var photoPreview = document.getElementById("enrPhotoPreview");
                var hasUpload = photoFile && photoFile.files && photoFile.files.length > 0;
                var hasFetched = photoPreview && photoPreview.style.display !== "none" && photoPreview.src;
                if (!isEdit && !hasUpload && !hasFetched) {
                    e.preventDefault();
                    showToast("A photo is required for enrollment — upload one, or pick an existing applicant who has a photo.", "error");
                    if (photoFile) photoFile.focus();
                    return;
                }

                var email = (document.getElementById("wfEmail").value || "").trim().toLowerCase();
                if (mode !== "walkin" || email === "") return; // server handles the rest
                e.preventDefault();
                if (submitBtn) submitBtn.disabled = true;
                fetch(CHECK_URL + "?email=" + encodeURIComponent(email), { headers: { "X-Requested-With": "fetch" } })
                    .then(function (r) { return r.json(); })
                    .then(function (d) {
                        if (submitBtn) submitBtn.disabled = false;
                        if (d.exists) {
                            showToast("An applicant already exists with that email — switch to Existing Applicant or use a different email.", "error");
                            // keep the modal open so the user can correct it
                            return;
                        }
                        enrollForm.submit();
                    })
                    .catch(function () {
                        if (submitBtn) submitBtn.disabled = false;
                        enrollForm.submit(); // fall back to server-side check
                    });
            });

            // Filter training batches by selected course
            var courseSel = document.getElementById("enrCourse");
            var trainingSel = document.getElementById("enrTraining");
            if (courseSel && trainingSel) {
                courseSel.addEventListener("change", function () {
                    var cid = courseSel.value;
                    Array.from(trainingSel.options).forEach(function (o) {
                        var show = o.value === "" || o.dataset.course === cid;
                        o.style.display = show ? "" : "none";
                    });
                    trainingSel.value = "";
                });
                // run once on load
                if (courseSel.value) courseSel.dispatchEvent(new Event("change"));
            }

            // Status modal — AJAX save + auto-reload (no full-page POST loop)
            var statusModal = document.getElementById("statusModal");
            var statusForm = document.getElementById("statusForm");
            function openStatus(d) {
                document.getElementById("statusId").value = d.id;
                document.getElementById("statusTarget").textContent = "Enrollment: " + d.no + " (current: " + d.status + ")";
                document.getElementById("statusSelect").value = d.status;
                statusModal.style.display = "flex";
            }
            document.querySelectorAll("[data-status]").forEach(function (b) {
                b.addEventListener("click", function () { try { openStatus(JSON.parse(b.dataset.status)); } catch (e) {} });
            });
            function closeStatus() { statusModal.style.display = "none"; }
            document.getElementById("statusClose").addEventListener("click", closeStatus);
            document.getElementById("statusCancel").addEventListener("click", closeStatus);
            statusModal.addEventListener("click", function (e) { if (e.target === statusModal) closeStatus(); });

            /* AJAX submit: prevent the normal POST reload (which could loop /
               require sign-out) — save via fetch, surface the server's flash
               message, then auto-reload to refresh the table. */
            var statusSubmitting = false;
            if (statusForm) statusForm.addEventListener("submit", function (e) {
                e.preventDefault();
                if (statusSubmitting) return;              // double-submit guard
                statusSubmitting = true;
                var fd = new FormData(statusForm);
                var btn = statusForm.querySelector('button[type="submit"]');
                var origBtn = btn ? btn.textContent : "";
                if (btn) { btn.disabled = true; btn.textContent = "Saving…"; }
                /* NOTE: statusForm.action resolves to the hidden <input name="action">
                   element (named-accessor gotcha) → use getAttribute('action'). */
                fetch(statusForm.getAttribute("action"), { method: "POST", body: fd })
                    .then(function (r) { return r.text(); })
                    .then(function (html) {
                        statusSubmitting = false;
                        if (btn) { btn.disabled = false; btn.textContent = origBtn; }
                        /* Parse the server-rendered flash so the reason is visible
                           (e.g. payment gate: "Marketing-endorsed enrollment
                           requires payment first…") instead of a silent reload. */
                        var msg = "", type = "success";
                        try {
                            var doc = new DOMParser().parseFromString(html, "text/html");
                            var fl = doc.getElementById("enrollFlash");
                            if (fl) { msg = (fl.textContent || "").trim(); type = fl.getAttribute("data-type") || "success"; }
                        } catch (err) {}
                        if (msg === "") msg = "Enrollment status updated.";
                        closeStatus();
                        if (type === "error") {
                            showToast(msg, "error");          // blocked — keep the page, show why
                            return;
                        }
                        /* success — persist the toast across the auto-reload */
                        try { sessionStorage.setItem("usmci_status_flash", JSON.stringify({ m: msg, t: type })); } catch (err) {}
                        window.location.reload();
                    })
                    .catch(function () {
                        statusSubmitting = false;
                        if (btn) { btn.disabled = false; btn.textContent = origBtn; }
                        showToast("Could not update the status.", "error");
                    });
            });
            /* restore the status-update toast after the auto-reload */
            try {
                var sf = sessionStorage.getItem("usmci_status_flash");
                if (sf) {
                    sessionStorage.removeItem("usmci_status_flash");
                    var sfj = JSON.parse(sf);
                    if (sfj && sfj.m) showToast(sfj.m, sfj.t || "success");
                }
            } catch (err) {}

            /* ============ Requirements modal (V5.38) ============ */
            var reqModal = document.getElementById("reqModal");
            var reqBody = document.getElementById("reqBody");
            var REQ_URL = <?= json_encode(base_url('sections/admissions/admin/enrollment_requirements.php')); ?>;

            function escReq(s) { return String(s ?? "").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;"); }

            function openReq(d) {
                document.getElementById("reqTarget").textContent = d.no + " · " + d.app + " — " + d.course;
                reqModal.style.display = "flex";
                reqBody.innerHTML = '<p class="field-hint">Loading requirements…</p>';
                fetch(REQ_URL + "?enrollment_id=" + d.id)
                    .then(function (r) { return r.json(); })
                    .then(function (data) {
                        if (!data.success) { reqBody.innerHTML = '<p class="field-hint" style="color:#E11D48;">' + escReq(data.message) + '</p>'; return; }
                        if (data.required.length === 0) {
                            reqBody.innerHTML = '<p class="field-hint">No required documents configured for this course yet — set them at Settings → Requirements Matrix.</p>';
                            return;
                        }
                        var html = "";
                        data.required.forEach(function (it) {
                            var src = it.source === "upload" ? "🟢 uploaded by trainee" : (it.source === "staff" ? "☑ received (staff)" : "— not yet");
                            var ok = !!it.submitted;
                            html += '<div data-type="' + it.type_id + '" data-enr="' + d.id + '" class="req-row" data-ok="' + (ok ? "1" : "0") + '" style="display:flex;align-items:center;gap:12px;border:1px solid #E2E8F0;border-radius:10px;padding:10px 14px;background:' + (ok ? "#D9F2EC" : "#F8FAFC") + ';">'
                                + '<div style="flex:1;">'
                                + '<strong style="font-size:.88rem;color:#0B3C5D;">' + escReq(it.name) + '</strong>'
                                + '<div style="font-size:.74rem;color:#5B6472;">' + escReq(it.code) + ' · status: ' + escReq(src) + (it.marked_at ? ' · marked ' + escReq(it.marked_at.slice(0,10)) : '') + '</div>'
                                + (it.doc_title ? '<div style="font-size:.74rem;color:#0D8A72;">📎 ' + escReq(it.doc_title) + '</div>' : '')
                                + '</div>'
                                + '<span class="docs-badge ' + (ok ? "docs-ok" : "docs-none") + '" style="min-width:64px;">' + (ok ? "OK" : "MISSING") + '</span>'
                                + '<button type="button" class="btn-secondary btn-sm req-toggle" style="min-width:128px;">' + (ok ? "✗ Mark Missing" : "✓ Mark Received") + '</button>'
                                + '</div>';
                        });
                        reqBody.innerHTML = html;
                        /* explicit vice-versa button toggles staff "received"
                           (state comes from data-ok, never from CSS colors) */
                        reqBody.querySelectorAll(".req-toggle").forEach(function (btn) {
                            btn.addEventListener("click", function (e) {
                                e.stopPropagation();
                                var row = btn.closest(".req-row");
                                var typeId = row.dataset.type, enrId = row.dataset.enr;
                                var newVal = row.dataset.ok === "1" ? "0" : "1";
                                var fd = new FormData();
                                fd.append("csrf_token", <?= json_encode(csrf_token()); ?>);
                                fd.append("action", "mark");
                                fd.append("enrollment_id", enrId);
                                fd.append("document_type_id", typeId);
                                fd.append("value", newVal);
                                btn.disabled = true;
                                btn.textContent = "Saving…";
                                fetch(REQ_URL, { method: "POST", body: fd })
                                    .then(function (r) { return r.json(); })
                                    .then(function (res) {
                                        showToast(res.message || "Saved.", res.success ? "success" : "error");
                                        openReq(d); // refresh the checklist
                                        refreshRowDocsBadge(enrId);
                                    })
                                    .catch(function () {
                                        btn.disabled = false; btn.textContent = "Retry";
                                        showToast("Could not update the requirement.", "error");
                                    });
                            });
                        });
                    })
                    .catch(function () { reqBody.innerHTML = '<p class="field-hint" style="color:#E11D48;">Could not load requirements.</p>'; });
            }
            document.querySelectorAll("[data-req]").forEach(function (b) {
                b.addEventListener("click", function () { try { openReq(JSON.parse(b.dataset.req)); } catch (e) {} });
            });
            function closeReq() { reqModal.style.display = "none"; }
            document.getElementById("reqClose").addEventListener("click", closeReq);
            document.getElementById("reqCancel").addEventListener("click", closeReq);
            reqModal.addEventListener("click", function (e) { if (e.target === reqModal) closeReq(); });

            /* After a requirement toggle, live-update the enrollment row's
               "Docs: X/Y" badge so the list never looks stale (V5.42). */
            function refreshRowDocsBadge(enrollmentId) {
                var btn = document.querySelector('[data-req][data-idx="' + enrollmentId + '"]');
                /* find via JSON in data-req if no data-idx */
                if (!btn) {
                    var all = document.querySelectorAll("[data-req]");
                    all.forEach(function (b) {
                        try {
                            var dd = JSON.parse(b.dataset.req);
                            if (String(dd.id) === String(enrollmentId)) btn = b;
                        } catch (e) {}
                    });
                }
                if (!btn) return;
                var row = btn.closest("tr");
                if (!row) return;
                fetch(REQ_URL + "?enrollment_id=" + enrollmentId)
                    .then(function (r) { return r.json(); })
                    .then(function (data) {
                        if (!data.success || !data.counts) return;
                        var badge = row.querySelector(".docs-badge");
                        if (!badge) return;
                        var sub = data.counts.submitted, req = data.counts.required;
                        badge.textContent = sub + "/" + req;
                        badge.className = "docs-badge " + (req > 0 && sub >= req ? "docs-ok" : (sub > 0 ? "docs-part" : "docs-none"));
                    })
                    .catch(function () {});
            }

            // Search + filter
            var searchEl = document.getElementById("enrollSearch");
            var filterEl = document.getElementById("enrollStatusFilter");
            function go() {
                var url = window.location.pathname + "?";
                if (searchEl.value.trim()) url += "q=" + encodeURIComponent(searchEl.value.trim()) + "&";
                if (filterEl.value) url += "status=" + encodeURIComponent(filterEl.value);
                window.location = url;
            }
            if (searchEl) { var t; searchEl.addEventListener("keydown", function (e) { if (e.key === "Enter") go(); }); }
            if (filterEl) filterEl.addEventListener("change", go);
        })();
    </script>

</body>
</html>
