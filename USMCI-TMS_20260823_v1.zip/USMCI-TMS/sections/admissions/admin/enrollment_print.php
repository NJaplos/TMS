<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Enrollment Registration Slip (print)
 * File : sections/admissions/admin/enrollment_print.php
 * ---------------------------------------------------------
 * Printable registration slip matching the client's ISO
 * REGISTRATION SLIP (FORM NO.: W18.1-01-01 rev. 01).
 *   - Header: USMCI logo + address/contacts + PHOTO HERE box
 *   - "Assessed by" = the logged-in staff's full name
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/config/bootstrap.php';

require_access('enrollment');

$enrollmentId = (int) ($_GET['enrollment_id'] ?? 0);
if (!$enrollmentId) {
    exit('Missing enrollment id.');
}

$pdo = db();

$stmt = $pdo->prepare(
    "SELECT e.*, a.first_name, a.middle_name, a.last_name, a.birth_date, a.mobile_no, a.email,
            ap.rank_position, ap.seafarer_id_no, ap.sirb_no, ap.passport_no, ap.photo_path,
            ap.place_of_birth, ap.address_line1, ap.address_line2, ap.postal_code,
            c.course_name, c.code AS course_code, c.price_amount,
            t.training_no, t.batch_name, t.start_date, t.end_date, t.venue,
            comp.company_name
     FROM enrollment e
     JOIN applicant a ON a.id = e.applicant_id
     LEFT JOIN applicant_profile ap ON ap.applicant_id = a.id
     JOIN mnt_course c ON c.id = e.course_id
     LEFT JOIN training t ON t.id = e.training_id
     LEFT JOIN mnt_company comp ON comp.id = e.company_id
     WHERE e.id = :id LIMIT 1"
);
$stmt->execute(['id' => $enrollmentId]);
$e = $stmt->fetch();

if (!$e) {
    exit('Enrollment not found.');
}

$payStmt = $pdo->prepare("SELECT total_amount, paid_amount, balance_amount FROM payment WHERE enrollment_id = :id ORDER BY id DESC LIMIT 1");
$payStmt->execute(['id' => $enrollmentId]);
$pay = $payStmt->fetch() ?: null;

$fullName = trim(($e['first_name'] ?? '') . ' ' . ($e['middle_name'] ?? '') . ' ' . ($e['last_name'] ?? ''));
$fullName = trim(preg_replace('/\s+/', ' ', $fullName));
$address  = trim(implode(', ', array_filter([$e['address_line1'] ?? '', $e['address_line2'] ?? '', $e['postal_code'] ?? ''])));
$assessedBy = trim((string) (current_user()['full_name'] ?? ''));
if ($assessedBy === '') { $assessedBy = trim((string) (current_user()['username'] ?? '')); }

/* Logo (base64-embedded so it always prints even when the web root differs) */
$logoB64 = '';
$logoPath = BASE_PATH . '/assets/images/branding/logo-light3.png';
if (is_file($logoPath)) {
    $logoB64 = 'data:image/png;base64,' . base64_encode(file_get_contents($logoPath));
}

/* Photo (base64-embedded) */
$photoSrc = '';
$photoFile = !empty($e['photo_path']) ? BASE_PATH . '/' . ltrim($e['photo_path'], '/') : '';
if ($photoFile !== '' && is_file($photoFile)) {
    $mime = strtolower(pathinfo($photoFile, PATHINFO_EXTENSION)) === 'png' ? 'image/png' : 'image/jpeg';
    $photoSrc = 'data:' . $mime . ';base64,' . base64_encode(file_get_contents($photoFile));
}

$remark = $e['remarks'] !== '' && $e['remarks'] !== null ? $e['remarks'] : '';

/* Letterhead from Settings → Report Letterhead (fallback = school default) */
$lhOrgName    = report_setting('report_org_name', 'UNITED SEAFARERS MARITIME CENTER INC');
$lhOrgAddress = report_setting('report_org_address', 'G/F YMCA OF MANILA BLDG 350 ANTONIO VILLEGAS ST ERMITA MANILA');
$lhTelNo      = report_setting('report_tel_no', 'TEL NO: 8241-0881');
$lhMobileNo   = report_setting('report_mobile_no', 'MOBILE NO: 09971201553');
$lhEmail      = report_setting('report_email', 'usmci2010@gmail.com');

/* Time of Training from the batch's session schedule (training_schedule) */
$timeOfTraining = '';
if (!empty($e['training_id'])) {
    $ts = $pdo->prepare(
        "SELECT start_time, end_time, COUNT(*) AS sessions
         FROM training_schedule WHERE training_id = :tid
         GROUP BY start_time, end_time ORDER BY start_time LIMIT 3"
    );
    $ts->execute(['tid' => (int) $e['training_id']]);
    $rows = $ts->fetchAll();
    if ($rows) {
        $times = [];
        foreach ($rows as $r) {
            $times[] = date('g:i A', strtotime($r['start_time'])) . ' – ' . date('g:i A', strtotime($r['end_time']));
        }
        $timeOfTraining = implode(' · ', array_unique($times));
    }
}
if ($timeOfTraining === '') {
    /* fall back to the batch name + date range */
    $timeOfTraining = trim(($e['batch_name'] ?? '') . (($e['start_date'] && $e['end_date']) ? ' (' . date('m/d', strtotime($e['start_date'])) . '–' . date('m/d/Y', strtotime($e['end_date'])) . ')' : ''));
}

function cell(string $label, ?string $value): string
{
    return '<div class="fcell"><span class="flabel">' . $label . '</span><div class="fval">' . htmlspecialchars((string) ($value === null || $value === '' ? '' : $value), ENT_QUOTES, 'UTF-8') . '</div></div>';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Registration Form — <?= htmlspecialchars($e['enrollment_no'], ENT_QUOTES); ?></title>
<style>
    * { margin:0; padding:0; box-sizing:border-box; }
    body { font-family:Arial, Helvetica, sans-serif; color:#111; font-size:13px; padding:20px; }
    .sheet { max-width:840px; margin:0 auto; border:1px solid #000; padding:16px 20px 20px; }
    .top { display:grid; grid-template-columns:1fr auto 1fr; gap:12px; align-items:start; border-bottom:2px solid #000; padding-bottom:10px; }
    .logo { width:170px; height:72px; display:flex; align-items:center; justify-content:center; overflow:hidden; justify-self:start; }
    .logo img { max-width:100%; max-height:100%; object-fit:contain; }
    .org { text-align:center; }
    .org .name { font-size:15px; font-weight:800; letter-spacing:.4px; }
    .org .addr { font-size:10px; margin-top:3px; }
    .org .contacts { font-size:10px; margin-top:2px; }
    .photo-box { width:88px; height:98px; border:1px solid #000; display:flex; align-items:center; justify-content:center; font-size:8.5px; color:#555; overflow:hidden; justify-self:end; }
    .photo-box img { width:100%; height:100%; object-fit:cover; }
    .title { text-align:center; font-weight:800; font-size:14px; padding:8px 0 2px; letter-spacing:1px; }
    .formno { text-align:center; font-size:9.5px; color:#333; margin-bottom:8px; }
    table { width:100%; border-collapse:collapse; table-layout:fixed; }
    td { border:1px solid #000; padding:5px 7px; vertical-align:top; }
    .lbl { font-size:8.5px; color:#555; display:block; text-transform:uppercase; letter-spacing:.3px; }
    .val { font-size:12.5px; font-weight:600; min-height:16px; margin-top:1px; }
    .half { width:50%; }
    .q { width:25%; }
    .note { font-size:9px; margin-top:10px; line-height:1.45; text-align:justify; }
    .cert-line { font-size:11px; margin-top:12px; }
    .sign { display:flex; justify-content:space-between; margin-top:48px; text-align:center; font-size:11px; }
    .sign .line { border-top:1px solid #000; padding-top:4px; min-width:250px; font-weight:700; }
    .actions { max-width:840px; margin:12px auto 0; text-align:right; }
    .btn { background:#0D8A72; color:#fff; border:none; padding:10px 22px; border-radius:8px; font-weight:700; cursor:pointer; font-size:13px; }
    @media print {
        body { padding:0; }
        .actions { display:none; }
        .sheet { border:none; }
    }
</style>
</head>
<body>
<div class="actions"><button class="btn" onclick="window.print()">🖨 Print / Save PDF</button></div>

<div class="sheet">
    <div class="top">
        <div class="logo"><?php if ($logoB64 !== ''): ?><img src="<?= htmlspecialchars($logoB64, ENT_QUOTES); ?>" alt="USMCI"><?php endif; ?></div>
        <div class="org">
            <div class="name"><?= htmlspecialchars($lhOrgName, ENT_QUOTES); ?></div>
            <div class="addr"><?= htmlspecialchars($lhOrgAddress, ENT_QUOTES); ?></div>
            <div class="contacts">
                <div><?= htmlspecialchars(trim($lhTelNo . '  ' . $lhMobileNo), ENT_QUOTES); ?></div>
                <div>EMAIL: <?= htmlspecialchars($lhEmail, ENT_QUOTES); ?></div>
            </div>
        </div>
        <div class="photo-box">
            <?php if ($photoSrc !== ''): ?>
                <img src="<?= htmlspecialchars($photoSrc, ENT_QUOTES); ?>" alt="photo">
            <?php else: ?>PHOTO HERE<?php endif; ?>
        </div>
    </div>

    <div class="title">REGISTRATION FORM</div>
    <div class="formno">FORM NO.: W18.1-01-01 rev. 01</div>

    <table>
        <tr>
            <td class="q"><?= cell('Registration No', $e['enrollment_no']); ?></td>
            <td class="q"><?= cell('SRN', $e['seafarer_id_no']); ?></td>
            <td class="q"><?= cell('Batch No', $e['training_no']); ?></td>
            <td class="q"><?= cell('Date', date('m/d/Y', strtotime($e['enrollment_date']))); ?></td>
        </tr>
        <tr>
            <td class="half" colspan="2"><?= cell('Rank', $e['rank_position']); ?></td>
            <td class="half" colspan="2"><?= cell('Name', $fullName); ?></td>
        </tr>
        <tr>
            <td class="half" colspan="2"><?= cell('Address', $address); ?></td>
            <td class="half" colspan="2"><?= cell('Contact No', $e['mobile_no']); ?></td>
        </tr>
        <tr>
            <td class="half" colspan="2"><?= cell('Birth Date', $e['birth_date']); ?></td>
            <td class="half" colspan="2"><?= cell('Birth Place', $e['place_of_birth']); ?></td>
        </tr>
        <tr>
            <td class="half" colspan="2"><?= cell('Email Add', $e['email']); ?></td>
            <td class="half" colspan="2"><?= cell('Co. / Endorser', trim(($e['endorsed_by'] ?? '') . ($e['company_name'] ? ' — ' . $e['company_name'] : ''))); ?></td>
        </tr>
        <tr>
            <td class="half" colspan="2"><?= cell('Course', $e['course_name']); ?></td>
            <td class="half" colspan="2"><?= cell('Time of Training', $timeOfTraining); ?></td>
        </tr>
        <tr>
            <td class="half" colspan="2"><?= cell('Training Sched', ($e['start_date'] && $e['end_date']) ? date('M d, Y', strtotime($e['start_date'])) . ' — ' . date('M d, Y', strtotime($e['end_date'])) : ''); ?></td>
            <td class="half" colspan="2"><?= cell('Course Fee', '₱ ' . number_format((float) $e['price_amount'], 2)); ?></td>
        </tr>
        <tr>
            <td><?= cell('Payment', '₱ ' . number_format((float) ($pay['paid_amount'] ?? 0), 2)); ?></td>
            <td><?= cell('Balance', '₱ ' . number_format((float) ($pay['balance_amount'] ?? $e['price_amount']), 2)); ?></td>
            <td colspan="2"><?= cell('Remark', (string) ($remark ?? '')); ?></td>
        </tr>
    </table>

    <p class="note">
        NOTE: KINDLY COME ON TIME. TRAINING WILL BE FORFEITED IF YOU MISSED THE TRAINING SCHEDULE. THE MANAGEMENT ALLOWS A
        15 MINUTE GRACE PERIOD, ANY EXTENSION THEREOF SHALL BE CONSIDERED ABSENT. THE TRAINEE, WHO INTENDS TO MAKE-UP THE
        TRAINING SHALL PAY 70% OF THE TOTAL COURSE FEE AS MISCELLANEOUS. CANCELLATION OF THE TRAINING WILL BE RESULTING TO
        FORFEITMENT OF THE TRAINING FEES.
    </p>

    <p class="cert-line">I hereby certify that the above details are true and correct.</p>

    <div class="sign">
        <div><div class="line"><?= htmlspecialchars($assessedBy, ENT_QUOTES); ?></div><div class="lbl" style="margin-top:4px;">Assessed by</div></div>
        <div>
            <div class="line"><?= htmlspecialchars($fullName, ENT_QUOTES); ?></div>
            <div class="lbl" style="margin-top:4px;">Trainee's Signature</div>
        </div>
    </div>
</div>

</body>
</html>
