<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Admin: Reports (V5.37)
 * File : sections/admissions/admin/reports.php
 * ---------------------------------------------------------
 * Operational summary with:
 *   - Date-range filter (from / to) applied to every KPI and list
 *   - Detail table per module (inquiries / applicants / enrollments /
 *     payments / certificates)
 *   - CSV export (same filters) via ?export=1&module=…
 *   - Revenue-by-month bar chart (pure CSS, last 6 months)
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/config/bootstrap.php';

require_access('reports');
if ($_SERVER['REQUEST_METHOD'] === 'POST') { require_edit('reports'); }

$pdo = db();

/* ---- Filters (validated) ---- */
$module = (string) ($_GET['module'] ?? 'enrollments');
$modules = ['inquiries', 'applicants', 'enrollments', 'payments', 'certificates'];
if (!in_array($module, $modules, true)) { $module = 'enrollments'; }

$from = trim((string) ($_GET['from'] ?? ''));
$to   = trim((string) ($_GET['to'] ?? ''));
if ($from !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $from)) { $from = ''; }
if ($to   !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $to))   { $to   = ''; }

$dateWhere = '';
$dateParams = [];
if ($from !== '') { $dateWhere .= ' AND DATE(%1$s.created_at) >= :dfrom'; $dateParams['dfrom'] = $from; }
if ($to   !== '') { $dateWhere .= ' AND DATE(%1$s.created_at) <= :dto';   $dateParams['dto']   = $to;   }

/* ---- Per-module query config (for list + CSV) ---- */
$moduleCfg = [
    'inquiries' => [
        'label'   => 'Inquiries',
        'icon'    => '📨',
        'table'   => 'inquiry',
        'alias'   => 'i',
        'sql'     => "SELECT i.inquiry_no, i.full_name, i.email, i.mobile_no, i.course_interest, i.subject, COALESCE(s.label,'New') AS status_label, i.created_at
                      FROM inquiry i LEFT JOIN mnt_inquiry_status s ON s.id = i.status_id",
        'headers' => ['Inquiry No.', 'Applicant', 'Email', 'Mobile', 'Course', 'Subject', 'Status', 'Date'],
        'cols'    => ['inquiry_no', 'full_name', 'email', 'mobile_no', 'course_interest', 'subject', 'status_label', 'created_at'],
    ],
    'applicants' => [
        'label'   => 'Applicants',
        'icon'    => '👥',
        'table'   => 'applicant',
        'alias'   => 'a',
        'sql'     => "SELECT a.applicant_no, a.first_name, a.middle_name, a.last_name, a.email, a.mobile_no, a.created_at
                      FROM applicant a",
        'headers' => ['Applicant No.', 'First Name', 'Middle Name', 'Last Name', 'Email', 'Mobile', 'Date'],
        'cols'    => ['applicant_no', 'first_name', 'middle_name', 'last_name', 'email', 'mobile_no', 'created_at'],
    ],
    'enrollments' => [
        'label'   => 'Enrollments',
        'icon'    => '📝',
        'table'   => 'enrollment',
        'alias'   => 'e',
        'sql'     => "SELECT e.enrollment_no, a.first_name, a.last_name, c.code AS course_code, c.course_name, t.training_no, e.status, e.endorser_type, e.enrollment_date
                      FROM enrollment e
                      LEFT JOIN applicant a ON a.id = e.applicant_id
                      LEFT JOIN mnt_course c ON c.id = e.course_id
                      LEFT JOIN training t ON t.id = e.training_id",
        'headers' => ['Enrollment No.', 'First Name', 'Last Name', 'Course Code', 'Course', 'Batch', 'Status', 'Endorser', 'Enrollment Date'],
        'cols'    => ['enrollment_no', 'first_name', 'last_name', 'course_code', 'course_name', 'training_no', 'status', 'endorser_type', 'enrollment_date'],
    ],
    'payments' => [
        'label'   => 'Payments',
        'icon'    => '💳',
        'table'   => 'payment',
        'alias'   => 'p',
        'sql'     => "SELECT p.payment_no, a.first_name, a.last_name, e.enrollment_no, p.total_amount, p.paid_amount, p.balance_amount, COALESCE(ps.name,'Unpaid') AS status_name, p.created_at
                      FROM payment p
                      LEFT JOIN applicant a ON a.id = p.applicant_id
                      LEFT JOIN enrollment e ON e.id = p.enrollment_id
                      LEFT JOIN mnt_payment_status ps ON ps.id = p.payment_status_id",
        'headers' => ['Payment No.', 'First Name', 'Last Name', 'Enrollment', 'Total (₱)', 'Paid (₱)', 'Balance (₱)', 'Status', 'Date'],
        'cols'    => ['payment_no', 'first_name', 'last_name', 'enrollment_no', 'total_amount', 'paid_amount', 'balance_amount', 'status_name', 'created_at'],
    ],
    'certificates' => [
        'label'   => 'Certificates',
        'icon'    => '📜',
        'table'   => 'certificate',
        'alias'   => 'c',
        'sql'     => "SELECT c.certificate_no, a.first_name, a.last_name, c.course_name_override, c.issued_date, c.expiry_date, c.status, c.created_at
                      FROM certificate c
                      LEFT JOIN applicant a ON a.id = c.applicant_id",
        'headers' => ['Certificate No.', 'First Name', 'Last Name', 'Course', 'Issued', 'Expiry', 'Status', 'Date'],
        'cols'    => ['certificate_no', 'first_name', 'last_name', 'course_name_override', 'issued_date', 'expiry_date', 'status', 'created_at'],
    ],
];

/* ---- CSV EXPORT (stream before any HTML) ---- */
if (($_GET['export'] ?? '') === '1') {
    $cfg = $moduleCfg[$module];
    $sql = $cfg['sql'] . ' WHERE 1 = 1'
        . str_replace('%1$s', $cfg['alias'], $dateWhere)
        . ' ORDER BY ' . $cfg['alias'] . '.id DESC LIMIT 10000';
    $stmt = $pdo->prepare($sql);
    $stmt->execute($dateParams);
    $rows = $stmt->fetchAll();

    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $module . '-' . date('Ymd') . '.csv"');
    $out = fopen('php://output', 'w');
    fwrite($out, "\xEF\xBB\xBF"); // UTF-8 BOM so Excel opens ₱ etc. correctly
    fputcsv($out, $cfg['headers']);
    foreach ($rows as $r) {
        $line = [];
        foreach ($cfg['cols'] as $c) {
            $v = $r[$c] ?? '';
            if (in_array($c, ['total_amount', 'paid_amount', 'balance_amount'], true) && $v !== '') {
                $v = number_format((float) $v, 2);
            }
            $line[] = $v;
        }
        fputcsv($out, $line);
    }
    fclose($out);
    exit;
}

/* ---- KPI tiles (respect the date range) ---- */
function rangeCount(PDO $pdo, string $table, string $dateWhere, array $dateParams, string $col = 'id'): int
{
    $sql = "SELECT COUNT(*) FROM $table WHERE 1 = 1" . str_replace('%1$s', $table, $dateWhere);
    $stmt = $pdo->prepare($sql);
    $stmt->execute($dateParams);
    return (int) $stmt->fetchColumn();
}

$stats = [
    'inquiries'   => rangeCount($pdo, 'inquiry', $dateWhere, $dateParams),
    'applicants'  => rangeCount($pdo, 'applicant', $dateWhere, $dateParams),
    'enrollments' => rangeCount($pdo, 'enrollment', $dateWhere, $dateParams),
    'payments'    => rangeCount($pdo, 'payment', $dateWhere, $dateParams),
    'certs'       => rangeCount($pdo, 'certificate', $dateWhere, $dateParams),
];
$revKpiStmt = $pdo->prepare("SELECT COALESCE(SUM(paid_amount),0) FROM payment WHERE 1 = 1" . str_replace('%1$s', 'payment', $dateWhere));
$revKpiStmt->execute($dateParams);
$stats['revenue'] = (float) $revKpiStmt->fetchColumn();

/* Inquiries by status (respect range) */
$byStatus = $pdo->prepare(
    "SELECT COALESCE(s.label, 'New') AS label, COUNT(*) AS n
     FROM inquiry i LEFT JOIN mnt_inquiry_status s ON s.id = i.status_id
     WHERE 1 = 1" . str_replace('%1$s', 'i', $dateWhere) . "
     GROUP BY s.label ORDER BY n DESC"
);
$byStatus->execute($dateParams);
$byStatus = $byStatus->fetchAll() ?: [];

/* Revenue by month — last 6 months (pure CSS bars) */
$revSql = "SELECT DATE_FORMAT(p.created_at, '%Y-%m') AS ym, SUM(paid_amount) AS total
           FROM payment p
           WHERE p.created_at >= DATE_SUB(CURDATE(), INTERVAL 5 MONTH)
             AND p.payment_status_id NOT IN (4,5)"
    . str_replace('%1$s', 'p', $dateWhere) . "
           GROUP BY ym ORDER BY ym";
$revStmt = $pdo->prepare($revSql);
$revStmt->execute($dateParams);
$revByMonth = [];
foreach ($revStmt->fetchAll() ?: [] as $r) { $revByMonth[$r['ym']] = (float) $r['total']; }

$months = [];
for ($i = 5; $i >= 0; $i--) {
    $months[] = date('Y-m', strtotime("-$i months"));
}
$maxRev = max(array_values($revByMonth) ?: [1]);

/* Detail rows for the selected module */
$cfg = $moduleCfg[$module];
$listStmt = $pdo->prepare(
    $cfg['sql'] . ' WHERE 1 = 1'
    . str_replace('%1$s', $cfg['alias'], $dateWhere)
    . ' ORDER BY ' . $cfg['alias'] . '.id DESC LIMIT 300'
);
$listStmt->execute($dateParams);
$listRows = $listStmt->fetchAll() ?: [];

$page = [
    'title'       => 'Reports | USMCI-TMS',
    'description' => 'Reports',
    'bodyClass'   => 'admissions-page',
];
?>
<!DOCTYPE html>
<html lang="en">

<?php include INCLUDES_PATH . '/head.php'; ?>

<link rel="stylesheet" href="<?= e(base_url('assets/css/portal.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/workspace.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/inquiry-queue/assets/css/page.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/admin/dashboard.css?v=' . ASSET_VERSION)); ?>">

<body class="<?= e($page['bodyClass']); ?>">

    <?php include NAVBAR_PATH . '/index.php'; ?>

    <section class="portal-shell portal-shell--2col">

        <?php require ADMISSIONS_PATH . '/inquiry-queue/partials/sidebar.php'; ?>

        <main class="portal-content admin-dashboard">

            <header class="workspace-header">
                <div class="workspace-header__left">
                    <span class="section-badge">Analytics</span>
                    <h1>Reports</h1>
                    <p>Operational summary of the admissions pipeline.</p>
                </div>
                <div class="workspace-header__right">
                    <a class="btn-secondary btn-sm" style="text-decoration:none;" href="<?= e(base_url('sections/admissions/admin/audit-log.php')); ?>">📋 Audit Log</a>
                </div>
            </header>

            <!-- ================= PRINTABLE FORM REPORTS ================= -->
            <section class="dash-panel" style="margin-top:18px;">
                <div class="dash-panel__head"><h2>🖨 Printable Form Reports</h2></div>
                <p class="field-hint" style="margin:0 0 12px;">Signed enrollment forms with the USMCI letterhead (editable at Settings → Report Letterhead). Filter by course / batch / date and print or export CSV.</p>
                <div style="display:flex;gap:12px;flex-wrap:wrap;">
                    <a class="btn-primary" style="text-decoration:none;display:inline-flex;align-items:center;height:42px;padding:0 18px;border-radius:10px;font-weight:700;font-size:.88rem;"
                       href="<?= e(base_url('sections/admissions/admin/report_form.php?type=enrollment_list')); ?>" target="_blank">
                        📋 Enrollment List (with signature)
                    </a>
                    <a class="btn-primary" style="text-decoration:none;display:inline-flex;align-items:center;height:42px;padding:0 18px;border-radius:10px;font-weight:700;font-size:.88rem;background:#0D8A72;"
                       href="<?= e(base_url('sections/admissions/admin/report_form.php?type=enrollment_status')); ?>" target="_blank">
                        🚦 Enrollment Status
                    </a>
                </div>
            </section>

            <!-- ================= FILTERS + EXPORT ================= -->
            <form method="get" action="<?= e(base_url('sections/admissions/admin/reports.php')); ?>" class="dash-panel" style="display:flex;flex-wrap:wrap;gap:12px;align-items:flex-end;padding:16px 18px;">
                <div class="t-field" style="margin:0;">
                    <label>From</label>
                    <input type="date" name="from" value="<?= e($from); ?>">
                </div>
                <div class="t-field" style="margin:0;">
                    <label>To</label>
                    <input type="date" name="to" value="<?= e($to); ?>">
                </div>
                <div class="t-field" style="margin:0;">
                    <label>Module</label>
                    <select name="module">
                        <?php foreach ($modules as $m): ?>
                            <option value="<?= e($m); ?>" <?= $module === $m ? 'selected' : ''; ?>><?= e($moduleCfg[$m]['label']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <button type="submit" class="btn-primary" style="height:42px;padding:0 18px;border:none;border-radius:10px;font-weight:700;background:#0D8A72;color:#fff;cursor:pointer;">Apply</button>
                <a class="btn-secondary" style="text-decoration:none;display:inline-flex;align-items:center;height:42px;padding:0 18px;border-radius:10px;font-weight:700;"
                   href="<?= e(base_url('sections/admissions/admin/reports.php?export=1&module=' . $module . ($from ? '&from=' . $from : '') . ($to ? '&to=' . $to : ''))); ?>">⬇ Export CSV</a>
            </form>

            <?php if ($from !== '' || $to !== ''): ?>
                <p class="field-hint" style="margin:6px 0 0;">
                    <?= $from ? 'From <strong>' . e($from) . '</strong>' : ''; ?>
                    <?= ($from !== '' && $to !== '') ? ' → ' : ''; ?>
                    <?= $to ? 'To <strong>' . e($to) . '</strong>' : ''; ?>
                    — applied to all tiles and lists below.
                </p>
            <?php endif; ?>

            <div class="kpi-grid" style="margin-top:18px;">
                <div class="kpi-card"><div class="kpi-card__icon" style="background:#EAF6F2;">📨</div><div><div class="kpi-card__value"><?= number_format($stats['inquiries']); ?></div><div class="kpi-card__label">Inquiries</div></div></div>
                <div class="kpi-card"><div class="kpi-card__icon" style="background:#EFF6FF;">👥</div><div><div class="kpi-card__value"><?= number_format($stats['applicants']); ?></div><div class="kpi-card__label">Applicants</div></div></div>
                <div class="kpi-card"><div class="kpi-card__icon" style="background:#FEF3C7;">📝</div><div><div class="kpi-card__value"><?= number_format($stats['enrollments']); ?></div><div class="kpi-card__label">Enrollments</div></div></div>
                <div class="kpi-card"><div class="kpi-card__icon" style="background:#DCFCE7;">💳</div><div><div class="kpi-card__value">₱ <?= number_format($stats['revenue'], 2); ?></div><div class="kpi-card__label">Payments Received</div></div></div>
                <div class="kpi-card"><div class="kpi-card__icon" style="background:#FFE4E6;">📜</div><div><div class="kpi-card__value"><?= number_format($stats['certs']); ?></div><div class="kpi-card__label">Certificates</div></div></div>
            </div>

            <!-- ================= REVENUE BY MONTH (CSS bars) ================= -->
            <section class="dash-panel" style="margin-top:18px;">
                <div class="dash-panel__head"><h2>Revenue by Month (last 6 months)</h2></div>
                <div style="display:flex;align-items:flex-end;gap:14px;height:180px;padding:16px 6px 0;overflow-x:auto;">
                    <?php foreach ($months as $m): $tot = $revByMonth[$m] ?? 0.0; $h = $tot > 0 ? max(6, (int) round(($tot / $maxRev) * 150)) : 2; ?>
                        <div style="flex:1;min-width:52px;display:flex;flex-direction:column;align-items:center;gap:6px;">
                            <div style="width:100%;max-width:56px;height:<?= $h; ?>px;background:linear-gradient(180deg,#0D8A72,#0B3C5D);border-radius:6px 6px 0 0;<?= $tot > 0 ? '' : 'opacity:.25;'; ?>"></div>
                            <div style="font-size:.72rem;font-weight:700;color:#0B3C5D;">₱<?= number_format($tot); ?></div>
                            <div style="font-size:.68rem;color:#5B6472;"><?= e(date('M y', strtotime($m . '-01'))); ?></div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </section>

            <!-- ================= INQUIRIES BY STATUS ================= -->
            <section class="dash-panel" style="margin-top:18px;">
                <div class="dash-panel__head"><h2>Inquiries by Status</h2></div>
                <div class="table-responsive">
                    <table class="inquiry-table">
                        <thead><tr><th>Status</th><th>Count</th></tr></thead>
                        <tbody>
                            <?php foreach ($byStatus as $r): ?>
                                <tr><td><?= e($r['label']); ?></td><td><?= number_format((int) $r['n']); ?></td></tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </section>

            <!-- ================= DETAIL LIST (selected module) ================= -->
            <section class="dash-panel" style="margin-top:18px;">
                <div class="dash-panel__head">
                    <h2><?= $cfg['icon']; ?> <?= e($cfg['label']); ?> (<?= count($listRows); ?>)</h2>
                </div>
                <div class="table-responsive">
                    <table class="inquiry-table">
                        <thead><tr>
                            <?php foreach ($cfg['headers'] as $hd): ?><th><?= e($hd); ?></th><?php endforeach; ?>
                        </tr></thead>
                        <tbody>
                            <?php if (!$listRows): ?>
                                <tr><td colspan="<?= count($cfg['headers']); ?>" style="text-align:center;color:#5B6472;padding:22px;">No records in this range.</td></tr>
                            <?php endif; ?>
                            <?php foreach ($listRows as $r): ?>
                                <tr>
                                    <?php foreach ($cfg['cols'] as $c):
                                        $v = $r[$c] ?? '';
                                        if (in_array($c, ['total_amount', 'paid_amount', 'balance_amount'], true) && $v !== '') {
                                            $v = '₱ ' . number_format((float) $v, 2);
                                        }
                                    ?><td><?= e((string) $v); ?></td><?php endforeach; ?>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </section>

        </main>
    </section>

    <?php include INCLUDES_PATH . '/footer.php'; ?>
    <?php include INCLUDES_PATH . '/scripts.php'; ?>

</body>
</html>
