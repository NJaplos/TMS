<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Admin: Staff Accounts
 * File : sections/admissions/admin/staff-accounts.php
 * ---------------------------------------------------------
 * Create / manage staff accounts (admin, admissions officer,
 * registrar, accounting, instructor).
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/config/bootstrap.php';

require_access('staff_accounts');
if ($_SERVER['REQUEST_METHOD'] === 'POST') { require_edit('staff_accounts'); }

$pdo = db();

/* ---- Only admins can manage accounts ---- */
$isAdmin = (current_user()['role_code'] ?? '') === 'ADMIN';
if (!$isAdmin) {
    header('Location: ' . base_url('sections/admissions/admin/index.php?flash=err&msg=' . urlencode('Only administrators can manage staff accounts.')));
    exit;
}

$flash = ['type' => null, 'message' => null];

/* ==========================================================
   Handle POST (create / update / toggle / reset)
========================================================== */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = $_POST['action'] ?? '';

    try {
        if ($action === 'create') {
            $username = trim((string) ($_POST['username'] ?? ''));
            $email    = trim((string) ($_POST['email'] ?? ''));
            $fullName = trim((string) ($_POST['full_name'] ?? ''));
            $mobile   = trim((string) ($_POST['mobile_no'] ?? ''));
            $roleId   = (int) ($_POST['role_id'] ?? 0);
            $password = (string) ($_POST['password'] ?? '');

            if ($username === '' || $email === '' || $fullName === '' || !$roleId || strlen($password) < 8) {
                $flash = ['type' => 'error', 'message' => 'All fields are required and password must be at least 8 characters.'];
            } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $flash = ['type' => 'error', 'message' => 'Enter a valid email address.'];
            } else {
                $statusActive = (int) $pdo->query("SELECT id FROM mnt_user_status WHERE code = 'ACTIVE' LIMIT 1")->fetchColumn() ?: 1;
                $pdo->prepare(
                    "INSERT INTO sys_user (role_id, username, email, password_hash, full_name, mobile_no, status_id, created_at)
                     VALUES (:r, :u, :e, :h, :fn, :m, :s, NOW())"
                )->execute([
                    'r' => $roleId, 'u' => $username, 'e' => $email,
                    'h' => password_hash($password, PASSWORD_DEFAULT),
                    'fn' => $fullName, 'm' => $mobile, 's' => $statusActive,
                ]);
                $newId = (int) $pdo->lastInsertId();
                audit_log('staff', 'create', $newId, "Staff account '{$username}' created (role id {$roleId})");
                $flash = ['type' => 'success', 'message' => "Staff account '{$username}' created."];
            }
        }

        elseif ($action === 'reset') {
            $id = (int) ($_POST['staff_id'] ?? 0);
            $newPass = (string) ($_POST['new_password'] ?? '');
            if ($id && strlen($newPass) >= 8) {
                $pdo->prepare("UPDATE sys_user SET password_hash = :h, failed_login_count = 0, locked_until = NULL WHERE id = :id")
                    ->execute(['h' => password_hash($newPass, PASSWORD_DEFAULT), 'id' => $id]);
                audit_log('staff', 'reset_password', $id, "Password reset for staff #{$id}");
                $flash = ['type' => 'success', 'message' => 'Password reset.'];
            } else {
                $flash = ['type' => 'error', 'message' => 'Password must be at least 8 characters.'];
            }
        }

        elseif ($action === 'toggle') {
            $id = (int) ($_POST['staff_id'] ?? 0);
            if ($id && $id !== (int) current_user()['id']) {
                $cur = (int) $pdo->prepare("SELECT status_id FROM sys_user WHERE id = ?")->execute([$id]) ?: 1;
                $stmt = $pdo->prepare("SELECT status_id FROM sys_user WHERE id = :id");
                $stmt->execute(['id' => $id]);
                $cur = (int) $stmt->fetchColumn();
                $new = $cur === 1 ? 2 : 1; // 1=ACTIVE, 2=PENDING/disabled
                $pdo->prepare("UPDATE sys_user SET status_id = :s WHERE id = :id")->execute(['s' => $new, 'id' => $id]);
                audit_log('staff', 'toggle', $id, 'Account ' . ($new === 1 ? 'enabled' : 'disabled') . ' (staff #' . $id . ')');
                $flash = ['type' => 'success', 'message' => 'Account ' . ($new === 1 ? 'enabled.' : 'disabled.')];
            } else {
                $flash = ['type' => 'error', 'message' => 'You cannot disable your own account.'];
            }
        }
    } catch (Throwable $e) {
        error_log('staff-accounts: ' . $e->getMessage());
        $dup = strpos($e->getMessage(), 'Duplicate entry') !== false;
        $flash = ['type' => 'error', 'message' => $dup ? 'That username or email is already in use.' : 'Could not save. Please try again.'];
    }
}

/* ---- Roles + staff list ---- */
$roles = $pdo->query("SELECT id, code, name FROM sys_role WHERE is_active = 1 ORDER BY name")->fetchAll();
$roleFilter = trim((string) ($_GET['role'] ?? ''));
$staffSql = "SELECT u.*, r.name AS role_name, r.code AS role_code
             FROM sys_user u
             LEFT JOIN sys_role r ON r.id = u.role_id";
$staffParams = [];
if ($roleFilter !== '') {
    $staffSql .= " WHERE r.code = :role";
    $staffParams['role'] = $roleFilter;
}
$staffSql .= " ORDER BY u.id";
$staffStmt = $pdo->prepare($staffSql);
$staffStmt->execute($staffParams);
$staff = $staffStmt->fetchAll();

$page = [
    'title'       => 'Staff Accounts | USMCI-TMS',
    'description' => 'Staff Accounts',
    'bodyClass'   => 'admissions-page',
];
?>
<!DOCTYPE html>
<html lang="en">

<?php include INCLUDES_PATH . '/head.php'; ?>

<link rel="stylesheet" href="<?= e(base_url('assets/css/portal.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/workspace.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/inquiry-queue/assets/css/page.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/admin/dashboard.css?v=' . ASSET_VERSION)); ?>">

<body class="<?= e($page['bodyClass']); ?>">

    <?php include NAVBAR_PATH . '/index.php'; ?>

    <section class="portal-shell portal-shell--2col">

        <?php require ADMISSIONS_PATH . '/inquiry-queue/partials/sidebar.php'; ?>

        <main class="portal-content staff-accounts-layout">

            <header class="workspace-header">
                <div class="workspace-header__left">
                    <span class="section-badge">Administration</span>
                    <h1>Staff Accounts</h1>
                    <p>Create and manage administrator / staff accounts.</p>
                </div>
                <div class="workspace-header__right">
                    <?php if (user_can('staff_accounts', 'edit')): ?><button type="button" class="btn-primary" id="btnAddStaff">＋ Add Staff</button><?php endif; ?>
                </div>
            </header>

            <?php if ($flash['message']): ?>
                <div id="staffFlash" data-type="<?= $flash['type']; ?>" style="display:none;"><?= htmlspecialchars($flash['message'], ENT_QUOTES, 'UTF-8'); ?></div>
            <?php endif; ?>

            <!-- ============ STAFF LIST ============ -->
            <section class="workspace-table">
                <div class="dash-panel__head">
                    <h2>Staff List (<?= count($staff); ?>)</h2>
                    <select id="roleFilter" class="toolbar-select" style="height:36px;">
                        <option value="">All Roles</option>
                        <?php foreach ($roles as $r): ?>
                            <option value="<?= e($r['code']); ?>" <?= $roleFilter === $r['code'] ? 'selected' : ''; ?>><?= e($r['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="table-responsive staff-scroll">
                    <table class="inquiry-table">
                        <thead>
                            <tr>
                                <th>Name</th><th>Username</th><th>Email</th><th>Role</th><th>Status</th><th>Last Login</th><th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($staff as $st): ?>
                                <tr>
                                    <td><?= e($st['full_name']); ?></td>
                                    <td><?= e($st['username']); ?></td>
                                    <td><?= e($st['email']); ?></td>
                                    <td><span class="status-badge"><?= e($st['role_name'] ?? $st['role_code']); ?></span></td>
                                    <td>
                                        <span class="status-badge status-<?= (int) $st['status_id'] === 1 ? 'converted' : 'closed'; ?>">
                                            <?= (int) $st['status_id'] === 1 ? 'Active' : 'Disabled'; ?>
                                        </span>
                                    </td>
                                    <td><?= e($st['last_login_at'] ?? '—'); ?></td>
                                    <td class="cert-table__actions">
                                        <div class="cert-actions-2x2">
                                            <button type="button" class="btn-secondary btn-sm" data-reset='<?= json_encode(['id'=>(int)$st['id'],'name'=>$st['full_name']], JSON_HEX_APOS|JSON_HEX_QUOT); ?>'>Reset PW</button>
                                            <?php if ((int) $st['id'] !== (int) current_user()['id']): ?>
                                                <form method="post" action="<?= e(base_url('sections/admissions/admin/staff-accounts.php')); ?>" style="display:contents;">
                                                    <?= csrf_field(); ?>
                                                    <input type="hidden" name="action" value="toggle">
                                                    <input type="hidden" name="staff_id" value="<?= (int) $st['id']; ?>">
                                                    <button type="submit" class="btn-secondary btn-sm"><?= (int) $st['status_id'] === 1 ? 'Disable' : 'Enable'; ?></button>
                                                </form>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </section>

        </main>
    </section>

    <?php include INCLUDES_PATH . '/footer.php'; ?>
    <?php include INCLUDES_PATH . '/scripts.php'; ?>

    <!-- Create staff account modal -->
    <div id="createModal" class="portal-modal" style="display:none;">
        <div class="portal-modal__box">
            <div class="portal-modal__head">
                <h3>Create Staff Account</h3>
                <p>Add an administrator / admissions / registrar account</p>
                <button class="portal-modal__close" id="createClose">&times;</button>
            </div>
            <form method="post" action="<?= e(base_url('sections/admissions/admin/staff-accounts.php')); ?>" class="staff-form">
                <?= csrf_field(); ?>
                <input type="hidden" name="action" value="create">
                <div class="portal-modal__body">
                    <div class="staff-form__grid">
                        <div class="t-field">
                            <label>Full Name *</label>
                            <input name="full_name" required placeholder="e.g. Juan Dela Cruz">
                        </div>
                        <div class="t-field">
                            <label>Username *</label>
                            <input name="username" required placeholder="e.g. jdela" autocomplete="off">
                        </div>
                        <div class="t-field">
                            <label>Email *</label>
                            <input type="email" name="email" required placeholder="e.g. jdela@usmci.edu.ph">
                        </div>
                        <div class="t-field">
                            <label>Mobile</label>
                            <input name="mobile_no" placeholder="e.g. 09XXXXXXXXX">
                        </div>
                        <div class="t-field">
                            <label>Role *</label>
                            <select name="role_id" required>
                                <option value="">— select role —</option>
                                <?php foreach ($roles as $r): ?>
                                    <option value="<?= (int) $r['id']; ?>"><?= e($r['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="t-field">
                            <label>Initial Password * (min 8)</label>
                            <input type="text" name="password" minlength="8" required placeholder="e.g. Temp@1234" autocomplete="off">
                            <small class="field-hint">Give this to the staff — they can change it after login.</small>
                        </div>
                    </div>
                </div>
                <div class="portal-modal__foot">
                    <button type="button" class="btn-secondary" id="createCancel">Cancel</button>
                    <button type="submit" class="btn-primary">Create Account</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Reset password modal -->
    <div id="resetModal" class="portal-modal" style="display:none;">
        <div class="portal-modal__box">
            <div class="portal-modal__head">
                <h3>Reset Password</h3>
                <p id="resetTarget">Account: —</p>
                <button class="portal-modal__close" id="resetClose">&times;</button>
            </div>
            <form method="post" action="<?= e(base_url('sections/admissions/admin/staff-accounts.php')); ?>">
                <?= csrf_field(); ?>
                <input type="hidden" name="action" value="reset">
                <input type="hidden" name="staff_id" id="resetId" value="">
                <div class="portal-modal__body">
                    <div class="t-field"><label>New Password (min 8)</label><input type="text" name="new_password" minlength="8" required autocomplete="off"></div>
                </div>
                <div class="portal-modal__foot">
                    <button type="button" class="btn-secondary" id="resetCancel">Cancel</button>
                    <button type="submit" class="btn-primary">Reset Password</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        (function () {
            function showToast(msg, type) { window.usmciToast(msg, type); }
            var flashEl = document.getElementById("staffFlash");
            if (flashEl && flashEl.textContent.trim() !== "") showToast(flashEl.textContent.trim(), flashEl.dataset.type);

            // Create staff modal
            var createModal = document.getElementById("createModal");
            function openCreate() { createModal.style.display = "flex"; }
            function closeCreate() { createModal.style.display = "none"; }
            document.getElementById("btnAddStaff").addEventListener("click", openCreate);
            document.getElementById("createClose").addEventListener("click", closeCreate);
            document.getElementById("createCancel").addEventListener("click", closeCreate);
            createModal.addEventListener("click", function (e) { if (e.target === createModal) closeCreate(); });

            // Reset password modal
            var modal = document.getElementById("resetModal");
            var idEl = document.getElementById("resetId");
            var target = document.getElementById("resetTarget");
            function openReset(d) { idEl.value = d.id; target.textContent = "Account: " + d.name; modal.style.display = "flex"; }
            function closeReset() { modal.style.display = "none"; }
            document.querySelectorAll("[data-reset]").forEach(function (b) {
                b.addEventListener("click", function () { try { openReset(JSON.parse(b.dataset.reset)); } catch (e) {} });
            });
            document.getElementById("resetClose").addEventListener("click", closeReset);
            document.getElementById("resetCancel").addEventListener("click", closeReset);
            modal.addEventListener("click", function (e) { if (e.target === modal) closeReset(); });
        var roleFilter = document.getElementById("roleFilter");
        if (roleFilter) roleFilter.addEventListener("change", function () {
            var url = window.location.pathname + "?";
            if (roleFilter.value) url += "role=" + encodeURIComponent(roleFilter.value);
            window.location = url;
        });
        })();
    </script>

</body>
</html>
