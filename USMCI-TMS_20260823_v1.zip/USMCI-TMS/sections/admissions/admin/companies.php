<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Admin: Affiliated Companies
 * File : sections/admissions/admin/companies.php
 * ---------------------------------------------------------
 * Grid of affiliated/endorsing companies with a profile view.
 * Fields: code, company name, type, address, email, phone,
 * website, contact person, contact number, contact email.
 * Used by the Enrollment "Charge To: Company" dropdown.
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/config/bootstrap.php';

require_access('companies');
if ($_SERVER['REQUEST_METHOD'] === 'POST') { require_edit('companies'); }

$pdo = db();
$flash = ['type' => null, 'message' => null];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = $_POST['action'] ?? '';
    try {
        if ($action === 'save') {
            $id        = (int) ($_POST['company_id'] ?? 0);
            $code      = trim((string) ($_POST['code'] ?? ''));
            $name      = trim((string) ($_POST['company_name'] ?? ''));
            $type      = trim((string) ($_POST['company_type'] ?? ''));
            $address   = trim((string) ($_POST['address'] ?? ''));
            $email     = trim((string) ($_POST['email'] ?? ''));
            $phone     = trim((string) ($_POST['phone'] ?? ''));
            $website   = trim((string) ($_POST['website'] ?? ''));
            $cperson   = trim((string) ($_POST['contact_person'] ?? ''));
            $cnumber   = trim((string) ($_POST['contact_number'] ?? ''));
            $cemail    = trim((string) ($_POST['contact_email'] ?? ''));

            if ($code === '' || $name === '') {
                $flash = ['type' => 'error', 'message' => 'Company code and name are required.'];
            } elseif ($id > 0) {
                $pdo->prepare(
                    "UPDATE mnt_company SET code = :c, company_name = :n, company_type = :t, address = :a,
                            email = :e, phone = :p, website = :w, contact_person = :cp, contact_number = :cn,
                            contact_email = :ce, updated_at = NOW()
                     WHERE id = :id"
                )->execute([
                    'c' => $code, 'n' => $name, 't' => $type !== '' ? $type : null, 'a' => $address !== '' ? $address : null,
                    'e' => $email !== '' ? $email : null, 'p' => $phone !== '' ? $phone : null, 'w' => $website !== '' ? $website : null,
                    'cp' => $cperson !== '' ? $cperson : null, 'cn' => $cnumber !== '' ? $cnumber : null,
                    'ce' => $cemail !== '' ? $cemail : null, 'id' => $id,
                ]);
                audit_log('companies', 'update', $id, "Company '{$name}' updated");
                $flash = ['type' => 'success', 'message' => "Company '{$name}' updated."];
            } else {
                $pdo->prepare(
                    "INSERT INTO mnt_company (code, company_name, company_type, address, email, phone, website,
                            contact_person, contact_number, contact_email, is_active)
                     VALUES (:c, :n, :t, :a, :e, :p, :w, :cp, :cn, :ce, 1)"
                )->execute([
                    'c' => $code, 'n' => $name, 't' => $type !== '' ? $type : null, 'a' => $address !== '' ? $address : null,
                    'e' => $email !== '' ? $email : null, 'p' => $phone !== '' ? $phone : null, 'w' => $website !== '' ? $website : null,
                    'cp' => $cperson !== '' ? $cperson : null, 'cn' => $cnumber !== '' ? $cnumber : null,
                    'ce' => $cemail !== '' ? $cemail : null,
                ]);
                audit_log('companies', 'create', (int) $pdo->lastInsertId(), "Company '{$name}' created");
                $flash = ['type' => 'success', 'message' => "Company '{$name}' added."];
            }
        } elseif ($action === 'toggle') {
            $id = (int) ($_POST['company_id'] ?? 0);
            $stmt = $pdo->prepare('SELECT is_active FROM mnt_company WHERE id = :id');
            $stmt->execute(['id' => $id]);
            $cur = (int) $stmt->fetchColumn();
            $pdo->prepare('UPDATE mnt_company SET is_active = :a, updated_at = NOW() WHERE id = :id')
                ->execute(['a' => $cur ? 0 : 1, 'id' => $id]);
            audit_log('companies', 'toggle', $id, 'Company ' . ($cur ? 'deactivated' : 'activated'));
            $flash = ['type' => 'success', 'message' => 'Company ' . ($cur ? 'deactivated.' : 'activated.')];
        }
    } catch (Throwable $e) {
        error_log('companies.php: ' . $e->getMessage());
        $flash = ['type' => 'error', 'message' => strpos($e->getMessage(), 'Duplicate') !== false ? 'That company code already exists.' : 'Could not save the company.'];
    }
}

$companies = $pdo->query('SELECT * FROM mnt_company ORDER BY is_active DESC, company_name')->fetchAll() ?: [];

$page = ['title' => 'Affiliated Companies | USMCI-TMS', 'description' => 'Affiliated Companies', 'bodyClass' => 'admissions-page'];
?>
<!DOCTYPE html>
<html lang="en">
<?php include INCLUDES_PATH . '/head.php'; ?>
<link rel="stylesheet" href="<?= e(base_url('assets/css/portal.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/workspace.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/inquiry-queue/assets/css/page.css?v=' . ASSET_VERSION)); ?>">
<link rel="stylesheet" href="<?= e(base_url('sections/admissions/admin/dashboard.css?v=' . ASSET_VERSION)); ?>">
<body class="<?= e($page['bodyClass']); ?>">
    <?php include NAVBAR_PATH . '/index.php'; ?>
    <section class="portal-shell portal-shell--2col">
        <?php require ADMISSIONS_PATH . '/inquiry-queue/partials/sidebar.php'; ?>
        <main class="portal-content">
            <header class="workspace-header">
                <div class="workspace-header__left">
                    <span class="section-badge">Partners</span>
                    <h1>Affiliated Companies</h1>
                    <p>Companies / agencies that endorse trainees — used in Enrollment (Charge To: Company).</p>
                </div>
                <div class="workspace-header__right">
                    <?php if (user_can('companies', 'edit')): ?>
                        <button type="button" class="btn-primary" id="btnAddCompany">＋ Add Company</button>
                    <?php endif; ?>
                </div>
            </header>

            <?php if ($flash['message']): ?>
                <div id="coFlash" data-type="<?= $flash['type']; ?>" style="display:none;"><?= htmlspecialchars($flash['message'], ENT_QUOTES, 'UTF-8'); ?></div>
            <?php endif; ?>

            <section class="workspace-table">
                <div class="dash-panel__head"><h2>Companies (<?= count($companies); ?>)</h2></div>
                <div class="table-responsive">
                    <table class="inquiry-table">
                        <thead><tr><th>Code</th><th>Company</th><th>Contact Person</th><th>Contact No.</th><th>Type</th><th>Status</th><th>Actions</th></tr></thead>
                        <tbody>
                            <?php if (!$companies): ?>
                                <tr><td colspan="7" style="text-align:center;color:#94A3B8;padding:30px;">No companies yet — add your first affiliated company.</td></tr>
                            <?php endif; ?>
                            <?php foreach ($companies as $co): ?>
                                <tr>
                                    <td class="cert-table__no"><?= e($co['code']); ?></td>
                                    <td><strong><?= e($co['company_name']); ?></strong></td>
                                    <td><?= e($co['contact_person'] ?? '—'); ?></td>
                                    <td><?= e($co['contact_number'] ?? '—'); ?></td>
                                    <td><?= e($co['company_type'] ?? '—'); ?></td>
                                    <td><span class="status-badge status-<?= $co['is_active'] ? 'converted' : 'closed'; ?>"><?= $co['is_active'] ? 'Active' : 'Inactive'; ?></span></td>
                                    <td class="cert-table__actions">
                                        <div class="cert-actions-2x2">
                                            <button type="button" class="btn-secondary btn-sm" data-company-view='<?= json_encode(['id'=>(int)$co['id'],'code'=>$co['code'],'name'=>$co['company_name'],'type'=>$co['company_type']??'','address'=>$co['address']??'','email'=>$co['email']??'','phone'=>$co['phone']??'','website'=>$co['website']??'','cp'=>$co['contact_person']??'','cn'=>$co['contact_number']??'','ce'=>$co['contact_email']??''], JSON_HEX_APOS|JSON_HEX_QUOT); ?>'>👁 View</button>
                                            <?php if (user_can('companies', 'edit')): ?>
                                                <button type="button" class="btn-secondary btn-sm" data-company-edit='<?= json_encode(['id'=>(int)$co['id'],'code'=>$co['code'],'name'=>$co['company_name'],'type'=>$co['company_type']??'','address'=>$co['address']??'','email'=>$co['email']??'','phone'=>$co['phone']??'','website'=>$co['website']??'','cp'=>$co['contact_person']??'','cn'=>$co['contact_number']??'','ce'=>$co['contact_email']??''], JSON_HEX_APOS|JSON_HEX_QUOT); ?>'>✏️ Edit</button>
                                                <button type="button" class="btn-secondary btn-sm" data-company-toggle='<?= json_encode(['id'=>(int)$co['id']], JSON_HEX_APOS|JSON_HEX_QUOT); ?>'><?= $co['is_active'] ? 'Deactivate' : 'Activate'; ?></button>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </section>
        </main>
    </section>

    <?php include INCLUDES_PATH . '/footer.php'; ?>
    <?php include INCLUDES_PATH . '/scripts.php'; ?>

    <!-- Company modal (add/edit) -->
    <div id="companyModal" class="portal-modal" style="display:none;">
        <div class="portal-modal__box">
            <div class="portal-modal__head">
                <h3 id="companyModalTitle">Add Company</h3>
                <p>Affiliated company / agency profile</p>
                <button class="portal-modal__close" id="companyClose">&times;</button>
            </div>
            <form method="post" action="<?= e(base_url('sections/admissions/admin/companies.php')); ?>">
                <?= csrf_field(); ?>
                <input type="hidden" name="action" value="save">
                <input type="hidden" name="company_id" id="cmId" value="0">
                <div class="portal-modal__body">
                    <div class="cert-form__grid">
                        <div class="t-field"><label>Code *</label><input name="code" id="cmCode" required placeholder="e.g. CMP-002"></div>
                        <div class="t-field"><label>Company Name *</label><input name="company_name" id="cmName" required></div>
                        <div class="t-field"><label>Company Type</label><input name="company_type" id="cmType" placeholder="e.g. Manning Agency"></div>
                        <div class="t-field"><label>Website</label><input name="website" id="cmWebsite" placeholder="https://…"></div>
                        <div class="t-field"><label>Email</label><input type="email" name="email" id="cmEmail"></div>
                        <div class="t-field"><label>Phone</label><input name="phone" id="cmPhone"></div>
                        <div class="t-field t-field--full"><label>Address</label><input name="address" id="cmAddress"></div>
                        <div class="t-field"><label>Contact Person</label><input name="contact_person" id="cmCp" placeholder="e.g. HR Manager"></div>
                        <div class="t-field"><label>Contact Number</label><input name="contact_number" id="cmCn"></div>
                        <div class="t-field t-field--full"><label>Contact Email</label><input type="email" name="contact_email" id="cmCe"></div>
                    </div>
                </div>
                <div class="portal-modal__foot">
                    <button type="button" class="btn-secondary" id="companyCancel">Cancel</button>
                    <button type="submit" class="btn-primary">Save Company</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Company view modal -->
    <div id="companyViewModal" class="portal-modal" style="display:none;">
        <div class="portal-modal__box">
            <div class="portal-modal__head">
                <h3>🏢 Company Profile</h3>
                <p id="cvSub">—</p>
                <button class="portal-modal__close" id="cvClose">&times;</button>
            </div>
            <div class="portal-modal__body">
                <div class="app-info" id="cvBody"></div>
            </div>
            <div class="portal-modal__foot">
                <button type="button" class="btn-primary" id="cvCloseBtn">Close</button>
            </div>
        </div>
    </div>

    <script>
        (function () {
            function showToast(msg, type) { window.usmciToast(msg, type); }
            var fl = document.getElementById("coFlash");
            if (fl && fl.textContent.trim() !== "") showToast(fl.textContent.trim(), fl.dataset.type);

            function esc(s) { return String(s ?? "").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;"); }
            function setVal(id, v) { var el = document.getElementById(id); if (el) el.value = v ?? ""; }

            /* Add/Edit modal */
            var modal = document.getElementById("companyModal");
            function open(d) {
                document.getElementById("companyModalTitle").textContent = d ? "Edit Company" : "Add Company";
                setVal("cmId", d ? d.id : 0);
                setVal("cmCode", d ? d.code : ""); setVal("cmName", d ? d.name : ""); setVal("cmType", d ? d.type : "");
                setVal("cmWebsite", d ? d.website : ""); setVal("cmEmail", d ? d.email : ""); setVal("cmPhone", d ? d.phone : "");
                setVal("cmAddress", d ? d.address : ""); setVal("cmCp", d ? d.cp : ""); setVal("cmCn", d ? d.cn : ""); setVal("cmCe", d ? d.ce : "");
                modal.style.display = "flex";
            }
            function close() { modal.style.display = "none"; }
            document.getElementById("btnAddCompany").addEventListener("click", function () { open(null); });
            document.querySelectorAll("[data-company-edit]").forEach(function (b) {
                b.addEventListener("click", function () { try { open(JSON.parse(b.dataset.companyEdit)); } catch (e) {} });
            });
            document.getElementById("companyClose").addEventListener("click", close);
            document.getElementById("companyCancel").addEventListener("click", close);
            modal.addEventListener("click", function (e) { if (e.target === modal) close(); });

            /* View modal */
            var vModal = document.getElementById("companyViewModal");
            function openView(d) {
                document.getElementById("cvSub").textContent = d.code + " · " + d.name;
                var cells = [
                    ["Company", d.name], ["Code", d.code], ["Type", d.type], ["Address", d.address],
                    ["Email", d.email], ["Phone", d.phone], ["Website", d.website],
                    ["Contact Person", d.cp], ["Contact Number", d.cn], ["Contact Email", d.ce]
                ];
                document.getElementById("cvBody").innerHTML = cells.map(function (c) {
                    return '<div class="app-info__cell"><span>' + esc(c[0]) + '</span><b>' + esc(c[1] || "—") + '</b></div>';
                }).join("");
                vModal.style.display = "flex";
            }
            function closeView() { vModal.style.display = "none"; }
            document.querySelectorAll("[data-company-view]").forEach(function (b) {
                b.addEventListener("click", function () { try { openView(JSON.parse(b.dataset.companyView)); } catch (e) {} });
            });
            document.getElementById("cvClose").addEventListener("click", closeView);
            document.getElementById("cvCloseBtn").addEventListener("click", closeView);
            vModal.addEventListener("click", function (e) { if (e.target === vModal) closeView(); });

            /* Toggle */
            var CSRF = <?= json_encode(csrf_token()); ?>;
            document.querySelectorAll("[data-company-toggle]").forEach(function (b) {
                b.addEventListener("click", function () {
                    var d = JSON.parse(b.dataset.companyToggle);
                    var fd = new FormData();
                    fd.append("csrf_token", CSRF); fd.append("action", "toggle"); fd.append("company_id", d.id);
                    fetch(window.location.href, { method: "POST", body: fd })
                        .then(function () { window.location.reload(); })
                        .catch(function () { showToast("Could not toggle the company.", "error"); });
                });
            });
        })();
    </script>
</body>
</html>
