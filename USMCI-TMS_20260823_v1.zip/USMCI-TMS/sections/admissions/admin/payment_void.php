<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Admin: Void payment (AJAX)
 * File : sections/admissions/admin/payment_void.php
 * ---------------------------------------------------------
 * JSON endpoint used by the Payments page to VOID a payment
 * that already has receipts (the accounting-correct way to
 * handle a mistaken or cancelled payment — you can't delete
 * it once receipts were issued):
 *   - marks every official_receipt of the payment VOID
 *   - sets the payment status to VOID
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/config/bootstrap.php';

require_edit('payments');

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'POST required.']);
    exit;
}

csrf_check();

$paymentId = (int) ($_POST['payment_id'] ?? 0);

if (!$paymentId) {
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => 'Payment id is required.']);
    exit;
}

try {
    $pdo = db();
    $pdo->beginTransaction();

    $stmt = $pdo->prepare('SELECT id, payment_no, payment_status_id FROM payment WHERE id = :id FOR UPDATE');
    $stmt->execute(['id' => $paymentId]);
    $payment = $stmt->fetch();

    if (!$payment) {
        $pdo->rollBack();
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'Payment not found.']);
        exit;
    }

    if ((int) $payment['payment_status_id'] === 5) {
        $pdo->rollBack();
        http_response_code(422);
        echo json_encode(['success' => false, 'message' => 'This payment is already void.']);
        exit;
    }
    if ((int) $payment['payment_status_id'] === 4) {
        $pdo->rollBack();
        http_response_code(422);
        echo json_encode(['success' => false, 'message' => 'This payment is refunded — voiding is not allowed.']);
        exit;
    }

    /* Void every official receipt issued against this payment */
    $pdo->prepare(
        "UPDATE official_receipt r
         JOIN payment_transaction pt ON pt.id = r.payment_transaction_id
         SET r.status = 'void'
         WHERE pt.payment_id = :id AND r.status = 'issued'"
    )->execute(['id' => $paymentId]);

    $stmt = $pdo->prepare('SELECT COUNT(*) FROM official_receipt r JOIN payment_transaction pt ON pt.id = r.payment_transaction_id WHERE pt.payment_id = :id');
    $stmt->execute(['id' => $paymentId]);
    $receiptCount = (int) $stmt->fetchColumn();

    /* Mark the payment VOID (mnt_payment_status id 5 = VOID) */
    $pdo->prepare("UPDATE payment SET payment_status_id = 5, updated_at = NOW() WHERE id = :id")
        ->execute(['id' => $paymentId]);

    /* V5.32: if nothing remains paid on the enrollment, revert it to Pending */
    $autoStatus = auto_sync_enrollment_from_payment($pdo, $paymentId);

    $pdo->commit();

    audit_log('payments', 'void', $paymentId, "Payment {$payment['payment_no']} voided — {$receiptCount} official receipt(s) voided"
        . ($autoStatus === 'pending' ? ' — enrollment reverted to Pending' : ''));

    echo json_encode([
        'success' => true,
        'message' => "Payment {$payment['payment_no']} voided — {$receiptCount} official receipt(s) voided."
            . ($autoStatus === 'pending' ? ' The enrollment was reverted to Pending.' : ''),
    ]);
} catch (Throwable $e) {
    if (isset($pdo) && $pdo->inTransaction()) { $pdo->rollBack(); }
    error_log('payment_void: ' . $e->getMessage());
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => 'Could not void the payment.']);
}
exit;
