<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Module      : Admissions Portal
 * Partial     : Sidebar
 * Description : Branding/pitch panel — Login now links to the
 *               staff login page; Create Account links to the
 *               public inquiry form (registration is by
 *               invitation only).
 * ---------------------------------------------------------
 */
?>

<aside class="portal-sidebar">

    <div class="portal-sidebar__inner">

        <span class="admissions-badge">
            Admissions Portal
        </span>

        <h2>
            Start Your Maritime Career
        </h2>

        <p>
            Complete your admission online through the secure
            USMCI Admissions Portal.
        </p>

        <ul class="portal-sidebar__features">

            <li>
                <span>✓</span>
                Secure Online Application
            </li>

            <li>
                <span>✓</span>
                Save Progress Anytime
            </li>

            <li>
                <span>✓</span>
                Upload Documents Later
            </li>

            <li>
                <span>✓</span>
                Track Admission Status
            </li>

        </ul>

        <div class="portal-sidebar__actions">

            <a
                href="<?= e(base_url('login.php')); ?>"
                class="btn btn-primary">
                Login
            </a>

            <a
                href="<?= e(base_url('sections/admissions/inquiry/index.php')); ?>"
                class="btn btn-outline">
                Inquire Now
            </a>

        </div>

        <div class="info-card">

            <div class="info-icon">
                🕒
            </div>

            <div class="info-text">

                <strong>Office Hours</strong>

                <p>
                    Monday – Friday, 8:00 AM – 5:00 PM
                </p>

            </div>

        </div>

    </div>

</aside>
