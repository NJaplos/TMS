<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Module      : Admissions Portal
 * Partial     : Right Panel
 * Version     : 2.2
 * Description : Dashboard right panel with slideshow,
 *               operational Inquiry Queue card and
 *               informational cards.
 *
 * 2.2: The "Inquiry Queue" card now links to the PUBLIC
 * inquiry form (this is a public page). The STAFF queue is
 * only reachable after login at /login.php.
 * ---------------------------------------------------------
 */

require __DIR__ . '/../includes/campus-images.php';

?>

<aside class="portal-right">

    <div class="portal-right__inner">

        <!-- ==================================================
             Campus Slideshow
        =================================================== -->

        <div class="right-slideshow">

            <div class="slideshow-container">

                <img
                    id="campusSlide"
                    src="<?= !empty($imageList) ? $imageList[0] : ''; ?>"
                    alt="USMCI Campus">

            </div>

        </div>

        <!-- ==================================================
             Staff Login
        =================================================== -->

        <a
            href="<?= e(base_url('login.php')); ?>"
            class="right-card right-card--action">

            <div class="right-card__icon">

                🔐

            </div>

            <div class="right-card__text">

                <strong>

                    Staff Login

                </strong>

                <p>

                    Login to manage the Inquiry Queue,
                    applicant accounts and the admissions
                    process.

                </p>

            </div>

            <div class="right-card__arrow">

                →

            </div>

        </a>

        <!-- ==================================================
             Admission Status
        =================================================== -->

        <div class="right-card">

            <div class="right-card__icon">

                📋

            </div>

            <div class="right-card__text">

                <strong>

                    Admission Status

                </strong>

                <p>

                    Login anytime to monitor your
                    application progress and
                    admission status.

                </p>

            </div>

        </div>

        <!-- ==================================================
             Application Tips
        =================================================== -->

        <div class="right-card">

            <div class="right-card__icon">

                💡

            </div>

            <div class="right-card__text">

                <strong>

                    Application Tips

                </strong>

                <p>

                    Prepare your required documents
                    in advance to make your
                    application faster.

                </p>

            </div>

        </div>

        <!-- ==================================================
             Need Help
        =================================================== -->

        <div class="right-card">

            <div class="right-card__icon">

                🛟

            </div>

            <div class="right-card__text">

                <strong>

                    Need Help?

                </strong>

                <p>

                    Contact the Admissions Office
                    or submit an

                    <a href="<?= e(base_url('sections/admissions/inquiry/index.php')); ?>">

                        Inquiry

                    </a>

                    if you need further assistance.

                </p>

            </div>

        </div>

    </div>

    <script>

        const campusImages = <?= json_encode($imageList); ?>;

    </script>

</aside>
