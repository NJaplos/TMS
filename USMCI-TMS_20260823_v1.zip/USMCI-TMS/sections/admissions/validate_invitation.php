<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Validate Applicant Invitation Token
 * ---------------------------------------------------------
 * Used by the registration screen (sections/admissions/register.php)
 * to check a token from the emailed link before showing the
 * account-creation form. Looks up by HASH of the submitted
 * token — the raw token is never stored, so this is the only
 * way to find the matching row.
 * ---------------------------------------------------------
 */

declare(strict_types=1);

if (!defined('USMCI_BOOTSTRAP')) {
    require_once dirname(__DIR__, 2) . '/config/bootstrap.php';
}

/**
 * @return array{valid: bool, reason?: string, invitation?: array}
 */
function validate_invitation_token(string $rawToken): array
{
    if ($rawToken === '') {
        return ['valid' => false, 'reason' => 'Missing invitation token.'];
    }

    $pdo = db();
    $tokenHash = hash('sha256', $rawToken);

    $stmt = $pdo->prepare(
        "SELECT ai.*, i.full_name, i.inquiry_no
         FROM applicant_invitation ai
         JOIN inquiry i ON i.id = ai.inquiry_id
         WHERE ai.token_hash = :token_hash"
    );
    $stmt->execute(['token_hash' => $tokenHash]);
    $invitation = $stmt->fetch();

    if (!$invitation) {
        return ['valid' => false, 'reason' => 'Invalid invitation link.'];
    }

    if ($invitation['used_at'] !== null) {
        return ['valid' => false, 'reason' => 'This invitation link has already been used.'];
    }

    if (strtotime($invitation['expires_at']) < time()) {
        return ['valid' => false, 'reason' => 'This invitation link has expired. Please contact the Admissions Office for a new one.'];
    }

    return ['valid' => true, 'invitation' => $invitation];
}

/**
 * Call this only after the applicant_account row has actually
 * been created — marks the token as spent so it can never be
 * reused, and advances the inquiry to CONVERTED.
 */
function mark_invitation_used(int $invitationId, int $inquiryId): void
{
    $pdo = db();

    $pdo->prepare("UPDATE applicant_invitation SET used_at = NOW() WHERE id = :id")
        ->execute(['id' => $invitationId]);

    $convertedStatusId = $pdo->query(
        "SELECT id FROM mnt_inquiry_status WHERE code = 'CONVERTED'"
    )->fetchColumn();

    $pdo->prepare("UPDATE inquiry SET status_id = :status_id WHERE id = :id")
        ->execute(['status_id' => $convertedStatusId, 'id' => $inquiryId]);
}

/**
 * Validate a human-usable REGISTRATION CODE (typed by the
 * applicant on the login page's "Create Account" tab).
 *
 * Looks up by the stored code, checks unused + not expired.
 *
 * @return array{valid: bool, reason?: string, invitation?: array}
 */
function validate_registration_code(string $code): array
{
    $code = strtoupper(trim($code));

    if ($code === '') {
        return ['valid' => false, 'reason' => 'Enter the registration code from your invitation email.'];
    }

    try {
        $pdo = db();

        $stmt = $pdo->prepare(
            "SELECT ai.*, i.full_name, i.inquiry_no
             FROM applicant_invitation ai
             JOIN inquiry i ON i.id = ai.inquiry_id
             WHERE ai.registration_code = :code
             LIMIT 1"
        );
        $stmt->execute(['code' => $code]);
        $invitation = $stmt->fetch();

        if (!$invitation) {
            return ['valid' => false, 'reason' => 'That registration code was not found. Double-check it or contact the Admissions Office.'];
        }

        if ($invitation['used_at'] !== null) {
            return ['valid' => false, 'reason' => 'This registration code has already been used. Please sign in instead.'];
        }

        if (strtotime($invitation['expires_at']) < time()) {
            return ['valid' => false, 'reason' => 'This registration code has expired. Please contact the Admissions Office for a new one.'];
        }

        return ['valid' => true, 'invitation' => $invitation];
    } catch (Throwable $e) {
        error_log('validate_registration_code failed: ' . $e->getMessage());

        return ['valid' => false, 'reason' => 'Could not validate the code right now. Please try again.'];
    }
}
