/*=========================================================
   USMCI-TMS — Contact section (V5.61)
   The public inquiry form was removed from this section —
   no form logic is needed here anymore. Kept as a light
   placeholder so the section stays script-ready.
=========================================================*/
(function () {
    "use strict";
    document.addEventListener("DOMContentLoaded", function () {
        /* nothing required — contact info, map and affiliates
           are rendered server-side */
    });
})();
