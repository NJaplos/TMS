<?php
/**
 * -------------------------------------------------------------------------
 * USMCI-TMS — Website Section: Contact (one-page anchor #contact)
 * -------------------------------------------------------------------------
 * V5.66 (client):
 *   ROW 1 — a single line of info cards:
 *           Main Office · Training Site · Facebook · Instagram ·
 *           Mobile Number · Telephone · Email
 *   ROW 2 — AFFILIATIONS (logo + name cards, link hidden)
 *   ROW 3 — PARTNERS (logo + name cards, link hidden)
 *
 * Info values come from the letterhead settings (report_*) + the
 * Website Content page (site_contact_*). Affiliations/Partners are
 * maintained at Settings → 🤝 Affiliated Companies (choose Type).
 * -------------------------------------------------------------------------
 */
declare(strict_types=1);

/* ---- editable copy (Website Content → Contact) ---- */
$contactIntro = site_content('site_contact_intro', 'Questions about courses, schedules, fees, or enrollment? Our admissions team is ready to help — reach us through any channel below.');
$mapQuery     = site_content('site_contact_map_query', 'YMCA of Manila Building, 350 Antonio Villegas St, Ermita, Manila');
$trainingSite = site_content('site_contact_training_site', 'USMCI Training Grounds, Manila');
$facebookUrl  = site_content('site_contact_facebook', 'https://www.facebook.com/');
$instagramUrl = site_content('site_contact_instagram', 'https://www.instagram.com/');

/* ---- official letterhead contact data (editable in Settings) ---- */
$orgName  = report_setting('report_org_name', 'United Seafarers Maritime Center, Inc.');
$orgAddr  = report_setting('report_org_address', 'G/F YMCA of Manila Bldg, 350 Antonio Villegas St, Ermita, Manila');
$telRaw   = report_setting('report_tel_no', 'TEL NO: 8241-0881');
$mobRaw   = report_setting('report_mobile_no', 'MOBILE NO: 09971201553');
$email    = report_setting('report_email', 'usmci2010@gmail.com');

$clean = fn(string $v): string => trim((string) preg_replace('/^[A-Z\s]+:\s*/i', '', $v));
$telDisplay = $clean($telRaw);
$mobDisplay = $clean($mobRaw);
$telHref = 'tel:+63' . ltrim(preg_replace('/\D+/', '', $telDisplay), '0');
$mobHref = 'tel:+63' . ltrim(preg_replace('/\D+/', '', $mobDisplay), '0');
$mailHref = 'mailto:' . htmlspecialchars($email, ENT_QUOTES, 'UTF-8');
$directionsHref = 'https://www.google.com/maps/search/?api=1&query=' . urlencode($mapQuery);

/* ---- Row 1 info items: maintained at Settings → Contact Info Cards
   (mnt_contact_info). Letterhead values stay in sync for the
   standard items. ---- */
$infoItems = [];
try {
    $pdoCi = function_exists('db') ? db() : null;
    if ($pdoCi) {
        $qCi = $pdoCi->query("SELECT icon, label, value, href, cta, external FROM mnt_contact_info WHERE is_active = 1 ORDER BY sort_order, id");
        foreach ($qCi->fetchAll() ?: [] as $ci) {
            $v = (string) $ci['value'];
            $h = trim((string) ($ci['href'] ?? ''));
            $c = trim((string) ($ci['cta'] ?? ''));
            /* keep the live letterhead values in sync */
            switch ((string) $ci['label']) {
                case 'Main Office':
                    $v = $orgAddr;
                    if ($h === '') { $h = $directionsHref; $c = 'Get Directions →'; }
                    break;
                case 'Training Site':
                    $v = $trainingSite;
                    break;
                case 'Facebook':
                    if ($h === '' || $h === 'https://www.facebook.com/') { $h = $facebookUrl; }
                    if ($c === '') { $c = 'Visit Page →'; }
                    break;
                case 'Instagram':
                    if ($h === '' || $h === 'https://www.instagram.com/') { $h = $instagramUrl; }
                    if ($c === '') { $c = 'Visit Profile →'; }
                    break;
                case 'Mobile Number':
                    $v = $mobDisplay;
                    if ($h === '') { $h = $mobHref; $c = 'Call Now →'; }
                    break;
                case 'Telephone':
                    $v = $telDisplay;
                    if ($h === '') { $h = $telHref; $c = 'Call Now →'; }
                    break;
                case 'Email':
                    $v = $email;
                    if ($h === '') { $h = $mailHref; $c = 'Write to Us →'; }
                    break;
            }
            $infoItems[] = [
                'icon' => (string) $ci['icon'],
                'label' => (string) $ci['label'],
                'value' => $v,
                'href' => $h,
                'cta' => $c,
                'external' => (int) ($ci['external'] ?? 0),
            ];
        }
    }
} catch (Throwable $e) {
    $infoItems = [];
}
/* fallback if the maintenance table is empty */
if (!$infoItems) {
    $infoItems = [
        ['icon' => '📍', 'label' => 'Main Office', 'value' => $orgAddr, 'href' => $directionsHref, 'cta' => 'Get Directions →', 'external' => 1],
        ['icon' => '🏗️', 'label' => 'Training Site', 'value' => $trainingSite, 'href' => '', 'cta' => ''],
        ['icon' => '📘', 'label' => 'Facebook', 'value' => 'Follow us on Facebook', 'href' => $facebookUrl, 'cta' => 'Visit Page →', 'external' => 1],
        ['icon' => '📸', 'label' => 'Instagram', 'value' => 'Follow us on Instagram', 'href' => $instagramUrl, 'cta' => 'Visit Profile →', 'external' => 1],
        ['icon' => '📱', 'label' => 'Mobile Number', 'value' => $mobDisplay, 'href' => $mobHref, 'cta' => 'Call Now →', 'external' => 0],
        ['icon' => '☎️', 'label' => 'Telephone', 'value' => $telDisplay, 'href' => $telHref, 'cta' => 'Call Now →', 'external' => 0],
        ['icon' => '✉️', 'label' => 'Email', 'value' => $email, 'href' => $mailHref, 'cta' => 'Write to Us →', 'external' => 0],
    ];
}

/* ---- Rows 2 & 3: Affiliations vs Partners (Settings → Affiliated Companies) ---- */
$affiliates = [];
$partners   = [];
try {
    $pdo = function_exists('db') ? db() : null;
    if ($pdo) {
        $q = $pdo->query(
            "SELECT id, name, logo_path, website_url, type
             FROM mnt_affiliate
             WHERE is_active = 1
             ORDER BY type, sort_order, name
             LIMIT 40"
        );
        foreach ($q->fetchAll() ?: [] as $a) {
            $logo = trim((string) ($a['logo_path'] ?? ''));
            $item = [
                'id'    => (int) $a['id'],
                'name'  => (string) $a['name'],
                'logo'  => $logo !== '' ? base_url($logo) : '',
                'url'   => trim((string) ($a['website_url'] ?? '')),
            ];
            if (($a['type'] ?? 'affiliation') === 'partner') {
                $partners[] = $item;
            } else {
                $affiliates[] = $item;
            }
        }
    }
} catch (Throwable $e) {
    $affiliates = $partners = [];
}

$affTitle = site_content('site_contact_affiliates_title', 'Our Affiliations');
$affIntro = site_content('site_contact_affiliates_intro', 'Accredited, recognized and certified by the following organizations.');
$partnerTitle = site_content('site_contact_partners_title', 'Our Partners');
$partnerIntro = site_content('site_contact_partners_intro', 'We work hand-in-hand with the following companies and organizations.');

/* shared affiliate/partner card renderer */
$renderLogoCard = function (array $item): void {
    if ($item['url'] !== ''): ?>
        <a class="contact__affiliate" href="<?= e($item['url']); ?>" target="_blank" rel="noopener" title="<?= e($item['name']); ?>">
            <span class="contact__affiliate-logo">
                <?php if ($item['logo'] !== ''): ?>
                    <img src="<?= e($item['logo']); ?>" alt="<?= e($item['name']); ?>" loading="lazy">
                <?php else: ?>
                    <span class="contact__affiliate-fallback"><?= e(mb_strimwidth($item['name'], 0, 2, '')); ?></span>
                <?php endif; ?>
            </span>
            <span class="contact__affiliate-name"><?= e($item['name']); ?></span>
        </a>
    <?php else: ?>
        <div class="contact__affiliate">
            <span class="contact__affiliate-logo">
                <?php if ($item['logo'] !== ''): ?>
                    <img src="<?= e($item['logo']); ?>" alt="<?= e($item['name']); ?>" loading="lazy">
                <?php else: ?>
                    <span class="contact__affiliate-fallback"><?= e(mb_strimwidth($item['name'], 0, 2, '')); ?></span>
                <?php endif; ?>
            </span>
            <span class="contact__affiliate-name"><?= e($item['name']); ?></span>
        </div>
    <?php endif;
};
?>
<section id="contact" class="contact">

    <div class="container">

        <div class="contact__head">
            <span class="contact__eyebrow reveal">Contact Us</span>
            <h2 class="contact__title reveal">Get in Touch With Us</h2>
            <p class="contact__intro reveal"><?= htmlspecialchars($contactIntro, ENT_QUOTES, 'UTF-8'); ?></p>
        </div>

        <!-- ==========================================
             ROW 1 — INFO CARD LINE (7 items)
        =========================================== -->
        <div class="contact__info-line reveal">
            <?php foreach ($infoItems as $it): ?>
                <?php if ($it['href'] !== ''): ?>
                    <a class="contact__info-card" href="<?= e($it['href']); ?>" <?= !empty($it['external']) ? 'target="_blank" rel="noopener"' : ''; ?>>
                        <span class="contact__info-icon"><?= $it['icon']; ?></span>
                        <span class="contact__info-label"><?= e($it['label']); ?></span>
                        <span class="contact__info-value"><?= e($it['value']); ?></span>
                        <?php if ($it['cta'] !== ''): ?><span class="contact__info-cta"><?= e($it['cta']); ?></span><?php endif; ?>
                    </a>
                <?php else: ?>
                    <div class="contact__info-card">
                        <span class="contact__info-icon"><?= $it['icon']; ?></span>
                        <span class="contact__info-label"><?= e($it['label']); ?></span>
                        <span class="contact__info-value"><?= e($it['value']); ?></span>
                    </div>
                <?php endif; ?>
            <?php endforeach; ?>
        </div>

        <!-- ==========================================
             ROW 2 — AFFILIATIONS
        =========================================== -->
        <div class="contact__partners-row contact__partners-row--affil reveal">
            <div class="contact__partners-head">
                <span class="contact__eyebrow">Affiliations</span>
                <h3 class="contact__partners-title"><?= htmlspecialchars($affTitle, ENT_QUOTES, 'UTF-8'); ?></h3>
                <p class="contact__partners-intro"><?= htmlspecialchars($affIntro, ENT_QUOTES, 'UTF-8'); ?></p>
            </div>

            <?php if ($affiliates): ?>
                <div class="contact__affiliates-grid contact__affiliates-grid--affil">
                    <?php foreach ($affiliates as $af): $renderLogoCard($af); endforeach; ?>
                </div>
            <?php else: ?>
                <p class="contact__partners-empty">No affiliations listed yet — add them at Settings → Affiliated Companies.</p>
            <?php endif; ?>
        </div>

        <!-- ==========================================
             ROW 3 — PARTNERS
        =========================================== -->
        <div class="contact__partners-row reveal">
            <div class="contact__partners-head">
                <span class="contact__eyebrow">Partners</span>
                <h3 class="contact__partners-title"><?= htmlspecialchars($partnerTitle, ENT_QUOTES, 'UTF-8'); ?></h3>
                <p class="contact__partners-intro"><?= htmlspecialchars($partnerIntro, ENT_QUOTES, 'UTF-8'); ?></p>
            </div>

            <?php if ($partners): ?>
                <div class="contact__affiliates-grid contact__affiliates-grid--partner">
                    <?php foreach ($partners as $pt): $renderLogoCard($pt); endforeach; ?>
                </div>
            <?php else: ?>
                <p class="contact__partners-empty">No partners listed yet — add them at Settings → Affiliated Companies.</p>
            <?php endif; ?>
        </div>

    </div>

</section>
