<?php
/**
 * -------------------------------------------------------------------------
 * USMCI-TMS — Website Section: About (one-page anchor #about)
 * -------------------------------------------------------------------------
 * Clean, elegant company-promotion section. All copy is editable at
 * Settings → Website Content (site_about_* keys) with graceful
 * fallbacks to the official company profile text.
 *
 * V5.50 additions:
 *  - Photo CAROUSEL that auto-fetches every image inside the folder
 *    configured in site_about_carousel_dir (default
 *    assets/images/site/carousel). Add/remove JPGs there → the
 *    carousel updates automatically (no code change).
 *  - Managing Director block: photo + welcome message (maintenance
 *    editable), placeholder image until the real photo is provided.
 *  - 3D tilt + scroll-reveal effects on the cards (about.js).
 * -------------------------------------------------------------------------
 */
declare(strict_types=1);

$aboutIntro    = site_content('site_about_intro', 'United Seafarers Maritime Center (USMC) — the premier destination of Filipino Seafarers for all their training and assessment needs.');
$aboutStory    = site_content('site_about_story', 'United Seafarers Maritime Center is a company duly approved and recognized by the Securities and Exchange Commission (CS201008536), operated by professionals with more than 20 years of maritime training industry experience.');
$aboutMission  = site_content_lines('site_about_mission', "Develop STCW-based training programs that satisfy the National and International Requirements of Seafarers\nProvide specialized training programs that compliment the competence of seafarers");
$aboutVision   = site_content('site_about_vision', 'United Seafarers Maritime Center shall be a world class and globally recognized maritime institution to offer training and competency assessment.');
$aboutVP       = site_content_lines('site_about_vision_points', "Accessible, innovative and fast services\nState of the art delivery of instruction\nUp-to-date on board technology related facilities and equipment\nWell trained and qualified personnel exceeding client expectations");
$aboutQuality  = site_content('site_about_quality', 'Our Quality Management System exemplifies a constant drive to satisfy our clientele while being mindful of our responsibility to Philippine Legislation, Standards, Employees and the broader community — operating to the requirements of ISO 9001:2015.');
$aboutValues   = site_content_lines('site_about_core_values', "Safety First: We place the safety of seafarers, the public and the environment above all else.\nExcellence in Training: We deliver internationally recognized, STCW-based programs.\nIntegrity & Transparency: We operate with honesty and full compliance.\nCustomer-Care: The Filipino seafarer is at the heart of every service.\nGlobal Readiness: We prepare seafarers for world-class careers.");
$aboutAccreds  = site_content_lines('site_about_accreditations', 'SEC Registered — CS201008536' . "\n" . 'ISO 9001:2015 Certified' . "\n" . 'MARINA Accredited');
$aboutLeader   = site_content_lines('site_about_leader', "Engr. Audie M. Macatol\nManaging Director");
$managerPhoto  = site_content('site_about_manager_photo', 'assets/images/site/manager-placeholder.jpg');
$managerMsg    = site_content('site_about_manager_message', 'Welcome to United Seafarers Maritime Center. We invite you to train with us and experience the USMCI difference.');
$carouselDir   = site_content('site_about_carousel_dir', 'assets/images/site/carousel');

/* ---- Carousel: auto-fetch every image in the configured folder ---- */
$carouselImages = [];
$carouselAbs = BASE_PATH . '/' . ltrim($carouselDir, '/');
if (is_dir($carouselAbs)) {
    foreach (glob($carouselAbs . '/*.{jpg,jpeg,png,webp}', GLOB_BRACE) ?: [] as $f) {
        $carouselImages[] = base_url(ltrim($carouselDir, '/') . '/' . basename($f));
    }
    sort($carouselImages);
}
/* graceful fallback: story photo setting, then the first site image */
if (!$carouselImages) {
    $fallback = site_content('site_about_photo', 'assets/images/site/facility-1.jpg');
    $carouselImages[] = base_url(ltrim($fallback, '/'));
}

/* ---- Live proof numbers ---- */
$pdo            = function_exists('db') ? db() : null;
$statsCourses   = $pdo ? (int) $pdo->query('SELECT COUNT(*) FROM mnt_course')->fetchColumn() : 0;
$statsCerts     = $pdo ? (int) $pdo->query("SELECT COUNT(*) FROM certificate WHERE status = 'issued'")->fetchColumn() : 0;
$statsTrainees  = $pdo ? (int) $pdo->query('SELECT COUNT(*) FROM applicant_account')->fetchColumn() : 0;
$statsInstructors = $pdo ? (int) $pdo->query('SELECT COUNT(*) FROM instructor')->fetchColumn() : 0;
?>
<section id="about" class="about">

    <div class="container">

        <!-- Header -->
        <div class="about__head">
            <span class="about__eyebrow">About USMCI</span>
            <h2 class="about__title">A Partner in Every Seafarer's Journey</h2>
            <p class="about__intro"><?= htmlspecialchars($aboutIntro, ENT_QUOTES, 'UTF-8'); ?></p>
        </div>

        <!-- Story + Carousel -->
        <div class="about__story">
            <div class="about__story-text reveal">
                <h3>Our Story</h3>
                <p><?= nl2br(htmlspecialchars($aboutStory, ENT_QUOTES, 'UTF-8')); ?></p>
                <div class="about__story-flags">
                    <span>🇵🇭 Filipino Seafarers First</span>
                    <span>⚓ STCW-Based</span>
                    <span>🌍 Globally Recognized</span>
                </div>
            </div>
            <div class="about__carousel reveal" id="aboutCarousel" aria-roledescription="carousel">
                <?php foreach ($carouselImages as $i => $src): ?>
                    <div class="about__slide <?= $i === 0 ? 'is-active' : ''; ?>">
                        <img src="<?= e($src); ?>" alt="USMCI <?= $i + 1; ?>" loading="lazy">
                    </div>
                <?php endforeach; ?>
                <button class="about__carousel-btn about__carousel-btn--prev" type="button" aria-label="Previous">&#10094;</button>
                <button class="about__carousel-btn about__carousel-btn--next" type="button" aria-label="Next">&#10095;</button>
                <div class="about__carousel-dots">
                    <?php foreach ($carouselImages as $i => $_): ?>
                        <button type="button" class="about__dot <?= $i === 0 ? 'is-active' : ''; ?>" data-slide="<?= $i; ?>" aria-label="Slide <?= $i + 1; ?>"></button>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <!-- Mission & Vision -->
        <div class="about__mv">
            <div class="about__card about__card--mission tilt reveal">
                <div class="about__card-icon">🎯</div>
                <h3>Our Mission</h3>
                <ul>
                    <?php foreach ($aboutMission as $m): ?>
                        <li><?= htmlspecialchars($m, ENT_QUOTES, 'UTF-8'); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <div class="about__card about__card--vision tilt reveal">
                <div class="about__card-icon">🔭</div>
                <h3>Our Vision</h3>
                <p class="about__vision-statement"><?= htmlspecialchars($aboutVision, ENT_QUOTES, 'UTF-8'); ?></p>
                <ul class="about__vision-points">
                    <?php foreach ($aboutVP as $v): ?>
                        <li><?= htmlspecialchars($v, ENT_QUOTES, 'UTF-8'); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>

        <!-- Core Values -->
        <div class="about__values">
            <h3 class="about__values-title reveal">Core Values</h3>
            <div class="about__values-grid">
                <?php foreach ($aboutValues as $i => $val):
                    $parts = array_map('trim', explode(':', $val, 2));
                    $vTitle = $parts[0] ?? '';
                    $vDesc  = $parts[1] ?? '';
                    $icons  = ['🛟','🎓','🤝','❤️','🌏'];
                    $icon   = $icons[$i % count($icons)];
                ?>
                    <div class="about__value tilt reveal" style="transition-delay:<?= ($i % 5) * 60; ?>ms;">
                        <div class="about__value-icon"><?= $icon; ?></div>
                        <h4><?= htmlspecialchars($vTitle, ENT_QUOTES, 'UTF-8'); ?></h4>
                        <p><?= htmlspecialchars($vDesc, ENT_QUOTES, 'UTF-8'); ?></p>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- Quality / ISO commitment -->
        <div class="about__quality reveal">
            <div class="about__quality-badge">ISO 9001:2015</div>
            <p><?= nl2br(htmlspecialchars($aboutQuality, ENT_QUOTES, 'UTF-8')); ?></p>
        </div>

        <!-- Accreditations -->
        <div class="about__accred reveal">
            <?php foreach ($aboutAccreds as $acc): ?>
                <span class="about__accred-badge">✔ <?= htmlspecialchars($acc, ENT_QUOTES, 'UTF-8'); ?></span>
            <?php endforeach; ?>
        </div>

        <!-- Leadership + Managing Director message -->
        <div class="about__leader reveal">
            <div class="about__leader-line"></div>
            <div class="about__leader-card tilt">
                <?php
                    $mp = trim($managerPhoto);
                    $mpUrl = $mp !== '' ? base_url(ltrim($mp, '/')) : '';
                ?>
                <?php if ($mpUrl !== ''): ?>
                    <img class="about__leader-photo" src="<?= e($mpUrl); ?>" alt="Managing Director" loading="lazy">
                <?php else: ?>
                    <div class="about__leader-photo about__leader-photo--initials">
                        <?= $aboutLeader[0] ? implode('', array_map(fn($w) => mb_substr($w, 0, 1), preg_split('/\s+/', $aboutLeader[0]) ?: [])) : 'MD'; ?>
                    </div>
                <?php endif; ?>
                <div class="about__leader-body">
                    <?php if (isset($aboutLeader[0])): ?><h4><?= htmlspecialchars($aboutLeader[0], ENT_QUOTES, 'UTF-8'); ?></h4><?php endif; ?>
                    <?php if (isset($aboutLeader[1])): ?><p class="about__leader-role"><?= htmlspecialchars($aboutLeader[1], ENT_QUOTES, 'UTF-8'); ?></p><?php endif; ?>
                    <?php if (trim($managerMsg) !== ''): ?>
                        <blockquote class="about__leader-message">“<?= nl2br(htmlspecialchars(trim($managerMsg), ENT_QUOTES, 'UTF-8')); ?>”</blockquote>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Proof numbers -->
        <div class="about__stats">
            <div class="about__stat reveal"><strong><?= number_format($statsCourses); ?></strong><span>Courses Offered</span></div>
            <div class="about__stat reveal" style="transition-delay:60ms;"><strong><?= number_format($statsCerts); ?></strong><span>Certificates Issued</span></div>
            <div class="about__stat reveal" style="transition-delay:120ms;"><strong><?= number_format($statsTrainees); ?></strong><span>Trainees Served</span></div>
            <div class="about__stat reveal" style="transition-delay:180ms;"><strong><?= $statsInstructors > 0 ? number_format($statsInstructors) : '20+'; ?></strong><span>Years / Expert Trainers</span></div>
        </div>

        <!-- CTA -->
        <div class="about__cta reveal">
            <a href="#courses" class="about__btn about__btn--primary">Explore Our Courses</a>
            <a href="#facilities" class="about__btn about__btn--ghost">Our Facilities</a>
        </div>

    </div>

</section>
