/*=========================================================
   USMCI-TMS — About section interactions
   - photo carousel (auto-advance + dots + prev/next)
   - 3D tilt on cards (cursor-driven)
   - scroll-reveal (IntersectionObserver)
=========================================================*/
(function () {
    "use strict";

    /* ---------- Carousel ---------- */
    var carousel = document.getElementById("aboutCarousel");
    if (carousel) {
        var slides = carousel.querySelectorAll(".about__slide");
        var dots = carousel.querySelectorAll(".about__dot");
        var prev = carousel.querySelector(".about__carousel-btn--prev");
        var next = carousel.querySelector(".about__carousel-btn--next");
        var current = 0;
        var timer = null;

        function show(i) {
            current = (i + slides.length) % slides.length;
            slides.forEach(function (s, idx) {
                s.classList.toggle("is-active", idx === current);
            });
            dots.forEach(function (d, idx) {
                d.classList.toggle("is-active", idx === current);
            });
        }
        function auto() {
            clearInterval(timer);
            timer = setInterval(function () { show(current + 1); }, 4500);
        }
        if (slides.length > 1) {
            if (prev) prev.addEventListener("click", function () { show(current - 1); auto(); });
            if (next) next.addEventListener("click", function () { show(current + 1); auto(); });
            dots.forEach(function (d) {
                d.addEventListener("click", function () { show(parseInt(d.dataset.slide, 10) || 0); auto(); });
            });
            auto();
            /* pause on hover */
            carousel.addEventListener("mouseenter", function () { clearInterval(timer); });
            carousel.addEventListener("mouseleave", auto);
        }
    }

    /* ---------- 3D tilt ---------- */
    var tiltEls = document.querySelectorAll(".tilt");
    if (window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
        /* skip tilt for reduced-motion users */
    } else if (tiltEls.length) {
        tiltEls.forEach(function (el) {
            el.addEventListener("mousemove", function (e) {
                var r = el.getBoundingClientRect();
                var px = (e.clientX - r.left) / r.width - 0.5;
                var py = (e.clientY - r.top) / r.height - 0.5;
                var maxTilt = 6; /* degrees */
                el.style.transform = "perspective(700px) rotateX(" + (-py * maxTilt).toFixed(2) + "deg) rotateY(" + (px * maxTilt).toFixed(2) + "deg) translateY(-4px)";
            });
            el.addEventListener("mouseleave", function () {
                el.style.transform = "";
            });
        });
    }

    /* ---------- Scroll reveal ---------- */
    var revealEls = document.querySelectorAll(".reveal");
    if ("IntersectionObserver" in window && revealEls.length) {
        var io = new IntersectionObserver(function (entries) {
            entries.forEach(function (en) {
                if (en.isIntersecting) {
                    en.target.classList.add("is-visible");
                    io.unobserve(en.target);
                }
            });
        }, { threshold: 0.12 });
        revealEls.forEach(function (el) { io.observe(el); });
    } else {
        revealEls.forEach(function (el) { el.classList.add("is-visible"); });
    }
})();
