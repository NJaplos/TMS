<?php
/**
 * -------------------------------------------------------------------------
 * USMCI-TMS — Website Section: News (one-page anchor #news)
 * -------------------------------------------------------------------------
 * LIVE "now enrolling" items from open/upcoming training batches.
 * Card (per client V5.53):
 *   - "NOW ENROLLING" badge + BATCH NUMBER (no course code)
 *   - Course name
 *   - Location | Date range | Lead Instructor
 *   - Slots (kept in its place) + Course fee
 *   - "Inquiry" button → public inquiry form pre-selected with the course
 * -------------------------------------------------------------------------
 */
declare(strict_types=1);

$pdo = function_exists('db') ? db() : null;

$newsIntro = site_content('site_news_intro', 'Currently enrolling batches — reserve your slot today.');

/* V5.60 — Training Center Announcements row (class cancellations,
   no-class days, venue changes, holiday closures, etc.) maintained at
   Settings → Training Center Announcements (mnt_announcement). */
$annTitle = site_content('site_news_announce_title', 'Training Center Announcements');
$annIntro = site_content('site_news_announce_intro', 'Official notices on class schedules, cancellations, and training-center operations.');
$announcements = [];
if ($pdo) {
    $annStmt = $pdo->query(
        "SELECT id, title, message, announcement_date
         FROM mnt_announcement
         WHERE is_active = 1
         ORDER BY COALESCE(announcement_date, created_at) DESC, id DESC
         LIMIT 10"
    );
    foreach ($annStmt->fetchAll() ?: [] as $a) {
        $announcements[] = [
            'id'     => (int) $a['id'],
            'title'  => (string) $a['title'],
            'message'=> (string) ($a['message'] ?? ''),
            'date'   => $a['announcement_date'],
        ];
    }
}

$items = [];
if ($pdo) {
    $stmt = $pdo->prepare(
        "SELECT t.id AS batch_id, t.training_no, t.batch_name, t.start_date, t.end_date, t.max_slots, t.venue,
                c.id AS course_id, c.code, c.course_name, c.price_amount,
                COALESCE(CONCAT(i.first_name, ' ', i.last_name), u.full_name, '—') AS lead_instructor,
                (SELECT COUNT(*) FROM enrollment e
                 WHERE e.training_id = t.id AND e.status NOT IN ('cancelled','no_show')) AS filled,
                bs.name AS batch_status
         FROM training t
         JOIN mnt_course c ON c.id = t.course_id
         LEFT JOIN instructor i ON i.id = t.lead_instructor_id
         LEFT JOIN sys_user u ON u.id = t.lead_instructor_id
         LEFT JOIN mnt_batch_status bs ON bs.id = t.batch_status_id
         WHERE c.is_active = 1
           AND t.start_date >= DATE_SUB(CURDATE(), INTERVAL 0 DAY)
           AND (bs.name IS NULL OR LOWER(bs.name) NOT IN ('closed','cancelled','completed','done','archived'))
         ORDER BY t.start_date ASC
         LIMIT 30"
    );
    $stmt->execute();
    foreach ($stmt->fetchAll() ?: [] as $b) {
        $items[] = [
            'batch_id'       => (int) $b['batch_id'],
            'training_no'    => $b['training_no'],
            'batch_name'     => $b['batch_name'],
            'start'          => $b['start_date'],
            'end'            => $b['end_date'],
            'venue'          => trim((string) ($b['venue'] ?? '')),
            'lead_instructor'=> trim((string) ($b['lead_instructor'] ?? '')),
            'slots'          => (int) $b['max_slots'],
            'filled'         => (int) $b['filled'],
            'course_id'      => (int) $b['course_id'],
            'course_name'    => $b['course_name'],
            'fee'            => (float) $b['price_amount'],
        ];
    }
}
?>
<section id="news" class="news">

    <div class="container">

        <div class="news__head">
            <span class="news__eyebrow">Enrollment News</span>
            <h2 class="news__title">Now Enrolling</h2>
            <p class="news__intro"><?= htmlspecialchars($newsIntro, ENT_QUOTES, 'UTF-8'); ?></p>
        </div>

        <?php if (!$items): ?>
            <p class="news__empty">No batches are currently enrolling. Please check back soon or send us an inquiry.</p>
        <?php endif; ?>

        <div class="news__grid">
            <?php foreach ($items as $it): ?>
                <article class="news__card reveal">
                    <div class="news__card-top">
                        <span class="news__badge">Now Enrolling</span>
                        <span class="news__batch" title="Batch Number"><?= htmlspecialchars($it['training_no'], ENT_QUOTES, 'UTF-8'); ?></span>
                    </div>
                    <h3 class="news__card-title"><?= htmlspecialchars($it['course_name'], ENT_QUOTES, 'UTF-8'); ?></h3>

                    <div class="news__card-details">
                        <div class="news__detail"><span>Location</span><strong><?= e($it['venue'] !== '' ? $it['venue'] : 'USMCI Training Center'); ?></strong></div>
                        <div class="news__detail"><span>Date</span><strong><?= date('M d', strtotime($it['start'])); ?> → <?= date('M d, Y', strtotime($it['end'])); ?></strong></div>
                        <div class="news__detail"><span>Lead Instructor</span><strong><?= e($it['lead_instructor']); ?></strong></div>
                    </div>

                    <div class="news__card-meta">
                        <span>👥 <?= $it['filled']; ?>/<?= $it['slots']; ?> slots</span>
                        <span class="news__fee">₱ <?= number_format($it['fee'], 2); ?></span>
                    </div>

                    <div class="news__card-foot">
                        <a class="news__btn" href="<?= e(base_url('sections/admissions/inquiry/index.php?course=' . urlencode($it['course_name']))); ?>" target="_blank">📩 Inquiry</a>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>

        <!-- ==========================================
             TRAINING CENTER ANNOUNCEMENTS (V5.60)
        =========================================== -->
        <?php if ($announcements): ?>
            <div class="news__announce">

                <div class="news__announce-head">
                    <span class="news__announce-eyebrow">Official Notices</span>
                    <h3 class="news__announce-title"><?= htmlspecialchars($annTitle, ENT_QUOTES, 'UTF-8'); ?></h3>
                    <p class="news__announce-intro"><?= htmlspecialchars($annIntro, ENT_QUOTES, 'UTF-8'); ?></p>
                </div>

                <div class="news__announce-list">
                    <?php foreach ($announcements as $an): ?>
                        <article class="news__announce-item reveal">
                            <span class="news__announce-icon" aria-hidden="true">📢</span>
                            <div class="news__announce-body">
                                <h4><?= htmlspecialchars($an['title'], ENT_QUOTES, 'UTF-8'); ?></h4>
                                <?php if ($an['message'] !== ''): ?>
                                    <p><?= htmlspecialchars($an['message'], ENT_QUOTES, 'UTF-8'); ?></p>
                                <?php endif; ?>
                            </div>
                            <time class="news__announce-date" datetime="<?= e($an['date'] ?? ''); ?>">
                                <?= $an['date'] ? e(date('M d, Y', strtotime((string) $an['date']))) : 'Ongoing'; ?>
                            </time>
                        </article>
                    <?php endforeach; ?>
                </div>

            </div>
        <?php endif; ?>

    </div>

</section>
