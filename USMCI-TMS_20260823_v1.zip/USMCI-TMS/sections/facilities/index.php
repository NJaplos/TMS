<?php
/**
 * -------------------------------------------------------------------------
 * USMCI-TMS — Website Section: Facilities (one-page anchor #facilities)
 * -------------------------------------------------------------------------
 * V5.56 (client): 3D ROTATING WHEEL CAROUSEL + photo MODAL per category.
 *
 *  • CAROUSEL — photos ride an invisible 3D wheel (front = big & bright;
 *    sides = angled + faded; back = faded to near-invisible). Auto-rotates,
 *    pauses on hover, arrows + gold dots, click a side photo to bring it
 *    to the front. Fed automatically from the "training-center" folder.
 *
 *  • CATEGORY CARDS — one card per image subfolder. Clicking a card opens
 *    a full-screen MODAL with that facility's photos (grid + lightbox with
 *    prev/next). No more separate gallery page in the navbar.
 *
 * Folders auto-fetched (drop images in → they appear):
 *   assets/images/site/facilities/<category>/
 *     training-center · classroom · simulators · fire-safety · equipment
 * -------------------------------------------------------------------------
 */
declare(strict_types=1);

$facIntro   = site_content('site_facilities_intro', 'Train in an environment built for seafarers — modern classrooms, hands-on simulators, and safety equipment that mirror the realities of life at sea.');
$facTitle   = site_content('site_facilities_title', 'World-Class Training Facilities');

/* main rotating wheel from the training-center folder */
$carouselImages = site_gallery_images('assets/images/site/facilities/training-center', 12);
if (!$carouselImages) {
    $carouselImages = [base_url('assets/images/site/facility-2.jpg')];
}

/* category cards: one per image subfolder (each auto-fetched) */
$catBase = 'assets/images/site/facilities';
$cats = site_gallery_categories($catBase);

/* ---- V5.64: 6 SIMPLE FEATURE CARDS (per client reference) ----
   Each comes from the editable site_facilities_features setting
   ("Title: description" one per line). An icon is auto-assigned by
   keyword; if the card's title matches an image folder, clicking it
   opens the photo modal. */
$featureIcons = [
    'classroom'  => '🏫',
    'simulator'  => '⚙️',
    'fire'       => '🧯',
    'equipment'  => '⚓',
    'library'    => '📚',
    'amenit'     => '☕',
];
$featureSlugs = [
    'classroom'  => 'classroom',
    'simulator'  => 'simulators',
    'fire'       => 'fire-safety',
    'equipment'  => 'equipment',
    'library'    => null,
    'amenit'     => null,
];
$facFeatures = site_content_lines('site_facilities_features', "Classrooms: Modern, air-conditioned lecture rooms with audio-visual aids.\nSimulators: State-of-the-art bridge, engine-room and cargo simulators.\nFire & Safety: Dedicated fire-fighting and survival training grounds.\nEquipment: Up-to-date onboard technology and life-saving appliances.\nLibrary & Study: Reference library and quiet study areas.\nAmenities: Convenient facilities for trainees and assessors.");
$featureCards = [];
foreach ($facFeatures as $line) {
    $line = trim($line);
    if ($line === '') { continue; }
    $colon = strpos($line, ':');
    $title = $colon !== false ? trim(substr($line, 0, $colon)) : $line;
    $desc  = $colon !== false ? trim(substr($line, $colon + 1)) : '';
    $lower = strtolower($title);
    $icon  = '🏢';
    $slug  = null;
    foreach ($featureIcons as $key => $ic) {
        if (strpos($lower, $key) !== false) { $icon = $ic; break; }
    }
    foreach ($featureSlugs as $key => $sl) {
        if (strpos($lower, $key) !== false) { $slug = $sl; break; }
    }
    $imgs = $slug ? site_gallery_images("$catBase/$slug", 24) : [];
    $featureCards[] = [
        'title'  => $title,
        'desc'   => $desc,
        'icon'   => $icon,
        'slug'   => $slug,
        'images' => $imgs,
    ];
}
/* fallback if the setting is empty */
if (!$featureCards) {
    $featureCards = [
        ['title' => 'Classrooms', 'desc' => 'Modern, air-conditioned lecture rooms.', 'icon' => '🏫', 'slug' => 'classroom', 'images' => site_gallery_images("$catBase/classroom", 24)],
        ['title' => 'Simulators', 'desc' => 'Bridge, engine-room and cargo simulators.', 'icon' => '⚙️', 'slug' => 'simulators', 'images' => site_gallery_images("$catBase/simulators", 24)],
        ['title' => 'Fire & Safety', 'desc' => 'Dedicated fire-fighting training grounds.', 'icon' => '🧯', 'slug' => 'fire-safety', 'images' => site_gallery_images("$catBase/fire-safety", 24)],
        ['title' => 'Equipment', 'desc' => 'Onboard technology and life-saving appliances.', 'icon' => '⚓', 'slug' => 'equipment', 'images' => site_gallery_images("$catBase/equipment", 24)],
        ['title' => 'Library & Study', 'desc' => 'Reference library and quiet study areas.', 'icon' => '📚', 'slug' => null, 'images' => []],
        ['title' => 'Amenities', 'desc' => 'Convenient facilities for trainees.', 'icon' => '☕', 'slug' => null, 'images' => []],
    ];
}
$icons = ['training-center' => '🏢', 'classroom' => '🏫', 'simulators' => '⚙️', 'fire-safety' => '🧯', 'equipment' => '⚓'];
?>
<section id="facilities" class="facilities">

    <div class="container">

        <div class="facilities__head">
            <span class="facilities__eyebrow reveal">Our Facilities</span>
            <h2 class="facilities__title reveal"><?= htmlspecialchars($facTitle, ENT_QUOTES, 'UTF-8'); ?></h2>
            <p class="facilities__intro reveal"><?= htmlspecialchars($facIntro, ENT_QUOTES, 'UTF-8'); ?></p>
        </div>

        <!-- ==========================================
             3D ROTATING WHEEL CAROUSEL
        =========================================== -->
        <div class="fac-stage reveal">
            <div class="fac-carousel" id="facCarousel" aria-roledescription="carousel" aria-label="Facility showcase">
                <div class="fac-carousel__core" aria-hidden="true"></div>
                <div class="fac-carousel__track">
                    <?php foreach ($carouselImages as $i => $src): ?>
                        <div class="fac-carousel__slide <?= $i === 0 ? 'is-active' : ''; ?>" data-slide="<?= $i; ?>" role="group" aria-label="Photo <?= $i + 1; ?> of <?= count($carouselImages); ?>">
                            <img src="<?= e($src); ?>" alt="Training Center <?= $i + 1; ?>" loading="lazy" draggable="false">
                        </div>
                    <?php endforeach; ?>
                </div>
                <div class="fac-carousel__dots" role="tablist" aria-label="Slide dots">
                    <?php foreach ($carouselImages as $i => $_): ?>
                        <button type="button" class="fac-carousel__dot <?= $i === 0 ? 'is-active' : ''; ?>" data-slide="<?= $i; ?>" aria-label="Go to photo <?= $i + 1; ?>"></button>
                    <?php endforeach; ?>
                </div>
            </div>
            <!-- Arrows sit OUTSIDE the image (stage-level, far left/right) -->
            <button class="fac-carousel__btn fac-carousel__btn--prev" type="button" aria-label="Previous photo">&#10094;</button>
            <button class="fac-carousel__btn fac-carousel__btn--next" type="button" aria-label="Next photo">&#10095;</button>
        </div>

        <!-- ==========================================
             FEATURE CARDS — 6 simple icon cards
             (V5.64 per client reference: icon + gold
              title + white description; click a card
              with photos opens the modal)
        =========================================== -->
        <div class="fac-cats">
            <?php foreach ($featureCards as $fc): ?>
                <?php if ($fc['images']): ?>
                    <button class="fac-cat reveal" type="button"
                            data-cat="<?= e($fc['slug'] ?? ''); ?>"
                            data-name="<?= e($fc['title']); ?>"
                            data-images='<?= htmlspecialchars(json_encode($fc['images'], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE), ENT_QUOTES, 'UTF-8'); ?>'
                            aria-haspopup="dialog">
                        <span class="fac-cat__icon" aria-hidden="true"><?= $fc['icon']; ?></span>
                        <span class="fac-cat__body">
                            <h3><?= e($fc['title']); ?></h3>
                            <p><?= e($fc['desc']); ?></p>
                        </span>
                    </button>
                <?php else: ?>
                    <div class="fac-cat fac-cat--static reveal">
                        <span class="fac-cat__icon" aria-hidden="true"><?= $fc['icon']; ?></span>
                        <span class="fac-cat__body">
                            <h3><?= e($fc['title']); ?></h3>
                            <p><?= e($fc['desc']); ?></p>
                        </span>
                    </div>
                <?php endif; ?>
            <?php endforeach; ?>
        </div>

        <!-- CTA — two buttons (per reference: Explore Courses + Send an Inquiry) -->
        <div class="facilities__cta reveal">
            <a href="#courses" class="facilities__btn facilities__btn--primary">Explore Courses</a>
            <a href="<?= e(base_url('sections/admissions/inquiry/index.php')); ?>" class="facilities__btn facilities__btn--ghost" target="_blank">Send an Inquiry</a>
        </div>

    </div>

</section>

<!-- ==========================================
     FACILITY PHOTO MODAL (shared by all cards)
=========================================== -->
<div class="fac-modal" id="facModal" hidden aria-hidden="true" role="dialog" aria-modal="true" aria-labelledby="facModalTitle">
    <div class="fac-modal__backdrop" data-fm-close></div>
    <div class="fac-modal__dialog">
        <button class="fac-modal__close" type="button" data-fm-close aria-label="Close photos">&times;</button>
        <div class="fac-modal__head">
            <span class="fac-modal__eyebrow">Facility Photos</span>
            <h3 class="fac-modal__title" id="facModalTitle"></h3>
            <span class="fac-modal__count" id="facModalCount"></span>
        </div>
        <div class="fac-modal__grid" id="facModalGrid"></div>
        <p class="fac-modal__empty" id="facModalEmpty" hidden>No photos in this category yet — check back soon.</p>

        <!-- inline lightbox -->
        <div class="fac-lb" id="facModalLb" hidden>
            <button class="fac-lb__close" type="button" data-lb-close aria-label="Close photo view">&times;</button>
            <button class="fac-lb__btn fac-lb__btn--prev" type="button" aria-label="Previous photo">&#10094;</button>
            <img class="fac-lb__img" id="facModalLbImg" src="" alt="Facility photo">
            <button class="fac-lb__btn fac-lb__btn--next" type="button" aria-label="Next photo">&#10095;</button>
            <span class="fac-lb__cap" id="facModalLbCap"></span>
        </div>
    </div>
</div>
