/*=========================================================
   USMCI-TMS — Facilities (V5.57)
   1. 3D rotating wheel carousel — side/back photos fade and
      sit OUTSIDE the front frame (no lapping)
   2. Category cards (original design) -> photo modal (3-color)
   3. Reveal scroll animation
=========================================================*/
(function () {
    "use strict";

    var reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    /* =====================================================
       1. 3D WHEEL CAROUSEL
    ===================================================== */
    var carousel = document.getElementById("facCarousel");
    var modal = document.getElementById("facModal");
    var carouselPaused = false;
    var carouselApi = null; /* { pause, auto } exposed to the modal */

    if (carousel) {
        var slides = carousel.querySelectorAll(".fac-carousel__slide");
        var dots = carousel.querySelectorAll(".fac-carousel__dot");
        /* V5.67: arrows live OUTSIDE the carousel (siblings in .fac-stage),
           so query from the document, not the carousel. */
        var prev = document.querySelector(".fac-carousel__btn--prev");
        var next = document.querySelector(".fac-carousel__btn--next");
        var current = 0;
        var timer = null;
        var n = slides.length;

        /*
          5-PHOTO FAN (V5.71) — slide width = 54% of the stage (set in CSS;
          the photos are ~50% BIGGER than V5.69). Every slide starts at
          left:50%/top:50% — translate(-50%,-50%) first centres it, then the
          wheel offset fans it out:
            WIDE screens (>=1900px): all FIVE photos visible
            smaller screens       : front + 2 sides (outers fade)
        */
        var CONFIG = {
            front: { ang: 0,   tx: 0,    tz: 0,    sc: 1,    op: 1,    z: 10 },
            side:  { ang: 15,  tx: 84,   tz: -20,  sc: .64,  op: .78,  z: 8  },
            back:  { ang: 28,  tx: 140,  tz: -40,  sc: .40,  op: .58,  z: 6  }
        };
        var CONFIG_MOBILE_SIDE = { ang: 16, tx: 90, tz: -16, sc: .72, op: .68, z: 8 };

        function narrow() { return window.innerWidth < 700; }
        function wide()   { return window.innerWidth >= 1900; }

        function layout() {
            if (n < 2) return;
            var half = Math.floor(n / 2);
            var isNarrow = narrow();
            var isWide = wide();
            Array.prototype.forEach.call(slides, function (s, i) {
                var off = ((i - current) % n + n) % n;
                if (off > half) off -= n;
                var a = Math.abs(off);
                var c = a === 0 ? CONFIG.front : (a === 1 ? CONFIG.side : CONFIG.back);
                var sign = off < 0 ? -1 : 1;
                var tx = c.tx;
                /* Smaller screens: show only front + 2 sides (outers fade out). */
                if (!isWide && a >= 2) {
                    c = { ang: 0, tx: 0, tz: 0, sc: .5, op: 0, z: 3 };
                    tx = 0;
                }
                if (isNarrow && a === 1) { c = CONFIG_MOBILE_SIDE; tx = CONFIG_MOBILE_SIDE.tx; }
                var ang = off === 0 ? 0 : c.ang * sign;
                var xOff = off === 0 ? 0 : tx * sign;
                s.style.transform = "translate(-50%, -50%) translateX(" + xOff + "%) translateZ(" + c.tz + "px) rotateY(" + ang + "deg) scale(" + c.sc + ")";
                s.style.opacity = c.op;
                s.style.zIndex = c.z;
                s.classList.toggle("is-active", a === 0);
            });
        }

        function go(i) {
            current = ((i % n) + n) % n;
            layout();
            Array.prototype.forEach.call(dots, function (d, idx) {
                d.classList.toggle("is-active", idx === current);
            });
        }

        function auto() {
            if (timer) clearInterval(timer);
            if (n < 2 || reduced || carouselPaused) return;
            timer = setInterval(function () { go(current + 1); }, 4000);
        }
        carouselApi = {
            pause: function () { if (timer) clearInterval(timer); },
            auto: auto
        };

        if (prev) prev.addEventListener("click", function () { go(current - 1); auto(); });
        if (next) next.addEventListener("click", function () { go(current + 1); auto(); });
        Array.prototype.forEach.call(dots, function (d) {
            d.addEventListener("click", function () { go(parseInt(d.dataset.slide, 10) || 0); auto(); });
        });

        /* click a side/back photo -> bring it to the front */
        Array.prototype.forEach.call(slides, function (s) {
            s.addEventListener("click", function () {
                if (s.classList.contains("is-active")) return;
                go(parseInt(s.dataset.slide, 10) || 0);
                auto();
            });
        });

        /* pause while hovering */
        carousel.addEventListener("mouseenter", function () { if (timer) clearInterval(timer); });
        carousel.addEventListener("mouseleave", auto);
        carousel.addEventListener("focusin", function () { if (timer) clearInterval(timer); });
        carousel.addEventListener("focusout", auto);

        /* touch swipe */
        var sx = null;
        carousel.addEventListener("touchstart", function (e) {
            sx = e.changedTouches[0].clientX;
            if (timer) clearInterval(timer);
        }, { passive: true });
        carousel.addEventListener("touchend", function (e) {
            if (sx === null) return;
            var dx = e.changedTouches[0].clientX - sx;
            if (Math.abs(dx) > 42) go(current + (dx < 0 ? 1 : -1));
            sx = null;
            auto();
        }, { passive: true });

        window.addEventListener("resize", function () { layout(); });
        layout();
        if (!reduced) auto();
    }

    /* =====================================================
       2. CATEGORY CARD -> PHOTO MODAL + LIGHTBOX
    ===================================================== */
    if (modal) {
        var grid = document.getElementById("facModalGrid");
        var lb = document.getElementById("facModalLb");
        var lbImg = document.getElementById("facModalLbImg");
        var lbCap = document.getElementById("facModalLbCap");
        var modalTitle = document.getElementById("facModalTitle");
        var modalCount = document.getElementById("facModalCount");
        var modalEmpty = document.getElementById("facModalEmpty");
        var lbIndex = 0;
        var lbImages = [];
        var lbName = "";
        var lastFocus = null;

        function openModal(name, imgs) {
            carouselPaused = true;
            if (carouselApi) carouselApi.pause();
            modalTitle.textContent = name;
            grid.innerHTML = "";
            lb.hidden = true;
            if (!imgs.length) {
                modalEmpty.hidden = false;
                modalCount.textContent = "0 photos";
            } else {
                modalEmpty.hidden = true;
                modalCount.textContent = imgs.length + (imgs.length === 1 ? " photo" : " photos");
                imgs.forEach(function (src, i) {
                    var b = document.createElement("button");
                    b.type = "button";
                    b.className = "fac-modal__item";
                    b.setAttribute("aria-label", "View photo " + (i + 1) + " of " + imgs.length);
                    var img = document.createElement("img");
                    img.src = src;
                    img.alt = name + " photo " + (i + 1);
                    img.loading = "lazy";
                    b.appendChild(img);
                    b.addEventListener("click", function () { openLb(i, imgs, name); });
                    grid.appendChild(b);
                });
            }
            modal.hidden = false;
            modal.setAttribute("aria-hidden", "false");
            document.body.style.overflow = "hidden";
            lastFocus = document.activeElement;
            var closeBtn = modal.querySelector(".fac-modal__close");
            if (closeBtn) closeBtn.focus();
        }

        function closeModal() {
            modal.hidden = true;
            modal.setAttribute("aria-hidden", "true");
            lb.hidden = true;
            document.body.style.overflow = "";
            carouselPaused = false;
            if (carouselApi) carouselApi.auto();
            if (lastFocus && lastFocus.focus) lastFocus.focus();
        }

        function openLb(i, imgs, name) {
            lbIndex = i;
            lbImages = imgs;
            lbName = name;
            lbImg.src = imgs[i];
            lbImg.alt = (name || "Facility") + " photo " + (i + 1);
            lbCap.textContent = (i + 1) + " / " + imgs.length;
            lb.hidden = false;
        }

        function lbStep(d) {
            if (!lbImages.length) return;
            lbIndex = ((lbIndex + d) % lbImages.length + lbImages.length) % lbImages.length;
            lbImg.src = lbImages[lbIndex];
            lbImg.alt = (lbName || "Facility") + " photo " + (lbIndex + 1);
            lbCap.textContent = (lbIndex + 1) + " / " + lbImages.length;
        }

        document.querySelectorAll(".fac-cat").forEach(function (card) {
            card.addEventListener("click", function () {
                var name = card.dataset.name || "Facility";
                var imgs = [];
                try { imgs = JSON.parse(card.dataset.images || "[]"); } catch (e) { imgs = []; }
                openModal(name, imgs);
            });
        });

        modal.querySelectorAll("[data-fm-close]").forEach(function (b) {
            b.addEventListener("click", function (e) {
                if (e.target === b) closeModal();
            });
        });
        modal.addEventListener("click", function (e) { if (e.target === e.currentTarget) closeModal(); });

        lb.querySelector("[data-lb-close]").addEventListener("click", function () { lb.hidden = true; });
        lb.querySelector(".fac-lb__btn--prev").addEventListener("click", function () { lbStep(-1); });
        lb.querySelector(".fac-lb__btn--next").addEventListener("click", function () { lbStep(1); });
        lb.addEventListener("click", function (e) {
            if (e.target === lb) { lb.hidden = true; }
        });

        document.addEventListener("keydown", function (e) {
            if (modal.hidden) return;
            if (e.key === "Escape") {
                if (!lb.hidden) { lb.hidden = true; e.preventDefault(); }
                else closeModal();
            } else if (!lb.hidden && (e.key === "ArrowLeft" || e.key === "ArrowRight")) {
                lbStep(e.key === "ArrowRight" ? 1 : -1);
                e.preventDefault();
            }
        });
    }
})();
