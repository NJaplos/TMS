<?php
/**
 * -------------------------------------------------------------------------
 * USMCI-TMS — Website Footer (V5.58)
 * -------------------------------------------------------------------------
 * Brand + quick links + popular courses + contact block.
 * Contact data comes from the letterhead settings (report_*) so it
 * always matches the Contact section and official documents.
 * -------------------------------------------------------------------------
 */
declare(strict_types=1);

$fOrgName = report_setting('report_org_name', 'United Seafarers Maritime Center, Inc.');
$fAddr    = report_setting('report_org_address', 'G/F YMCA of Manila Bldg, 350 Antonio Villegas St, Ermita, Manila');
$fTel     = trim((string) preg_replace('/^[A-Z\s]+:\s*/i', '', report_setting('report_tel_no', 'TEL NO: 8241-0881')));
$fMob     = trim((string) preg_replace('/^[A-Z\s]+:\s*/i', '', report_setting('report_mobile_no', 'MOBILE NO: 09971201553')));
$fEmail   = report_setting('report_email', 'usmci2010@gmail.com');

$fCourses = [];
try {
    $pdo = function_exists('db') ? db() : null;
    if ($pdo) {
        $fCourses = $pdo->query("SELECT course_name FROM mnt_course WHERE is_active = 1 ORDER BY course_name LIMIT 4")->fetchAll(PDO::FETCH_COLUMN) ?: [];
    }
} catch (Throwable $e) {
    $fCourses = [];
}
?>
<footer class="site-footer">

    <div class="container">

        <div class="site-footer__grid">

            <div class="site-footer__col site-footer__col--brand">
                <h3 class="site-footer__title">United Seafarers<br>Maritime Center, Inc.</h3>
                <p class="site-footer__blurb">SEC Registered — CS201008536 · ISO 9001:2015 certified maritime training provider serving seafarers for over two decades.</p>
                <p class="site-footer__badges">🏅 MARINA Accredited &nbsp;·&nbsp; ⚓ STCW Compliant</p>
            </div>

            <div class="site-footer__col">
                <h4 class="site-footer__heading">Quick Links</h4>
                <ul class="site-footer__links">
                    <li><a href="index.php#about">About Us</a></li>
                    <li><a href="index.php#courses">Courses</a></li>
                    <li><a href="index.php#facilities">Facilities</a></li>
                    <li><a href="index.php#news">News &amp; Batches</a></li>
                    <li><a href="index.php#contact">Contact</a></li>
                    <li><a href="admissions.php">Apply Now</a></li>
                </ul>
            </div>

            <div class="site-footer__col">
                <h4 class="site-footer__heading">Popular Courses</h4>
                <ul class="site-footer__links">
                    <?php foreach ($fCourses as $fc): ?>
                        <li><a href="index.php#courses"><?= htmlspecialchars($fc, ENT_QUOTES, 'UTF-8'); ?></a></li>
                    <?php endforeach; ?>
                </ul>
            </div>

            <div class="site-footer__col">
                <h4 class="site-footer__heading">Contact</h4>
                <ul class="site-footer__links site-footer__links--contact">
                    <li>📍 <?= htmlspecialchars($fAddr, ENT_QUOTES, 'UTF-8'); ?></li>
                    <li>📞 <?= htmlspecialchars($fTel, ENT_QUOTES, 'UTF-8'); ?> · <?= htmlspecialchars($fMob, ENT_QUOTES, 'UTF-8'); ?></li>
                    <li>✉️ <?= htmlspecialchars($fEmail, ENT_QUOTES, 'UTF-8'); ?></li>
                    <li>🕒 Mon – Fri 8:00 AM – 5:00 PM · Sat 8:00 AM – 12:00 PM</li>
                </ul>
            </div>

        </div>

        <div class="site-footer__bottom">
            <p>&copy; <?= date('Y'); ?> <?= htmlspecialchars($fOrgName, ENT_QUOTES, 'UTF-8'); ?> — All rights reserved.</p>
            <p class="site-footer__credit">Powered by USMCI Training Management System</p>
        </div>

    </div>

</footer>
