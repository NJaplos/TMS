<?php

/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Admissions Portal (public)
 * ---------------------------------------------------------
 * Boots the app framework so base_url() and constants are
 * available — makes all links/asset paths portable regardless
 * of the project folder name.
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once __DIR__ . '/config/bootstrap.php';

$page = [

'title' => 'USMCI Admissions Portal',

'description' => 'Online Admissions Portal of USMCI',

'bodyClass' => 'admissions-page'

];

?>

<!DOCTYPE html>

<html lang="en">

<?php include 'includes/head.php'; ?>

<link rel="stylesheet" href="<?= e(base_url('sections/admissions/style.css')); ?>">

<body class="<?= $page['bodyClass']; ?>">

<?php include 'navbar/index.php'; ?>

<main id="main-content">

<?php include 'sections/admissions/index.php'; ?>

</main>

<?php include 'includes/footer.php'; ?>

<?php include 'includes/scripts.php'; ?>

<script src="<?= e(base_url('sections/admissions/assets/js/portal.js')); ?>"></script>

<script src="<?= e(base_url('sections/admissions/assets/js/slideshow.js')); ?>"></script>

</body>

</html>
