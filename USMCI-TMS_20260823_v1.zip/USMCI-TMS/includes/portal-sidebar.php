<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — UNIFIED PORTAL SIDEBAR
 * ---------------------------------------------------------
 * Used by BOTH the staff dashboards and the trainee
 * dashboard. Expects $portalNav (array of items) and
 * $portalUser (array with name/role/sub/code/photo) to be
 * set before include. The styling is 100% the approved
 * Admissions sidebar (assets/css/portal.css).
 * ---------------------------------------------------------
 */

$portalUser = $portalUser ?? current_user();
$portalNav  = $portalNav ?? [];

$pName = $portalUser['name'] ?? ($portalUser['full_name'] ?? 'User');
$pRole = $portalUser['role_label'] ?? ($portalUser['role_code'] ?? ($portalUser['role'] ?? 'User'));
$pSub  = $portalUser['sub'] ?? '';
$pPhoto = $portalUser['photo'] ?? '';
?>

<aside class="portal-sidebar">
    <div class="portal-profile">
        <div class="portal-avatar">
            <?php if ($pPhoto): ?>
                <img src="<?= e($pPhoto); ?>" alt="Profile" data-photo>
            <?php else: ?>
                👤
            <?php endif; ?>
        </div>
        <h1><?= e($pName); ?></h1>
        <p class="portal-role"><?= e($pRole); ?></p>
        <?php if ($pSub !== ''): ?><p class="portal-srn"><?= e($pSub); ?></p><?php endif; ?>
    </div>

    <nav class="portal-nav">
        <?php foreach ($portalNav as $item): ?>
            <a href="<?= e($item['href']); ?>" class="<?= !empty($item['active']) ? 'active' : ''; ?>">
                <span class="nav-ic"><?= $item['icon']; ?>
                    <?php if (!empty($item['badge'])): ?>
                        <span class="nav-badge"><?= (int) $item['badge']; ?></span>
                    <?php endif; ?>
                </span>
                <span class="nav-label"><?= e($item['label']); ?><span class="nav-desc"><?= e($item['desc'] ?? ''); ?></span></span>
            </a>
        <?php endforeach; ?>
    </nav>

    <div class="portal-sidebar__foot">
        <a href="<?= e(base_url('logout.php')); ?>" class="portal-logout">Sign Out</a>
    </div>
</aside>
