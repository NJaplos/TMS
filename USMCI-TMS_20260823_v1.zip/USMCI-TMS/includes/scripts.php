<?php
/*
|--------------------------------------------------------------------------
| USMCI-TMS
|--------------------------------------------------------------------------
| Global Script Loader
|--------------------------------------------------------------------------
|
| Loads all JavaScript modules required by the application.
| Add new section scripts here as the project grows.
|
*/
?>

<!-- ==================================================
     GLOBAL CORE
=================================================== -->

<!-- (Future)
<script src="assets/js/core/theme.js"></script>
<script src="assets/js/core/navigation.js"></script>
<script src="assets/js/core/api.js"></script>
-->

<!-- ==================================================
     NAVIGATION MODULE
=================================================== -->

<script src="navbar/config.js?v=<?= ASSET_VERSION; ?>"></script>

<script src="navbar/modules/toggle.js?v=<?= ASSET_VERSION; ?>"></script>

<script src="navbar/modules/sticky.js?v=<?= ASSET_VERSION; ?>"></script>

<script src="navbar/modules/active.js?v=<?= ASSET_VERSION; ?>"></script>

<script src="navbar/script.js?v=<?= ASSET_VERSION; ?>"></script>

<!-- ==================================================
     HERO MODULE
=================================================== -->

<script src="sections/hero/config.js?v=<?= ASSET_VERSION; ?>"></script>

<script src="sections/hero/modules/offset.js?v=<?= ASSET_VERSION; ?>"></script>

<script src="sections/hero/modules/carousel.js?v=<?= ASSET_VERSION; ?>"></script>

<script src="sections/hero/modules/counter.js?v=<?= ASSET_VERSION; ?>"></script>

<script src="sections/hero/modules/reveal.js?v=<?= ASSET_VERSION; ?>"></script>

<script src="sections/hero/modules/scroll.js?v=<?= ASSET_VERSION; ?>"></script>

<script src="sections/hero/script.js?v=<?= ASSET_VERSION; ?>"></script>

<?php if (file_exists(__DIR__ . '/../sections/about/about.js')): ?>
    <script src="sections/about/about.js?v=<?= ASSET_VERSION; ?>"></script>
<?php endif; ?>

<?php if (file_exists(__DIR__ . '/../sections/courses/courses.js')): ?>
    <script src="sections/courses/courses.js?v=<?= ASSET_VERSION; ?>"></script>
<?php endif; ?>

<?php if (file_exists(__DIR__ . '/../sections/facilities/facilities.js')): ?>
    <script src="sections/facilities/facilities.js?v=<?= ASSET_VERSION; ?>"></script>
<?php endif; ?>

<?php if (file_exists(__DIR__ . '/../sections/contact/contact.js')): ?>
    <script src="sections/contact/contact.js?v=<?= ASSET_VERSION; ?>"></script>
<?php endif; ?>

<!-- ==================================================
     UNIFIED TOAST (UDS .c-toast) — defines window.usmciToast
=================================================== -->

<script src="assets/js/usmci-toast.js?v=<?= ASSET_VERSION; ?>"></script>

<script src="assets/js/usmci-confirm.js?v=<?= ASSET_VERSION; ?>"></script>

<!-- ==================================================
     PAGE SPECIFIC
=================================================== -->

<!-- Future Page Scripts -->