<?php

if (!isset($page)) {
    $page = [];
}

$title = $page['title'] ?? 'USMCI Training Management System';

$description = $page['description']
    ?? 'Official Website of USMCI Training Management System';

$keywords = $page['keywords']
    ?? 'USMCI, Maritime, Training, Courses';

$author = 'USMCI';

/*
|--------------------------------------------------------------------------
| Base URL (portable)
|--------------------------------------------------------------------------
| Uses the application's BASE_URL constant when the page boots through
| config/bootstrap.php; otherwise falls back to a conventional value.
| Replace the fallback below with your own project folder name if it
| differs, or better — boot every page through bootstrap.php.
|--------------------------------------------------------------------------
*/
$baseHref = defined('BASE_URL') ? BASE_URL : '/USMCI-TMS/';
$baseHref = rtrim($baseHref, '/') . '/';

?>

<head>

    <meta charset="UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <!-- Ensures relative asset paths (assets/css/main.css,
         navbar/style.css, etc.) resolve correctly from ANY
         page URL depth — e.g. a page nested under
         sections/admissions/inquiry/ — rather than only from
         the site root. Harmless no-op for pages already at
         the root, like the homepage. -->
    <base href="<?= htmlspecialchars($baseHref, ENT_QUOTES, 'UTF-8'); ?>">

    <title><?= htmlspecialchars($title); ?></title>

    <meta name="description"
          content="<?= htmlspecialchars($description); ?>">

    <meta name="keywords"
          content="<?= htmlspecialchars($keywords); ?>">

    <meta name="author"
          content="<?= htmlspecialchars($author); ?>">

    <meta name="theme-color"
          content="#0f5d36">

    <!-- Favicon -->

    <link
        rel="icon"
        href="assets/images/branding/favicon.png">

    <!-- Google Fonts -->

    <link rel="preconnect"
          href="https://fonts.googleapis.com">

    <link rel="preconnect"
          href="https://fonts.gstatic.com"
          crossorigin>

    <link
        href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap"
        rel="stylesheet">

    <!-- Global CSS -->

    <link
        rel="stylesheet"
        href="assets/css/main.css?v=<?= ASSET_VERSION; ?>">

    <!-- Navigation -->

    <link
        rel="stylesheet"
        href="navbar/style.css?v=<?= ASSET_VERSION; ?>">

    <!-- Hero -->

    <link
        rel="stylesheet"
        href="sections/hero/style.css?v=<?= ASSET_VERSION; ?>">

    <?php if (file_exists(__DIR__ . '/../sections/about/style.css')): ?>
        <link rel="stylesheet" href="sections/about/style.css?v=<?= ASSET_VERSION; ?>">
    <?php endif; ?>

    <?php if (file_exists(__DIR__ . '/../sections/courses/style.css')): ?>
        <link rel="stylesheet" href="sections/courses/style.css?v=<?= ASSET_VERSION; ?>">
    <?php endif; ?>

    <?php if (file_exists(__DIR__ . '/../sections/news/style.css')): ?>
        <link rel="stylesheet" href="sections/news/style.css?v=<?= ASSET_VERSION; ?>">
    <?php endif; ?>

    <?php if (file_exists(__DIR__ . '/../sections/facilities/style.css')): ?>
        <link rel="stylesheet" href="sections/facilities/style.css?v=<?= ASSET_VERSION; ?>">
    <?php endif; ?>

    <?php if (file_exists(__DIR__ . '/../sections/contact/style.css')): ?>
        <link rel="stylesheet" href="sections/contact/style.css?v=<?= ASSET_VERSION; ?>">
    <?php endif; ?>

    <?php if (file_exists(__DIR__ . '/../sections/footer/style.css')): ?>
        <link rel="stylesheet" href="sections/footer/style.css?v=<?= ASSET_VERSION; ?>">
    <?php endif; ?>

</head>
