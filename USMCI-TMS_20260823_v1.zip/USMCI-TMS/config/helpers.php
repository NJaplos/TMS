<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Global Helper Functions
 * File : config/helpers.php
 * Version : 3.1
 *
 * Description
 * ---------------------------------------------------------
 * Global helper functions used throughout the
 * entire USMCI-TMS application.
 *
 * This file is automatically loaded by
 * config/bootstrap.php.
 * ---------------------------------------------------------
 */

if (!defined('USMCI_CONFIG')) {
    require_once __DIR__ . '/config.php';
}

/*
|--------------------------------------------------------------------------
| Ensure Paths are Available
|--------------------------------------------------------------------------
*/

if (!defined('BASE_PATH')) {
    require_once __DIR__ . '/paths.php';
}

/*==========================================================
Application URL
==========================================================*/

if (!function_exists('base_url')) {

    function base_url(string $path = ''): string
    {
        return rtrim(BASE_URL, '/') . '/' . ltrim($path, '/');
    }

}

/*==========================================================
Application Filesystem Path
==========================================================*/

if (!function_exists('base_path')) {

    function base_path(string $path = ''): string
    {
        return rtrim(BASE_PATH, DIRECTORY_SEPARATOR)
            . DIRECTORY_SEPARATOR
            . ltrim($path, DIRECTORY_SEPARATOR);
    }

}

/*==========================================================
Assets
==========================================================*/

if (!function_exists('asset')) {

    function asset(string $path): string
    {
        return base_url($path);
    }

}

/*==========================================================
Redirect
==========================================================*/

if (!function_exists('redirect')) {

    function redirect(string $url): void
    {
        header('Location: ' . $url);
        exit;
    }

}

/*==========================================================
HTML Escape
==========================================================*/

if (!function_exists('e')) {

    function e($value): string
    {
        return htmlspecialchars(
            (string)($value ?? ''),
            ENT_QUOTES,
            'UTF-8'
        );
    }

}

/*==========================================================
Flash Messages
==========================================================*/

if (!function_exists('flash')) {

    function flash(string $key, ?string $message = null)
    {
        if (!isset($_SESSION)) {
            return null;
        }

        if ($message !== null) {

            $_SESSION['_flash'][$key] = $message;

            return;
        }

        if (!isset($_SESSION['_flash'][$key])) {
            return null;
        }

        $value = $_SESSION['_flash'][$key];

        unset($_SESSION['_flash'][$key]);

        return $value;
    }

}

/*==========================================================
Current Timestamp
==========================================================*/

if (!function_exists('now')) {

    function now(): string
    {
        return date('Y-m-d H:i:s');
    }

}

/*==========================================================
Current Date
==========================================================*/

if (!function_exists('today')) {

    function today(): string
    {
        return date('Y-m-d');
    }

}

/*==========================================================
Dump & Die (Development Only)
==========================================================*/

if (!function_exists('dd')) {

    function dd($value): void
    {
        echo '<pre>';

        print_r($value);

        echo '</pre>';

        exit;
    }

}
/*==========================================================
AUDIT TRAIL
==========================================================*/

if (!function_exists('audit_log')) {

    /**
     * Write a lightweight audit entry for money/legal-sensitive
     * actions (payment records/voids, certificate voids,
     * applicant deletes, staff account changes).
     *
     * Uses the base schema's audit_log columns:
     *   actor_type='user', actor_id, action, table_name (module),
     *   record_id, new_values (detail), ip_address, user_agent.
     *
     * @param string $module   e.g. 'payments', 'certificates', 'applicants', 'staff'
     * @param string $action   e.g. 'record_payment', 'void', 'delete', 'create'
     * @param int|null $recordId
     * @param string $detail   short human-readable description
     */
    function audit_log(string $module, string $action, ?int $recordId = null, string $detail = ''): void
    {
        try {
            $pdo = db();
            $user = function_exists('current_user') ? current_user() : null;
            $userId = (int) ($user['id'] ?? 0);
            $ip = substr((string) ($_SERVER['REMOTE_ADDR'] ?? ''), 0, 45);
            $ua = substr((string) ($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 255);

            $pdo->prepare(
                'INSERT INTO audit_log (actor_type, actor_id, action, table_name, record_id, new_values, ip_address, user_agent, created_at)
                 VALUES (\'user\', :uid, :a, :t, :rid, :v, :ip, :ua, NOW())'
            )->execute([
                'uid' => $userId ?: null,
                'a'   => $module . '.' . $action,
                't'   => $module,
                'rid' => $recordId ?: null,
                /* new_values has a CHECK(json_valid) constraint — store JSON */
                'v'   => $detail !== '' ? json_encode(['detail' => substr($detail, 0, 500)]) : null,
                'ip'  => $ip !== '' ? $ip : null,
                'ua'  => $ua !== '' ? $ua : null,
            ]);
        } catch (Throwable $e) {
            // Never break the main action because of logging.
            error_log('audit_log failed: ' . $e->getMessage());
        }
    }
}

/*==========================================================
V5.32 — ENROLLMENT ⇄ PAYMENT AUTO-SYNC
==========================================================*/

if (!function_exists('send_enrollment_confirmation')) {

    /**
     * Queue (and immediately try to send) the "Enrollment Confirmed"
     * email for an enrollment. Returns the queued email id (0 if none).
     * Mirrors the email built in enrollment.php's status action.
     */
    function send_enrollment_confirmation(PDO $pdo, int $enrollmentId): int
    {
        try {
            $info = $pdo->prepare(
                "SELECT e.enrollment_no, a.first_name, a.last_name, a.email,
                        c.course_name,
                        t.training_no, t.batch_name, t.start_date, t.end_date, t.venue
                 FROM enrollment e
                 JOIN applicant a ON a.id = e.applicant_id
                 JOIN mnt_course c ON c.id = e.course_id
                 LEFT JOIN training t ON t.id = e.training_id
                 WHERE e.id = :id LIMIT 1"
            );
            $info->execute(['id' => $enrollmentId]);
            $ei = $info->fetch();
            if (!$ei || empty($ei['email'])) {
                return 0;
            }

            $payInfo = $pdo->prepare("SELECT payment_no, total_amount, due_date FROM payment WHERE enrollment_id = :id ORDER BY id DESC LIMIT 1");
            $payInfo->execute(['id' => $enrollmentId]);
            $pr = $payInfo->fetch();

            $qid = queue_email(
                $ei['email'],
                'Enrollment Confirmation — ' . $ei['enrollment_no'],
                email_shell('Enrollment Confirmed', '<p>Dear <strong>' . htmlspecialchars(trim($ei['first_name'] . ' ' . $ei['last_name'])) . '</strong>,</p>'
                    . '<p>You are now <strong>enrolled</strong> in <strong>' . htmlspecialchars($ei['course_name']) . '</strong>.</p>'
                    . '<table style="border-collapse:collapse;width:100%;font-size:13px;">'
                    . '<tr><td style="padding:6px 10px;border:1px solid #E2E8F0;"><strong>Registration No.</strong></td><td style="padding:6px 10px;border:1px solid #E2E8F0;">' . htmlspecialchars($ei['enrollment_no']) . '</td></tr>'
                    . ($ei['training_no'] ? '<tr><td style="padding:6px 10px;border:1px solid #E2E8F0;"><strong>Batch</strong></td><td style="padding:6px 10px;border:1px solid #E2E8F0;">' . htmlspecialchars($ei['training_no'] . ' · ' . $ei['batch_name']) . '</td></tr>'
                        . '<tr><td style="padding:6px 10px;border:1px solid #E2E8F0;"><strong>Schedule</strong></td><td style="padding:6px 10px;border:1px solid #E2E8F0;">' . htmlspecialchars(date('M d, Y', strtotime($ei['start_date'])) . ' → ' . date('M d, Y', strtotime($ei['end_date']))) . '</td></tr>'
                        . '<tr><td style="padding:6px 10px;border:1px solid #E2E8F0;"><strong>Location</strong></td><td style="padding:6px 10px;border:1px solid #E2E8F0;">' . htmlspecialchars($ei['venue'] ?: 'USMCI Training Center') . '</td></tr>' : '')
                    . ($pr ? '<tr><td style="padding:6px 10px;border:1px solid #E2E8F0;"><strong>Course Fee</strong></td><td style="padding:6px 10px;border:1px solid #E2E8F0;">₱ ' . number_format((float) $pr['total_amount'], 2) . ' (Payment ' . htmlspecialchars($pr['payment_no']) . ')</td></tr>'
                        . ($pr['due_date'] ? '<tr><td style="padding:6px 10px;border:1px solid #E2E8F0;"><strong>Due Date</strong></td><td style="padding:6px 10px;border:1px solid #E2E8F0;">' . htmlspecialchars($pr['due_date']) . '</td></tr>' : '') : '')
                    . '</table>'
                    . '<p>Kindly come on time. Training is forfeited if you miss the schedule; a 15-minute grace period is allowed.</p>')
            );
            if ($qid) {
                mailer_send_now($qid);
            }
            return (int) $qid;
        } catch (Throwable $e) {
            error_log('send_enrollment_confirmation: ' . $e->getMessage());
            return 0;
        }
    }
}

if (!function_exists('auto_sync_enrollment_from_payment')) {

    /**
     * Keep the enrollment status consistent with its payments.
     *   - pending   + any paid amount (non-void/refunded)  → enrolled (+ confirmation email)
     *   - enrolled  + nothing paid (all payments voided/deleted) → back to pending
     * Returns the new status applied ('enrolled' / 'pending' / '').
     * Mirrors the manual status gate so the two can never disagree.
     */
    function auto_sync_enrollment_from_payment(PDO $pdo, int $paymentId, ?int $enrollmentIdOverride = null): string
    {
        $enrollmentId = $enrollmentIdOverride ?: 0;
        if (!$enrollmentId) {
            $stmt = $pdo->prepare('SELECT enrollment_id FROM payment WHERE id = :id');
            $stmt->execute(['id' => $paymentId]);
            $enrollmentId = (int) ($stmt->fetchColumn() ?: 0);
        }
        if (!$enrollmentId) {
            return '';
        }

        $stmt = $pdo->prepare(
            "SELECT COALESCE(SUM(paid_amount), 0) FROM payment
             WHERE enrollment_id = :eid AND payment_status_id NOT IN (4, 5)"
        );
        $stmt->execute(['eid' => $enrollmentId]);
        $paid = (float) $stmt->fetchColumn();

        $stmt = $pdo->prepare('SELECT status, endorser_type FROM enrollment WHERE id = :id');
        $stmt->execute(['id' => $enrollmentId]);
        $row = $stmt->fetch();
        $current = (string) ($row['status'] ?? '');
        $endType = ((string) ($row['endorser_type'] ?? 'marketing')) === 'company' ? 'company' : 'marketing';

        /* V5.33: honor the configurable process rules */
        $requirePaid = process_rule(
            $endType === 'company' ? 'rule_enroll_company_require_paid' : 'rule_enroll_marketing_require_paid',
            $endType !== 'company'
        );
        $autoEnroll = process_rule('rule_auto_enroll_on_payment', true);

        $uid = (int) ((function_exists('current_user') ? (current_user()['id'] ?? 0) : 0));
        $changed = '';

        if ($current === 'pending' && $paid > 0 && $autoEnroll) {
            $pdo->prepare("UPDATE enrollment SET status = 'enrolled', updated_at = NOW() WHERE id = :id")
                ->execute(['id' => $enrollmentId]);
            $pdo->prepare("INSERT INTO enrollment_history (enrollment_id, changed_by, old_status, new_status, created_at)
                           VALUES (:eid, :uid, 'pending', 'enrolled', NOW())")
                ->execute(['eid' => $enrollmentId, 'uid' => $uid ?: null]);
            send_enrollment_confirmation($pdo, $enrollmentId);
            $changed = 'enrolled';
        } elseif ($current === 'enrolled' && $paid <= 0 && $requirePaid) {
            /* only revert when this endorser type's rule still requires payment
               (company-endorsed with "no payment required" stays Enrolled) */
            $pdo->prepare("UPDATE enrollment SET status = 'pending', updated_at = NOW() WHERE id = :id")
                ->execute(['id' => $enrollmentId]);
            $pdo->prepare("INSERT INTO enrollment_history (enrollment_id, changed_by, old_status, new_status, created_at)
                           VALUES (:eid, :uid, 'enrolled', 'pending', NOW())")
                ->execute(['eid' => $enrollmentId, 'uid' => $uid ?: null]);
            $changed = 'pending';
        }

        return $changed;
    }
}

/*==========================================================
V5.33 — PROCESS RULES (configurable enrollment/certificate policy)
==========================================================*/

if (!function_exists('process_rule')) {

    /**
     * Read a process rule (boolean toggle) from mnt_system_setting.
     * Defaults are baked into the code so the app still behaves
     * correctly even before v17 is applied.
     *
     * Rule keys (Settings → Process Rules):
     *   rule_enroll_marketing_require_paid  — marketing: paid before Enrolled
     *   rule_enroll_company_require_paid    — company:   paid before Enrolled
     *   rule_auto_enroll_on_payment         — payment → auto Enrolled
     *   rule_cert_marketing_require_paid    — marketing: paid before certificate
     *   rule_cert_company_allow_unpaid      — company:   certificate allowed unpaid
     *   rule_cert_require_enrolled_status   — certificate needs Enrolled/Completed
     *   rule_auto_complete_on_cert          — certificate → enrollment Completed
     *
     * @var array<string,bool> $cache per-request
     */
    static $ruleCache = [];

    function process_rule(string $key, bool $default = true): bool
    {
        static $cache = [];
        if (array_key_exists($key, $cache)) {
            return $cache[$key];
        }
        $cache[$key] = $default;
        try {
            $pdo = db();
            $stmt = $pdo->prepare('SELECT setting_value FROM mnt_system_setting WHERE setting_key = :k LIMIT 1');
            $stmt->execute(['k' => $key]);
            $v = $stmt->fetchColumn();
            if ($v !== false && $v !== null) {
                $cache[$key] = in_array(strtolower(trim((string) $v)), ['1', 'true', 'on', 'yes'], true);
            }
        } catch (Throwable $e) {
            error_log('process_rule(' . $key . '): ' . $e->getMessage());
        }
        return $cache[$key];
    }
}

/*==========================================================
V5.37 — APPLICANT DOCUMENTS STATUS (requirements gate)
==========================================================*/

if (!function_exists('applicant_docs_status')) {

    /**
     * How many requirement documents an applicant has submitted vs
     * how many are required (active mnt_document_type rows).
     * Used by the enrollment list ("Docs: X/Y") and the optional
     * "require documents before Enrolled" process rule.
     *
     * @return array{submitted:int, required:int}
     */
    function applicant_docs_status(PDO $pdo, int $applicantId): array
    {
        $sub = $pdo->prepare(
            "SELECT COUNT(*) FROM document
             WHERE owner_type = 'applicant' AND owner_id = :id
               AND status IN ('submitted','verified')"
        );
        $sub->execute(['id' => $applicantId]);

        $req = $pdo->prepare('SELECT COUNT(*) FROM mnt_document_type WHERE is_active = 1');
        $req->execute();

        return [
            'submitted' => (int) $sub->fetchColumn(),
            'required'  => (int) $req->fetchColumn(),
        ];
    }
}

/*==========================================================
V5.38 — REPORT LETTERHEAD SETTINGS + COURSE REQUIRED DOCS
==========================================================*/

if (!function_exists('report_setting')) {

    /**
     * Read a printable-report letterhead setting (Settings →
     * Report Letterhead). Falls back to the school's default so
     * reports print correctly even before the setting is saved.
     */
    function report_setting(string $key, string $default): string
    {
        static $cache = [];
        if (array_key_exists($key, $cache)) {
            return $cache[$key];
        }
        $cache[$key] = $default;
        try {
            $pdo = db();
            $stmt = $pdo->prepare('SELECT setting_value FROM mnt_system_setting WHERE setting_key = :k LIMIT 1');
            $stmt->execute(['k' => $key]);
            $v = $stmt->fetchColumn();
            if ($v !== false && $v !== null && trim((string) $v) !== '') {
                $cache[$key] = (string) $v;
            }
        } catch (Throwable $e) {
            error_log('report_setting(' . $key . '): ' . $e->getMessage());
        }
        return $cache[$key];
    }
}

if (!function_exists('course_required_docs')) {

    /**
     * Required document types for a course (Settings → Requirements).
     * @return array<int, array{id:int, code:string, name:string}>
     */
    function course_required_docs(PDO $pdo, int $courseId): array
    {
        $stmt = $pdo->prepare(
            "SELECT dt.id, dt.code, dt.name
             FROM course_prerequisite cp
             JOIN mnt_document_type dt ON dt.id = cp.required_document_type_id
             WHERE cp.course_id = :cid AND cp.required_document_type_id IS NOT NULL
               AND dt.is_active = 1
             ORDER BY dt.sort_order, dt.name"
        );
        $stmt->execute(['cid' => $courseId]);
        return $stmt->fetchAll() ?: [];
    }
}

/*==========================================================
V5.41 — QR IMAGE HELPER (printed certificates)
==========================================================*/

if (!function_exists('qr_png_base64')) {

    /**
     * Render a QR code as a base64 data-URI PNG (pure PHP, no
     * external service — works offline and in print).
     * Uses assets/lib/qrcode.php (kazuhikoarase/qrcode-generator).
     */
    function qr_png_base64(string $text, int $size = 6, int $margin = 2): string
    {
        static $loaded = false;
        if (!$loaded) {
            $lib = BASE_PATH . '/assets/lib/qrcode.php';
            if (is_file($lib)) {
                require_once $lib;
            }
            $loaded = true;
        }
        if (!class_exists('QRCode')) {
            return '';
        }
        try {
            $qr = QRCode::getMinimumQRCode($text, defined('QR_ERROR_CORRECT_LEVEL_M') ? QR_ERROR_CORRECT_LEVEL_M : QR_ERROR_CORRECT_LEVEL_L);
            $im = $qr->createImage($size, $margin);
            ob_start();
            imagepng($im);
            $png = (string) ob_get_clean();
            imagedestroy($im);
            return 'data:image/png;base64,' . base64_encode($png);
        } catch (Throwable $e) {
            error_log('qr_png_base64: ' . $e->getMessage());
            return '';
        }
    }
}

/*==========================================================
V5.41 — TRAINEE NOTIFICATIONS
==========================================================*/

if (!function_exists('notify_applicant')) {

    /**
     * Insert a trainee notification (applicant_notification).
     * @param int|null $typeId mnt_notification_type id, or null (SYSTEM default)
     * @return int inserted id (0 = skipped)
     */
    function notify_applicant(PDO $pdo, int $applicantId, string $title, string $message, ?int $typeId = null): int
    {
        if ($applicantId <= 0 || trim($title) === '') {
            return 0;
        }
        if (!$typeId) {
            $t = $pdo->query("SELECT id FROM mnt_notification_type WHERE code = 'SYSTEM' LIMIT 1")->fetchColumn();
            $typeId = $t ? (int) $t : null;
        }
        try {
            $pdo->prepare(
                "INSERT INTO applicant_notification (applicant_id, title, message, notification_type_id, read_at, created_at)
                 VALUES (:ap, :t, :m, :ty, NULL, NOW())"
            )->execute(['ap' => $applicantId, 't' => $title, 'm' => $message, 'ty' => $typeId]);
            return (int) $pdo->lastInsertId();
        } catch (Throwable $e) {
            error_log('notify_applicant: ' . $e->getMessage());
            return 0;
        }
    }
}

if (!function_exists('applicant_unread_notifications')) {

    /** Number of unread notifications for an applicant (bell badge). */
    function applicant_unread_notifications(PDO $pdo, int $applicantId): int
    {
        try {
            $s = $pdo->prepare("SELECT COUNT(*) FROM applicant_notification WHERE applicant_id = :ap AND read_at IS NULL");
            $s->execute(['ap' => $applicantId]);
            return (int) $s->fetchColumn();
        } catch (Throwable $e) {
            return 0;
        }
    }
}

/*==========================================================
V5.49 — WEBSITE CONTENT (editable site copy)
==========================================================*/

if (!function_exists('site_content')) {

    /**
     * Read a website-content setting (Settings → Website Content).
     * Falls back to the given default so pages never break even
     * before the seed is applied.
     */
    function site_content(string $key, string $default = ''): string
    {
        static $cache = [];
        if (array_key_exists($key, $cache)) {
            return $cache[$key];
        }
        $cache[$key] = $default;
        try {
            $pdo = db();
            $stmt = $pdo->prepare('SELECT setting_value FROM mnt_system_setting WHERE setting_key = :k LIMIT 1');
            $stmt->execute(['k' => $key]);
            $v = $stmt->fetchColumn();
            if ($v !== false && $v !== null && trim((string) $v) !== '') {
                $cache[$key] = (string) $v;
            }
        } catch (Throwable $e) {
            error_log('site_content(' . $key . '): ' . $e->getMessage());
        }
        return $cache[$key];
    }
}

if (!function_exists('site_content_lines')) {

    /** Split a multi-line site-content value into trimmed, non-empty lines. */
    function site_content_lines(string $key, string $default = ''): array
    {
        $raw = site_content($key, $default);
        $lines = preg_split('/\r\n|\r|\n/', $raw);
        $out = [];
        foreach ($lines ?: [] as $l) {
            $l = trim($l);
            if ($l !== '') { $out[] = $l; }
        }
        return $out;
    }
}

/*==========================================================
V5.71 — CAROUSEL PHOTOS +50% (container right-sized) + CARD CONTENT LEFT / CARDS CENTERED
==========================================================*/

if (!function_exists('site_gallery_images')) {

    /**
     * Auto-fetch all images inside a folder under the web root.
     * e.g. site_gallery_images('assets/images/site/facilities/classroom')
     * Returns an array of public URLs (sorted by filename).
     */
    function site_gallery_images(string $dir, int $limit = 50): array
    {
        $out = [];
        $abs = BASE_PATH . '/' . ltrim($dir, '/');
        if (is_dir($abs)) {
            foreach (glob($abs . '/*.{jpg,jpeg,png,webp}', GLOB_BRACE) ?: [] as $f) {
                $out[] = base_url(ltrim($dir, '/') . '/' . basename($f));
            }
            sort($out);
        }
        return array_slice($out, 0, $limit);
    }
}

if (!function_exists('site_gallery_categories')) {

    /**
     * Facility categories = subfolders of the facilities folder.
     * Returns [ slug => label, ... ] in folder order.
     */
    function site_gallery_categories(string $base = 'assets/images/site/facilities'): array
    {
        $cats = [];
        $abs = BASE_PATH . '/' . ltrim($base, '/');
        if (is_dir($abs)) {
            foreach (glob($abs . '/*', GLOB_ONLYDIR) ?: [] as $d) {
                $slug = basename($d);
                $cats[$slug] = ucwords(str_replace(['-', '_'], ' ', $slug));
            }
        }
        return $cats;
    }
}
