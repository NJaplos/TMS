<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Global Paths & URLs
 * File : config/paths.php
 * Version : 3.0
 *
 * Description:
 * Centralized application paths and URLs.
 *
 * This file is completely independent of the
 * project folder name. The project may be renamed
 * without changing any application code.
 * ---------------------------------------------------------
 */

if (!defined('USMCI_CONFIG')) {
    require_once __DIR__ . '/config.php';
}

/*==========================================================
PROJECT ROOT
==========================================================*/

defined('BASE_PATH')
    || define('BASE_PATH', realpath(__DIR__ . '/..'));

/*
|--------------------------------------------------------------------------
| Project Folder Name
|
| Examples:
|
| C:\xampp\htdocs\USMCI-TMS
| PROJECT_FOLDER = USMCI-TMS
|
| C:\xampp\htdocs\USMCI
| PROJECT_FOLDER = USMCI
|--------------------------------------------------------------------------
*/

defined('PROJECT_FOLDER')
    || define('PROJECT_FOLDER', basename(BASE_PATH));

/*
|--------------------------------------------------------------------------
| Base URL
|--------------------------------------------------------------------------
*/

defined('BASE_URL')
    || define('BASE_URL', '/' . PROJECT_FOLDER);

/*
|--------------------------------------------------------------------------
| ASSET_VERSION — cache-busting for ALL css/js includes
|--------------------------------------------------------------------------
| Bump this integer on every release. Every <link>/<script> in the site
| head/scripts loaders appends ?v=ASSET_VERSION so browsers can NEVER
| serve a stale cached section file (the cause of the "old lapping wheel
| still showing" reports after installs).
|--------------------------------------------------------------------------
*/
defined('ASSET_VERSION')
    || define('ASSET_VERSION', 75);

/*==========================================================
CORE DIRECTORIES
==========================================================*/

defined('CONFIG_PATH')
    || define('CONFIG_PATH', BASE_PATH . '/config');

defined('INCLUDES_PATH')
    || define('INCLUDES_PATH', BASE_PATH . '/includes');

defined('NAVBAR_PATH')
    || define('NAVBAR_PATH', BASE_PATH . '/navbar');

defined('ASSETS_PATH')
    || define('ASSETS_PATH', BASE_PATH . '/assets');

defined('SECTIONS_PATH')
    || define('SECTIONS_PATH', BASE_PATH . '/sections');

/*==========================================================
CORE URLS
==========================================================*/

defined('ASSETS_URL')
    || define('ASSETS_URL', BASE_URL . '/assets');

/*==========================================================
ADMISSIONS
==========================================================*/

defined('ADMISSIONS_PATH')
    || define('ADMISSIONS_PATH', SECTIONS_PATH . '/admissions');

defined('ADMISSIONS_URL')
    || define('ADMISSIONS_URL', BASE_URL . '/sections/admissions');

defined('ADMISSIONS_PARTIALS')
    || define('ADMISSIONS_PARTIALS', ADMISSIONS_PATH . '/partials');

defined('ADMISSIONS_ASSETS')
    || define('ADMISSIONS_ASSETS', ADMISSIONS_PATH . '/assets');

/*==========================================================
PUBLIC INQUIRY
==========================================================*/

defined('INQUIRY_PATH')
    || define('INQUIRY_PATH', ADMISSIONS_PATH . '/inquiry');

defined('INQUIRY_URL')
    || define('INQUIRY_URL', ADMISSIONS_URL . '/inquiry');

defined('INQUIRY_PARTIALS')
    || define('INQUIRY_PARTIALS', INQUIRY_PATH . '/partials');

defined('INQUIRY_ASSETS')
    || define('INQUIRY_ASSETS', INQUIRY_PATH . '/assets');

/*==========================================================
INQUIRY QUEUE
==========================================================*/

defined('INQUIRY_QUEUE_PATH')
    || define('INQUIRY_QUEUE_PATH', ADMISSIONS_PATH . '/inquiry-queue');

defined('INQUIRY_QUEUE_URL')
    || define('INQUIRY_QUEUE_URL', ADMISSIONS_URL . '/inquiry-queue');

defined('INQUIRY_QUEUE_PARTIALS')
    || define('INQUIRY_QUEUE_PARTIALS', INQUIRY_QUEUE_PATH . '/partials');

defined('INQUIRY_QUEUE_ASSETS')
    || define('INQUIRY_QUEUE_ASSETS', INQUIRY_QUEUE_PATH . '/assets');