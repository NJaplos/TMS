<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Mail Configuration + DB-backed SMTP Settings
 * File : config/mail.php   Version : 2.0
 * ---------------------------------------------------------
 * SMTP settings are stored in the mnt_system_setting table so
 * they can be changed from the Email Center without editing
 * files — the constants below are only FALLBACK defaults.
 *
 * Defaults for development: SMTP is empty -> the mailer falls
 * back to PHP mail(). Fill in SMTP in the Email Center (or
 * here) to actually send.
 *
 * Testing options:
 *   - Mailtrap:  host=sandbox.smtp.mailtrap.io  port=2525
 *                username=...  password=...
 *   - Gmail:     host=smtp.gmail.com  port=587  encryption=tls
 *                username=your@gmail.com  password=<App Password>
 *   - Company:   use the company SMTP host/credentials before live
 * ---------------------------------------------------------
 */

declare(strict_types=1);

/* ==========================================================
   Defaults (used until overridden in the Email Center)
========================================================== */

if (!defined('ADMIN_INQUIRY_EMAIL')) {
    define('ADMIN_INQUIRY_EMAIL', 'nieljaplos0924@gmail.com');
}

if (!defined('WEBSITE_FROM_EMAIL')) {
    define('WEBSITE_FROM_EMAIL', 'no-reply@usmci.test');
}

if (!defined('WEBSITE_FROM_NAME')) {
    define('WEBSITE_FROM_NAME', 'USMCI Admissions');
}

if (!defined('MAIL_SEND_IMMEDIATELY')) {
    define('MAIL_SEND_IMMEDIATELY', false);
}

/* ==========================================================
   SMTP defaults (fallbacks only)
========================================================== */

if (!defined('SMTP_HOST'))      { define('SMTP_HOST', ''); }
if (!defined('SMTP_PORT'))      { define('SMTP_PORT', 587); }
if (!defined('SMTP_ENCRYPTION')){ define('SMTP_ENCRYPTION', 'tls'); }
if (!defined('SMTP_USERNAME'))  { define('SMTP_USERNAME', ''); }
if (!defined('SMTP_PASSWORD'))  { define('SMTP_PASSWORD', ''); }

/* ==========================================================
   Website base URL used inside email links.
   Must be an absolute URL (scheme + host).
========================================================== */

if (!defined('WEBSITE_BASE_URL')) {
    define('WEBSITE_BASE_URL', 'http://localhost/USMCI-TMS');
}

/* ==========================================================
   Setting keys stored in mnt_system_setting
========================================================== */

const MAIL_SETTING_KEYS = [
    'smtp_host',
    'smtp_port',
    'smtp_encryption',
    'smtp_username',
    'smtp_password',
    'mail_from_email',
    'mail_from_name',
    'admin_notify_email',
];

/**
 * Read one setting from mnt_system_setting (cached per request).
 * Falls back to $default if the table is unavailable.
 */
function mail_setting(string $key, ?string $default = null): ?string
{
    static $cache = [];

    if (array_key_exists($key, $cache)) {
        return $cache[$key];
    }

    try {
        $pdo = db();
        $stmt = $pdo->prepare('SELECT setting_value FROM mnt_system_setting WHERE setting_key = :k LIMIT 1');
        $stmt->execute(['k' => $key]);
        $value = $stmt->fetchColumn();

        $cache[$key] = $value === false ? $default : (string) $value;
    } catch (Throwable $e) {
        $cache[$key] = $default;
    }

    return $cache[$key];
}

/**
 * Upsert one setting (setting_key is UNIQUE).
 */
function mail_setting_save(string $key, ?string $value): void
{
    $pdo = db();

    $stmt = $pdo->prepare(
        'INSERT INTO mnt_system_setting (setting_key, setting_value, data_type, created_at, updated_at)
         VALUES (:k, :v, :t, NOW(), NOW())
         ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = NOW()'
    );
    $stmt->execute([
        'k' => $key,
        'v' => $value,
        't' => $key === 'smtp_port' ? 'number' : 'string',
    ]);
}

/**
 * Resolved mail configuration: DB settings win, constants fallback.
 *
 * @return array{host: string, port: int, encryption: string, username: string,
 *               password: string, from_email: string, from_name: string,
 *               admin_notify_email: string}
 */
function smtp_config(): array
{
    return [
        'host'              => (string) (mail_setting('smtp_host', SMTP_HOST) ?? ''),
        'port'              => (int) (mail_setting('smtp_port', (string) SMTP_PORT) ?? 587),
        'encryption'        => (string) (mail_setting('smtp_encryption', SMTP_ENCRYPTION) ?? 'tls'),
        'username'          => (string) (mail_setting('smtp_username', SMTP_USERNAME) ?? ''),
        'password'          => (string) (mail_setting('smtp_password', SMTP_PASSWORD) ?? ''),
        'from_email'        => (string) (mail_setting('mail_from_email', WEBSITE_FROM_EMAIL) ?? ''),
        'from_name'         => (string) (mail_setting('mail_from_name', WEBSITE_FROM_NAME) ?? ''),
        'admin_notify_email'=> (string) (mail_setting('admin_notify_email', ADMIN_INQUIRY_EMAIL) ?? ''),
    'send_mode'         => (string) (mail_setting('mail_send_mode', 'immediate') ?? 'immediate'),
    ];
}

/** True when the app should attempt delivery inside the request. */
function mailer_send_mode_is_immediate(): bool
{
    $cfg = smtp_config();
    return ($cfg['send_mode'] ?? 'immediate') === 'immediate';
}

/**
 * True when a usable SMTP host is configured (DB or constants).
 */
function smtp_is_configured(): bool
{
    $cfg = smtp_config();

    return $cfg['host'] !== '' && $cfg['host'] !== null;
}

/**
 * Attempt to send one queued email RIGHT NOW (by its email_queue id).
 * Used by reply.php / convert.php / submit.php so that clicking
 * "Send Reply" actually delivers the email immediately instead of
 * waiting for the queue worker.
 *
 * @return array{success: bool, message: string}
 */
function mailer_send_now(int $emailId): array
{
    try {
        $pdo = db();

        $stmt = $pdo->prepare(
            "SELECT id, recipient_email, subject, body_html, status
             FROM email_queue WHERE id = :id LIMIT 1"
        );
        $stmt->execute(['id' => $emailId]);
        $row = $stmt->fetch();

        if (!$row) {
            return ['success' => false, 'message' => 'Queued email not found.'];
        }

        if ($row['status'] === 'sent') {
            return ['success' => true, 'message' => 'Already sent.'];
        }

        // If SMTP isn't configured yet, keep the email PENDING so it
        // retries once the Email Center SMTP settings are saved —
        // do NOT mark it failed (that would require a manual retry).
        if (!smtp_is_configured()) {
            return [
                'success' => false,
                'message' => 'SMTP is not configured yet. Open Email Center → SMTP Settings to enable delivery. This email is saved and will send automatically once SMTP is set.',
            ];
        }

        // Load the SMTP client only when actually sending.
        $mailerFile = dirname(__DIR__) . '/sections/admissions/mailer/SimpleSmtpMailer.php';

        if (!class_exists('SimpleSmtpMailer', false) && is_file($mailerFile)) {
            require_once $mailerFile;
        }

        if (!class_exists('SimpleSmtpMailer', false)) {
            return ['success' => false, 'message' => 'Mailer class not available.'];
        }

        $result = SimpleSmtpMailer::send(
            $row['recipient_email'],
            $row['subject'],
            $row['body_html'],
            null,
            smtp_config()
        );

        if ($result['success']) {
            $pdo->prepare(
                "UPDATE email_queue
                 SET status = 'sent', sent_at = NOW(), attempts = attempts + 1, error_message = NULL
                 WHERE id = :id"
            )->execute(['id' => $emailId]);

            return ['success' => true, 'message' => 'Email delivered to ' . $row['recipient_email'] . '.'];
        }

        $pdo->prepare(
            "UPDATE email_queue
             SET status = 'failed', attempts = attempts + 1, error_message = :error
             WHERE id = :id"
        )->execute(['id' => $emailId, 'error' => $result['error']]);

        return ['success' => false, 'message' => 'Delivery failed: ' . $result['error']];
    } catch (Throwable $exception) {
        error_log('mailer_send_now failed: ' . $exception->getMessage());

        return ['success' => false, 'message' => 'Could not send email right now.'];
    }
}

/*==========================================================
Generic queued email helper (uses SMTP from-address)
==========================================================*/

/**
 * Queue an email for background delivery (Email Center worker).
 * Returns the email_queue id (or 0 on failure).
 */
function queue_email(string $recipient, string $subject, string $bodyHtml): int
{
    try {
        $pdo = db();
        $pdo->prepare(
            'INSERT INTO email_queue (recipient_email, subject, body_html, status, scheduled_at, created_at)
             VALUES (:to, :subj, :body, \'pending\', NOW(), NOW())'
        )->execute([
            'to'   => $recipient,
            'subj' => $subject,
            'body' => $bodyHtml,
        ]);
        return (int) $pdo->lastInsertId();
    } catch (Throwable $e) {
        error_log('queue_email failed: ' . $e->getMessage());
        return 0;
    }
}

/** Simple branded HTML email shell (navy header, teal accent). */
function email_shell(string $title, string $bodyHtml): string
{
    return '<div style="font-family:Arial,Helvetica,sans-serif;max-width:600px;margin:0 auto;border:1px solid #E2E8F0;border-radius:12px;overflow:hidden;">'
        . '<div style="background:linear-gradient(135deg,#0B3C5D,#114B73);color:#fff;padding:18px 24px;">'
        . '<div style="font-weight:800;font-size:16px;">USMCI — Training Management System</div>'
        . '<div style="font-size:12px;opacity:.85;">United Seafarers Maritime Center, Inc.</div>'
        . '</div>'
        . '<div style="padding:22px 24px;color:#334155;font-size:14px;line-height:1.6;">'
        . $bodyHtml
        . '</div>'
        . '<div style="background:#F8FAFC;padding:14px 24px;font-size:11px;color:#94A3B8;border-top:1px solid #E2E8F0;">'
        . htmlspecialchars((string) mail_setting('mail_from_name', 'USMCI Admissions')) . ' · ' . htmlspecialchars((string) mail_setting('mail_from_email', 'no-reply@usmci.test'))
        . '</div></div>';
}
