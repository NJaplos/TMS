<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Bootstrap Loader
 * File : config/bootstrap.php
 * Version : 3.1
 *
 * Description:
 * Initializes the application by loading all required
 * core components. Every page in the system should include
 * ONLY this file.
 * ---------------------------------------------------------
 */

if (!defined('USMCI_BOOTSTRAP')) {

    define('USMCI_BOOTSTRAP', true);

}

/*==========================================================
APPLICATION CONFIGURATION
==========================================================*/

require_once __DIR__ . '/config.php';

/*==========================================================
GLOBAL PATHS
==========================================================*/

require_once __DIR__ . '/paths.php';

/*==========================================================
SESSION
==========================================================*/

require_once __DIR__ . '/session.php';

/*==========================================================
HELPER FUNCTIONS
==========================================================*/

require_once __DIR__ . '/helpers.php';

/*==========================================================
FUTURE MODULES
==========================================================*/

require_once __DIR__ . '/database.php';
require_once __DIR__ . '/mail.php';

/*==========================================================
AUTHENTICATION & CSRF (staff side)
==========================================================*/

require_once __DIR__ . '/auth.php';
