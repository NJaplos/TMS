<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Authentication + CSRF Helpers (v2 — unified login)
 * File : config/auth.php
 * Version : 2.0
 *
 * Description:
 * Central auth for BOTH roles:
 *   - staff   (sys_user)          -> staff/admin dashboard
 *   - trainee (applicant_account) -> trainee dashboard
 *
 *   - login_user() / logout_user() / current_user()
 *   - require_login()      — any logged-in role
 *   - require_staff()      — staff only (queue, email center…)
 *   - require_trainee()    — trainee only (trainee dashboard)
 *   - login_redirect()     — send a user to their home by role
 *   - CSRF helpers used by every POST form/endpoint
 * ---------------------------------------------------------
 */

declare(strict_types=1);

if (!defined('USMCI_CONFIG')) {
    require_once __DIR__ . '/config.php';
}

if (!defined('BASE_PATH')) {
    require_once __DIR__ . '/paths.php';
}

/*==========================================================
SESSION KEYS
==========================================================*/

if (!defined('SESSION_USER')) {
    define('SESSION_USER', 'usmci_user');
}

/*==========================================================
Current logged-in user (staff or trainee) or null.
Returns: ['role' => 'staff'|'trainee', 'id' => int, ...]
==========================================================*/

function current_user(): ?array
{
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }

    $user = $_SESSION[SESSION_USER] ?? null;

    return is_array($user) ? $user : null;
}

/*==========================================================
Gatekeepers
==========================================================*/

function require_login(string $redirectTo = ''): void
{
    if (current_user() !== null) {
        return;
    }

    if (headers_sent()) {
        http_response_code(401);
        echo 'Unauthorized — please log in first.';
        exit;
    }

    $target = $redirectTo !== '' ? $redirectTo : ($_SERVER['REQUEST_URI'] ?? '');
    $loginUrl = base_url('login.php');

    if ($target !== '' && $target !== '/' && strpos($target, 'login.php') === false) {
        $loginUrl .= '?redirect=' . urlencode($target);
    }

    header('Location: ' . $loginUrl);
    exit;
}

function require_staff(string $redirectTo = ''): void
{
    require_login($redirectTo);

    $user = current_user();

    if ($user['role'] !== 'staff') {
        if (headers_sent()) {
            http_response_code(403);
            echo 'Forbidden — staff access only.';
            exit;
        }
        header('Location: ' . base_url('trainee/index.php'));
        exit;
    }
}

function require_trainee(string $redirectTo = ''): void
{
    require_login($redirectTo);

    $user = current_user();

    if ($user['role'] !== 'trainee') {
        if (headers_sent()) {
            http_response_code(403);
            echo 'Forbidden — trainee access only.';
            exit;
        }
        header('Location: ' . base_url('sections/admissions/admin/index.php'));
        exit;
    }
}

/*==========================================================
Send the current user to their role's home page.
==========================================================*/

function login_redirect(): string
{
    $user = current_user();

    if ($user && ($user['role'] ?? '') === 'trainee') {
        return base_url('trainee/index.php');
    }

    return base_url('sections/admissions/admin/index.php');
}

/*==========================================================
Login / Logout
==========================================================*/

function login_user(array $user): void
{
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }

    session_regenerate_id(true);

    $_SESSION[SESSION_USER] = $user;

    // Touch last_login + reset lockout counters for the right table.
    try {
        $pdo = db();

        if (($user['role'] ?? '') === 'trainee') {
            $stmt = $pdo->prepare(
                'UPDATE applicant_account
                 SET last_login_at = NOW(), failed_login_count = 0, locked_until = NULL
                 WHERE id = :id'
            );
        } else {
            $stmt = $pdo->prepare(
                'UPDATE sys_user
                 SET last_login_at = NOW(), failed_login_count = 0, locked_until = NULL
                 WHERE id = :id'
            );
        }

        $stmt->execute(['id' => $user['id']]);
    } catch (Throwable $e) {
        error_log('auth login_user last_login update failed: ' . $e->getMessage());
    }
}

function logout_user(): void
{
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }

    $_SESSION = [];

    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }

    session_destroy();
}

/*==========================================================
CSRF
==========================================================*/

function csrf_token(): string
{
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }

    if (empty($_SESSION['_csrf_token'])) {
        $_SESSION['_csrf_token'] = bin2hex(random_bytes(32));
    }

    return $_SESSION['_csrf_token'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf_token" value="'
        . htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8')
        . '">';
}

function csrf_check(): void
{
    $sent = $_POST['csrf_token'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');

    if (!is_string($sent) || !hash_equals(csrf_token(), $sent)) {
        http_response_code(419);
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => 'Your session expired or the request token was invalid. Refresh the page and try again.',
        ]);
        exit;
    }
}

/*==========================================================
Role-based access (RBAC) — sidebar permission filtering
==========================================================*/

/** All sidebar page keys (RBAC granularity = sidebar buttons). */
function rbac_pages(): array
{
    return [
        'dashboard'       => '🏠 Dashboard',
        'inquiry_queue'   => '📨 Inquiry Queue',
        'applicants'      => '👥 Applicants',
        'courses'         => '📅 Course Management',
        'batches'         => '🗓️ Training Batches',
        'instructors'     => '🏢 Instructors & Venues',
        'companies'       => '🏢 Affiliated Companies',
        'enrollment'      => '📝 Enrollment',
        'payments'        => '💰 Payments',
        'certificates'    => '📜 Certificates',
        'reports'         => '📊 Reports',
        'settings'        => '⚙️ Admissions Settings',
        'staff_accounts'  => '👤 Staff Accounts',
    ];
}

/** Map a sidebar item's URL to its page key. */
function rbac_key_for_url(string $url): string
{
    if (strpos($url, '/admin/index.php') !== false)     { return 'dashboard'; }
    if (strpos($url, '/inquiry-queue/') !== false)      { return 'inquiry_queue'; }
    if (strpos($url, '/admin/applicants.php') !== false){ return 'applicants'; }
    if (strpos($url, '/admin/courses.php') !== false)   { return 'courses'; }
    if (strpos($url, '/admin/batches.php') !== false)   { return 'batches'; }
    if (strpos($url, '/admin/maintenance.php') !== false){ return 'instructors'; }
    if (strpos($url, '/admin/companies.php') !== false)   { return 'companies'; }
    if (strpos($url, '/admin/enrollment.php') !== false){ return 'enrollment'; }
    if (strpos($url, '/admin/payments.php') !== false)  { return 'payments'; }
    if (strpos($url, '/admin/certificates.php') !== false){ return 'certificates'; }
    if (strpos($url, '/admin/reports.php') !== false)   { return 'reports'; }
    if (strpos($url, '/admin/audit-log.php') !== false) { return 'reports'; }
    if (strpos($url, '/settings/') !== false || strpos($url, '/email-center/') !== false) { return 'settings'; }
    if (strpos($url, '/admin/staff-accounts.php') !== false){ return 'staff_accounts'; }
    return '';
}

/** URL for a page key (for RBAC redirects). */
function rbac_url_for_key(string $key): string
{
    $map = [
        'dashboard'      => 'sections/admissions/admin/index.php',
        'inquiry_queue'  => 'sections/admissions/inquiry-queue/index.php',
        'applicants'     => 'sections/admissions/admin/applicants.php',
        'courses'        => 'sections/admissions/admin/courses.php',
        'batches'        => 'sections/admissions/admin/batches.php',
        'instructors'    => 'sections/admissions/admin/maintenance.php',
        'companies'      => 'sections/admissions/admin/companies.php',
        'enrollment'     => 'sections/admissions/admin/enrollment.php',
        'payments'       => 'sections/admissions/admin/payments.php',
        'certificates'   => 'sections/admissions/admin/certificates.php',
        'reports'        => 'sections/admissions/admin/reports.php',
        'settings'       => 'sections/admissions/settings/index.php',
        'staff_accounts' => 'sections/admissions/admin/staff-accounts.php',
    ];
    return base_url($map[$key] ?? 'sections/admissions/admin/index.php');
}

/** First page key the current user can access (in menu order). */
function rbac_first_allowed(): string
{
    foreach (['dashboard','inquiry_queue','applicants','courses','batches','instructors','companies','enrollment','payments','certificates','reports','settings','staff_accounts'] as $k) {
        if (user_can($k)) { return $k; }
    }
    return '';
}

/**
 * Can the current staff user access $pageKey?
 * - ADMIN always can (view + edit).
 * - If the role has NO permission rows, everyone can (backward compat).
 * - Otherwise the role must have a matching role_permission row.
 *   $need = 'view' (page render) | 'edit' (create/update/delete).
 */
function user_can(string $pageKey, string $need = 'view'): bool
{
    static $cache = [];
    $user = current_user();
    if (!$user || ($user['role'] ?? '') !== 'staff') {
        return false;
    }
    if (($user['role_code'] ?? '') === 'ADMIN') {
        return true;
    }
    $roleId = (int) ($user['role_id'] ?? 0);
    if (!$roleId) {
        return false;
    }
    if (!array_key_exists($roleId, $cache)) {
        try {
            $pdo = db();
            $stmt = $pdo->prepare('SELECT page_key, can_view, can_edit FROM role_permission WHERE role_id = :rid');
            $stmt->execute(['rid' => $roleId]);
            $cache[$roleId] = $stmt->fetchAll();
        } catch (Throwable $e) {
            $cache[$roleId] = null; // table missing → no restriction
        }
    }
    $rows = $cache[$roleId];
    if ($rows === null || count($rows) === 0) {
        return true; // no permissions configured → allow (backward compat)
    }
    foreach ($rows as $r) {
        if ($r['page_key'] !== $pageKey) { continue; }
        if ($need === 'edit') {
            return (bool) $r['can_edit'];
        }
        return (bool) $r['can_view'];
    }
    return false;
}

/** Guard a page by its RBAC key (staff + permission). */
function require_access(string $pageKey, string $need = 'view'): void
{
    require_staff();
    if (user_can($pageKey, $need)) {
        return;
    }
    if (headers_sent()) {
        http_response_code(403);
        echo 'Forbidden — you do not have access to this module.';
        exit;
    }
    /* Land on the user's first permitted page (avoid a redirect loop
       when they can't see the dashboard). */
    $first = rbac_first_allowed();
    if ($first !== '') {
        header('Location: ' . rbac_url_for_key($first) . '?flash=err&msg=' . urlencode('You do not have access to that module.'));
    } else {
        header('Location: ' . base_url('login.php?flash=err&msg=' . urlencode('Your role has no modules assigned yet.')));
    }
    exit;
}

/** Guard a MUTATION (POST) by RBAC edit permission. */
function require_edit(string $pageKey): void
{
    require_staff();
    if (user_can($pageKey, 'edit')) {
        return;
    }
    if (headers_sent()) {
        http_response_code(403);
        echo 'Forbidden — your role has view-only access to this module.';
        exit;
    }
    $first = rbac_first_allowed();
    header('Location: ' . ($first !== '' ? rbac_url_for_key($first) : base_url('login.php')) . '?flash=err&msg=' . urlencode('Your role has view-only access to that module.'));
    exit;
}
