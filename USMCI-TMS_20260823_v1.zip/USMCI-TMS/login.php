<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Unified Login + Account Creation (v2)
 * File : login.php
 * Version : 2.0
 *
 * Two tabs:
 *   [1] Sign In      — staff (sys_user) OR trainee (applicant_account);
 *                      after login, routed by role.
 *   [2] Create Account — invite-only: applicant enters the unique
 *                      REGISTRATION CODE emailed by Admissions
 *                      (single-use, validated, related to inquiry no.)
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once __DIR__ . '/config/bootstrap.php';
require_once __DIR__ . '/sections/admissions/validate_invitation.php';

$error = '';
$username = '';
$code = '';
$mode = 'signin';          // 'signin' | 'create'
$success = false;

/* ==========================================================
   Handle POST
========================================================== */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();

    $mode = ($_POST['mode'] ?? 'signin') === 'create' ? 'create' : 'signin';

    /* ---------- CREATE ACCOUNT (invite code) ---------- */
    if ($mode === 'create') {
        $code = strtoupper(trim((string) ($_POST['code'] ?? '')));

        if ($code === '') {
            $error = 'Please enter the registration code from your invitation email.';
        } else {
            $check = validate_registration_code($code);

            if (!$check['valid']) {
                $error = $check['reason'] ?? 'This registration code is not valid.';
            } else {
                $invitation = $check['invitation'];

                // If an account already exists for this email, send them to sign in.
                try {
                    $pdo = db();
                    $dup = $pdo->prepare('SELECT id FROM applicant_account WHERE email = :e LIMIT 1');
                    $dup->execute(['e' => $invitation['email']]);

                    if ($dup->fetch()) {
                        $error = 'An account already exists for ' . $invitation['email'] . '. Please sign in instead.';
                    } else {
                        // Create the account now
                        $password = (string) ($_POST['password'] ?? '');
                        $confirm  = (string) ($_POST['password_confirm'] ?? '');

                        if (strlen($password) < (int) (defined('PASSWORD_MIN_LENGTH') ? PASSWORD_MIN_LENGTH : 8)) {
                            $error = 'Password must be at least ' . (int) (defined('PASSWORD_MIN_LENGTH') ? PASSWORD_MIN_LENGTH : 8) . ' characters long.';
                        } elseif ($password !== $confirm) {
                            $error = 'Passwords do not match.';
                        } else {
                            $statusActive = (int) $pdo->query(
                                "SELECT id FROM mnt_account_status WHERE code = 'ACTIVE' LIMIT 1"
                            )->fetchColumn() ?: 1;

                            $pdo->beginTransaction();

                            $stmt = $pdo->prepare(
                                "INSERT INTO applicant_account
                                    (applicant_id, username, email, password_hash, email_verified_at, status_id, created_at)
                                 VALUES
                                    (:applicant_id, :username, :email, :hash, NOW(), :status_id, NOW())"
                            );
                            $stmt->execute([
                                'applicant_id' => (int) $invitation['applicant_id'],
                                'username'     => $invitation['email'],
                                'email'        => $invitation['email'],
                                'hash'         => password_hash($password, PASSWORD_DEFAULT),
                                'status_id'    => $statusActive,
                            ]);

                            mark_invitation_used((int) $invitation['id'], (int) $invitation['inquiry_id']);

                            $pdo->commit();

                            // Auto-login the new trainee
                            $account = $pdo->prepare(
                                'SELECT id, applicant_id, username, email FROM applicant_account WHERE email = :e LIMIT 1'
                            );
                            $account->execute(['e' => $invitation['email']]);
                            $acc = $account->fetch();

                            if ($acc) {
                                login_user([
                                    'role'         => 'trainee',
                                    'id'           => (int) $acc['id'],
                                    'applicant_id' => (int) $acc['applicant_id'],
                                    'username'     => $acc['username'],
                                    'email'        => $acc['email'],
                                ]);
                            }

                            $success = true;
                        }
                    }
                } catch (Throwable $exception) {
                    if (isset($pdo) && $pdo->inTransaction()) {
                        $pdo->rollBack();
                    }
                    error_log('login.php create failed: ' . $exception->getMessage());
                    $error = 'Your account could not be created right now. Please try again.';
                }
            }
        }
    }

    /* ---------- SIGN IN (staff OR trainee) ---------- */
    else {
        $username = trim((string) ($_POST['username'] ?? ''));
        $password = (string) ($_POST['password'] ?? '');

        if ($username === '' || $password === '') {
            $error = 'Username and password are required.';
        } else {
            try {
                $pdo = db();

                /* Try staff first, then trainee */
                $staff = $pdo->prepare(
                    "SELECT u.id, u.username, u.email, u.password_hash, u.full_name,
                            u.role_id, r.code AS role_code, u.status_id, u.failed_login_count, u.locked_until
                     FROM sys_user u
                     LEFT JOIN sys_role r ON r.id = u.role_id
                     WHERE u.username = :username OR u.email = :email
                     LIMIT 1"
                );
                $staff->execute(['username' => $username, 'email' => $username]);
                $found = $staff->fetch();

                $trainee = null;
                if (!$found) {
                    $tq = $pdo->prepare(
                        "SELECT id, applicant_id, username, email, password_hash, status_id, failed_login_count, locked_until
                         FROM applicant_account
                         WHERE username = :username OR email = :email
                         LIMIT 1"
                    );
                    $tq->execute(['username' => $username, 'email' => $username]);
                    $trainee = $tq->fetch();
                }

                if (!$found && !$trainee) {
                    $error = 'Invalid username or password.';
                } elseif ($found) {
                    if ($found['locked_until'] !== null && strtotime($found['locked_until']) > time()) {
                        $error = 'Account temporarily locked. Try again later.';
                    } elseif ((int) $found['status_id'] !== 1) {
                        $error = 'This account is disabled. Contact the administrator.';
                    } elseif (!password_verify($password, $found['password_hash'])) {
                        $failed = (int) $found['failed_login_count'] + 1;
                        if ($failed >= 5) {
                            $pdo->prepare("UPDATE sys_user SET failed_login_count = :f, locked_until = DATE_ADD(NOW(), INTERVAL 15 MINUTE) WHERE id = :id")
                                ->execute(['f' => $failed, 'id' => $found['id']]);
                            $error = 'Too many failed attempts. Account locked for 15 minutes.';
                        } else {
                            $pdo->prepare("UPDATE sys_user SET failed_login_count = :f WHERE id = :id")
                                ->execute(['f' => $failed, 'id' => $found['id']]);
                            $error = 'Invalid username or password.';
                        }
                    } else {
                        login_user([
                            'role'      => 'staff',
                            'id'        => (int) $found['id'],
                            'username'  => $found['username'],
                            'email'     => $found['email'],
                            'full_name' => $found['full_name'],
                            'role_id'   => (int) $found['role_id'],
                            'role_code' => $found['role_code'],
                        ]);

                        $redirect = trim((string) ($_GET['redirect'] ?? ''));
                        if ($redirect === '' || !str_starts_with($redirect, '/')) {
                            $redirect = login_redirect();
                        }
                        header('Location: ' . $redirect);
                        exit;
                    }
                } else {
                    // Trainee
                    if ($trainee['locked_until'] !== null && strtotime($trainee['locked_until']) > time()) {
                        $error = 'Account temporarily locked. Try again later.';
                    } elseif ((int) $trainee['status_id'] !== 1) {
                        $error = 'This account is disabled. Contact the Admissions Office.';
                    } elseif (!password_verify($password, $trainee['password_hash'])) {
                        $failed = (int) $trainee['failed_login_count'] + 1;
                        if ($failed >= 5) {
                            $pdo->prepare("UPDATE applicant_account SET failed_login_count = :f, locked_until = DATE_ADD(NOW(), INTERVAL 15 MINUTE) WHERE id = :id")
                                ->execute(['f' => $failed, 'id' => $trainee['id']]);
                            $error = 'Too many failed attempts. Account locked for 15 minutes.';
                        } else {
                            $pdo->prepare("UPDATE applicant_account SET failed_login_count = :f WHERE id = :id")
                                ->execute(['f' => $failed, 'id' => $trainee['id']]);
                            $error = 'Invalid username or password.';
                        }
                    } else {
                        login_user([
                            'role'         => 'trainee',
                            'id'           => (int) $trainee['id'],
                            'applicant_id' => (int) $trainee['applicant_id'],
                            'username'     => $trainee['username'],
                            'email'        => $trainee['email'],
                        ]);

                        $redirect = trim((string) ($_GET['redirect'] ?? ''));
                        if ($redirect === '' || !str_starts_with($redirect, '/')) {
                            $redirect = login_redirect();
                        }
                        header('Location: ' . $redirect);
                        exit;
                    }
                }
            } catch (Throwable $exception) {
                error_log('login.php failed: ' . $exception->getMessage());
                $error = 'Login could not be processed right now. Please try again.';
            }
        }
    }
}

/* If the page was opened with ?code= (e.g. from an email), pre-fill */
if ($_GET['code'] ?? '') {
    $code = strtoupper(trim((string) $_GET['code']));
    $mode = 'create';
}

$page = [
    'title'       => 'Login | USMCI-TMS',
    'description' => 'Sign in to USMCI-TMS.',
    'bodyClass'   => 'login-page',
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | USMCI-TMS</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(150deg, #0B3C5D 0%, #114B73 55%, #0D8A72 130%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 24px;
        }
        .wrap { width: 100%; max-width: 440px; }
        .brand { display: flex; flex-direction: column; align-items: center; margin-bottom: 22px; }
        .brand img { width: 64px; height: 64px; object-fit: contain; margin-bottom: 8px; }
        .brand__name { color: #FFF; font-size: 1.05rem; font-weight: 800; letter-spacing: .02em; }
        .brand__sub { color: rgba(255,255,255,.7); font-size: .75rem; letter-spacing: .12em; text-transform: uppercase; }

        .card {
            background: #FFF; border-radius: 18px;
            box-shadow: 0 30px 70px rgba(0,0,0,.3);
            overflow: hidden;
        }
        .tabs { display: flex; border-bottom: 1px solid #E2E8F0; }
        .tab {
            flex: 1; padding: 16px; text-align: center;
            font-size: .9rem; font-weight: 700; color: #64748B;
            cursor: pointer; border-bottom: 3px solid transparent;
            background: none; border-top: none; border-left: none; border-right: none;
            font-family: inherit; transition: color .15s, border-color .15s;
        }
        .tab.active { color: #0D8A72; border-bottom-color: #0D8A72; }

        .body { padding: 28px 30px 30px; }
        .form-group { margin-bottom: 16px; }
        .form-group label { display: block; font-size: .8rem; font-weight: 600; color: #334155; margin-bottom: 6px; }
        .form-group input {
            width: 100%; padding: 12px 14px;
            border: 1px solid #CBD5E1; border-radius: 10px;
            font-size: .92rem; font-family: inherit; color: #334155;
        }
        .form-group input:focus { outline: none; border-color: #0D8A72; box-shadow: 0 0 0 3px rgba(13,138,114,.15); }
        .btn {
            width: 100%; padding: 13px; border: none; border-radius: 10px;
            background: #0D8A72; color: #FFF; font-size: .95rem; font-weight: 700;
            font-family: inherit; cursor: pointer; transition: background .15s;
            margin-top: 6px;
        }
        .btn:hover { background: #0B6D5B; }
        .alert {
            background: #FEF2F2; border: 1px solid #FECACA; color: #B91C1C;
            padding: 11px 14px; border-radius: 10px; font-size: .84rem; margin-bottom: 16px;
        }
        .notice {
            background: #F0FDF4; border: 1px solid #BBF7D0; color: #166534;
            padding: 11px 14px; border-radius: 10px; font-size: .84rem; margin-bottom: 16px;
        }
        .hint { font-size: .8rem; color: #94A3B8; line-height: 1.5; margin: -6px 0 16px; }
        .panel { display: none; }
        .panel.active { display: block; }
        .code-input {
            letter-spacing: .12em; font-weight: 700; text-transform: uppercase;
            font-size: 1rem !important; text-align: center;
        }
        .back { display: block; text-align: center; margin-top: 18px; font-size: .82rem; color: #0D8A72; text-decoration: none; }
        .foot { text-align: center; margin-top: 18px; font-size: .75rem; color: rgba(255,255,255,.65); }
        .success-box { text-align: center; padding: 10px 0 4px; }
        .success-box .icon { font-size: 3rem; margin-bottom: 8px; }
        .success-box h2 { color: #0B3C5D; font-size: 1.25rem; margin-bottom: 8px; }
        .success-box p { color: #5B6472; font-size: .9rem; margin-bottom: 18px; }
    </style>
</head>
<body>
<div class="wrap">

    <div class="brand">
        <img src="<?= e(base_url('assets/images/branding/logo-light.png')); ?>" alt="USMCI Logo">
        <div class="brand__name">UNITED SEAFARERS MARITIME CENTER, INC.</div>
        <div class="brand__sub">Training Management System</div>
    </div>

    <div class="card">

        <?php if ($success): ?>
            <div class="body">
                <div class="success-box">
                    <div class="icon">🎉</div>
                    <h2>Account Created!</h2>
                    <p>You're now signed in to your Trainee Dashboard.</p>
                    <a class="btn" href="<?= e(base_url('trainee/index.php')); ?>" style="text-decoration:none;display:inline-block;">Go to my Dashboard →</a>
                </div>
            </div>
        <?php else: ?>

        <div class="tabs">
            <button type="button" class="tab active" id="tabSignin">Sign In</button>
            <button type="button" class="tab" id="tabCreate">Create Account</button>
        </div>

        <div class="body">

            <?php if ($error !== ''): ?>
                <div class="alert"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></div>
            <?php endif; ?>

            <!-- ================= SIGN IN ================= -->
            <div class="panel active" id="panelSignin">
                <form method="post" action="<?= e(base_url('login.php')); ?><?= isset($_GET['redirect']) ? '?redirect=' . urlencode((string) $_GET['redirect']) : ''; ?>">
                    <?= csrf_field(); ?>
                    <input type="hidden" name="mode" value="signin">
                    <div class="form-group">
                        <label for="username">Username or Email</label>
                        <input type="text" id="username" name="username"
                               value="<?= e($username); ?>" required autofocus autocomplete="username">
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" id="password" name="password" required autocomplete="current-password">
                    </div>
                    <button type="submit" class="btn">Sign In</button>
                </form>
                <p class="hint" style="margin-top:14px;">Staff and trainees both sign in here — you'll be routed to your own dashboard automatically.</p>
            </div>

            <!-- ================= CREATE ACCOUNT ================= -->
            <div class="panel" id="panelCreate">
                <p class="hint">
                    Account creation is <strong>by invitation only</strong>. Enter the unique registration code
                    sent to your email by the Admissions Office.
                </p>
                <form method="post" action="<?= e(base_url('login.php')); ?>">
                    <?= csrf_field(); ?>
                    <input type="hidden" name="mode" value="create">

                    <div class="form-group">
                        <label for="code">Registration Code</label>
                        <input type="text" id="code" name="code" class="code-input"
                               value="<?= e($code); ?>" placeholder="USMCI-…" required
                               autocomplete="off">
                    </div>

                    <div class="form-group">
                        <label for="pwd">Password</label>
                        <input type="password" id="pwd" name="password"
                               minlength="8" placeholder="At least 8 characters" required autocomplete="new-password">
                    </div>

                    <div class="form-group">
                        <label for="pwd2">Confirm Password</label>
                        <input type="password" id="pwd2" name="password_confirm" required autocomplete="new-password">
                    </div>

                    <button type="submit" class="btn">Create My Account</button>
                </form>
                <p class="hint" style="margin-top:14px;">Don't have a code? Contact the Admissions Office — a code is issued after your inquiry is approved.</p>
            </div>

        </div>
        <?php endif; ?>
    </div>

    <a class="back" href="<?= e(base_url('index.php')); ?>">← Back to website</a>
    <div class="foot">© <?= date('Y'); ?> USMCI · Training Management System</div>
</div>

<script>
(function () {
    var tabSignin = document.getElementById("tabSignin");
    var tabCreate = document.getElementById("tabCreate");
    var panelSignin = document.getElementById("panelSignin");
    var panelCreate = document.getElementById("panelCreate");

    function show(name) {
        var signin = name === "signin";
        tabSignin.classList.toggle("active", signin);
        tabCreate.classList.toggle("active", !signin);
        panelSignin.classList.toggle("active", signin);
        panelCreate.classList.toggle("active", !signin);
    }

    tabSignin.addEventListener("click", function () { show("signin"); });
    tabCreate.addEventListener("click", function () { show("create"); });

    // Pre-open Create Account if a code was passed
    <?php if ($mode === 'create' && !$success): ?>show("create");<?php endif; ?>
})();
</script>
</body>
</html>
