<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS — Public Certificate Verification
 * File : verify.php
 * ---------------------------------------------------------
 * Public page (no login) for verifying an issued certificate
 * by its certificate number + QR token:
 *
 *   /USMCI-TMS/verify.php?ref=CRT-2026-000001&t=9f3c…
 *
 * Prints a branded USMCI card: VALID / EXPIRED / VOID /
 * NOT FOUND. The URL is stored in certificate.verification_url
 * when a certificate is issued.
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once __DIR__ . '/config/bootstrap.php';

$ref = trim((string) ($_GET['ref'] ?? ''));
$tok = trim((string) ($_GET['t'] ?? ''));

$result = null;   // ['cert_no','name','course','issued','expiry','status','issued_by']
$lookup = false;

if ($ref !== '') {
    $lookup = true;
    try {
        $pdo = db();
        $stmt = $pdo->prepare(
            "SELECT c.certificate_no, c.issued_date, c.expiry_date, c.status, c.qr_code_value,
                    COALESCE(m.course_name, c.course_name_override) AS course,
                    a.first_name, a.middle_name, a.last_name,
                    u.full_name AS issued_by_name
             FROM certificate c
             LEFT JOIN mnt_course m ON m.id = c.course_id
             JOIN applicant a ON a.id = c.applicant_id
             LEFT JOIN sys_user u ON u.id = c.issued_by
             WHERE c.certificate_no = :ref
             LIMIT 1"
        );
        $stmt->execute(['ref' => $ref]);
        $row = $stmt->fetch();

        if (!$row) {
            $result = ['found' => false, 'reason' => 'No certificate found with that number.'];
        } elseif ($tok !== '' && $row['qr_code_value'] !== null && !hash_equals((string) $row['qr_code_value'], $tok)) {
            $result = ['found' => false, 'reason' => 'The verification token does not match this certificate.'];
        } else {
            $expired = $row['expiry_date'] && strtotime($row['expiry_date']) < time();
            $status  = $row['status'];
            if ($status === 'issued' && $expired) {
                $status = 'expired';
            }
            $result = [
                'found'    => true,
                'cert_no'  => $row['certificate_no'],
                'name'     => trim(preg_replace('/\s+/', ' ', trim(($row['first_name'] ?? '') . ' ' . ($row['middle_name'] ?? '') . ' ' . ($row['last_name'] ?? '')))),
                'course'   => $row['course'] ?? '—',
                'issued'   => $row['issued_date'],
                'expiry'   => $row['expiry_date'] ?? '—',
                'status'   => $status,
                'issued_by' => $row['issued_by_name'] ?? 'USMCI',
            ];
        }
    } catch (Throwable $e) {
        error_log('verify.php: ' . $e->getMessage());
        $result = ['found' => false, 'reason' => 'Verification service is temporarily unavailable.'];
    }
}

/* ------------------------------------------------------------------
   Simple branded standalone page (inline CSS — no sidebar needed)
------------------------------------------------------------------- */
$statusMeta = [
    'issued'  => ['title' => '✓ VALID CERTIFICATE', 'color' => '#15803D', 'bg' => '#DCFCE7', 'icon' => '✅'],
    'expired' => ['title' => '⚠ EXPIRED CERTIFICATE', 'color' => '#B91C1C', 'bg' => '#FEE2E2', 'icon' => '⏰'],
    'void'    => ['title' => '✗ VOID CERTIFICATE', 'color' => '#64748B', 'bg' => '#F1F5F9', 'icon' => '🚫'],
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Certificate Verification | USMCI</title>
<style>
    * { margin:0; padding:0; box-sizing:border-box; }
    body { font-family:'Segoe UI', Arial, sans-serif; background:linear-gradient(160deg,#0B3C5D 0%,#114B73 100%); min-height:100vh; display:flex; align-items:center; justify-content:center; padding:24px; }
    .card { background:#fff; border-radius:18px; box-shadow:0 30px 70px rgba(0,0,0,.35); width:100%; max-width:520px; overflow:hidden; }
    .card__head { background:linear-gradient(135deg,#0B3C5D 0%,#114B73 60%,#0D8A72 130%); color:#fff; padding:22px 26px; text-align:center; }
    .card__head h1 { font-size:1.15rem; font-weight:800; letter-spacing:.04em; }
    .card__head p { font-size:.8rem; color:rgba(255,255,255,.85); margin-top:4px; }
    .card__body { padding:26px; }
    .lookup { display:flex; gap:8px; margin-bottom:22px; }
    .lookup input { flex:1; padding:11px 14px; border:1px solid #CBD5E1; border-radius:10px; font-size:.9rem; }
    .lookup input:focus { outline:none; border-color:#0D8A72; box-shadow:0 0 0 3px rgba(13,138,114,.12); }
    .lookup button { background:#0D8A72; color:#fff; border:none; border-radius:10px; padding:0 18px; font-weight:700; cursor:pointer; }
    .badge { display:flex; align-items:center; gap:10px; padding:16px 18px; border-radius:12px; font-weight:800; font-size:1rem; margin-bottom:20px; }
    .meta { display:grid; grid-template-columns:1fr 1fr; gap:12px 16px; }
    .meta .field { background:#F8FAFC; border:1px solid #E2E8F0; border-radius:10px; padding:10px 14px; }
    .meta .field span { display:block; font-size:.68rem; font-weight:700; color:#94A3B8; text-transform:uppercase; letter-spacing:.05em; margin-bottom:3px; }
    .meta .field b { font-size:.9rem; color:#0B3C5D; }
    .meta .full { grid-column:1 / -1; }
    .notfound { text-align:center; color:#B91C1C; background:#FEE2E2; border-radius:12px; padding:18px; font-weight:700; }
    .foot { text-align:center; font-size:.72rem; color:#94A3B8; margin-top:20px; }
</style>
</head>
<body>
    <div class="card">
        <div class="card__head">
            <h1>🏛 USMCI TRAINING MANAGEMENT SYSTEM</h1>
            <p>Official Certificate Verification</p>
        </div>
        <div class="card__body">

            <form class="lookup" method="get" action="<?= e(base_url('verify.php')); ?>">
                <input type="text" name="ref" value="<?= e($ref); ?>" placeholder="Certificate No. e.g. CRT-2026-000001" required>
                <input type="hidden" name="t" value="<?= e($tok); ?>">
                <button type="submit">Verify</button>
            </form>

            <?php if ($lookup && $result): ?>
                <?php if (!$result['found']): ?>
                    <div class="notfound">🚫 <?= e($result['reason'] ?? 'Certificate not found.'); ?></div>
                <?php else: ?>
                    <?php $meta = $statusMeta[$result['status']] ?? $statusMeta['issued']; ?>
                    <div class="badge" style="background:<?= e($meta['bg']); ?>;color:<?= e($meta['color']); ?>;">
                        <span style="font-size:1.3rem;"><?= e($meta['icon']); ?></span>
                        <?= e($meta['title']); ?>
                    </div>
                    <div class="meta">
                        <div class="field full"><span>Certificate No.</span><b><?= e($result['cert_no']); ?></b></div>
                        <div class="field full"><span>Name of Trainee</span><b><?= e($result['name']); ?></b></div>
                        <div class="field full"><span>Course Completed</span><b><?= e($result['course']); ?></b></div>
                        <div class="field"><span>Date Issued</span><b><?= e($result['issued']); ?></b></div>
                        <div class="field"><span>Date Expiry</span><b><?= e($result['expiry']); ?></b></div>
                        <div class="field full"><span>Status</span><b style="text-transform:uppercase;"><?= e($result['status']); ?></b></div>
                        <div class="field full"><span>Issued By</span><b><?= e($result['issued_by']); ?></b></div>
                    </div>
                <?php endif; ?>
            <?php elseif (!$lookup): ?>
                <p style="text-align:center;color:#64748B;font-size:.9rem;padding:10px 0;">
                    Enter the certificate number printed on the certificate (or scan its QR code) to verify its authenticity.
                </p>
            <?php endif; ?>

            <div class="foot">This page verifies certificates issued through the USMCI Training Management System.</div>
        </div>
    </div>
</body>
</html>
