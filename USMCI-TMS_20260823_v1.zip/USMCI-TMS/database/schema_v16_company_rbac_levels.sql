-- ============================================================
-- USMCI-TMS — Schema v16: Company profiles + Role access levels
-- ------------------------------------------------------------
-- 1. mnt_company: contact_person / contact_number / contact_email
--    (for the Affiliated Companies profile form)
-- 2. role_permission: can_view / can_edit (RBAC granularity —
--    a role can have VIEW-ONLY access per module)
-- SAFE / IDEMPOTENT / portable (MariaDB + MySQL).
-- ============================================================
USE enrollsys;

-- ============ 1. mnt_company contact fields ============
SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='mnt_company' AND COLUMN_NAME='contact_person');
SET @s := IF(@c = 0, 'ALTER TABLE mnt_company ADD COLUMN contact_person VARCHAR(150) NULL AFTER company_type', 'SELECT 1');
PREPARE s FROM @s; EXECUTE s; DEALLOCATE PREPARE s;

SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='mnt_company' AND COLUMN_NAME='contact_number');
SET @s := IF(@c = 0, 'ALTER TABLE mnt_company ADD COLUMN contact_number VARCHAR(50) NULL AFTER contact_person', 'SELECT 1');
PREPARE s FROM @s; EXECUTE s; DEALLOCATE PREPARE s;

SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='mnt_company' AND COLUMN_NAME='contact_email');
SET @s := IF(@c = 0, 'ALTER TABLE mnt_company ADD COLUMN contact_email VARCHAR(150) NULL AFTER contact_number', 'SELECT 1');
PREPARE s FROM @s; EXECUTE s; DEALLOCATE PREPARE s;

-- ============ 2. role_permission view/edit levels ============
SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='role_permission' AND COLUMN_NAME='can_view');
SET @s := IF(@c = 0, 'ALTER TABLE role_permission ADD COLUMN can_view TINYINT(1) NOT NULL DEFAULT 1 AFTER page_key', 'SELECT 1');
PREPARE s FROM @s; EXECUTE s; DEALLOCATE PREPARE s;

SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='role_permission' AND COLUMN_NAME='can_edit');
SET @s := IF(@c = 0, 'ALTER TABLE role_permission ADD COLUMN can_edit TINYINT(1) NOT NULL DEFAULT 1 AFTER can_view', 'SELECT 1');
PREPARE s FROM @s; EXECUTE s; DEALLOCATE PREPARE s;

SELECT 'v16_ok' AS step,
       (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='mnt_company' AND COLUMN_NAME IN ('contact_person','contact_number','contact_email')) AS company_cols,
       (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='role_permission' AND COLUMN_NAME IN ('can_view','can_edit')) AS perm_cols;
