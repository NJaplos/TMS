-- ============================================================
-- USMCI-TMS — Schema v7: Course upcoming_batches (editable)
-- ------------------------------------------------------------
-- Adds mnt_course.upcoming_batches so admins can set the
-- planned number of upcoming training batches for a course.
-- SAFE / IDEMPOTENT / portable.
-- ============================================================
USE enrollsys;
SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='mnt_course' AND COLUMN_NAME='upcoming_batches');
SET @s := IF(@c = 0, 'ALTER TABLE mnt_course ADD COLUMN upcoming_batches INT NOT NULL DEFAULT 0 AFTER price_amount', 'SELECT 1');
PREPARE s FROM @s; EXECUTE s; DEALLOCATE PREPARE s;
SELECT COLUMN_NAME, COLUMN_TYPE FROM information_schema.COLUMNS
WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='mnt_course' AND COLUMN_NAME='upcoming_batches';
