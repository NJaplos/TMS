-- ============================================================
-- USMCI-TMS — Schema v5: Trainee-managed certificates
-- ------------------------------------------------------------
-- Lets trainees add/edit their own certificate records.
--   - certificate.enrollment_id  -> NULLABLE (no enrollment needed)
--   - certificate.course_id      -> NULLABLE (no catalog course needed)
--   - certificate.course_name_override VARCHAR(200) — free-text
--     course name when not linked to mnt_course
--   - certificate.is_self_recorded TINYINT(1) — marks trainee-added
--
-- SAFE / IDEMPOTENT: uses MariaDB IF NOT EXISTS and auto-selects
-- the enrollsys DB, so it works whether or not you picked a
-- database in phpMyAdmin, and can be re-run safely.
-- ============================================================

USE enrollsys;

-- 1) enrollment_id nullable (keeps FK/index)
ALTER TABLE certificate MODIFY enrollment_id BIGINT UNSIGNED NULL;

-- 2) course_id nullable (keeps FK/index)
ALTER TABLE certificate MODIFY course_id BIGINT UNSIGNED NULL;

-- 3) course_name_override column
SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='certificate' AND COLUMN_NAME='course_name_override');
SET @s := IF(@c = 0, 'ALTER TABLE certificate ADD COLUMN course_name_override VARCHAR(200) NULL AFTER course_id', 'SELECT 1');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- 4) is_self_recorded column
SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='certificate' AND COLUMN_NAME='is_self_recorded');
SET @s := IF(@c = 0, 'ALTER TABLE certificate ADD COLUMN is_self_recorded TINYINT(1) NOT NULL DEFAULT 0 AFTER status', 'SELECT 1');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- Verify
SELECT COLUMN_NAME, IS_NULLABLE, COLUMN_TYPE
FROM information_schema.COLUMNS
WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'certificate'
  AND COLUMN_NAME IN ('enrollment_id','course_id','course_name_override','is_self_recorded')
ORDER BY ORDINAL_POSITION;
