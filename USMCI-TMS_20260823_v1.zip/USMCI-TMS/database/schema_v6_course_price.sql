-- ============================================================
-- USMCI-TMS — Schema v6: Course price
-- ------------------------------------------------------------
-- Adds mnt_course.price_amount so admins can set course fees
-- (shown in course management, course availability, and used
-- by payment/enrollment later).
--
-- SAFE / IDEMPOTENT / portable (MariaDB + MySQL).
-- HOW TO RUN: paste into phpMyAdmin SQL tab, click Go.
-- ============================================================

USE enrollsys;

SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='mnt_course' AND COLUMN_NAME='price_amount');
SET @s := IF(@c = 0, 'ALTER TABLE mnt_course ADD COLUMN price_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00 AFTER validity_months', 'SELECT 1');
PREPARE s FROM @s; EXECUTE s; DEALLOCATE PREPARE s;

-- Verify
SELECT COLUMN_NAME, COLUMN_TYPE FROM information_schema.COLUMNS
WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='mnt_course' AND COLUMN_NAME='price_amount';
