-- ============================================================
-- USMCI-TMS — Schema v11: Certificate file upload
-- ------------------------------------------------------------
-- Adds file_path / file_name to certificate so the admin can
-- attach the actual certificate document (PDF/image) when
-- issuing. The trainee then downloads it from their account.
-- SAFE / IDEMPOTENT / portable (MariaDB + MySQL).
-- ============================================================
USE enrollsys;

SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='certificate' AND COLUMN_NAME='file_path');
SET @s := IF(@c = 0, 'ALTER TABLE certificate ADD COLUMN file_path VARCHAR(500) NULL AFTER verification_url', 'SELECT 1');
PREPARE s FROM @s; EXECUTE s; DEALLOCATE PREPARE s;

SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='certificate' AND COLUMN_NAME='file_name');
SET @s := IF(@c = 0, 'ALTER TABLE certificate ADD COLUMN file_name VARCHAR(255) NULL AFTER file_path', 'SELECT 1');
PREPARE s FROM @s; EXECUTE s; DEALLOCATE PREPARE s;

SELECT 'v11_ok' AS step, COUNT(*) AS cert_cols FROM information_schema.COLUMNS
WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='certificate' AND COLUMN_NAME IN ('file_path','file_name');
