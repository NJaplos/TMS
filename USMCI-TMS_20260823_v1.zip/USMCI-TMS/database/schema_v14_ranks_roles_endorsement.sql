-- ============================================================
-- USMCI-TMS — Schema v14: Ranks + Role permissions + Endorsement
-- ------------------------------------------------------------
-- 1. mnt_rank_position   — maintenance list for Rank/Position
-- 2. role_permission     — role → sidebar page access (RBAC)
-- 3. enrollment          — endorsed_by, charge_to, company_id
-- 4. sys_role            — seeds ENDORSER (idempotent)
-- SAFE / IDEMPOTENT / portable (MariaDB + MySQL).
-- ============================================================
USE enrollsys;

-- ============ 1. mnt_rank_position ============
CREATE TABLE IF NOT EXISTS mnt_rank_position (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    sort_order INT NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_rank_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO mnt_rank_position (name, sort_order, is_active)
SELECT 'Oiler', 1, 1 WHERE NOT EXISTS (SELECT 1 FROM mnt_rank_position WHERE name = 'Oiler');
INSERT INTO mnt_rank_position (name, sort_order, is_active)
SELECT 'Deck Cadet', 2, 1 WHERE NOT EXISTS (SELECT 1 FROM mnt_rank_position WHERE name = 'Deck Cadet');
INSERT INTO mnt_rank_position (name, sort_order, is_active)
SELECT 'Able Seaman', 3, 1 WHERE NOT EXISTS (SELECT 1 FROM mnt_rank_position WHERE name = 'Able Seaman');
INSERT INTO mnt_rank_position (name, sort_order, is_active)
SELECT 'Ordinary Seaman', 4, 1 WHERE NOT EXISTS (SELECT 1 FROM mnt_rank_position WHERE name = 'Ordinary Seaman');
INSERT INTO mnt_rank_position (name, sort_order, is_active)
SELECT '2nd Engineer', 5, 1 WHERE NOT EXISTS (SELECT 1 FROM mnt_rank_position WHERE name = '2nd Engineer');
INSERT INTO mnt_rank_position (name, sort_order, is_active)
SELECT '3rd Engineer', 6, 1 WHERE NOT EXISTS (SELECT 1 FROM mnt_rank_position WHERE name = '3rd Engineer');
INSERT INTO mnt_rank_position (name, sort_order, is_active)
SELECT '4th Engineer', 7, 1 WHERE NOT EXISTS (SELECT 1 FROM mnt_rank_position WHERE name = '4th Engineer');
INSERT INTO mnt_rank_position (name, sort_order, is_active)
SELECT 'Motorman', 8, 1 WHERE NOT EXISTS (SELECT 1 FROM mnt_rank_position WHERE name = 'Motorman');
INSERT INTO mnt_rank_position (name, sort_order, is_active)
SELECT 'Chief Cook', 9, 1 WHERE NOT EXISTS (SELECT 1 FROM mnt_rank_position WHERE name = 'Chief Cook');
INSERT INTO mnt_rank_position (name, sort_order, is_active)
SELECT 'Messman', 10, 1 WHERE NOT EXISTS (SELECT 1 FROM mnt_rank_position WHERE name = 'Messman');
INSERT INTO mnt_rank_position (name, sort_order, is_active)
SELECT 'Bosun', 11, 1 WHERE NOT EXISTS (SELECT 1 FROM mnt_rank_position WHERE name = 'Bosun');
INSERT INTO mnt_rank_position (name, sort_order, is_active)
SELECT 'Cadet', 12, 1 WHERE NOT EXISTS (SELECT 1 FROM mnt_rank_position WHERE name = 'Cadet');

-- ============ 2. role_permission (RBAC) ============
CREATE TABLE IF NOT EXISTS role_permission (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    role_id BIGINT UNSIGNED NOT NULL,
    page_key VARCHAR(100) NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_role_page (role_id, page_key),
    KEY idx_rp_role (role_id),
    CONSTRAINT fk_rp_role FOREIGN KEY (role_id) REFERENCES sys_role(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============ 3. enrollment — endorsement & billing ============
SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='enrollment' AND COLUMN_NAME='endorsed_by');
SET @s := IF(@c = 0, 'ALTER TABLE enrollment ADD COLUMN endorsed_by VARCHAR(200) NULL AFTER training_id', 'SELECT 1');
PREPARE s FROM @s; EXECUTE s; DEALLOCATE PREPARE s;

SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='enrollment' AND COLUMN_NAME='charge_to');
SET @s := IF(@c = 0, 'ALTER TABLE enrollment ADD COLUMN charge_to ENUM(''company'',''trainee'') NOT NULL DEFAULT ''trainee'' AFTER endorsed_by', 'SELECT 1');
PREPARE s FROM @s; EXECUTE s; DEALLOCATE PREPARE s;

SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='enrollment' AND COLUMN_NAME='company_id');
SET @s := IF(@c = 0, 'ALTER TABLE enrollment ADD COLUMN company_id BIGINT UNSIGNED NULL AFTER charge_to', 'SELECT 1');
PREPARE s FROM @s; EXECUTE s; DEALLOCATE PREPARE s;

-- FK company_id -> mnt_company (guarded)
SET @c := (SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
           WHERE CONSTRAINT_SCHEMA='enrollsys' AND TABLE_NAME='enrollment' AND CONSTRAINT_NAME='fk_enrollment_company');
SET @s := IF(@c = 0, 'ALTER TABLE enrollment ADD CONSTRAINT fk_enrollment_company FOREIGN KEY (company_id) REFERENCES mnt_company(id)', 'SELECT 1');
PREPARE s FROM @s; EXECUTE s; DEALLOCATE PREPARE s;

-- ============ 4. ENDORSER role (idempotent) ============
INSERT INTO sys_role (code, name, description, is_active)
SELECT 'ENDORSER', 'Endorser', 'Endorses trainees (no admin access)', 1
WHERE NOT EXISTS (SELECT 1 FROM sys_role WHERE code = 'ENDORSER');

SELECT 'v14_ok' AS step,
       (SELECT COUNT(*) FROM mnt_rank_position) AS ranks,
       (SELECT COUNT(*) FROM role_permission) AS perms,
       (SELECT COUNT(*) FROM sys_role WHERE code = 'ENDORSER') AS endorser;
