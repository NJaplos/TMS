-- ============================================================
-- USMCI-TMS — Schema v9: Instructors (no login)
-- ------------------------------------------------------------
-- Standalone instructor table with full profile details.
-- Re-points training.lead_instructor_id and
-- training_schedule.instructor_id FKs to instructor.id.
-- SAFE / IDEMPOTENT / portable.
-- ============================================================
USE enrollsys;

CREATE TABLE IF NOT EXISTS instructor (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    instructor_code VARCHAR(30) NULL,
    first_name VARCHAR(100) NOT NULL,
    middle_name VARCHAR(100) DEFAULT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(150) DEFAULT NULL,
    mobile_no VARCHAR(50) DEFAULT NULL,
    specialization VARCHAR(200) DEFAULT NULL,
    license_no VARCHAR(100) DEFAULT NULL,
    license_expiry DATE DEFAULT NULL,
    years_experience INT DEFAULT 0,
    rate_per_day DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    bio TEXT DEFAULT NULL,
    photo_path VARCHAR(255) DEFAULT NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Re-point training.lead_instructor_id FK
SET @c := (SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
           WHERE CONSTRAINT_SCHEMA='enrollsys' AND TABLE_NAME='training' AND CONSTRAINT_NAME='fk_training_instructor');
SET @s := IF(@c > 0, 'ALTER TABLE training DROP FOREIGN KEY fk_training_instructor', 'SELECT 1');
PREPARE s FROM @s; EXECUTE s; DEALLOCATE PREPARE s;

UPDATE training t LEFT JOIN instructor i ON i.id = t.lead_instructor_id
SET t.lead_instructor_id = NULL WHERE i.id IS NULL AND t.lead_instructor_id IS NOT NULL;

SET @s := 'ALTER TABLE training ADD CONSTRAINT fk_training_instructor FOREIGN KEY (lead_instructor_id) REFERENCES instructor(id)';
PREPARE s FROM @s; EXECUTE s; DEALLOCATE PREPARE s;

-- Re-point training_schedule.instructor_id FK
SET @c := (SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
           WHERE CONSTRAINT_SCHEMA='enrollsys' AND TABLE_NAME='training_schedule' AND CONSTRAINT_NAME='fk_training_schedule_instructor');
SET @s := IF(@c > 0, 'ALTER TABLE training_schedule DROP FOREIGN KEY fk_training_schedule_instructor', 'SELECT 1');
PREPARE s FROM @s; EXECUTE s; DEALLOCATE PREPARE s;

UPDATE training_schedule ts LEFT JOIN instructor i ON i.id = ts.instructor_id
SET ts.instructor_id = NULL WHERE i.id IS NULL AND ts.instructor_id IS NOT NULL;

SET @s := 'ALTER TABLE training_schedule ADD CONSTRAINT fk_training_schedule_instructor FOREIGN KEY (instructor_id) REFERENCES instructor(id)';
PREPARE s FROM @s; EXECUTE s; DEALLOCATE PREPARE s;

SELECT 'instructor' AS table_name, COUNT(*) AS rows_ FROM instructor;
