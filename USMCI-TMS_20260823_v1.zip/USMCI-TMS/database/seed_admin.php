<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Seed First Admin User
 * File : database/seed_admin.php
 * ---------------------------------------------------------
 * Creates (or resets) the first staff account so login works.
 * Run ONCE from the command line:
 *
 *     php database/seed_admin.php
 *
 * Optional custom password:
 *     php database/seed_admin.php YourPassword123
 *
 * The default password is:  Admin@1234  (change it after first login!)
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once __DIR__ . '/../config/bootstrap.php';

$password = $argv[1] ?? 'Admin@1234';
$username = 'admin';
$email    = 'admin@usmci.edu.ph';
$fullName = 'System Administrator';

if (strlen($password) < 8) {
    fwrite(STDERR, "Password must be at least 8 characters.\n");
    exit(1);
}

try {
    $pdo = db();

    // Find the ADMIN role id dynamically (sys_role is seeded in the dump).
    $roleId = (int) $pdo->query("SELECT id FROM sys_role WHERE code = 'ADMIN' LIMIT 1")->fetchColumn();

    if (!$roleId) {
        fwrite(STDERR, "Could not find the ADMIN role in sys_role. Import the database dump first.\n");
        exit(1);
    }

    $statusActive = (int) $pdo->query("SELECT id FROM mnt_user_status WHERE code = 'ACTIVE' LIMIT 1")->fetchColumn() ?: 1;

    $existing = $pdo->prepare("SELECT id FROM sys_user WHERE username = :username OR email = :email LIMIT 1");
    $existing->execute(['username' => $username, 'email' => $email]);
    $userId = $existing->fetchColumn();

    if ($userId) {
        $stmt = $pdo->prepare(
            "UPDATE sys_user
             SET password_hash = :hash, role_id = :role, status_id = :status,
                 failed_login_count = 0, locked_until = NULL
             WHERE id = :id"
        );
        $stmt->execute([
            'hash' => password_hash($password, PASSWORD_DEFAULT),
            'role' => $roleId,
            'status' => $statusActive,
            'id' => $userId,
        ]);
        echo "Admin user updated (id {$userId}).\n";
    } else {
        $stmt = $pdo->prepare(
            "INSERT INTO sys_user (role_id, username, email, password_hash, full_name, status_id, created_at)
             VALUES (:role, :username, :email, :hash, :full_name, :status, NOW())"
        );
        $stmt->execute([
            'role' => $roleId,
            'username' => $username,
            'email' => $email,
            'hash' => password_hash($password, PASSWORD_DEFAULT),
            'full_name' => $fullName,
            'status' => $statusActive,
        ]);
        echo "Admin user created (id {$pdo->lastInsertId()}).\n";
    }

    echo "Login at:  http://localhost/" . basename(dirname(__DIR__)) . "/login.php\n";
    echo "Username:  {$username}\n";
    echo "Password:  {$password}   <-- change this after first login!\n";
} catch (Throwable $exception) {
    fwrite(STDERR, "Seed failed: " . $exception->getMessage() . "\n");
    exit(1);
}
