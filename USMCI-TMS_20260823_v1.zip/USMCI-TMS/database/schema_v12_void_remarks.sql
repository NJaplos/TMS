-- ============================================================
-- USMCI-TMS — Schema v12: Certificate void remarks
-- ------------------------------------------------------------
-- Adds certificate.void_remarks so staff can record WHY a
-- certificate was voided; the trainee sees it in the Verify
-- modal. SAFE / IDEMPOTENT / portable (MariaDB + MySQL).
-- ============================================================
USE enrollsys;

SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='certificate' AND COLUMN_NAME='void_remarks');
SET @s := IF(@c = 0, 'ALTER TABLE certificate ADD COLUMN void_remarks VARCHAR(500) NULL AFTER status', 'SELECT 1');
PREPARE s FROM @s; EXECUTE s; DEALLOCATE PREPARE s;

SELECT 'v12_ok' AS step, COUNT(*) AS has_col FROM information_schema.COLUMNS
WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='certificate' AND COLUMN_NAME='void_remarks';
