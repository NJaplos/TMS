-- ============================================================
-- USMCI-TMS — Schema v15: Registration form fields
-- ------------------------------------------------------------
-- 1. enrollment.remarks         (form "Remark")
-- 2. enrollment.endorser_type   ('company' | 'marketing')
--    company    → payment NOT mandatory
--    marketing  → payment required to proceed
-- SAFE / IDEMPOTENT / portable.
-- ============================================================
USE enrollsys;

SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='enrollment' AND COLUMN_NAME='remarks');
SET @s := IF(@c = 0, 'ALTER TABLE enrollment ADD COLUMN remarks TEXT NULL AFTER company_id', 'SELECT 1');
PREPARE s FROM @s; EXECUTE s; DEALLOCATE PREPARE s;

SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='enrollment' AND COLUMN_NAME='endorser_type');
SET @s := IF(@c = 0, 'ALTER TABLE enrollment ADD COLUMN endorser_type ENUM(''company'',''marketing'') NOT NULL DEFAULT ''marketing'' AFTER endorsed_by', 'SELECT 1');
PREPARE s FROM @s; EXECUTE s; DEALLOCATE PREPARE s;

SELECT 'v15_ok' AS step, COUNT(*) AS new_cols FROM information_schema.COLUMNS
WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='enrollment' AND COLUMN_NAME IN ('remarks','endorser_type');
