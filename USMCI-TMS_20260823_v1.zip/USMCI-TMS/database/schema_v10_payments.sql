-- ============================================================
-- USMCI-TMS — Schema v10: Payment receipt sequence
-- ------------------------------------------------------------
-- The `payment`, `payment_item`, `payment_transaction` and
-- `official_receipt` tables already exist in the base schema.
-- v10 only registers the OR (official receipt) counter in
-- sequence_generator so receipts get OR-YYYY-###### numbers.
-- SAFE / IDEMPOTENT / portable (MariaDB + MySQL).
-- ============================================================
USE enrollsys;

SET @y := YEAR(CURDATE());

INSERT INTO sequence_generator (sequence_code, sequence_year, current_value, prefix, padding_length)
SELECT 'OR', @y, 0, 'OR', 6
WHERE NOT EXISTS (
    SELECT 1 FROM sequence_generator
    WHERE sequence_code = 'OR' AND sequence_year = @y
);

-- ensure PAY counter exists for the current year too (belt & braces)
INSERT INTO sequence_generator (sequence_code, sequence_year, current_value, prefix, padding_length)
SELECT 'PAY', @y, 0, 'PAY', 6
WHERE NOT EXISTS (
    SELECT 1 FROM sequence_generator
    WHERE sequence_code = 'PAY' AND sequence_year = @y
);

SELECT 'sequence_ok' AS check_name, COUNT(*) AS rows_ FROM sequence_generator WHERE sequence_code IN ('PAY','OR');
