SET NAMES utf8mb4;

-- ============================================================
-- USMCI-TMS — APPLY ALL DATABASE UPDATES (one-click, bulletproof)
-- ------------------------------------------------------------
-- Portable across MariaDB AND MySQL. Every step is guarded via
-- information_schema so it never errors, even if run twice or
-- if a previous partial run left things behind.
--
--   v2: applicant_invitation.registration_code
--   v3: applicant_profile.photo_path
--   v4: applicant_profile.rank_position
--   v5: certificate self-management (nullable FKs +
--       course_name_override + is_self_recorded)
--
-- IMPORTANT (MySQL note): columns used by foreign keys can only
-- be modified after the FK is dropped, so v5 drops the two
-- certificate FKs, makes the columns nullable, then re-adds
-- the FKs. Guarded so missing FKs don't cause errors.
-- ============================================================

USE enrollsys;

-- ============================================================
-- v2 — Registration code for applicant invitations
-- ============================================================
SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='applicant_invitation' AND COLUMN_NAME='registration_code');
SET @s := IF(@c = 0, 'ALTER TABLE applicant_invitation ADD COLUMN registration_code VARCHAR(40) NULL AFTER token_hash', 'SELECT 1');
PREPARE s FROM @s; EXECUTE s; DEALLOCATE PREPARE s;

SET @c := (SELECT COUNT(*) FROM information_schema.STATISTICS
           WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='applicant_invitation' AND INDEX_NAME='uq_applicant_invitation_code');
SET @s := IF(@c = 0, 'ALTER TABLE applicant_invitation ADD UNIQUE KEY uq_applicant_invitation_code (registration_code)', 'SELECT 1');
PREPARE s FROM @s; EXECUTE s; DEALLOCATE PREPARE s;

-- ============================================================
-- v3 — Trainee profile photo
-- ============================================================
SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='applicant_profile' AND COLUMN_NAME='photo_path');
SET @s := IF(@c = 0, 'ALTER TABLE applicant_profile ADD COLUMN photo_path VARCHAR(255) NULL AFTER relationship_id', 'SELECT 1');
PREPARE s FROM @s; EXECUTE s; DEALLOCATE PREPARE s;

-- ============================================================
-- v4 — Trainee rank / position
-- ============================================================
SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='applicant_profile' AND COLUMN_NAME='rank_position');
SET @s := IF(@c = 0, 'ALTER TABLE applicant_profile ADD COLUMN rank_position VARCHAR(100) NULL AFTER seafarer_id_no', 'SELECT 1');
PREPARE s FROM @s; EXECUTE s; DEALLOCATE PREPARE s;

-- ============================================================
-- v5 — Trainee-managed certificates
-- ------------------------------------------------------------
-- Step 1: drop the two FKs (if they exist) so the columns can
--         be modified on MySQL too.
-- Step 2: make enrollment_id + course_id nullable.
-- Step 3: add course_name_override + is_self_recorded.
-- Step 4: re-add the FKs (guarded).
-- ============================================================

-- 1a) drop fk_certificate_enrollment if present
SET @c := (SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
           WHERE CONSTRAINT_SCHEMA='enrollsys' AND TABLE_NAME='certificate' AND CONSTRAINT_NAME='fk_certificate_enrollment' AND CONSTRAINT_TYPE='FOREIGN KEY');
SET @s := IF(@c > 0, 'ALTER TABLE certificate DROP FOREIGN KEY fk_certificate_enrollment', 'SELECT 1');
PREPARE s FROM @s; EXECUTE s; DEALLOCATE PREPARE s;

-- 1b) drop fk_certificate_course if present
SET @c := (SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
           WHERE CONSTRAINT_SCHEMA='enrollsys' AND TABLE_NAME='certificate' AND CONSTRAINT_NAME='fk_certificate_course' AND CONSTRAINT_TYPE='FOREIGN KEY');
SET @s := IF(@c > 0, 'ALTER TABLE certificate DROP FOREIGN KEY fk_certificate_course', 'SELECT 1');
PREPARE s FROM @s; EXECUTE s; DEALLOCATE PREPARE s;

-- 2a) make enrollment_id nullable
SET @c := (SELECT IS_NULLABLE FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='certificate' AND COLUMN_NAME='enrollment_id');
SET @s := IF(@c <> 'YES', 'ALTER TABLE certificate MODIFY enrollment_id BIGINT UNSIGNED NULL', 'SELECT 1');
PREPARE s FROM @s; EXECUTE s; DEALLOCATE PREPARE s;

-- 2b) make course_id nullable
SET @c := (SELECT IS_NULLABLE FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='certificate' AND COLUMN_NAME='course_id');
SET @s := IF(@c <> 'YES', 'ALTER TABLE certificate MODIFY course_id BIGINT UNSIGNED NULL', 'SELECT 1');
PREPARE s FROM @s; EXECUTE s; DEALLOCATE PREPARE s;

-- 3a) course_name_override column
SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='certificate' AND COLUMN_NAME='course_name_override');
SET @s := IF(@c = 0, 'ALTER TABLE certificate ADD COLUMN course_name_override VARCHAR(200) NULL AFTER course_id', 'SELECT 1');
PREPARE s FROM @s; EXECUTE s; DEALLOCATE PREPARE s;

-- 3b) is_self_recorded column
SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='certificate' AND COLUMN_NAME='is_self_recorded');
SET @s := IF(@c = 0, 'ALTER TABLE certificate ADD COLUMN is_self_recorded TINYINT(1) NOT NULL DEFAULT 0 AFTER status', 'SELECT 1');
PREPARE s FROM @s; EXECUTE s; DEALLOCATE PREPARE s;

-- 4a) re-add fk_certificate_enrollment (only if not present)
SET @c := (SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
           WHERE CONSTRAINT_SCHEMA='enrollsys' AND TABLE_NAME='certificate' AND CONSTRAINT_NAME='fk_certificate_enrollment' AND CONSTRAINT_TYPE='FOREIGN KEY');
SET @s := IF(@c = 0, 'ALTER TABLE certificate ADD CONSTRAINT fk_certificate_enrollment FOREIGN KEY (enrollment_id) REFERENCES enrollment(id)', 'SELECT 1');
PREPARE s FROM @s; EXECUTE s; DEALLOCATE PREPARE s;

-- 4b) re-add fk_certificate_course (only if not present)
SET @c := (SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
           WHERE CONSTRAINT_SCHEMA='enrollsys' AND TABLE_NAME='certificate' AND CONSTRAINT_NAME='fk_certificate_course' AND CONSTRAINT_TYPE='FOREIGN KEY');
SET @s := IF(@c = 0, 'ALTER TABLE certificate ADD CONSTRAINT fk_certificate_course FOREIGN KEY (course_id) REFERENCES mnt_course(id)', 'SELECT 1');
PREPARE s FROM @s; EXECUTE s; DEALLOCATE PREPARE s;

-- ============================================================
-- Verify
-- ============================================================
SELECT 'registration_code' AS col, COUNT(*) AS ok FROM information_schema.COLUMNS
WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='applicant_invitation' AND COLUMN_NAME='registration_code'
UNION ALL SELECT 'photo_path', COUNT(*) FROM information_schema.COLUMNS
WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='applicant_profile' AND COLUMN_NAME='photo_path'
UNION ALL SELECT 'rank_position', COUNT(*) FROM information_schema.COLUMNS
WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='applicant_profile' AND COLUMN_NAME='rank_position'
UNION ALL SELECT 'course_name_override', COUNT(*) FROM information_schema.COLUMNS
WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='certificate' AND COLUMN_NAME='course_name_override'
UNION ALL SELECT 'is_self_recorded', COUNT(*) FROM information_schema.COLUMNS
WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='certificate' AND COLUMN_NAME='is_self_recorded';

-- ============================================================
-- v6 — Course price (mnt_course.price_amount)
-- ============================================================
SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='mnt_course' AND COLUMN_NAME='price_amount');
SET @s := IF(@c = 0, 'ALTER TABLE mnt_course ADD COLUMN price_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00 AFTER validity_months', 'SELECT 1');
PREPARE s FROM @s; EXECUTE s; DEALLOCATE PREPARE s;

-- ============================================================
-- v7 — Course upcoming_batches (editable planning count)
-- ============================================================
SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='mnt_course' AND COLUMN_NAME='upcoming_batches');
SET @s := IF(@c = 0, 'ALTER TABLE mnt_course ADD COLUMN upcoming_batches INT NOT NULL DEFAULT 0 AFTER price_amount', 'SELECT 1');
PREPARE s FROM @s; EXECUTE s; DEALLOCATE PREPARE s;

-- ============================================================
-- v8 — Venue maintenance (mnt_venue)
-- ============================================================
CREATE TABLE IF NOT EXISTS mnt_venue (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    location VARCHAR(200) DEFAULT NULL,
    capacity INT NOT NULL DEFAULT 0,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Idempotent seed: insert each default venue only if no row with the
-- same name exists yet (portable SELECT..WHERE NOT EXISTS — works on
-- MySQL and MariaDB; INSERT IGNORE was NOT enough because the table has
-- no unique key on name, so re-running the updater duplicated venues).
INSERT INTO mnt_venue (name, location, capacity, is_active)
SELECT 'USMCI Main Campus — Hall A', 'Main Campus, Zamboanga', 60, 1
WHERE NOT EXISTS (SELECT 1 FROM mnt_venue WHERE name = 'USMCI Main Campus — Hall A');
INSERT INTO mnt_venue (name, location, capacity, is_active)
SELECT 'USMCI Main Campus — Hall B', 'Main Campus, Zamboanga', 40, 1
WHERE NOT EXISTS (SELECT 1 FROM mnt_venue WHERE name = 'USMCI Main Campus — Hall B');
INSERT INTO mnt_venue (name, location, capacity, is_active)
SELECT 'Simulation Room', 'Main Campus, Zamboanga', 25, 1
WHERE NOT EXISTS (SELECT 1 FROM mnt_venue WHERE name = 'Simulation Room');

-- Repair: collapse any duplicate venue names left by the old
-- INSERT IGNORE seed (keep the lowest id per name).
DELETE v1 FROM mnt_venue v1
JOIN mnt_venue v2 ON v2.name = v1.name AND v2.id < v1.id;

-- ============================================================
-- v9 — Instructors (standalone profile, NO login)
-- ------------------------------------------------------------
-- Instructors are records, not user accounts. The training
-- table's lead_instructor_id + training_schedule.instructor_id
-- and enrollment_schedule/subject.instructor_id previously
-- pointed at sys_user; we re-point them to instructor.id.
-- ============================================================
CREATE TABLE IF NOT EXISTS instructor (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    instructor_code VARCHAR(30) NULL,
    first_name VARCHAR(100) NOT NULL,
    middle_name VARCHAR(100) DEFAULT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(150) DEFAULT NULL,
    mobile_no VARCHAR(50) DEFAULT NULL,
    specialization VARCHAR(200) DEFAULT NULL,
    license_no VARCHAR(100) DEFAULT NULL,
    license_expiry DATE DEFAULT NULL,
    years_experience INT DEFAULT 0,
    rate_per_day DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    bio TEXT DEFAULT NULL,
    photo_path VARCHAR(255) DEFAULT NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Re-point training.lead_instructor_id FK to instructor
SET @c := (SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
           WHERE CONSTRAINT_SCHEMA='enrollsys' AND TABLE_NAME='training' AND CONSTRAINT_NAME='fk_training_instructor');
SET @s := IF(@c > 0, 'ALTER TABLE training DROP FOREIGN KEY fk_training_instructor', 'SELECT 1');
PREPARE s FROM @s; EXECUTE s; DEALLOCATE PREPARE s;

-- Null out any lead_instructor_id that isn't a real instructor row
-- (old values pointed at sys_user ids — they would break the new FK)
UPDATE training t LEFT JOIN instructor i ON i.id = t.lead_instructor_id
SET t.lead_instructor_id = NULL WHERE i.id IS NULL AND t.lead_instructor_id IS NOT NULL;

SET @s := 'ALTER TABLE training ADD CONSTRAINT fk_training_instructor FOREIGN KEY (lead_instructor_id) REFERENCES instructor(id)';
PREPARE s FROM @s; EXECUTE s; DEALLOCATE PREPARE s;

-- Re-point training_schedule.instructor_id FK to instructor
SET @c := (SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
           WHERE CONSTRAINT_SCHEMA='enrollsys' AND TABLE_NAME='training_schedule' AND CONSTRAINT_NAME='fk_training_schedule_instructor');
SET @s := IF(@c > 0, 'ALTER TABLE training_schedule DROP FOREIGN KEY fk_training_schedule_instructor', 'SELECT 1');
PREPARE s FROM @s; EXECUTE s; DEALLOCATE PREPARE s;

UPDATE training_schedule ts LEFT JOIN instructor i ON i.id = ts.instructor_id
SET ts.instructor_id = NULL WHERE i.id IS NULL AND ts.instructor_id IS NOT NULL;

SET @s := 'ALTER TABLE training_schedule ADD CONSTRAINT fk_training_schedule_instructor FOREIGN KEY (instructor_id) REFERENCES instructor(id)';
PREPARE s FROM @s; EXECUTE s; DEALLOCATE PREPARE s;

-- ============================================================
-- v10 — Payment receipt sequence (OR counter)
-- ------------------------------------------------------------
-- Payment tables already exist in the base schema. This only
-- registers the OR (official receipt) counter and re-ensures
-- the PAY counter for the current year. Idempotent + portable.
-- ============================================================
SET @y := YEAR(CURDATE());

INSERT INTO sequence_generator (sequence_code, sequence_year, current_value, prefix, padding_length)
SELECT 'OR', @y, 0, 'OR', 6
WHERE NOT EXISTS (
    SELECT 1 FROM sequence_generator
    WHERE sequence_code = 'OR' AND sequence_year = @y
);

INSERT INTO sequence_generator (sequence_code, sequence_year, current_value, prefix, padding_length)
SELECT 'PAY', @y, 0, 'PAY', 6
WHERE NOT EXISTS (
    SELECT 1 FROM sequence_generator
    WHERE sequence_code = 'PAY' AND sequence_year = @y
);

SELECT 'v10_ok' AS step, COUNT(*) AS or_pay_count FROM sequence_generator WHERE sequence_code IN ('PAY','OR');

-- ============================================================
-- v11 — Certificate file upload (file_path / file_name)
-- ============================================================
SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='certificate' AND COLUMN_NAME='file_path');
SET @s := IF(@c = 0, 'ALTER TABLE certificate ADD COLUMN file_path VARCHAR(500) NULL AFTER verification_url', 'SELECT 1');
PREPARE s FROM @s; EXECUTE s; DEALLOCATE PREPARE s;

SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='certificate' AND COLUMN_NAME='file_name');
SET @s := IF(@c = 0, 'ALTER TABLE certificate ADD COLUMN file_name VARCHAR(255) NULL AFTER file_path', 'SELECT 1');
PREPARE s FROM @s; EXECUTE s; DEALLOCATE PREPARE s;

SELECT 'v11_ok' AS step, COUNT(*) AS cert_file_cols FROM information_schema.COLUMNS
WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='certificate' AND COLUMN_NAME IN ('file_path','file_name');

-- ============================================================
-- v12 — Certificate void remarks (void_remarks)
-- ============================================================
SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='certificate' AND COLUMN_NAME='void_remarks');
SET @s := IF(@c = 0, 'ALTER TABLE certificate ADD COLUMN void_remarks VARCHAR(500) NULL AFTER status', 'SELECT 1');
PREPARE s FROM @s; EXECUTE s; DEALLOCATE PREPARE s;

SELECT 'v12_ok' AS step, COUNT(*) AS void_remarks_col FROM information_schema.COLUMNS
WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='certificate' AND COLUMN_NAME='void_remarks';

-- ============================================================
-- v13 — Audit log (ensures the base audit_log table exists)
-- ============================================================
CREATE TABLE IF NOT EXISTS audit_log (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    actor_type ENUM('user','applicant','system') NOT NULL DEFAULT 'user',
    actor_id BIGINT UNSIGNED DEFAULT NULL,
    action VARCHAR(100) NOT NULL,
    table_name VARCHAR(100) DEFAULT NULL,
    record_id BIGINT UNSIGNED DEFAULT NULL,
    old_values LONGTEXT DEFAULT NULL,
    new_values LONGTEXT DEFAULT NULL,
    ip_address VARCHAR(45) DEFAULT NULL,
    user_agent TEXT DEFAULT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_audit_table (table_name),
    INDEX idx_audit_created (created_at),
    INDEX idx_audit_actor (actor_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SELECT 'v13_ok' AS step, COUNT(*) AS has_audit_table FROM information_schema.TABLES
WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='audit_log';

-- ============================================================
-- v14 — Ranks + Role permissions + Endorsement
-- ============================================================
CREATE TABLE IF NOT EXISTS mnt_rank_position (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    sort_order INT NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_rank_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO mnt_rank_position (name, sort_order, is_active)
SELECT 'Oiler', 1, 1 WHERE NOT EXISTS (SELECT 1 FROM mnt_rank_position WHERE name = 'Oiler');
INSERT INTO mnt_rank_position (name, sort_order, is_active)
SELECT 'Deck Cadet', 2, 1 WHERE NOT EXISTS (SELECT 1 FROM mnt_rank_position WHERE name = 'Deck Cadet');
INSERT INTO mnt_rank_position (name, sort_order, is_active)
SELECT 'Able Seaman', 3, 1 WHERE NOT EXISTS (SELECT 1 FROM mnt_rank_position WHERE name = 'Able Seaman');
INSERT INTO mnt_rank_position (name, sort_order, is_active)
SELECT 'Ordinary Seaman', 4, 1 WHERE NOT EXISTS (SELECT 1 FROM mnt_rank_position WHERE name = 'Ordinary Seaman');
INSERT INTO mnt_rank_position (name, sort_order, is_active)
SELECT '2nd Engineer', 5, 1 WHERE NOT EXISTS (SELECT 1 FROM mnt_rank_position WHERE name = '2nd Engineer');
INSERT INTO mnt_rank_position (name, sort_order, is_active)
SELECT '3rd Engineer', 6, 1 WHERE NOT EXISTS (SELECT 1 FROM mnt_rank_position WHERE name = '3rd Engineer');
INSERT INTO mnt_rank_position (name, sort_order, is_active)
SELECT '4th Engineer', 7, 1 WHERE NOT EXISTS (SELECT 1 FROM mnt_rank_position WHERE name = '4th Engineer');
INSERT INTO mnt_rank_position (name, sort_order, is_active)
SELECT 'Motorman', 8, 1 WHERE NOT EXISTS (SELECT 1 FROM mnt_rank_position WHERE name = 'Motorman');
INSERT INTO mnt_rank_position (name, sort_order, is_active)
SELECT 'Chief Cook', 9, 1 WHERE NOT EXISTS (SELECT 1 FROM mnt_rank_position WHERE name = 'Chief Cook');
INSERT INTO mnt_rank_position (name, sort_order, is_active)
SELECT 'Messman', 10, 1 WHERE NOT EXISTS (SELECT 1 FROM mnt_rank_position WHERE name = 'Messman');
INSERT INTO mnt_rank_position (name, sort_order, is_active)
SELECT 'Bosun', 11, 1 WHERE NOT EXISTS (SELECT 1 FROM mnt_rank_position WHERE name = 'Bosun');
INSERT INTO mnt_rank_position (name, sort_order, is_active)
SELECT 'Cadet', 12, 1 WHERE NOT EXISTS (SELECT 1 FROM mnt_rank_position WHERE name = 'Cadet');

CREATE TABLE IF NOT EXISTS role_permission (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    role_id BIGINT UNSIGNED NOT NULL,
    page_key VARCHAR(100) NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_role_page (role_id, page_key),
    KEY idx_rp_role (role_id),
    CONSTRAINT fk_rp_role FOREIGN KEY (role_id) REFERENCES sys_role(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='enrollment' AND COLUMN_NAME='endorsed_by');
SET @s := IF(@c = 0, 'ALTER TABLE enrollment ADD COLUMN endorsed_by VARCHAR(200) NULL AFTER training_id', 'SELECT 1');
PREPARE s FROM @s; EXECUTE s; DEALLOCATE PREPARE s;

SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='enrollment' AND COLUMN_NAME='charge_to');
SET @s := IF(@c = 0, 'ALTER TABLE enrollment ADD COLUMN charge_to ENUM(''company'',''trainee'') NOT NULL DEFAULT ''trainee'' AFTER endorsed_by', 'SELECT 1');
PREPARE s FROM @s; EXECUTE s; DEALLOCATE PREPARE s;

SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='enrollment' AND COLUMN_NAME='company_id');
SET @s := IF(@c = 0, 'ALTER TABLE enrollment ADD COLUMN company_id BIGINT UNSIGNED NULL AFTER charge_to', 'SELECT 1');
PREPARE s FROM @s; EXECUTE s; DEALLOCATE PREPARE s;

SET @c := (SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
           WHERE CONSTRAINT_SCHEMA='enrollsys' AND TABLE_NAME='enrollment' AND CONSTRAINT_NAME='fk_enrollment_company');
SET @s := IF(@c = 0, 'ALTER TABLE enrollment ADD CONSTRAINT fk_enrollment_company FOREIGN KEY (company_id) REFERENCES mnt_company(id)', 'SELECT 1');
PREPARE s FROM @s; EXECUTE s; DEALLOCATE PREPARE s;

INSERT INTO sys_role (code, name, description, is_active)
SELECT 'ENDORSER', 'Endorser', 'Endorses trainees (no admin access)', 1
WHERE NOT EXISTS (SELECT 1 FROM sys_role WHERE code = 'ENDORSER');

SELECT 'v14_ok' AS step,
       (SELECT COUNT(*) FROM mnt_rank_position) AS ranks,
       (SELECT COUNT(*) FROM role_permission) AS perms,
       (SELECT COUNT(*) FROM sys_role WHERE code = 'ENDORSER') AS endorser;

-- ============================================================
-- v15 — Registration form fields (remarks, endorser_type)
-- ============================================================
SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='enrollment' AND COLUMN_NAME='remarks');
SET @s := IF(@c = 0, 'ALTER TABLE enrollment ADD COLUMN remarks TEXT NULL AFTER company_id', 'SELECT 1');
PREPARE s FROM @s; EXECUTE s; DEALLOCATE PREPARE s;

SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='enrollment' AND COLUMN_NAME='endorser_type');
SET @s := IF(@c = 0, 'ALTER TABLE enrollment ADD COLUMN endorser_type ENUM(''company'',''marketing'') NOT NULL DEFAULT ''marketing'' AFTER endorsed_by', 'SELECT 1');
PREPARE s FROM @s; EXECUTE s; DEALLOCATE PREPARE s;

SELECT 'v15_ok' AS step, COUNT(*) AS reg_form_cols FROM information_schema.COLUMNS
WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='enrollment' AND COLUMN_NAME IN ('remarks','endorser_type');

-- ============================================================
-- v16 — Company contact fields + Role access levels
-- ============================================================
SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='mnt_company' AND COLUMN_NAME='contact_person');
SET @s := IF(@c = 0, 'ALTER TABLE mnt_company ADD COLUMN contact_person VARCHAR(150) NULL AFTER company_type', 'SELECT 1');
PREPARE s FROM @s; EXECUTE s; DEALLOCATE PREPARE s;

SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='mnt_company' AND COLUMN_NAME='contact_number');
SET @s := IF(@c = 0, 'ALTER TABLE mnt_company ADD COLUMN contact_number VARCHAR(50) NULL AFTER contact_person', 'SELECT 1');
PREPARE s FROM @s; EXECUTE s; DEALLOCATE PREPARE s;

SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='mnt_company' AND COLUMN_NAME='contact_email');
SET @s := IF(@c = 0, 'ALTER TABLE mnt_company ADD COLUMN contact_email VARCHAR(150) NULL AFTER contact_number', 'SELECT 1');
PREPARE s FROM @s; EXECUTE s; DEALLOCATE PREPARE s;

SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='role_permission' AND COLUMN_NAME='can_view');
SET @s := IF(@c = 0, 'ALTER TABLE role_permission ADD COLUMN can_view TINYINT(1) NOT NULL DEFAULT 1 AFTER page_key', 'SELECT 1');
PREPARE s FROM @s; EXECUTE s; DEALLOCATE PREPARE s;

SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='role_permission' AND COLUMN_NAME='can_edit');
SET @s := IF(@c = 0, 'ALTER TABLE role_permission ADD COLUMN can_edit TINYINT(1) NOT NULL DEFAULT 1 AFTER can_view', 'SELECT 1');
PREPARE s FROM @s; EXECUTE s; DEALLOCATE PREPARE s;

SELECT 'v16_ok' AS step,
       (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='mnt_company' AND COLUMN_NAME IN ('contact_person','contact_number','contact_email')) AS company_cols,
       (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='role_permission' AND COLUMN_NAME IN ('can_view','can_edit')) AS perm_cols;

-- ============================================================
-- v17 — Process Rules (configurable enrollment & certificate policy)
-- Stored in mnt_system_setting (boolean). The property can flip
-- these in Settings → Process Rules without code changes.
-- ============================================================
INSERT INTO mnt_system_setting (setting_key, setting_value, data_type, description)
SELECT 'rule_enroll_marketing_require_paid', '1', 'boolean', 'Marketing/Endorser: require payment before the enrollment can be marked Enrolled'
WHERE NOT EXISTS (SELECT 1 FROM mnt_system_setting WHERE setting_key = 'rule_enroll_marketing_require_paid');

INSERT INTO mnt_system_setting (setting_key, setting_value, data_type, description)
SELECT 'rule_enroll_company_require_paid', '0', 'boolean', 'Company-Endorsed: require payment before the enrollment can be marked Enrolled'
WHERE NOT EXISTS (SELECT 1 FROM mnt_system_setting WHERE setting_key = 'rule_enroll_company_require_paid');

INSERT INTO mnt_system_setting (setting_key, setting_value, data_type, description)
SELECT 'rule_auto_enroll_on_payment', '1', 'boolean', 'Auto-update a Pending enrollment to Enrolled when a payment is recorded'
WHERE NOT EXISTS (SELECT 1 FROM mnt_system_setting WHERE setting_key = 'rule_auto_enroll_on_payment');

INSERT INTO mnt_system_setting (setting_key, setting_value, data_type, description)
SELECT 'rule_cert_marketing_require_paid', '1', 'boolean', 'Marketing/Endorser: payment required before a certificate can be issued'
WHERE NOT EXISTS (SELECT 1 FROM mnt_system_setting WHERE setting_key = 'rule_cert_marketing_require_paid');

INSERT INTO mnt_system_setting (setting_key, setting_value, data_type, description)
SELECT 'rule_cert_company_allow_unpaid', '1', 'boolean', 'Company-Endorsed: certificate may be issued even when no payment was received'
WHERE NOT EXISTS (SELECT 1 FROM mnt_system_setting WHERE setting_key = 'rule_cert_company_allow_unpaid');

INSERT INTO mnt_system_setting (setting_key, setting_value, data_type, description)
SELECT 'rule_cert_require_enrolled_status', '0', 'boolean', 'Certificate requires the enrollment to be Enrolled or Completed (OFF = Pending allowed where permitted)'
WHERE NOT EXISTS (SELECT 1 FROM mnt_system_setting WHERE setting_key = 'rule_cert_require_enrolled_status');

INSERT INTO mnt_system_setting (setting_key, setting_value, data_type, description)
SELECT 'rule_auto_complete_on_cert', '1', 'boolean', 'Auto-update the enrollment to Completed when a certificate is issued'
WHERE NOT EXISTS (SELECT 1 FROM mnt_system_setting WHERE setting_key = 'rule_auto_complete_on_cert');

SELECT 'v17_ok' AS step, COUNT(*) AS process_rules FROM mnt_system_setting WHERE setting_key LIKE 'rule_%';

-- ============================================================
-- v18 — Requirements gate rule (V5.37)
-- ============================================================
INSERT INTO mnt_system_setting (setting_key, setting_value, data_type, description)
SELECT 'rule_enroll_require_docs', '0', 'boolean', 'Require all requirement documents before an enrollment can be marked Enrolled (Docs: X/Y indicator)'
WHERE NOT EXISTS (SELECT 1 FROM mnt_system_setting WHERE setting_key = 'rule_enroll_require_docs');

SELECT 'v18_ok' AS step, COUNT(*) AS rules_total FROM mnt_system_setting WHERE setting_key LIKE 'rule\_%';

-- ============================================================
-- v19 — Report letterhead settings (editable by the school)
-- ============================================================
INSERT INTO mnt_system_setting (setting_key, setting_value, data_type, description)
SELECT 'report_org_name', 'UNITED SEAFARERS MARITIME CENTER INC', 'string', 'Report letterhead: organization name'
WHERE NOT EXISTS (SELECT 1 FROM mnt_system_setting WHERE setting_key = 'report_org_name');

INSERT INTO mnt_system_setting (setting_key, setting_value, data_type, description)
SELECT 'report_org_address', 'G/F YMCA OF MANILA BLDG 350 ANTONIO VILLEGAS ST ERMITA MANILA', 'string', 'Report letterhead: address'
WHERE NOT EXISTS (SELECT 1 FROM mnt_system_setting WHERE setting_key = 'report_org_address');

INSERT INTO mnt_system_setting (setting_key, setting_value, data_type, description)
SELECT 'report_tel_no', 'TEL NO: 8241-0881', 'string', 'Report letterhead: telephone'
WHERE NOT EXISTS (SELECT 1 FROM mnt_system_setting WHERE setting_key = 'report_tel_no');

INSERT INTO mnt_system_setting (setting_key, setting_value, data_type, description)
SELECT 'report_mobile_no', 'MOBILE NO: 09971201553', 'string', 'Report letterhead: mobile'
WHERE NOT EXISTS (SELECT 1 FROM mnt_system_setting WHERE setting_key = 'report_mobile_no');

INSERT INTO mnt_system_setting (setting_key, setting_value, data_type, description)
SELECT 'report_email', 'usmci2010@gmail.com', 'string', 'Report letterhead: email'
WHERE NOT EXISTS (SELECT 1 FROM mnt_system_setting WHERE setting_key = 'report_email');

INSERT INTO mnt_system_setting (setting_key, setting_value, data_type, description)
SELECT 'report_footer', '', 'string', 'Report letterhead: footer note (optional)'
WHERE NOT EXISTS (SELECT 1 FROM mnt_system_setting WHERE setting_key = 'report_footer');

SELECT 'v19_ok' AS step, COUNT(*) AS letterhead_settings FROM mnt_system_setting WHERE setting_key LIKE 'report\_%';

-- ============================================================
-- v20 — application_requirement unique (application, doc type)
-- so staff "mark received" upserts cleanly (V5.38)
-- ============================================================
SET @c := (SELECT COUNT(*) FROM information_schema.STATISTICS
           WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='application_requirement'
             AND INDEX_NAME='uq_app_req_doc');
SET @s := IF(@c = 0,
    'ALTER TABLE application_requirement ADD UNIQUE KEY uq_app_req_doc (application_id, document_type_id)',
    'SELECT 1');
PREPARE s FROM @s; EXECUTE s; DEALLOCATE PREPARE s;

SELECT 'v20_ok' AS step,
       (SELECT COUNT(*) FROM information_schema.STATISTICS
        WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='application_requirement'
          AND INDEX_NAME='uq_app_req_doc') AS uniq_idx;

-- ============================================================
-- v21 — Website Content: About (editable, one-page anchor model)
-- ============================================================
INSERT INTO mnt_system_setting (setting_key, setting_value, data_type, description)
SELECT 'site_about_intro', 'United Seafarers Maritime Center (USMC) — a company duly approved and recognized by the Securities and Exchange Commission (CS201008536), operated and maintained by a dynamic group of professionals with more than 20 years of experience in the maritime training industry.', 'string', 'Website About: intro / tagline'
WHERE NOT EXISTS (SELECT 1 FROM mnt_system_setting WHERE setting_key = 'site_about_intro');

INSERT INTO mnt_system_setting (setting_key, setting_value, data_type, description)
SELECT 'site_about_story', 'United Seafarers Maritime Center is a company duly approved and recognized by the Securities and Exchange Commission with Company Registration Number CS201008536. It is operated and maintained by a dynamic group of Professionals with extensive and diverse experience in the Maritime Training Industry for more than 20 years. USMC was formed with the main objective of providing the highest quality of training products with intense focus on affordability and speed of service. It aims to become the premier destination of Filipino Seafarers for all their training and assessment needs.', 'string', 'Website About: Our Story'
WHERE NOT EXISTS (SELECT 1 FROM mnt_system_setting WHERE setting_key = 'site_about_story');

INSERT INTO mnt_system_setting (setting_key, setting_value, data_type, description)
SELECT 'site_about_mission', 'Develop STCW-based training programs that will satisfy the National and International Requirements of Seafarers
Provide specialized training programs that will compliment the competence of seafarers', 'string', 'Website About: Mission (one item per line)'
WHERE NOT EXISTS (SELECT 1 FROM mnt_system_setting WHERE setting_key = 'site_about_mission');

INSERT INTO mnt_system_setting (setting_key, setting_value, data_type, description)
SELECT 'site_about_vision', 'United Seafarers Maritime Center shall be a world class and globally recognized maritime institution to offer training and competency assessment.', 'string', 'Website About: Vision statement'
WHERE NOT EXISTS (SELECT 1 FROM mnt_system_setting WHERE setting_key = 'site_about_vision');

INSERT INTO mnt_system_setting (setting_key, setting_value, data_type, description)
SELECT 'site_about_vision_points', 'Accessible, innovative and fast services to the required trainings and assessments of the Filipino Seafarers
State of the art delivery of instruction
Up-to-date on board technology related training facilities and equipment
Well trained and qualified training personnel that consistently exceed the expectations of the clients with regards to quality, safety and reliability, service satisfaction and environmental responsibilities', 'string', 'Website About: Vision pillars (one per line)'
WHERE NOT EXISTS (SELECT 1 FROM mnt_system_setting WHERE setting_key = 'site_about_vision_points');

INSERT INTO mnt_system_setting (setting_key, setting_value, data_type, description)
SELECT 'site_about_quality', 'Our Quality Management System exemplifies constant drive to satisfy our clientele, while always being mindful of our responsibility to Philippine Legislation, Standards, Employees and the broader community. We operate a Quality Management System that meets the requirements of ISO 9001:2015 — encouraging the active participation, endeavour and contribution of ideas from all personnel.', 'string', 'Website About: Quality / ISO commitment'
WHERE NOT EXISTS (SELECT 1 FROM mnt_system_setting WHERE setting_key = 'site_about_quality');

INSERT INTO mnt_system_setting (setting_key, setting_value, data_type, description)
SELECT 'site_about_core_values', 'Safety First: We place the safety of seafarers, the public and the environment above all else.
Excellence in Training: We deliver internationally recognized, STCW-based programs of the highest standard.
Integrity & Transparency: We operate with honesty, accountability and full compliance with SEC and ISO standards.
Customer-Care: We put the Filipino seafarer at the heart of every service we provide.
Global Readiness: We prepare seafarers for world-class careers on the global stage.', 'string', 'Website About: Core values (one per line, format: Title: description)'
WHERE NOT EXISTS (SELECT 1 FROM mnt_system_setting WHERE setting_key = 'site_about_core_values');

INSERT INTO mnt_system_setting (setting_key, setting_value, data_type, description)
SELECT 'site_about_accreditations', 'SEC Registered — CS201008536
ISO 9001:2015 Certified
MARINA Accredited', 'string', 'Website About: Accreditations (one per line)'
WHERE NOT EXISTS (SELECT 1 FROM mnt_system_setting WHERE setting_key = 'site_about_accreditations');

INSERT INTO mnt_system_setting (setting_key, setting_value, data_type, description)
SELECT 'site_about_leader', 'Engr. Audie M. Macatol
Managing Director', 'string', 'Website About: Leadership (line 1 = name, line 2 = role)'
WHERE NOT EXISTS (SELECT 1 FROM mnt_system_setting WHERE setting_key = 'site_about_leader');

INSERT INTO mnt_system_setting (setting_key, setting_value, data_type, description)
SELECT 'site_about_photo', 'assets/images/site/facility-1.jpg', 'string', 'Website About: story photo path'
WHERE NOT EXISTS (SELECT 1 FROM mnt_system_setting WHERE setting_key = 'site_about_photo');

SELECT 'v21_ok' AS step, COUNT(*) AS about_settings FROM mnt_system_setting WHERE setting_key LIKE 'site_about\_%';

-- ============================================================
-- v22 — Website Content: About carousel + manager message
-- ============================================================
INSERT INTO mnt_system_setting (setting_key, setting_value, data_type, description)
SELECT 'site_about_carousel_dir', 'assets/images/site/carousel', 'string', 'Website About: folder scanned for carousel photos'
WHERE NOT EXISTS (SELECT 1 FROM mnt_system_setting WHERE setting_key = 'site_about_carousel_dir');

INSERT INTO mnt_system_setting (setting_key, setting_value, data_type, description)
SELECT 'site_about_manager_photo', 'assets/images/site/manager-placeholder.jpg', 'string', 'Website About: Managing Director photo path'
WHERE NOT EXISTS (SELECT 1 FROM mnt_system_setting WHERE setting_key = 'site_about_manager_photo');

INSERT INTO mnt_system_setting (setting_key, setting_value, data_type, description)
SELECT 'site_about_manager_message', 'Welcome to United Seafarers Maritime Center. For more than two decades we have dedicated ourselves to one mission: to prepare Filipino seafarers for the world — through quality training, modern facilities, and a team that puts the seafarer first. We invite you to train with us and experience the USMCI difference.', 'string', 'Website About: Managing Director message'
WHERE NOT EXISTS (SELECT 1 FROM mnt_system_setting WHERE setting_key = 'site_about_manager_message');

SELECT 'v22_ok' AS step, COUNT(*) AS about_v22 FROM mnt_system_setting WHERE setting_key IN ('site_about_carousel_dir','site_about_manager_photo','site_about_manager_message');

-- ============================================================
-- v23 — Website Content: Courses + News section intros
-- ============================================================
INSERT INTO mnt_system_setting (setting_key, setting_value, data_type, description)
SELECT 'site_courses_intro', 'Explore our full range of maritime training programs. Click a course to see its details and send an inquiry.', 'string', 'Website Courses: intro paragraph'
WHERE NOT EXISTS (SELECT 1 FROM mnt_system_setting WHERE setting_key = 'site_courses_intro');

INSERT INTO mnt_system_setting (setting_key, setting_value, data_type, description)
SELECT 'site_news_intro', 'Currently enrolling batches — reserve your slot today.', 'string', 'Website News: intro paragraph'
WHERE NOT EXISTS (SELECT 1 FROM mnt_system_setting WHERE setting_key = 'site_news_intro');

SELECT 'v23_ok' AS step, COUNT(*) AS site_intros FROM mnt_system_setting WHERE setting_key IN ('site_courses_intro','site_news_intro');

-- ============================================================
-- v24 — Course photo + website courses background (V5.53)
-- ============================================================
SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='mnt_course' AND COLUMN_NAME='photo_path');
SET @s := IF(@c = 0, 'ALTER TABLE mnt_course ADD COLUMN photo_path VARCHAR(255) NULL AFTER description', 'SELECT 1');
PREPARE s FROM @s; EXECUTE s; DEALLOCATE PREPARE s;

INSERT INTO mnt_system_setting (setting_key, setting_value, data_type, description)
SELECT 'site_courses_bg', 'assets/images/site/course-bg.jpg', 'string', 'Website Courses: background image path'
WHERE NOT EXISTS (SELECT 1 FROM mnt_system_setting WHERE setting_key = 'site_courses_bg');

SELECT 'v24_ok' AS step,
       (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='mnt_course' AND COLUMN_NAME='photo_path') AS course_photo_col,
       (SELECT COUNT(*) FROM mnt_system_setting WHERE setting_key='site_courses_bg') AS bg_setting;

-- ============================================================
-- v25 — Website Content: Facilities (V5.53)
-- ============================================================
INSERT INTO mnt_system_setting (setting_key, setting_value, data_type, description)
SELECT 'site_facilities_title', 'World-Class Training Facilities', 'string', 'Website Facilities: title'
WHERE NOT EXISTS (SELECT 1 FROM mnt_system_setting WHERE setting_key = 'site_facilities_title');

INSERT INTO mnt_system_setting (setting_key, setting_value, data_type, description)
SELECT 'site_facilities_intro', 'Train in an environment built for seafarers — modern classrooms, hands-on simulators, and safety equipment that mirror the realities of life at sea.', 'string', 'Website Facilities: intro'
WHERE NOT EXISTS (SELECT 1 FROM mnt_system_setting WHERE setting_key = 'site_facilities_intro');

INSERT INTO mnt_system_setting (setting_key, setting_value, data_type, description)
SELECT 'site_facilities_features', "Classrooms: Modern, air-conditioned lecture rooms with audio-visual aids.\nSimulators: State-of-the-art bridge, engine-room and cargo simulators.\nFire & Safety: Dedicated fire-fighting and survival training grounds.\nEquipment: Up-to-date onboard technology and life-saving appliances.\nLibrary & Study: Reference library and quiet study areas.\nAmenities: Convenient facilities for trainees and assessors.", 'string', 'Website Facilities: feature cards (one per line, Title: desc)'
WHERE NOT EXISTS (SELECT 1 FROM mnt_system_setting WHERE setting_key = 'site_facilities_features');

SELECT 'v25_ok' AS step, COUNT(*) AS facilities_settings FROM mnt_system_setting WHERE setting_key LIKE 'site_facilities\_%';

-- ============================================================
-- v26 — Website Content: Contact (V5.58)
-- ============================================================
INSERT INTO mnt_system_setting (setting_key, setting_value, data_type, description)
SELECT 'site_contact_intro', 'Questions about courses, schedules, fees, or enrollment? Our admissions team is ready to help — reach us through any channel below, or send an inquiry and we will get back to you within one business day.', 'string', 'Website Contact: intro'
WHERE NOT EXISTS (SELECT 1 FROM mnt_system_setting WHERE setting_key = 'site_contact_intro');

INSERT INTO mnt_system_setting (setting_key, setting_value, data_type, description)
SELECT 'site_contact_hours', 'Monday – Friday: 8:00 AM – 5:00 PM
Saturday: 8:00 AM – 12:00 PM
Sunday: Closed', 'string', 'Website Contact: business hours (one per line)'
WHERE NOT EXISTS (SELECT 1 FROM mnt_system_setting WHERE setting_key = 'site_contact_hours');

INSERT INTO mnt_system_setting (setting_key, setting_value, data_type, description)
SELECT 'site_contact_map_query', 'YMCA of Manila Building, 350 Antonio Villegas St, Ermita, Manila', 'string', 'Website Contact: address used for the Get-Directions link'
WHERE NOT EXISTS (SELECT 1 FROM mnt_system_setting WHERE setting_key = 'site_contact_map_query');

INSERT INTO mnt_system_setting (setting_key, setting_value, data_type, description)
SELECT 'site_contact_note', 'Walk-in inquiries are welcome at our office. Bring a valid ID for on-site enrollment.', 'string', 'Website Contact: small note under contact details'
WHERE NOT EXISTS (SELECT 1 FROM mnt_system_setting WHERE setting_key = 'site_contact_note');

SELECT 'v26_ok' AS step, COUNT(*) AS contact_settings FROM mnt_system_setting WHERE setting_key LIKE 'site_contact\_%';

-- ============================================================
-- v27 — Training Center Announcements (V5.60)
-- Table + demo rows + news-section settings
-- ============================================================
CREATE TABLE IF NOT EXISTS mnt_announcement (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    title VARCHAR(200) NOT NULL,
    message TEXT NULL,
    announcement_date DATE NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NULL ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_announce_active (is_active, announcement_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO mnt_announcement (title, message, announcement_date, is_active)
SELECT 'Class Suspension — Friday Afternoon Batch', 'The Friday afternoon Basic Training (BT) session on the training ground is cancelled due to scheduled equipment maintenance. Affected trainees will be re-slotted to the Saturday morning make-up class.', '2026-08-21', 1
WHERE NOT EXISTS (SELECT 1 FROM mnt_announcement WHERE title LIKE 'Class Suspension%');

INSERT INTO mnt_announcement (title, message, announcement_date, is_active)
SELECT 'Training Center Closed — August 24 (National Holiday)', 'The training center and office will be closed on Monday, August 24, 2026 (National Heroes Day). Classes resume on Tuesday, August 25. Scheduled enrollments on that day will be processed on the next working day.', '2026-08-24', 1
WHERE NOT EXISTS (SELECT 1 FROM mnt_announcement WHERE title LIKE 'Training Center Closed%');

INSERT INTO mnt_announcement (title, message, announcement_date, is_active)
SELECT 'FF Batch 12 — Venue Change', 'Fire Fighting & Fire Prevention Batch 12 (September) will now be held at the Fire Training Ground instead of the Main Training Hall. Please report directly to the training ground on the first day.', '2026-09-07', 1
WHERE NOT EXISTS (SELECT 1 FROM mnt_announcement WHERE title LIKE 'FF Batch 12%');

INSERT INTO mnt_system_setting (setting_key, setting_value, data_type, description)
SELECT 'site_news_announce_title', 'Training Center Announcements', 'string', 'Website News: announcements row title'
WHERE NOT EXISTS (SELECT 1 FROM mnt_system_setting WHERE setting_key = 'site_news_announce_title');

INSERT INTO mnt_system_setting (setting_key, setting_value, data_type, description)
SELECT 'site_news_announce_intro', 'Official notices on class schedules, cancellations, and training-center operations — maintained from Admissions Settings.', 'string', 'Website News: announcements intro'
WHERE NOT EXISTS (SELECT 1 FROM mnt_system_setting WHERE setting_key = 'site_news_announce_intro');

SELECT 'v27_ok' AS step, COUNT(*) AS announcements FROM mnt_announcement;

-- ============================================================
-- v28 — Affiliated Companies + Contact map (V5.61)
-- Table + demo rows for the website Contact section
-- ============================================================
CREATE TABLE IF NOT EXISTS mnt_affiliate (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    name VARCHAR(200) NOT NULL,
    logo_path VARCHAR(255) NULL,
    website_url VARCHAR(500) NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    sort_order INT NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NULL ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_affiliate_active (is_active, sort_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO mnt_affiliate (name, logo_path, website_url, is_active, sort_order)
SELECT 'MARINA — Maritime Industry Authority', 'assets/images/site/affiliates/marina-placeholder.svg', 'https://marina.gov.ph', 1, 1
WHERE NOT EXISTS (SELECT 1 FROM mnt_affiliate WHERE website_url = 'https://marina.gov.ph');

INSERT INTO mnt_affiliate (name, logo_path, website_url, is_active, sort_order)
SELECT 'International Maritime Organization (IMO)', 'assets/images/site/affiliates/imo-placeholder.svg', 'https://www.imo.org', 1, 2
WHERE NOT EXISTS (SELECT 1 FROM mnt_affiliate WHERE website_url = 'https://www.imo.org');

INSERT INTO mnt_affiliate (name, logo_path, website_url, is_active, sort_order)
SELECT 'Philippine Coast Guard (PCG)', 'assets/images/site/affiliates/pcg-placeholder.svg', 'https://coastguard.gov.ph', 1, 3
WHERE NOT EXISTS (SELECT 1 FROM mnt_affiliate WHERE website_url = 'https://coastguard.gov.ph');

INSERT INTO mnt_affiliate (name, logo_path, website_url, is_active, sort_order)
SELECT 'ISO — International Organization for Standardization', 'assets/images/site/affiliates/iso-placeholder.svg', 'https://www.iso.org', 1, 4
WHERE NOT EXISTS (SELECT 1 FROM mnt_affiliate WHERE website_url = 'https://www.iso.org');

INSERT INTO mnt_system_setting (setting_key, setting_value, data_type, description)
SELECT 'site_contact_affiliates_title', 'Our Affiliations & Partners', 'string', 'Website Contact: affiliated companies row title'
WHERE NOT EXISTS (SELECT 1 FROM mnt_system_setting WHERE setting_key = 'site_contact_affiliates_title');

INSERT INTO mnt_system_setting (setting_key, setting_value, data_type, description)
SELECT 'site_contact_affiliates_intro', 'We are accredited, recognized and partnered with the following organizations.', 'string', 'Website Contact: affiliated companies intro'
WHERE NOT EXISTS (SELECT 1 FROM mnt_system_setting WHERE setting_key = 'site_contact_affiliates_intro');

SELECT 'v28_ok' AS step, COUNT(*) AS affiliates FROM mnt_affiliate;

-- ============================================================
-- v29 — Contact rows: info line + Affiliations vs Partners (V5.66)
--   • mnt_affiliate gets a `type` column ('affiliation' | 'partner')
--   • new settings for Training Site / Facebook / Instagram
--   • demo PARTNER rows (replace with real partners)
-- ============================================================
SET @has_type := (SELECT COUNT(*) FROM information_schema.COLUMNS
                  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'mnt_affiliate' AND COLUMN_NAME = 'type');
SET @sql := IF(@has_type = 0,
  'ALTER TABLE mnt_affiliate ADD COLUMN type VARCHAR(20) NOT NULL DEFAULT ''affiliation'' AFTER website_url',
  'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

UPDATE mnt_affiliate SET type = 'affiliation' WHERE type IS NULL OR type = '';

INSERT INTO mnt_affiliate (name, logo_path, website_url, type, is_active, sort_order)
SELECT 'Sample Manning Agency (Partner)', 'assets/images/site/affiliates/partner-manning.svg', 'https://example.com/manning', 'partner', 1, 1
WHERE NOT EXISTS (SELECT 1 FROM mnt_affiliate WHERE type = 'partner' AND name LIKE 'Sample Manning Agency%');

INSERT INTO mnt_affiliate (name, logo_path, website_url, type, is_active, sort_order)
SELECT 'Sample Shipping Line (Partner)', 'assets/images/site/affiliates/partner-shipping.svg', 'https://example.com/shipping', 'partner', 1, 2
WHERE NOT EXISTS (SELECT 1 FROM mnt_affiliate WHERE type = 'partner' AND name LIKE 'Sample Shipping Line%');

INSERT INTO mnt_affiliate (name, logo_path, website_url, type, is_active, sort_order)
SELECT 'Sample Crewing Services (Partner)', 'assets/images/site/affiliates/partner-crewing.svg', 'https://example.com/crewing', 'partner', 1, 3
WHERE NOT EXISTS (SELECT 1 FROM mnt_affiliate WHERE type = 'partner' AND name LIKE 'Sample Crewing Services%');

INSERT INTO mnt_system_setting (setting_key, setting_value, data_type, description)
SELECT 'site_contact_training_site', 'USMCI Training Grounds, Manila (subject to update)', 'string', 'Website Contact: training site address'
WHERE NOT EXISTS (SELECT 1 FROM mnt_system_setting WHERE setting_key = 'site_contact_training_site');

INSERT INTO mnt_system_setting (setting_key, setting_value, data_type, description)
SELECT 'site_contact_facebook', 'https://www.facebook.com/', 'string', 'Website Contact: Facebook page URL'
WHERE NOT EXISTS (SELECT 1 FROM mnt_system_setting WHERE setting_key = 'site_contact_facebook');

INSERT INTO mnt_system_setting (setting_key, setting_value, data_type, description)
SELECT 'site_contact_instagram', 'https://www.instagram.com/', 'string', 'Website Contact: Instagram profile URL'
WHERE NOT EXISTS (SELECT 1 FROM mnt_system_setting WHERE setting_key = 'site_contact_instagram');

SELECT 'v29_ok' AS step, COUNT(*) AS partners FROM mnt_affiliate WHERE type = 'partner';

-- rename the old combined title now that Partners are a separate row
UPDATE mnt_system_setting SET setting_value = 'Our Affiliations', updated_at = NOW()
WHERE setting_key = 'site_contact_affiliates_title' AND setting_value = 'Our Affiliations & Partners';

-- ============================================================
-- v30 — Contact info cards maintenance (V5.68)
-- Table + seed for the 7 single-row contact cards
-- ============================================================
CREATE TABLE IF NOT EXISTS mnt_contact_info (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    icon VARCHAR(10) NOT NULL DEFAULT '📍',
    label VARCHAR(80) NOT NULL,
    value VARCHAR(255) NOT NULL,
    href VARCHAR(500) NULL,
    cta VARCHAR(80) NULL,
    external TINYINT(1) NOT NULL DEFAULT 0,
    sort_order INT NOT NULL DEFAULT 0,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NULL ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_contact_info (is_active, sort_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO mnt_contact_info (icon, label, value, href, cta, external, sort_order, is_active)
SELECT '📍','Main Office','G/F YMCA of Manila Bldg, 350 Antonio Villegas St, Ermita, Manila', NULL, NULL, 0, 1, 1
WHERE NOT EXISTS (SELECT 1 FROM mnt_contact_info WHERE label = 'Main Office');

INSERT INTO mnt_contact_info (icon, label, value, href, cta, external, sort_order, is_active)
SELECT '🏗️','Training Site','USMCI Training Grounds, Manila', NULL, NULL, 0, 2, 1
WHERE NOT EXISTS (SELECT 1 FROM mnt_contact_info WHERE label = 'Training Site');

INSERT INTO mnt_contact_info (icon, label, value, href, cta, external, sort_order, is_active)
SELECT '📘','Facebook','Follow us on Facebook', 'https://www.facebook.com/', 'Visit Page →', 1, 3, 1
WHERE NOT EXISTS (SELECT 1 FROM mnt_contact_info WHERE label = 'Facebook');

INSERT INTO mnt_contact_info (icon, label, value, href, cta, external, sort_order, is_active)
SELECT '📸','Instagram','Follow us on Instagram', 'https://www.instagram.com/', 'Visit Profile →', 1, 4, 1
WHERE NOT EXISTS (SELECT 1 FROM mnt_contact_info WHERE label = 'Instagram');

INSERT INTO mnt_contact_info (icon, label, value, href, cta, external, sort_order, is_active)
SELECT '📱','Mobile Number','09971201553', NULL, NULL, 0, 5, 1
WHERE NOT EXISTS (SELECT 1 FROM mnt_contact_info WHERE label = 'Mobile Number');

INSERT INTO mnt_contact_info (icon, label, value, href, cta, external, sort_order, is_active)
SELECT '☎️','Telephone','8241-0881', NULL, NULL, 0, 6, 1
WHERE NOT EXISTS (SELECT 1 FROM mnt_contact_info WHERE label = 'Telephone');

INSERT INTO mnt_contact_info (icon, label, value, href, cta, external, sort_order, is_active)
SELECT '✉️','Email','usmci2010@gmail.com', NULL, NULL, 0, 7, 1
WHERE NOT EXISTS (SELECT 1 FROM mnt_contact_info WHERE label = 'Email');

SELECT 'v30_ok' AS step, COUNT(*) AS contact_info FROM mnt_contact_info;
