-- ============================================================
-- USMCI-TMS — Schema v13: Audit log (ensures base table exists)
-- ------------------------------------------------------------
-- The base schema already ships an audit_log table (actor_type,
-- actor_id, action, table_name, record_id, new_values, ...).
-- v13 only guarantees it exists for installs that skipped the
-- base dump. SAFE / IDEMPOTENT / portable.
-- ============================================================
USE enrollsys;

CREATE TABLE IF NOT EXISTS audit_log (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    actor_type ENUM('user','applicant','system') NOT NULL DEFAULT 'user',
    actor_id BIGINT UNSIGNED DEFAULT NULL,
    action VARCHAR(100) NOT NULL,
    table_name VARCHAR(100) DEFAULT NULL,
    record_id BIGINT UNSIGNED DEFAULT NULL,
    old_values LONGTEXT DEFAULT NULL,
    new_values LONGTEXT DEFAULT NULL,
    ip_address VARCHAR(45) DEFAULT NULL,
    user_agent TEXT DEFAULT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_audit_table (table_name),
    INDEX idx_audit_created (created_at),
    INDEX idx_audit_actor (actor_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SELECT 'v13_ok' AS step, COUNT(*) AS has_audit_table FROM information_schema.TABLES
WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='audit_log';
