USE enrollsys;

-- ============================================================
-- USMCI-TMS — Local schema update / fix script
-- ------------------------------------------------------------
-- Fixes the gaps between enrollsys (2).sql (the dump you
-- uploaded) and what the code expects:
--
--   A. mnt_inquiry_status     (missing table — the queue's
--                              status badges, reply/convert,
--                              summary counts all need it)
--   B. applicant_invitation   (missing table — the invitation
--                              link → register.php flow)
--   C. sys_user seed accounts (the dump has ZERO staff users,
--                              so login could never work)
--   D. inquiry.status_id FK + useful indexes (optional)
--   E. Verify queries
--
-- HOW TO RUN:
--   1. Open phpMyAdmin → select the `enrollsys` database
--   2. Click the "SQL" tab
--   3. Paste ALL of this and click Go
--      (or: mysql -u root enrollsys < schema_update.sql)
--
-- SAFE TO RE-RUN: every statement is idempotent (IF NOT EXISTS
-- / INSERT IGNORE / guarded ALTERs). No data is deleted.
-- ============================================================

-- ============================================================
-- A. mnt_inquiry_status  (status lookup for inquiry.status_id)
-- ============================================================

CREATE TABLE IF NOT EXISTS mnt_inquiry_status (
    id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    code        VARCHAR(30) NOT NULL UNIQUE,
    label       VARCHAR(100) NOT NULL,
    sort_order  INT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO mnt_inquiry_status (code, label, sort_order) VALUES
('NEW',       'New',                1),
('REPLIED',   'Replied',            2),
('INVITED',   'Invited to Enroll',  3),
('CONVERTED', 'Account Created',    4),
('CLOSED',    'Closed',             5);

-- Existing inquiries (all 11 have status_id = NULL) → NEW
UPDATE inquiry
SET status_id = (SELECT id FROM mnt_inquiry_status WHERE code = 'NEW')
WHERE status_id IS NULL;

-- ============================================================
-- B. applicant_invitation  (single-use registration tokens)
-- ------------------------------------------------------------
-- The referenced tables (inquiry, applicant, sys_user) already
-- exist in the dump, so all real FKs can be created right here.
-- sys_user is created by the dump (it's just empty until Part C).
-- ============================================================

CREATE TABLE IF NOT EXISTS applicant_invitation (
    id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    inquiry_id      BIGINT UNSIGNED NOT NULL,
    applicant_id    BIGINT UNSIGNED NULL,
    token_hash      CHAR(64) NOT NULL UNIQUE,
    email           VARCHAR(150) NOT NULL,
    expires_at      DATETIME NOT NULL,
    used_at         DATETIME NULL,
    created_by      BIGINT UNSIGNED NOT NULL,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (inquiry_id)   REFERENCES inquiry(id)   ON DELETE CASCADE,
    FOREIGN KEY (applicant_id) REFERENCES applicant(id) ON DELETE SET NULL,
    FOREIGN KEY (created_by)   REFERENCES sys_user(id),

    INDEX idx_invitation_lookup (token_hash, used_at, expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- C. Seed staff accounts  (so login.php works)
-- ------------------------------------------------------------
--   admin      / Admin@1234
--   admissions / Admissions@1234
-- Hashes are real bcrypt (password_verify() compatible).
-- Safe to re-run: resets the passwords to the values above.
-- ============================================================

INSERT INTO sys_user
    (role_id, username, email, password_hash, full_name, mobile_no, status_id, created_at)
VALUES
    (1, 'admin',
     'admin@usmci.edu.ph',
     '$2y$12$r4r1xG.I4vEsFdNzSxjKDOfD6ncD6FR4ruSFAdFCtOPIyQPTeaXM2',
     'System Administrator', '09171234567', 1, NOW()),
    (2, 'admissions',
     'admissions@usmci.edu.ph',
     '$2y$12$cwXIxE1E5iqS/e3YIj5R2uuyDXKgcbdivAjcB7qEgEmHWDCYNH/TG',
     'Admissions Officer', '09179876543', 1, NOW())
ON DUPLICATE KEY UPDATE
    password_hash = VALUES(password_hash),
    role_id       = VALUES(role_id),
    status_id     = VALUES(status_id);

-- ============================================================
-- D. (Optional but recommended) inquiry.status_id FK + indexes
-- ------------------------------------------------------------
-- Guards via information_schema so this is safe to re-run.
-- ============================================================

-- FK: inquiry.status_id -> mnt_inquiry_status.id
SET @has_fk := (SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
                WHERE CONSTRAINT_SCHEMA = DATABASE()
                  AND TABLE_NAME = 'inquiry'
                  AND CONSTRAINT_NAME = 'fk_inquiry_status');
SET @sql := IF(@has_fk = 0,
    'ALTER TABLE inquiry ADD CONSTRAINT fk_inquiry_status FOREIGN KEY (status_id) REFERENCES mnt_inquiry_status(id)',
    'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- Index: status_id (speeds up status filters / counts)
SET @has_idx := (SELECT COUNT(*) FROM information_schema.STATISTICS
                 WHERE TABLE_SCHEMA = DATABASE()
                   AND TABLE_NAME = 'inquiry'
                   AND INDEX_NAME = 'idx_inquiry_status');
SET @sql := IF(@has_idx = 0,
    'ALTER TABLE inquiry ADD INDEX idx_inquiry_status (status_id)',
    'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- Index: created_at (speeds up date filter + sort)
SET @has_idx := (SELECT COUNT(*) FROM information_schema.STATISTICS
                 WHERE TABLE_SCHEMA = DATABASE()
                   AND TABLE_NAME = 'inquiry'
                   AND INDEX_NAME = 'idx_inquiry_created');
SET @sql := IF(@has_idx = 0,
    'ALTER TABLE inquiry ADD INDEX idx_inquiry_created (created_at)',
    'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- ============================================================
-- E. (Optional) wipe test data for a clean local slate
-- ------------------------------------------------------------
-- Only run this if you want to remove the 11 sample inquiries.
-- Keeps the INQ sequence at 12 so numbers don't repeat.
-- ============================================================

-- SET FOREIGN_KEY_CHECKS = 0;
-- TRUNCATE TABLE email_queue;
-- TRUNCATE TABLE inquiry_reply;
-- TRUNCATE TABLE inquiry_attachment;
-- TRUNCATE TABLE communication_log;
-- TRUNCATE TABLE applicant_invitation;
-- TRUNCATE TABLE inquiry;
-- SET FOREIGN_KEY_CHECKS = 1;

-- ============================================================
-- F. Verify everything
-- ============================================================

SELECT 'mnt_inquiry_status' AS part, COUNT(*) AS rows_ FROM mnt_inquiry_status
UNION ALL SELECT 'applicant_invitation', COUNT(*) FROM applicant_invitation
UNION ALL SELECT 'sys_user (staff accounts)', COUNT(*) FROM sys_user;

SELECT i.inquiry_no, s.label AS status_label
FROM inquiry i
LEFT JOIN mnt_inquiry_status s ON s.id = i.status_id
ORDER BY i.id
LIMIT 5;
