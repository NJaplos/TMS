-- ============================================================
-- USMCI-TMS — Schema v8: Venue maintenance
-- ------------------------------------------------------------
-- Adds mnt_venue (list of training venues) used by the
-- Training Batches form. Seeds 3 default venues.
-- SAFE / IDEMPOTENT / portable.
-- ============================================================
USE enrollsys;
CREATE TABLE IF NOT EXISTS mnt_venue (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    location VARCHAR(200) DEFAULT NULL,
    capacity INT NOT NULL DEFAULT 0,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Idempotent seed (portable): insert each default venue only when the
-- name is not present yet. INSERT IGNORE alone was not enough — the
-- table has no unique key on name, so re-running duplicated venues.
INSERT INTO mnt_venue (name, location, capacity, is_active)
SELECT 'USMCI Main Campus — Hall A', 'Main Campus, Zamboanga', 60, 1
WHERE NOT EXISTS (SELECT 1 FROM mnt_venue WHERE name = 'USMCI Main Campus — Hall A');
INSERT INTO mnt_venue (name, location, capacity, is_active)
SELECT 'USMCI Main Campus — Hall B', 'Main Campus, Zamboanga', 40, 1
WHERE NOT EXISTS (SELECT 1 FROM mnt_venue WHERE name = 'USMCI Main Campus — Hall B');
INSERT INTO mnt_venue (name, location, capacity, is_active)
SELECT 'Simulation Room', 'Main Campus, Zamboanga', 25, 1
WHERE NOT EXISTS (SELECT 1 FROM mnt_venue WHERE name = 'Simulation Room');

-- Repair: collapse duplicate venue names (keep lowest id per name).
DELETE v1 FROM mnt_venue v1
JOIN mnt_venue v2 ON v2.name = v1.name AND v2.id < v1.id;

SELECT 'mnt_venue' AS table_name, COUNT(*) AS rows_ FROM mnt_venue;
