-- ============================================================
-- USMCI-TMS — Schema v4: Trainee rank/position
-- ------------------------------------------------------------
-- Adds rank_position to applicant_profile so trainees can
-- record their maritime rank / position in their profile.
-- Additive only — safe to run, keeps existing data.
--
-- HOW TO RUN: phpMyAdmin -> SQL tab -> paste -> Go (auto-selects enrollsys)
-- ============================================================

USE enrollsys;


SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='applicant_profile' AND COLUMN_NAME='rank_position');
SET @s := IF(@c = 0, 'ALTER TABLE applicant_profile ADD COLUMN rank_position VARCHAR(100) NULL AFTER seafarer_id_no', 'SELECT 1');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- Verify
SHOW COLUMNS FROM applicant_profile LIKE 'rank_position';
