-- ============================================================
-- USMCI-TMS — Schema v3: Trainee dashboard support
-- ------------------------------------------------------------
-- Adds a photo column to applicant_profile so trainees can
-- upload or capture a profile photo (camera). Additive only —
-- your data is untouched.
--
-- HOW TO RUN: phpMyAdmin -> SQL tab -> paste -> Go (auto-selects enrollsys)
-- ============================================================

USE enrollsys;


SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA='enrollsys' AND TABLE_NAME='applicant_profile' AND COLUMN_NAME='photo_path');
SET @s := IF(@c = 0, 'ALTER TABLE applicant_profile ADD COLUMN photo_path VARCHAR(255) NULL AFTER relationship_id', 'SELECT 1');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- Verify
SHOW COLUMNS FROM applicant_profile LIKE 'photo_path';
