<?php
/*
|--------------------------------------------------------------------------
| USMCI Training Management System
|--------------------------------------------------------------------------
|
| Homepage Assembler
| Version : 1.1
| (boots bootstrap so head.php's <base href> is dynamic and the
|  project can be renamed without breaking relative links)
|
*/

require_once __DIR__ . '/config/bootstrap.php';

$page = [
    'title'       => 'USMCI Training Management System',
    'description' => 'Official website of USMCI Training Management System.',
    'bodyClass'   => 'homepage'
];
?>

<!DOCTYPE html>
<html lang="en">

<?php include 'includes/head.php'; ?>

<body class="<?= $page['bodyClass']; ?>">

    <!-- Navigation -->
    <?php include 'navbar/index.php'; ?>

    <main id="main-content">

        <!-- Hero -->
        <?php include 'sections/hero/index.php'; ?>

        <!-- About -->
        <?php
        if (file_exists('sections/about/index.php')) {
            include 'sections/about/index.php';
        }
        ?>

        <!-- Courses -->
        <?php
        if (file_exists('sections/courses/index.php')) {
            include 'sections/courses/index.php';
        }
        ?>

        <!-- Programs (legacy) -->
        <?php
        if (file_exists('sections/programs/index.php')) {
            include 'sections/programs/index.php';
        }
        ?>

        <!-- Facilities -->
        <?php
        if (file_exists('sections/facilities/index.php')) {
            include 'sections/facilities/index.php';
        }
        ?>

        <!-- Testimonials -->
        <?php
        if (file_exists('sections/testimonials/index.php')) {
            include 'sections/testimonials/index.php';
        }
        ?>

        <!-- News -->
        <?php
        if (file_exists('sections/news/index.php')) {
            include 'sections/news/index.php';
        }
        ?>

        <!-- Call To Action -->
        <?php
        if (file_exists('sections/cta/index.php')) {
            include 'sections/cta/index.php';
        }
        ?>

        <!-- Contact -->
        <?php
        if (file_exists('sections/contact/index.php')) {
            include 'sections/contact/index.php';
        }
        ?>

    </main>

    <?php include 'includes/footer.php'; ?>

    <?php include 'includes/scripts.php'; ?>

</body>

</html>
