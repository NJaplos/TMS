<?php
/**
 * ---------------------------------------------------------
 * USMCI-TMS
 * Staff Logout
 * File : logout.php
 * Version : 1.1
 *
 * 1.1: after signing out, return the user to the MAIN page
 * of the website (index.php), not the login page.
 * ---------------------------------------------------------
 */

declare(strict_types=1);

require_once __DIR__ . '/config/bootstrap.php';

logout_user();

header('Location: ' . base_url('index.php'));
exit;
