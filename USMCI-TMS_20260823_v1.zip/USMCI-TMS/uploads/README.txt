USMCI-TMS — uploads folder
============================
This folder holds user-uploaded files (trainee photos, documents,
certificate attachments).

IMPORTANT: These files are YOUR data — they are NOT included in the
build zip (only this README ships). Always BACK UP the whole uploads/
folder before replacing htdocs/USMCI-TMS, then restore it after
installing. Otherwise photos and attachments will appear "missing".
