/* ==========================================================
   USMCI-TMS — UNIFIED TOAST (UDS .c-toast component)
   ----------------------------------------------------------
   One toast system for the whole app (staff + trainee + queue).
   Uses the design-system .c-toast markup from
   assets/css/components/feedback/toast.css:
     - top-right stack, below the fixed navbar
     - white card, icon + title + message
     - colored left border by type (success/danger/warning/info)
     - animated progress bar synced to the 4s lifetime
   Every page calls window.usmciToast(message, type, title).
   ----------------------------------------------------------
   Usage:
     usmciToast("Batch deleted.", "success");
     usmciToast("Cannot delete — has enrollments.", "danger", "Blocked");
   Types: success | danger | error (alias) | warning | info | sending (alias)
   ========================================================== */
(function () {
    "use strict";

    var container = null;

    function getContainer() {
        if (container && document.body.contains(container)) return container;
        container = document.createElement("div");
        container.className = "c-toast-container";
        container.id = "usmciToastContainer";

        // Clear the fixed navbar (~--hero-top-offset) so toasts never
        // slide under it. Fall back to 86px if the var is missing.
        var offset = 86;
        var root = getComputedStyle(document.documentElement);
        if (root && root.getPropertyValue("--hero-top-offset")) {
            offset = parseFloat(root.getPropertyValue("--hero-top-offset")) || 86;
        }
        container.style.top = (offset + 14) + "px";

        document.body.appendChild(container);
        return container;
    }

    var ICONS = { success: "✅", danger: "❌", error: "❌", warning: "⚠️", info: "ℹ️", primary: "ℹ️", sending: "⏳" };
    var TITLES = { success: "Success", danger: "Error", error: "Error", warning: "Heads up", info: "Notice", primary: "Notice", sending: "Please wait…" };

    window.usmciToast = function (message, type, title) {
        type = type || "info";
        var cls = (type === "error") ? "danger" : type;      // error → danger
        if (cls === "sending") cls = "info";                  // sending → info

        var t = document.createElement("div");
        t.className = "c-toast c-toast--" + cls;
        t.setAttribute("role", "status");

        t.innerHTML =
            '<span class="c-toast__icon">' + (ICONS[type] || "ℹ️") + "</span>" +
            '<div class="c-toast__content">' +
                '<div class="c-toast__title">' + (title || TITLES[type] || "Notice") + "</div>" +
                '<div class="c-toast__message"></div>' +
            "</div>" +
            '<button type="button" class="c-toast__close" aria-label="Dismiss">&times;</button>' +
            '<span class="c-toast__progress"></span>';

        // Message is set via textContent — never innerHTML — so server
        // messages with quotes/HTML can't break the toast or inject.
        t.querySelector(".c-toast__message").textContent = message || "";

        // Progress bar lifetime matches the toast lifetime.
        var progress = t.querySelector(".c-toast__progress");
        progress.style.animationDuration = "4000ms";

        var box = getContainer();
        box.appendChild(t);

        var removed = false;
        function remove() {
            if (removed) return;
            removed = true;
            t.style.animation = "toastOut .3s ease forwards";
            setTimeout(function () {
                if (t.parentNode) t.parentNode.removeChild(t);
            }, 320);
        }

        t.querySelector(".c-toast__close").addEventListener("click", remove);
        setTimeout(remove, 4000);

        return t;
    };

    // Backwards-compatible shim used by older inline code.
    window.showToast = function (message, type, title) {
        return window.usmciToast(message, type, title);
    };
})();
