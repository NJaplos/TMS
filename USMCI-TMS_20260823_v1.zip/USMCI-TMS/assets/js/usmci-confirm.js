/* ==========================================================
   USMCI-TMS — UNIFIED CONFIRM MODAL (system modal, not native)
   ----------------------------------------------------------
   Replaces every window.confirm() with the app's own modal,
   styled with the portal-modal design system (navy head,
   body, pinned footer with Cancel / Confirm).
   Returns a Promise<boolean>.
   ----------------------------------------------------------
   Usage:
     const ok = await usmciConfirm({
       title: "Void payment?",
       message: "This voids 2 official receipt(s)…",
       confirmText: "Yes, Void",
       danger: true
     });
     if (!ok) return;
   ---------------------------------------------------------- */
(function () {
    "use strict";

    var overlay = null;

    function build() {
        overlay = document.createElement("div");
        overlay.className = "portal-modal usmci-confirm";
        overlay.id = "usmciConfirm";
        overlay.style.zIndex = "9999998";
        overlay.innerHTML =
            '<div class="portal-modal__box usmci-confirm__box">' +
                '<div class="portal-modal__head">' +
                    '<h3 id="usmciConfirmTitle"></h3>' +
                    '<button type="button" class="portal-modal__close" id="usmciConfirmClose" aria-label="Close">&times;</button>' +
                "</div>" +
                '<div class="portal-modal__body">' +
                    '<div class="usmci-confirm__msg" id="usmciConfirmMsg"></div>' +
                "</div>" +
                '<div class="portal-modal__foot">' +
                    '<button type="button" class="btn-secondary" id="usmciConfirmCancel"></button>' +
                    '<button type="button" class="btn-primary" id="usmciConfirmOk"></button>' +
                "</div>" +
            "</div>";
        document.body.appendChild(overlay);
    }

    function close() {
        if (overlay) overlay.style.display = "none";
    }

    /* Prompt variant: like usmciConfirm but includes a textarea.
       Resolves { ok: boolean, value: string } — value is the
       textarea content (trimmed) when ok, or "" when cancelled. */
    window.usmciPrompt = function (opts) {
        opts = opts || {};
        if (!overlay || !document.body.contains(overlay)) build();

        var titleEl = document.getElementById("usmciConfirmTitle");
        var msgEl   = document.getElementById("usmciConfirmMsg");
        var okBtn   = document.getElementById("usmciConfirmOk");
        var cancelBtn = document.getElementById("usmciConfirmCancel");
        var closeBtn  = document.getElementById("usmciConfirmClose");

        titleEl.textContent = opts.title || "Are you sure?";
        msgEl.innerHTML = "";
        var p = document.createElement("p");
        p.textContent = opts.message || "";
        msgEl.appendChild(p);
        if (opts.label) {
            var lb = document.createElement("label");
            lb.textContent = opts.label;
            lb.style.cssText = "display:block;font-size:.78rem;font-weight:700;color:#334155;margin:10px 0 6px;";
            var ta = document.createElement("textarea");
            ta.rows = 3;
            ta.style.cssText = "width:100%;padding:10px 12px;border:1px solid #CBD5E1;border-radius:10px;font-family:inherit;font-size:.9rem;color:#334155;resize:vertical;";
            ta.placeholder = opts.placeholder || "";
            if (opts.value) ta.value = opts.value;
            msgEl.appendChild(lb);
            msgEl.appendChild(ta);
        }

        okBtn.textContent = opts.confirmText || "Confirm";
        cancelBtn.textContent = opts.cancelText || "Cancel";
        okBtn.className = "btn-primary" + (opts.danger ? " usmci-confirm__ok--danger" : "");
        if (opts.danger) { okBtn.style.background = "#B91C1C"; okBtn.style.borderColor = "#B91C1C"; }
        else { okBtn.style.background = ""; okBtn.style.borderColor = ""; }

        overlay.style.display = "flex";

        return new Promise(function (resolve) {
            function done(val) { close(); cleanup(); resolve(val); }
            function cleanup() {
                okBtn.removeEventListener("click", onOk);
                cancelBtn.removeEventListener("click", onCancel);
                closeBtn.removeEventListener("click", onCancel);
                overlay.removeEventListener("click", onOverlay);
                document.removeEventListener("keydown", onKey);
            }
            function onOk() {
                var ta = msgEl.querySelector("textarea");
                done({ ok: true, value: ta ? ta.value.trim() : "" });
            }
            function onCancel() { done({ ok: false, value: "" }); }
            function onOverlay(e) { if (e.target === overlay) done({ ok: false, value: "" }); }
            function onKey(e) { if (e.key === "Escape") done({ ok: false, value: "" }); }

            okBtn.addEventListener("click", onOk);
            cancelBtn.addEventListener("click", onCancel);
            closeBtn.addEventListener("click", onCancel);
            overlay.addEventListener("click", onOverlay);
            document.addEventListener("keydown", onKey);
            setTimeout(function () { var ta = msgEl.querySelector("textarea"); if (ta) ta.focus(); else okBtn.focus(); }, 50);
        });
    };

    window.usmciConfirm = function (opts) {
        opts = opts || {};
        if (!overlay || !document.body.contains(overlay)) build();

        var titleEl = document.getElementById("usmciConfirmTitle");
        var msgEl   = document.getElementById("usmciConfirmMsg");
        var okBtn   = document.getElementById("usmciConfirmOk");
        var cancelBtn = document.getElementById("usmciConfirmCancel");
        var closeBtn  = document.getElementById("usmciConfirmClose");

        titleEl.textContent = opts.title || "Are you sure?";
        msgEl.innerHTML = "";   // message built from nodes — never raw HTML
        var p = document.createElement("p");
        p.textContent = opts.message || "Continue?";
        msgEl.appendChild(p);

        okBtn.textContent = opts.confirmText || "Confirm";
        cancelBtn.textContent = opts.cancelText || "Cancel";

        // Danger variant → red confirm button
        okBtn.className = "btn-primary" + (opts.danger ? " usmci-confirm__ok--danger" : "");
        if (opts.danger) {
            okBtn.style.background = "#B91C1C";
            okBtn.style.borderColor = "#B91C1C";
        } else {
            okBtn.style.background = "";
            okBtn.style.borderColor = "";
        }

        overlay.style.display = "flex";

        return new Promise(function (resolve) {
            function done(val) {
                close();     // hide the modal (display:none)
                cleanup();
                resolve(val);
            }
            function cleanup() {
                okBtn.removeEventListener("click", onOk);
                cancelBtn.removeEventListener("click", onCancel);
                closeBtn.removeEventListener("click", onCancel);
                overlay.removeEventListener("click", onOverlay);
                document.removeEventListener("keydown", onKey);
            }
            function onOk() { done(true); }
            function onCancel() { done(false); }
            function onOverlay(e) { if (e.target === overlay) done(false); }
            function onKey(e) { if (e.key === "Escape") done(false); }

            okBtn.addEventListener("click", onOk);
            cancelBtn.addEventListener("click", onCancel);
            closeBtn.addEventListener("click", onCancel);
            overlay.addEventListener("click", onOverlay);
            document.addEventListener("keydown", onKey);

            // Focus the primary action
            setTimeout(function () { okBtn.focus(); }, 50);
        });
    };
})();
